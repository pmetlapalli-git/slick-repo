/* 
 * @(#) ACJDemoApp.java 1.1 04/01/98
 * 
 * Copyright (c) 1997-2000 Actuate. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of 
 * Actuate. ("Confidential Information").  You shall not 
 * disclose such Confidential Information and shall use it only in 
 * accordance with the terms of the license agreement you entered into 
 * with Actuate. 
 * 
 * ACTUATE MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT 
 * NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. ACTUATE SHALL NOT BE 
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, 
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. 
 * 
 * CopyrightVersion 1.1 
 * 
 */

import java.awt.*;
import java.io.*;
import java.util.*;
import java.text.*;
import java.applet.*;
import java.awt.event.*;
import javax.swing.*;

import com.actuate.ereport.engine.*;
import com.actuate.ereport.designer.*;
import com.actuate.ereport.datasrcmgrs.appdatasrc.*;

/**
 * This is a simple demo application that instantiates ACJEngine.
 * It uses its own sample data ( Ex: refer to CSVSource.txt file) as data source.
 *
 * This demo shows the following
 *   1. How to instantiate the ACJEngine
 *   2. How to create the table from the test data
 *   3. How register tables using AppDataSrc.
 *
 */
public class ACJDemoApp extends JApplet
{
	char delimiter = ',';
	char[] exclude = {'"', '\\'};
	SimpleDateFormat dtFormat = new SimpleDateFormat("MM/DD/YY");
	Vector categories, products, suppliers, customers, orders;
	Vector orderDetails, shippers, employees;
	IDataSource activeIDS = null;
	ACJEngine erw = null;
	ACJDesigner gui = null;

	private static final int DATEFORMAT     = 0;
	private static final int CATEGORY       = 1;
        private static final int CUSTOMER       = 2;
        private static final int EMPLOYEE       = 3;
        private static final int ORDER          = 4;
        private static final int ORDER_DETAIL   = 5;
        private static final int PRODUCT        = 6;
        private static final int SHIPPER        = 7;
        private static final int SUPPLIER       = 8;


	public static void main(String[] str)
	{
	   	ACJDemoApp appl = new ACJDemoApp();

        System.out.println("Actuate e.Report Designer - JAVA Edition " + com.actuate.ereport.common.Globals.getVersion());
        System.out.println("(Demo 1. Handling simple data structures)\n");

		try
		{
			/** 
			 * Read app data from data file on disk
			 * For the demo, how data is created in the app is not important
			 * The important part is how that data is converted into tables
			 * and sent to ACJEngine to generate reports
             */
            System.out.println("Constructing TableData from CSV source ...");
            appl.importData(str[0]);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		try
		{
			appl.createReport(str[1]);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	/**
	 * There may be a lot of other code in the app. The call to createReport
	 * is the method that actually instantiates ACJMain, generates the reports
	 * and displays it in the Preview window
	 **/
	public void createReport(String tfile) throws Exception
	{
	        JFrame f = new JFrame(); 
		f.getContentPane().setLayout(new BorderLayout());
		processSystem(f, tfile);
	        f.getContentPane().add(gui, "Center");
		f.pack();
		f.setTitle("Actuate e.Report Designer - JAVA Edition " + com.actuate.ereport.common.Globals.getVersion() + " for Java(TM)");
		f.setVisible(true);
	}

    public void setColumnProperties(AppDataHandler aDH, String sTable, String sColumn, String sRemarks)
    {
        // Write the remarks for columns ...
        //aDH.setRemarks(sTable, sColumn, sRemarks);
    }

    public void processSystem(JFrame mf, String tfile)
	{
        /**
         * Instantiate ACJEngine
         **/
        erw = new ACJEngine();

        /**
         * Instantiate ACJDesigner which contains the designer and the viewer
         **/
        gui = new ACJDesigner(mf, erw, true, true);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(gui, "Center");
        
        /**
         * Load report template from  a file.
         **/
        System.out.print("Loading template ... ");

        try
        {
            erw.readTemplate(tfile);
            gui.updateDesigner();
            gui.setTemplateFile(tfile);
            System.out.println("DONE");
        }
        catch (Exception ex)
        {
            //ex.printStackTrace();
            System.out.println("\n*** Error loading template ***");
        }

        /**
         * Instantiate a data source; in our case, we use a  Application DataSource.
         */
        AppDataHandler ds = new AppDataHandler();

        /**
         * Register the data source.
         */
        registerObjectsWithACJ(ds);

        /**
         * Optionally pass relationships between tables
         */
        //initializeRelationships(ds);

        try
        {
            /** 
             * PERFORM DataSource CONNECTIVITY AUTHENTICATION HERE
             * AND THROW AN EXCEPTION IF AUTHENTICATION FAILS
             */
            erw.setDataSource(ds);

            if (gui != null)
            {
                gui.addDataSource(ds);
                gui.setActiveDataSource(ds);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
	}

	/**
	 * This is the critical method in AppDataSrc interface that is used to
	 * pass application data to ACJEngine. The data being passed is in terms of vectors
	 * The getFieldVector for each data class is used to convert whatever structure
	 * the data is in into tables
	 **/
    public void registerObjectsWithACJ(AppDataHandler appInterface)
	{
        System.out.println("Registering tables ...");

        Vector fVector = new Vector();

        /**
         * Register each of the objects as a table with AppDataHandler
         **/
        appInterface.registerObjectAsTable(new Category(), "CATEGORIES", Category.getFieldVector());
        appInterface.registerObjectAsTable(new Customer(), "CUSTOMERS", Customer.getFieldVector());
        appInterface.registerObjectAsTable(new Employee(), "EMPLOYEES", Employee.getFieldVector());
        appInterface.registerObjectAsTable(new Order(), "ORDERS", Order.getFieldVector());
        appInterface.registerObjectAsTable(new OrderDetail(), "ORDER_DETAILS", OrderDetail.getFieldVector());
        appInterface.registerObjectAsTable(new Product(), "PRODUCTS", Product.getFieldVector());
        appInterface.registerObjectAsTable(new Shipper(), "SHIPPERS", Shipper.getFieldVector());
        appInterface.registerObjectAsTable(new Supplier(), "SUPPLIERS", Supplier.getFieldVector());


        /**
         * Since our DataSet is already available, we register it with AppDataHandler
         * right away. For you, this may not be true. The only requirement here is
         * you register your DataSet BEFORE calling ACJEngine.generateRepport()
         **/
        appInterface.registerDataSet("CATEGORIES", categories);
        appInterface.registerDataSet("CUSTOMERS", customers);
        appInterface.registerDataSet("EMPLOYEES", employees);
        appInterface.registerDataSet("ORDERS", orders);
        appInterface.registerDataSet("ORDER_DETAILS", orderDetails);
        appInterface.registerDataSet("PRODUCTS", products);
        appInterface.registerDataSet("SHIPPERS", shippers);
        appInterface.registerDataSet("SUPPLIERS", suppliers);
	}

    /**
     * Initializes all relationships between tables
     */
    private void initializeRelationships(AppDataHandler adh)
    {
        Vector vR = new Vector();

        vR.addElement("SUPPLIERS.SUPPLIERID - PRODUCTS.SUPPLIERID, ONE_TO_MANY");
        vR.addElement("CATEGORIES.CATEGORYID - PRODUCTS.CATEGORYID, ONE_TO_MANY");
        vR.addElement("PRODUCTS.PRODUCTID - ORDER_DETAILS.PRODUCTID, ONE_TO_MANY");
        vR.addElement("EMPLOYEES.EMPLOYEEID - ORDERS.EMPLOYEEID, ONE_TO_MANY");
        vR.addElement("ORDERS.ORDERID - ORDER_DETAILS.ORDERID, ONE_TO_MANY");
        vR.addElement("CUSTOMERS.CUSTOMERID - ORDERS.CUSTOMERID, ONE_TO_MANY");
        vR.addElement("SHIPPERS.SHIPPERID - ORDERS.SHIPVIA, ONE_TO_MANY");

        adh.setRelations(vR);
    }


	/**
	 * Used by the demo app to read data from data file
	 **/
    private void importData(String fileName) throws Exception
	{
		LineNumberReader lineReader = null;
		lineReader = new LineNumberReader(new FileReader(fileName));

		categories = new Vector();
		products = new Vector();
		suppliers = new Vector();
		customers = new Vector();
		orders = new Vector();
		shippers = new Vector();
		employees = new Vector();
		orderDetails = new Vector();

		int dataType = DATEFORMAT;

		String line = null;
                System.out.print("Loading ... ");
		while ( (line = lineReader.readLine()) != null)
		{
			if (line.equals("")) continue;
			else
			if (line.trim().equalsIgnoreCase("#Categories"))
			{
                System.out.print("Categories, ");
				dataType = CATEGORY; 
				continue;
			}
			else
			if (line.trim().equalsIgnoreCase("#Customers"))
			{
                System.out.print("Customers, ");
				dataType = CUSTOMER; 
				continue;
			}
			else
			if(line.trim().equalsIgnoreCase("#Employees"))
			{
                System.out.print("Employees, ");
				dataType = EMPLOYEE; 
				continue;
			}
			else
			if(line.trim().equalsIgnoreCase("#Orders"))
			{
                System.out.print("Orders, ");
				dataType = ORDER; 
				continue;
			}
			else
            if(line.trim().equalsIgnoreCase("#Order_Details"))
			{
                System.out.print("Order_Details, ");
                dataType = ORDER_DETAIL; 
				continue;
			}
			else
			if(line.trim().equalsIgnoreCase("#Products"))
			{
                System.out.print("Products, ");
				dataType = PRODUCT; 
				continue;
			}
			else
			if(line.trim().equalsIgnoreCase("#Shippers"))
			{
                System.out.print("Shippers, ");
				dataType = SHIPPER; 
				continue;
			}
                        else
			if (line.trim().equalsIgnoreCase("#Suppliers"))
			{
                System.out.print("Suppliers ... ");
				dataType = SUPPLIER; 
				continue;
			}
			try
			{
				switch(dataType)
				{
                    case DATEFORMAT         : dtFormat.applyPattern(line); break;
                    case CATEGORY           : categories.addElement(Category.parseCategory(line, delimiter, exclude, this, getToolkit())); break;
                    case CUSTOMER           : customers.addElement(Customer.parseCustomer(line, delimiter, exclude)); break;
                    case EMPLOYEE           : employees.addElement(Employee.parseEmployee(this, line, delimiter, exclude)); break;
                    case ORDER              : orders.addElement(Order.parseOrder(this, line, delimiter, exclude)); break;
                    case ORDER_DETAIL       : orderDetails.addElement(OrderDetail.parseOrderDetail(this, line, delimiter, exclude)); break;
                    case PRODUCT            : products.addElement(Product.parseProduct(this, line, delimiter, exclude)); break;
                    case SHIPPER            : shippers.addElement(Shipper.parseShipper(line, delimiter, exclude)); break;
                    case SUPPLIER           : suppliers.addElement(Supplier.parseSupplier(line, delimiter, exclude)); break;
				}
			}
			catch(Exception e)
			{
				System.out.println("ACJDemoApp : Error while importing data at line number " + lineReader.getLineNumber() + " \nThe error is " + e);
				e.printStackTrace();
				System.exit(0);
			}
		}
		lineReader.close();
        System.out.println("DONE");
	}


	/**
	 * Used by the demo app to read data from data file
	 **/
	public static void createTokens(String str, Vector collect, 
                char delimiter, char[] exclude)
	{
		char tempExcl = exclude[0];
		int n = 1;
		boolean lineEndFlag = false;
		int index = -1;
		int lastIndex = -1;

        while (!lineEndFlag)
		{
			lastIndex = index;
			index = giveIndex(str, delimiter, n, tempExcl);

            if (index == -1)
			{
                if (lastIndex != str.length() - 1)
				{
                    if (str.charAt(lastIndex + 1) != '"')
						collect.addElement(str.substring(lastIndex + 1, str.length()));
					else
						collect.addElement(str.substring(lastIndex + 2, str.length() - 1));
				}
				lineEndFlag = true; 
			}
			else
			{
                if (lastIndex + 1 <= index)
				{
                    if (str.charAt(lastIndex + 1) != '"')
						collect.addElement(str.substring(lastIndex + 1, index));
					else
						collect.addElement(str.substring(lastIndex + 2, index - 1));
				}
				else
				{
					collect.addElement("");
				}
				n++;
			}
		}  
	}

	public static int giveIndex(String str, char searchChar, int n, char exclude)
	{
		boolean excludeFlag = false;
        for (int i = 0; i < str.length(); i++)
		{
            if (str.charAt(i) == searchChar && !excludeFlag)
				n--;

            if (str.charAt(i) == exclude)
				excludeFlag = !excludeFlag;
			
            if (n == 0)
				return i;
		}
		return -1;
	}
			

	/**
	 * Used by the demo app to read data from data file
	 **/
	public static String constructFromTokens(Vector tokens)
	{
		String retval = "";

		for (int i = 0; i < tokens.size(); i++)
			retval += (String)tokens.elementAt(i);

		return retval;
	}


	public Object getCategory(Object name) throws Exception
	{ 
		return getObjectByName(categories, name); 
	}


    public Object getCustomer(Object name) throws Exception
	{
		return getObjectByName(customers, name);
	}


	public Object getProduct(Object name) throws Exception
	{
		return getObjectByName(products, name); 
	}


    public Object getEmployee(Object name) throws Exception
	{ 
        return getObjectByName(employees, name); 
	}


    public Object getOrder(Object name) throws Exception
	{ 
        return getObjectByName(orders, name); 
	}


    public Object getOrderDetails(Object name) throws Exception
	{ 
        return getObjectByName(orderDetails, name); 
	}


	public Object getSupplier(Object name) throws Exception
	{
		return getObjectByName(suppliers, name); 
	}


	private Object getObjectByName(Vector v, Object name) throws Exception
	{
		Object temp = null;

		for (int i = 0; i < v.size(); i++)
		{
			temp = v.elementAt(i);

            if (temp.equals(name)) return temp;
		}

		throw new RuntimeException("No element found with name " + name);
	}

	
	public Date parseDate(String str)
	{
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);

		try
		{
			return df.parse(str);
		}
		catch(Exception e)
		{
			return null;
		}
	}
}

