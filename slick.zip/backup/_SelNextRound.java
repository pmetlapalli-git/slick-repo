/*
* This code was automatically generated at 6:02:39 PM on Jan 4, 2001
* by weblogic.servlet.jsp.Jsp2Java -- do not edit.
*/

package ems._b2e._projects._selection;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

// User imports
import javax.naming.*; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import weblogic.rmi.Naming; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import java.math.BigDecimal; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import java.util.Date; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import weblogic.rmi.RemoteException; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.exception.SubmitException; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.exception.b2eException; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.Constant; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.DebugUtils; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.WeblogicUtilities; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.NumberUtilities; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.common.ServletUtils; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.common.util.IResourceBundle; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.common.util.ResourceManager; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.resources.projects.selection.ISelectionResourceConstants; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.common.util.LookupManager; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.XReferenceEntry; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.ems.application.IEMSAPI; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.common.WebConstant; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.common.JSPErrorHandler; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.gui.GUIUtils; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.gui.SelUtils; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.gui.IniRFQSummary; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.gui.IniGroupList; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.gui.IniGroupCurrentAndTargetPrice; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.gui.IniRFQInviteeList; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.builders.SelEventHBuilder; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.builders.SelBuilderManager; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.DBConstant; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.common.DateUtilities; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.common.StringUtils; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]
import b2emarkets.web.gui.URLCreator; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 13]


// built-in init parameters:
// boolean             _verbose -- wants debugging

// Well-known variables:
// JspWriter out                  -- to write to the browser
// HttpServletRequest  request    -- the request object.
// HttpServletResponse response   -- the response object.
// PageContext pageContext        -- the page context for this JSP
// HttpSession session            -- the session object for the client (if any)
// ServletContext application     -- The servlet (application) context
// ServletConfig config           -- The ServletConfig for this JSP
// Object page                    -- the instance of this page's implementation class (i.e., 'this')

/**
* This code was automatically generated at 6:02:39 PM on Jan 4, 2001
* by weblogic.servlet.jsp.Jsp2Java -- do not edit.
*
* Copyright (c) 2001 by BEA Systems, Inc. All Rights Reserved.
*/
public class _SelNextRound
extends
weblogic.servlet.jsp.JspBase
implements weblogic.servlet.jsp.StaleIndicator
{
    
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 15]
    private class Info //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 16]
    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 17]
        IEMSAPI api = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 18]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 19]
        String strEventId = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 20]
        // String strGroupId = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 21]
        Integer nEventId = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 22]
        IResourceBundle irb = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 23]
        String strReturnUrl = ""; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 24]
        Integer nUserId = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 25]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 26]
        IniGroupList groups = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 27]
        IniRFQInviteeList responders = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 28]
        IniRFQSummary event = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 29]
        IniGroupCurrentAndTargetPrice curTarPrices = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 30]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 31]
        String dueBackDate = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 32]
        String dueBackHour = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 33]
        String dueBackMin = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 34]
        String dueBackAMPM = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 35]
        String message = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 36]
    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 37]
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 38]
    /** //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 39]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 40]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 41]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 42]
    */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 43]
    private void handleHeaderInfo(javax.servlet.jsp.JspWriter writer, Info info) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 44]
    throws IOException //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 45]
    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 46]
        writer.println("<table BORDER=\"0\" CELLPADDING=\"2\" CELLSPACING=\"0\" WIDTH=\"70%\">"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 47]
        writer.println("<tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 48]
        writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> "+ info.irb.getString(ISelectionResourceConstants.SEL_ANA_RFQ_NAME) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 49]
        writer.println("<td align=\"left\" colspan = \"3\" class=\"pageHeaderValue\"> " + StringUtils.htmlSafeString(info.event.getName(-1)) + " </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 50]
        writer.println("</tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 51]
        writer.println("<tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 52]
        writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_ANA_RFQ_STATUS) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 53]
        XReferenceEntry ref = LookupManager.getEntryByName(info.api, "EVENT_STATUS_LOOKUP", info.event.getStatus()); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 54]
        writer.println("<td align=\"left\" class=\"pageHeaderValue\"> " + ref.getDescription() + " </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 55]
        writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_ANA_TIME_ZONE) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 56]
        ref = LookupManager.getEntryByName(info.api, "TIME_ZONE_LOOKUP", info.api.getDefaultTimeZoneName()); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 57]
        writer.println("<td align=\"left\" class=\"pageHeaderValue\"> " + ref.getDescription() + " </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 58]
        writer.println("</tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 59]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 60]
        writer.println("<tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 61]
        writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_ANA_RFQ_TYPE) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 62]
        ref = LookupManager.getEntryByName(info.api, "EVENT_STYLE_LOOKUP", info.event.getStyle()); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 63]
        writer.println("<td align=\"left\" class=\"pageHeaderValue\"> " + ref.getDescription() + " </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 64]
        ref = LookupManager.getEntryByName(info.api, "CURRENCY_LOOKUP", info.event.getCurrency()); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 65]
        writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_ANA_CURRENCY) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 66]
        writer.println("<td align=\"left\" class=\"pageHeaderValue\"> " + ref.getDescription() + " </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 67]
        writer.println("</tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 68]
        if (info.event.getDefaultNumberOfIntervals().intValue() > 1) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 69]
        { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 70]
            writer.println("<tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 71]
            writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_ANA_COST_OF_CAPITAL) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 72]
            BigDecimal bd = info.event.getCostOfCapital(); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 73]
            String strCostOfCapital = "&nbsp;"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 74]
            if (bd != null) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 75]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 76]
                strCostOfCapital = NumberUtilities.format(  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 77]
                info.api.getDefaultNumberFormatName(), bd.toString(), info.event.getPrecision() ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 78]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 79]
            writer.println("<td align=\"left\" class=\"pageHeaderValue\"> " + strCostOfCapital + "% </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 80]
            writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_ANA_INTERVALS) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 81]
            writer.println("<td align=\"left\" class=\"pageHeaderValue\"> " + SelUtils.formatIntervalHeading(info.api, info.event) + " </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 82]
            writer.println("</tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 83]
        } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 84]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 85]
        writer.println("<tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 86]
        writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_ANA_ROUND) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 87]
        writer.println("<td align=\"left\" class=\"pageHeaderValue\"> " + info.event.getRound().intValue() + " </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 88]
        writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> &nbsp; </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 89]
        writer.println("<td align=\"left\" class=\"pageHeaderValue\"> &nbsp; </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 90]
        writer.println("</tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 91]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 92]
        writer.println("<tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 93]
        writer.println("<td align=\"left\" class=\"pageHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_ANA_RFQ_DESC) + ": </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 94]
        writer.println("<td align=\"left\" colspan=3 class=\"pageHeaderValue\"> " + StringUtils.htmlSafeString(info.event.getDescription()) + " </td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 95]
        writer.println("</tr>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 96]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 97]
        writer.println("</table>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 98]
    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 99]
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 100]
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 101]
    /** //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 102]
    *  This method will initialze many of the variables which are used by other parts of the code. //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 103]
    *  It will only initialize the variable are used irrespective of METHOD (POST or GET). There are //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 104]
    *  individual methods defined for initializing for each method specific data. //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 105]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 106]
    */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 107]
    private String initializeCommon(javax.servlet.http.HttpServletRequest  request, //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 108]
    javax.servlet.http.HttpServletResponse response, //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 109]
    Info info //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 110]
    ) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 111]
    throws IOException //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 112]
    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 113]
        String returnStr = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 114]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 115]
        info.event = new IniRFQSummary(info.api, info.strEventId); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 116]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 117]
        if (!DBConstant.EVENT_STATUS__CLOSE.equalsIgnoreCase(info.event.getStatus())) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 118]
        { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 119]
            returnStr = "Internal Error, SelNextRound, the RFQ must be CLOSE (not " + info.event.getStatus() + ")";  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 120]
        } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 121]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 122]
        if (info.event.getRound().intValue() >= 4) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 123]
        { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 124]
            returnStr = "Internal Error, SelNextRound, the RFQ must be in round 3 or lower (not " + info.event.getRound() + ")";  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 125]
        } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 126]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 127]
        if (returnStr == null) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 128]
        { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 129]
            info.groups = new IniGroupList(info.api, info.strEventId); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 130]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 131]
            info.responders = new IniRFQInviteeList(info.api, info.strEventId);     //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 132]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 133]
            info.curTarPrices = new IniGroupCurrentAndTargetPrice(info.api, info.strEventId); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 134]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 135]
            info.strReturnUrl = "SelAnalysesPrivateBid.jsp" +  "?" + WebConstant.EVENTID + "=" + info.strEventId; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 136]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 137]
        } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 138]
        return returnStr; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 139]
    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 140]
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 141]
    /** //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 142]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 143]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 144]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 145]
    */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 146]
    private void handleGroupTable(javax.servlet.jsp.JspWriter writer, Info info) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 147]
    throws IOException //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 148]
    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 149]
        XReferenceEntry ref = LookupManager.getEntryByName(info.api, "CURRENCY_LOOKUP", info.event.getCurrency()); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 150]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 151]
        String rowClass = "tableEvenRow"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 152]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 153]
        writer.println("<table BORDER=\"0\" CELLPADDING=\"2\" CELLSPACING=\"1\" WIDTH=\"100%\">"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 154]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 155]
        writer.println("<tr class=\"tableHeaderBackground\">"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 156]
        writer.println("<td align=\"center\"><span class=\"tableHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_MON_GROUP_NAME) + " </SPAN></td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 157]
        writer.println("<td align=\"center\"><span class=\"tableHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_MON_CURRENT_COST) + "&nbsp;(" + ref.getShortName() + ")</SPAN></td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 158]
        writer.println("<td align=\"center\"><span class=\"tableHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_MON_TARGET_PRICE) + "&nbsp;(" + ref.getShortName() + ")</SPAN></td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 159]
        writer.println("<td align=\"center\"><span class=\"tableHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_NXTR_BAFO) + " </SPAN></td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 160]
        writer.println("<td align=\"center\"><span class=\"tableHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_NXTR_CHNG_TARGET_PRICE) + " </SPAN></td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 161]
        writer.println("</TR>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 162]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 163]
        for (int groupIndex = 0; groupIndex < info.groups.size(); groupIndex++) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 164]
        { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 165]
            // Bug # 4250: Don't show Completed or Withdrawn groups: //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 166]
            if (info.groups.getStatus(groupIndex).equals(DBConstant.GROUP_STATUS__COMPLETE) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 167]
            || info.groups.getStatus(groupIndex).equals(DBConstant.GROUP_STATUS__WITHDRAW)) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 168]
            continue; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 169]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 170]
            if (rowClass.equals("tableEvenRow")) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 171]
            rowClass = "tableOddRow"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 172]
            else //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 173]
            rowClass = "tableEvenRow"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 174]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 175]
            BigDecimal curPrice = info.curTarPrices.getCurrentPrice(info.curTarPrices.find(info.groups.getGroupId(groupIndex))); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 176]
            BigDecimal tarPrice = info.curTarPrices.getTargetPrice(info.curTarPrices.find(info.groups.getGroupId(groupIndex))); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 177]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 178]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 179]
            String currentPriceStr; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 180]
            if (curPrice != null) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 181]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 182]
                currentPriceStr = NumberUtilities.format(info.api.getDefaultNumberFormatName(), curPrice.toString(),  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 183]
                info.event.getPrecision()); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 184]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 185]
            else //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 186]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 187]
                currentPriceStr = WebConstant.SPACE; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 188]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 189]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 190]
            String targetPriceStr; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 191]
            if (tarPrice != null) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 192]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 193]
                targetPriceStr = NumberUtilities.format(info.api.getDefaultNumberFormatName(), tarPrice.toString(),  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 194]
                info.event.getPrecision()); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 195]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 196]
            else //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 197]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 198]
                targetPriceStr = WebConstant.SPACE; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 199]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 200]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 201]
            String strGroupId = "" + info.groups.getGroupId(groupIndex).intValue(); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 202]
            DebugUtils.printDebugMsg(" in next rnd, after setting value, strGroupId = " + strGroupId); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 203]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 204]
            String isCheckedStr = " "; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 205]
            if (info.groups.getIsBAFO(groupIndex)) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 206]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 207]
                isCheckedStr = "CHECKED"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 208]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 209]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 210]
            writer.println("<TR class=\"" + rowClass + "\">"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 211]
            writer.println("<TD align=\"left\"><span class=\"tableDataLabel\">&nbsp;" + StringUtils.htmlSafeString(info.groups.getName(groupIndex, -1)) + "</SPAN></TD>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 212]
            writer.println("<TD ALIGN='RIGHT'><span class=\"tableDataLabel\">" + currentPriceStr + "</SPAN></TD>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 213]
            writer.println("<TD ALIGN='RIGHT'><span class=\"tableDataLabel\">" + targetPriceStr + "</SPAN></TD>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 214]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 215]
            if (DBConstant.GROUP_STATUS__CLOSE.equalsIgnoreCase(info.groups.getStatus(groupIndex))) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 216]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 217]
                writer.println("<TD ALIGN=\"CENTER\"><span class=\"tableDataLabel\"><INPUT TYPE=\"CHECKBOX\" NAME=\"" +  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 218]
                info.groups.getGroupIdAsString(groupIndex) + "\" "+ isCheckedStr + "> </SPAN></TD>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 219]
            }  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 220]
            else  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 221]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 222]
                // THE GROUP MIGHT BE OPEN, EXTENDED, COMPLETED, WITHDRAWN //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 223]
                // SO DON'T ALLOW USER TO HAVE BAFO CHECKBOX //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 224]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 225]
                writer.println("<TD><span class=\"tableDataLabel\">&nbsp;</SPAN></TD>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 226]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 227]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 228]
            // writer.println("<TD ALIGN=\"CENTER\"><a href=SelNewTargetPrice.jsp?" +  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 229]
            // WebConstant.EVENTID + "=" + info.strEventId + "&" +  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 230]
            // WebConstant.GROUPID + "=" + info.strGroupId + ">" + "&" + //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 231]
            // "closeddate" + "=" + info.dueBackDate +  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 232]
            // writer.println("<TD ALIGN=\"CENTER\"><span class=\"tableDataLabel\"><a href=\"javascript:setFormsAction('" + info.strGroupId + "');\" >" + //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 233]
            // String tmp = "<TD ALIGN=\"CENTER\"><span class=\"tableDataLabel\"><a href=\"void(0);\" onClick=\"javascript:setFormsAction('123'); return false;\" >" + info.irb.getString(ISelectionResourceConstants.SEL_NXTR_NEW_TARGET_PRICE_LINK) + "</a></SPAN></TD>"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 234]
            String tmp = "<TD ALIGN=\"CENTER\"><span class=\"tableDataLabel\"><a href=\"javascript:setFormsAction('" + strGroupId + "');\" >" + info.irb.getString(ISelectionResourceConstants.SEL_NXTR_NEW_TARGET_PRICE_LINK) + "</a></SPAN></TD>"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 235]
            DebugUtils.printDebugMsg("in Sel next round, tmp = " + tmp ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 236]
            writer.println(tmp); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 237]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 238]
            writer.println("</TR>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 239]
        } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 240]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 241]
        writer.println("</TABLE>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 242]
    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 243]
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 244]
    /** //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 245]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 246]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 247]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 248]
    */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 249]
    private void handleInviteeTable(javax.servlet.jsp.JspWriter writer, Info info) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 250]
    throws IOException //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 251]
    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 252]
        String rowClass = "tableEvenRow"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 253]
        writer.println("<table BORDER=\"0\" CELLPADDING=\"2\" CELLSPACING=\"1\" WIDTH=\"100%\">"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 254]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 255]
        writer.println("<tr class=\"tableHeaderBackground\">"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 256]
        writer.println("<td align=\"center\"><SPAN CLASS=\"tableHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_NXTR_SUPPLIER_NAME) + " </SPAN></td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 257]
        writer.println("<td align=\"center\"><SPAN CLASS=\"tableHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_NXTR_CONTACT_NAME) + " </SPAN></td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 258]
        writer.println("<td align=\"center\"><SPAN CLASS=\"tableHeaderLabel\"> " + info.irb.getString(ISelectionResourceConstants.SEL_NXTR_CONTACT_PHONE) + " </SPAN></td>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 259]
        writer.println("</TR>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 260]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 261]
        for (int inviteeIndex = 0; inviteeIndex < info.responders.size(); inviteeIndex++) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 262]
        { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 263]
            if (rowClass.equals("tableEvenRow")) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 264]
            rowClass = "tableOddRow"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 265]
            else //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 266]
            rowClass = "tableEvenRow"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 267]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 268]
            writer.println("<tr class=\"" + rowClass + "\">"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 269]
            writer.println("<TD align=\"left\"><span class=\"tableDataLabel\">&nbsp;"+ StringUtils.htmlSafeString(info.responders.getPartnerName(inviteeIndex)) + "</SPAN></TD>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 270]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 271]
            writer.println("<TD align=\"left\"><span class=\"tableDataLabel\">&nbsp;"+ StringUtils.htmlSafeString(info.responders.getContactFirstName(inviteeIndex)) + //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 272]
            "&nbsp;" + StringUtils.htmlSafeString(info.responders.getContactLastName(inviteeIndex)) + "</SPAN></TD>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 273]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 274]
            writer.println("<TD align=\"left\"><span class=\"tableDataLabel\">&nbsp;"+ info.responders.getContactPhone(inviteeIndex) + "</SPAN></TD>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 275]
            writer.println("</TR>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 276]
        } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 277]
        writer.println("</TABLE>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 278]
    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 279]
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 280]
    /** //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 281]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 282]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 283]
    * //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 284]
    */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 285]
    private void handleBodyInfo(javax.servlet.jsp.JspWriter writer, //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 286]
    javax.servlet.http.HttpServletResponse response, //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 287]
    Info info) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 288]
    throws IOException //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 289]
    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 290]
        writer.println("<BR>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 291]
        handleInviteeTable(writer, info); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 292]
        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 293]
        writer.println("<BR>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 294]
        handleGroupTable(writer, info); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 295]
    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 296]
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 297]
    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 298]
    // StaleIndicator interface
    public boolean _isStale() {
        java.io.File f = null; long lastModWhenBuilt = 0L, lastMod = 0L;
        f = new File("J:\\b2emarkets\\Web\\jsp\\b2e\\projects\\selection\\SelNextRound.jsp");
        lastModWhenBuilt = 978649343451L;
        lastMod = f.lastModified();
        if (!f.exists() || lastMod > lastModWhenBuilt) return true;
        return false;
    }
    
    
    
    
    public void _jspService(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.io.IOException, javax.servlet.ServletException 
    {  
        
        // declare and set well-known variables:
        javax.servlet.ServletConfig config = getServletConfig();
        javax.servlet.ServletContext application = config.getServletContext();
        Object page = this;
        boolean _needToFlush = true;
        javax.servlet.jsp.JspWriter out;
        PageContext pageContext =
        JspFactory.getDefaultFactory().getPageContext(this, request, response, "/b2e/common/error/ErrorHandler.jsp", true, 8192, true);
        
        out = pageContext.getOut();
        HttpSession session = request.getSession(true);
        
        
        
        try { // error page try block
            
            out.print("<!-- ***************************************************************\r\n** \"This program code contains trade secrets of B2eMarkets that   ** \r\n** (i) derive independent economic value, actual or potential,    ** \r\n** from not being generally known to, and not being readily       ** \r\n** ascertainable by proper means by other persons who can obtain  ** \r\n** economic value from their disclosure or use and; (ii) are the  ** \r\n** subject of efforts by B2eMarkets that are reasonable under the ** \r\n** circumstances to maintain their secrecy. You may not use this  ** \r\n** program code without prior written authorization from          ** \r\n** B2eMarkets.\"                                                   ** \r\n**************************************************************** -->\r\n\r\n");
            out.print("\r\n\r\n");
            out.print("\r\n\r\n");
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 300]
            Info info = new Info(); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 301]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 302]
            String submitErrorStr = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 303]
            info.api = GUIUtils.getSessionAPI ( session, response ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 304]
            boolean done = false; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 305]
            boolean abort_flag = false; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 306]
            JSPErrorHandler jspErrorHandler = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 307]
            String errMsg = ""; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 308]
            //String strEventId = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 309]
            //Integer nEventId = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 310]
            //IResourceBundle irb = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 311]
            XReferenceEntry ref = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 312]
            //String returnURL = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 313]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 314]
            final boolean isNav = ServletUtils.isNav( request ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 315]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 316]
            String currencyShortName = null; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 317]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 318]
            // ask the browser to not cache the returned page.. //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 319]
            // the no-cache for cache control does not appear to works always //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 320]
            response.setHeader("Cache-Control", "no-store"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 321]
            do //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 322]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 323]
                done = true; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 324]
                if ( info.api == null )  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 325]
                { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 326]
                    errMsg = "Internal Error, SelNextRound, failed to get api."; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 327]
                    abort_flag = true; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 328]
                    break; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 329]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 330]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 331]
                info.irb = ResourceManager.getResource(ISelectionResourceConstants.RESOURCE_NAME, info.api); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 332]
                if ( info.irb == null )  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 333]
                { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 334]
                    errMsg = "Internal Error, SelNextRound, failed to get Resource Bundle."; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 335]
                    abort_flag = true; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 336]
                    break; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 337]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 338]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 339]
                info.strEventId = ServletUtils.getValue( request, WebConstant.EVENTID, null ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 340]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 341]
                if ( info.strEventId == null || info.strEventId.length() <= 0 )  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 342]
                { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 343]
                    errMsg = "Internal Error, SelNextRound, failed to get input event id."; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 344]
                    abort_flag = true; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 345]
                    break; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 346]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 347]
                try //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 348]
                { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 349]
                    info.nEventId = new Integer(info.strEventId); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 350]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 351]
                catch(NumberFormatException e) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 352]
                { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 353]
                    errMsg = "Internal Error, SelNextRound, invalid event id=" +  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 354]
                    info.strEventId; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 355]
                    abort_flag = true; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 356]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 357]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 358]
                if (abort_flag) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 359]
                break; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 360]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 361]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 362]
                if (null != (errMsg = initializeCommon(request, response, info))) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 363]
                { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 364]
                    abort_flag = true; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 365]
                    break; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 366]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 367]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 368]
                info.dueBackDate = ServletUtils.getValue( request, "closedate", null ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 369]
                info.dueBackHour = ServletUtils.getValue( request, "due_back_time_hr", null ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 370]
                info.dueBackMin  = ServletUtils.getValue( request, "due_back_time_min",  null ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 371]
                info.dueBackAMPM = ServletUtils.getValue( request, "due_back_time_ampm", null ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 372]
                info.message = ServletUtils.getValue( request, "message", null ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 373]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 374]
                /********************************************************************* //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 375]
                *              handling POST //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 376]
                *********************************************************************/ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 377]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 378]
                if ( DBConstant.EVENT_STATUS__POST.equals(request.getMethod()) ) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 379]
                {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 380]
                    String message = ServletUtils.getValue( request, "message", null ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 381]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 382]
                    // System.out.println("************************** message=" + message); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 383]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 384]
                    // System.out.println("Before SeleBuilderManager"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 385]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 386]
                    SelEventHBuilder eventBuilder =  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 387]
                    SelBuilderManager.extendPORFQNextRound( info.api, info.strEventId, info.dueBackDate, dueBackTime, info.message ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 388]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 389]
                    // System.out.println("After SeleBuilderManager"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 390]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 391]
                    if (info == null) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 392]
                    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 393]
                        // System.out.println("info is null"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 394]
                    } else if (info.groups == null) { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 395]
                        // System.out.println("info.groups is null"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 396]
                    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 397]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 398]
                    // loop through each group to see if BAFO checkbox was set //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 399]
                    boolean isBAFO; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 400]
                    for (int i = 0; i < info.groups.size(); i++) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 401]
                    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 402]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 403]
                        // System.out.println("Inside loop i=" + i); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 404]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 405]
                        isBAFO = false; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 406]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 407]
                        if (null != ServletUtils.getValue( request, info.groups.getGroupIdAsString(i), null )) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 408]
                        { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 409]
                            isBAFO = true; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 410]
                        } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 411]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 412]
                        SelBuilderManager.addBAFOGroup(info.api, eventBuilder, info.groups.getGroupIdAsString(i), isBAFO); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 413]
                    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 414]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 415]
                    try  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 416]
                    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 417]
                        // System.out.println("before Submit"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 418]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 419]
                        SelBuilderManager.submit_data(info.api, eventBuilder); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 420]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 421]
                        // return to Analyses screen //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 422]
                        response.sendRedirect(info.strReturnUrl); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 423]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 424]
                    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 425]
                    catch ( weblogic.rmi.RemoteException e ) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 426]
                    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 427]
                        submitErrorStr =  e.getMessage(); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 428]
                    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 429]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 430]
                // if there wasn //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 431]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 432]
                SelUtils.logTrace("SelNextRound.jsp, ready, strEventId=" + info.strEventId); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 433]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 434]
            } while( !done );   // end of abort do-while structure //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 435]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 436]
            if (abort_flag && jspErrorHandler == null) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 437]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 438]
                SelUtils.logError( errMsg ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 439]
                Exception e = new Exception( errMsg ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 440]
                jspErrorHandler = new JSPErrorHandler( session, request, e ); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 441]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 442]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 443]
            out.print("\r\n\r\n<html>\r\n<head>\r\n<meta HTTP-EQUIV=\"Pragma\" content=\"no-cache\"></meta>\r\n\r\n");
            { /* include block for '/b2e/common/styles/InitiatorStyle.jsp' */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 449]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 450]
                String __includePage =  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 449]
                "/b2e/common/styles/InitiatorStyle.jsp"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 449]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 450]
                pageContext.include(__includePage, out); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 449]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 450]
                out.flush(); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 449]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 450]
            } /* end include block for '/b2e/common/styles/InitiatorStyle.jsp' */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 449]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 450]
            out.print("\r\n<STYLE type=\"text/css\">\r\n\r\n.CenterButtons { text-align:center; font-style:normal;font-family:Helvetica,Arial;height:20; }\r\n \r\n.pagedata {position:absolute; visibility:visible; left:0; top:0; }\r\n\r\n.callayer{ position:absolute; }\r\n");
            /*styles for calendar*/  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 457]
            out.print("\r\n");
            if ( isNav ) {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 458]
                out.print("\r\n.dueBackCalendar{ position:absolute;visibility:hidden;background-color:white;top:60;left:400;width:160;height:120;}\r\n");
            } else {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 460]
                out.print("\r\n.dueBackCalendar{ position:absolute;visibility:hidden;background-color:#DDDDDD;top:60;left:320;width:160;height:120;border-color:black;border-style:solid;border-width:1;}\r\n");
            }  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 462]
            out.print("\r\n</STYLE>\r\n\r\n<SCRIPT language=\"JavaScript\" src=\"/b2e/common/scripts/BrowserType.js\"></SCRIPT>\r\n<SCRIPT language=\"JavaScript\" src=\"/b2e/common/scripts/CrossBrowser.js\"></SCRIPT>\r\n<script language=\"javascript\" src=\"/b2e/common/scripts/DebugUtils.js\"></script>\r\n");
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 468]
            //<script language="javascript" src="/b2e/common/scripts/Calendar.js"></script> //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 469]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 470]
            out.print("\r\n");
            { /* include block for '/b2e/common/jsp/Calendar.jsp' */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 471]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 472]
                String __includePage =  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 471]
                "/b2e/common/jsp/Calendar.jsp"; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 471]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 472]
                pageContext.include(__includePage, out); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 471]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 472]
                out.flush(); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 471]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 472]
            } /* end include block for '/b2e/common/jsp/Calendar.jsp' */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 471]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 472]
            out.print("\r\n<script language=\"javascript\" src=\"/b2e/common/scripts/LaunchPopUp.js\"></script>\r\n<SCRIPT language=\"javascript\" src=\"/b2e/common/scripts/LaunchWindow.js\"></SCRIPT>\r\n<SCRIPT LANGUAGE=\"JAVASCRIPT\" SRC=\"/b2e/help/scripts/HelpLaunch.js\"></SCRIPT>\r\n<script language=\"javascript\" SRC=\"/b2e/common/scripts/WizardUtil.js\"></script>\r\n<SCRIPT language=\"Javascript\">\r\n\r\n");
            if (jspErrorHandler != null){ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 478]
                out.print("\r\n");
                out.print(weblogic.utils.StringUtils.valueOf(jspErrorHandler.createErrorPopupWindowSupportJavaScriptIncludes(false))); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 479]
                out.print("\r\n");
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 480]
            out.print("\r\n\r\nvar dateFormat = \"");
            out.print(weblogic.utils.StringUtils.valueOf(info.api.getDefaultDateFormatDescription() )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 482]
            out.print("\";\r\n\r\nfunction onLoadHandler()\r\n{\r\n");
                if (jspErrorHandler != null){ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 486]
                    out.print("\r\n");
                    out.print(weblogic.utils.StringUtils.valueOf(jspErrorHandler.createErrorPopupMessageJavaScript())); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 487]
                    out.print("\r\n");
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 488]
                out.print("\r\n   self.popup = null;\r\n");
                if (submitErrorStr != null) {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 490]
                    out.print("\r\n\r\n    alert(\"");
                    out.print(weblogic.utils.StringUtils.valueOf( submitErrorStr )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 492]
                    out.print("\");\r\n");
                } else if (!abort_flag){ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 493]
                    out.print("\r\n   init();\r\n");
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 495]
                out.print("\r\n\r\n   initializeLocalHelpFrame();\r\n   setHelpContext(\"HelpNextRound.htm\");\r\n\r\n   calendar = new EmsCalendar ( \"callayer\", \"calendar\", \"callbackFunc\", null, 1, null, \"changeMonth\", null, \"");
                out.print(weblogic.utils.StringUtils.valueOf(info.api.getDefaultDateFormatDescription() )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 500]
                out.print("\", \"calCancel\" );\r\n   setDueBackTime();\r\n   window.status=\"\";\r\n}  \r\n\r\nfunction onUnloadHandler()\r\n{\r\n");
                if (!abort_flag){ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 507]
                    out.print("\r\n   term();\r\n");
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 509]
                out.print("\r\n}  \r\n\r\n</SCRIPT>\r\n\r\n");
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 514]
            if (!abort_flag)   // everything is OK //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 515]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 516]
                // this is where we will put the code if everything checks out OK //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 517]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 518]
                out.print("\r\n\r\n<SCRIPT language=\"JAVASCRIPT\">\r\n\r\nvar calendar;\r\nvar onlywhite = /^(\\s*)$/;\r\n\r\nfunction getCloseDateForm()\r\n{\r\n");
                    if ( isNav ) {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 527]
                        out.print("\r\n     return document.pagedata.document.forms[0].closedate;\r\n");
                    } else {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 529]
                        out.print("\r\n     return document.all.closedate;\r\n");
                    }  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 531]
                    out.print("\r\n}\r\n\r\nfunction getMessage()\r\n{\r\n");
                    if ( isNav ) {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 536]
                        out.print("\r\n     return document.pagedata.document.forms[0].message;\r\n");
                    } else {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 538]
                        out.print("\r\n     return document.all.message;\r\n");
                    }  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 540]
                    out.print("\r\n}\r\n\r\n\r\nfunction validateDate()\r\n{\r\n  var errMsg = null;    \r\n  var theDate = getCloseDateForm().value;\r\n\r\n  if (theDate == null || onlywhite.test(theDate))\r\n  { \r\n    errMsg = \"");
                        out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_NXTR_ERR_EMPTY_DUEBACK_DATE) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 551]
                        out.print("\";\r\n  }\r\n  if (errMsg == null && !checkDate(theDate, dateFormat))\r\n  {\r\n    errMsg = \"");
                        out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_NXTR_ERR_INVALID_DUEBACK_DATE) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 555]
                        out.print("\";\r\n  }\r\n  return errMsg;\r\n}\r\n\r\nfunction callbackFunc ( date)\r\n{\r\n  getCloseDateForm().value = date;\r\n  hideCalendar();\r\n}\r\n\r\nfunction calCancel()\r\n{\r\n  hideCalendar();\r\n}\r\n\r\nfunction setDueBackTime()\r\n{\r\n");
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 573]
                    // Bug # 4263: Check whether at least one value out of the due date / message fields  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 574]
                    // were already entered before going to New Target Price screen: //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 575]
                    if ( info.dueBackDate != null || info.dueBackHour != null //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 576]
                    || info.dueBackMin != null || info.dueBackAMPM != null || info.message != null)  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 577]
                    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 578]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 579]
                        out.print("\r\n\t  alert(\"setting previous values in due date\");\r\n\t  ");
                        if (info.dueBackDate != null)  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 581]
                        out.print("\r\n\t\t setFormElement(\"nextroundform\", \"closedate\", \"");
                        out.print(weblogic.utils.StringUtils.valueOf( info.dueBackDate )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 582]
                        out.print("\");\r\n\t  ");
                        else if (info.dueBackHour != null)  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 583]
                        out.print("\r\n\t\t setFormElement(\"nextroundform\", \"due_back_time_hr\", \"");
                        out.print(weblogic.utils.StringUtils.valueOf( info.dueBackHour )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 584]
                        out.print("\");\r\n\t  ");
                        else if (info.dueBackMin != null)  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 585]
                        out.print("\r\n\t\t setFormElement(\"nextroundform\", \"due_back_time_min\", \"");
                        out.print(weblogic.utils.StringUtils.valueOf( info.dueBackMin )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 586]
                        out.print("\");\r\n\t  ");
                        else if (info.dueBackAMPM != null)  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 587]
                        out.print("\r\n\t\t setFormElement(\"nextroundform\", \"due_back_time_ampm\", \"");
                        out.print(weblogic.utils.StringUtils.valueOf( info.dueBackAMPM )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 588]
                        out.print("\");\r\n\t  ");
                        else if (info.message != null)  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 589]
                        out.print("\r\n\t\t setFormElement(\"nextroundform\", \"message\", \"");
                        out.print(weblogic.utils.StringUtils.valueOf( info.message )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 590]
                        out.print("\");\r\n  ");
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 591]
                    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 592]
                    else	// else, use the default values from the event object to populate the due date fields: //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 593]
                    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 594]
                        Date promptDateObj = info.event.getDueBackDateObject(); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 595]
                        Date curTime = new Date(); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 596]
                        if ( promptDateObj == null ) promptDateObj = curTime;   //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 597]
                        if ( promptDateObj.before(curTime) ) promptDateObj = curTime; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 598]
                        String promptDate =  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 599]
                        DateUtilities.format( promptDateObj, info.api.getDefaultDateFormatDescription(), //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 600]
                        info.api.getDefaultTimeZoneName(), true, false); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 601]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 602]
                        out.print(" \r\n   alert(\"setting default values in due date\");\r\n   getCloseDateForm().value = \"");
                        out.print(weblogic.utils.StringUtils.valueOf( promptDate )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 604]
                        out.print("\";\r\n  ");
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 605]
                    }	 // if ( info.dueBackDate != null || .. //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 606]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 607]
                    out.print("\r\n}\r\n\r\n//function setDueDate()\r\n//{\r\n   //alert(\" in set due date\");\r\n   //dueDate = getFormElement(\"nextroundform\", \"closedate\");\r\n//}\t\r\n\r\nfunction setFormsAction(grpId)\r\n{\r\n   alert(\"in setFormsAction\");\r\n   alert(grpId);\r\n   \r\n   // var dueBackDate = getFormElement(\"nextroundform\", \"closedate\", null );\r\n   // var dueBackTimeHr = getFormElement(\"nextroundform\", \"due_back_time_hr\", null );\r\n   // var dueBackTimeMin = getFormElement(\"nextroundform\", \"due_back_time_min\", null );\r\n   // var dueBackTimeAMPM = getFormElement(\"nextroundform\", \"due_back_time_ampm\", null );\r\n\r\n   setFormElement(\"nextroundform\", \"");
                    out.print(weblogic.utils.StringUtils.valueOf( WebConstant.GROUPID )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 626]
                    out.print("\", grpId);\r\n\r\n   // var urlstr = \"SelNewTargetPrice.jsp?\" + \r\n   //             \"");
                    out.print(weblogic.utils.StringUtils.valueOf( WebConstant.EVENTID )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 629]
                    out.print("\" + \"=\" + \"");
                    out.print(weblogic.utils.StringUtils.valueOf( info.strEventId )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 629]
                    out.print("\" + \"&\" + \r\n   //             \"");
                    out.print(weblogic.utils.StringUtils.valueOf( WebConstant.GROUPID )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 630]
                    out.print("\" + \"=\" + grpId; \r\n\t\t\t\t  // + \"&\" + \r\n\t\t\t    // \" ;\r\n\r\n   // strDueBackTimeHr = ServletUtils.getValue( request, \"due_back_time_hr\", null );\r\n   // strDueBackTimeMin = ServletUtils.getValue( request, \"due_back_time_min\", null );\r\n   // strDueBackTimeAMPM = ServletUtils.getValue( request, \"due_back_time_ampm\", null );\r\n\r\n   // alert(urlstr);\r\n\r\n   document.forms.nextroundform.method=\"GET\";\r\n   document.forms.nextroundform.action= \"SelNewTargetPrice.jsp?\";\r\n   document.forms.nextroundform.submit();\r\n}\r\n\r\nfunction changeMonth(year, month)\r\n{\r\n  this.showDueBackCalendar()\r\n}\r\n\r\nfunction showDueBackCalendar()\r\n{\r\n");
                    if( isNav ) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 652]
                    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 653]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 654]
                        out.print("\r\n  document.callayer.visibility=\"visible\";\r\n");
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 656]
                    } else { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 657]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 658]
                        out.print("\r\n  document.all.callayer.style.visibility=\"visible\";\r\n");
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 660]
                    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 661]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 662]
                    out.print("\r\n}\r\n\r\nfunction hideCalendar()\r\n{\r\n");
                    if( isNav ) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 667]
                    { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 668]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 669]
                        out.print("\r\n  document.callayer.visibility=\"hidden\";\r\n");
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 671]
                    } else { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 672]
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 673]
                        out.print("\r\n  document.all.callayer.style.visibility=\"hidden\";\r\n");
                        //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 675]
                    } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 676]
                    //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 677]
                    out.print("\r\n   return false;\r\n}\r\n\r\n\r\n");
                /* generate the Javascript code since everything is OK */  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 682]
                out.print("\r\n");
                /* may want to init global vars here such as eventPrecision, numIntervals etc. */  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 683]
                out.print("\r\n\r\nfunction init()\r\n{\r\n  ");
                    /* init Javascrip code, text fields etc.. here */  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 687]
                    out.print("\r\n} // end of JS Init fn\r\n\r\n\r\nfunction term()\r\n{\r\n  ");
                    /* Javascrip code to terminate this page, perform cleanup etc.. here */  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 693]
                    out.print("\r\n}\r\n\r\n\r\nfunction handleCancel()\r\n{\r\n   var resp = confirm(\"");
                    out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_NXTR_MSG_SURE_TO_CANCEL))); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 699]
                    out.print("\");\r\n   if (resp == false)\r\n      return;\r\n\r\n   self.location = \"");
                    out.print(weblogic.utils.StringUtils.valueOf(info.strReturnUrl)); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 703]
                    out.print("\";\r\n}\r\n\r\nfunction handleFinish()\r\n{\r\n\r\n   var errorMsg = null;\r\n   var msg = getMessage();\r\n   if (msg.length >= 2000) \r\n   {\r\n      alert(\"");
                        out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_NXTR_MSG_TOO_LONG))); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 713]
                        out.print("\");\r\n   }\r\n   else if ((errorMsg = validateDate()) == null)\r\n   {\r\n      ");
                        if ( isNav ) {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 717]
                            out.print("\r\n         document.pagedata.document.forms[0].submit( document.pagedata.document.forms[0] );\r\n         //document.nextroundform.submit( document.nextroundform );\r\n      ");
                        } else {  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 720]
                            out.print("\r\n         document.nextroundform.submit( document.nextroundform );\r\n         //self.document.forms[0].submit();\r\n      ");
                        }  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 723]
                        out.print("\r\n\r\n   }\r\n   else\r\n   {\r\n      alert(errorMsg);\r\n   }\r\n}\r\n\r\n");
                /* end of Javascript for OK scenario */  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 732]
                out.print("\r\n</SCRIPT>\r\n</head>\r\n");
                if ( !isNav ) { /* added by Keng */ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 735]
                    out.print("\r\n<script for=document EVENT=\"onclick()\">hideCalendar();</script>\r\n");
                }  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 737]
                out.print("\r\n\r\n<body onload=\"onLoadHandler()\" onunload=\"onUnloadHandler()\" class=\"pageBackground\">\r\n<div name=\"pagedata\" id=\"pagedata\" class=\"pagedata\">\r\n\r\n<table bgcolor=\"#006699\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\" frame=\"0\">\r\n   <tr CLASS=\"pageHeaderBackground\">\r\n   \r\n   <td align=\"left\" class=\"pageHeaderTitle\">\r\n        <span class=\"pageHeaderTitle\">\r\n            ");
                out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_NXTR_TITLE) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 747]
                out.print("\r\n        </span>\r\n   </td>\r\n   \r\n      ");
                /* need to encode url */  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 751]
                out.print("\r\n      <td  class=\"pageHeaderActiveLink\" nowrap width=10%>\r\n        <span class=\"pageHeaderActiveLink\">\r\n        <a class=\"pageHeaderActiveLink\" href=\"");
                out.print(weblogic.utils.StringUtils.valueOf( "SelAnalysesPrivateBid.jsp?" + WebConstant.EVENTID + "=" + info.strEventId )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 754]
                out.print("\">");
                out.print(weblogic.utils.StringUtils.valueOf( info.irb.getString(ISelectionResourceConstants.SEL_NXTR_ANALYZE) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 754]
                out.print("</a>&nbsp; &nbsp;\r\n        ");
                out.print(weblogic.utils.StringUtils.valueOf(SelUtils.fmtCoachingTextLinkTags( "pageHeaderActiveLink", "CoachNextRound.htm", info.irb ))); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 755]
                out.print("\r\n        </span>\r\n      </td>\r\n   </tr>\r\n</table>\r\n<form name=\"nextroundform\" action=\"SelNextRound.jsp\" method=\"POST\" target=\"_self\">\r\n\r\n<input type=\"hidden\" name=\"");
                out.print(weblogic.utils.StringUtils.valueOf( WebConstant.EVENTID )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 762]
                out.print("\" value=\"");
                out.print(weblogic.utils.StringUtils.valueOf( info.strEventId )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 762]
                out.print("\">\r\n<input type=\"hidden\" name=\"");
                out.print(weblogic.utils.StringUtils.valueOf( WebConstant.GROUPID )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 763]
                out.print("\" >\r\n\r\n");
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 765]
                handleHeaderInfo(out, info); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 766]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 767]
                out.print("\r\n<BR>\r\n  \r\n<table width=100% cellspacing=0 cellpadding=0 border=0 frame=\"void\">\r\n <tr >\r\n   <td class=\'pageHeaderLabel\'>&nbsp;</td>\r\n   <td class=\'pageHeaderLabel\'>");
                out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_NXTR_HDG_NEXT_ROUND_DUE_BACK) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 773]
                out.print("</td>\r\n   <td class=\'pageHeaderLabel\'>&nbsp;</td>\r\n </tr>\r\n</table>\r\n<table width=100% cellspacing=0 cellpadding=0 border=0 frame=\"void\">\r\n <tr >\r\n   <td class=\'pageHeaderLabel\'>&nbsp;</td>\r\n   <td class=\'pageHeaderLabel\' nowrap>");
                out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_EXTENDPO_DATE) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 780]
                out.print(":</td>\r\n   <td valign=middle class=\'pageHeaderLabel\' nowrap>\r\n     <input name=\"closedate\" id=\"closedate\">\r\n");
                if( !isNav ){ /*only show calendar for IE, as per Jay's request*/ //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 783]
                    out.print("\r\n     <a href=\"javascript:showDueBackCalendar();\"\r\n        onMouseOver=\"window.status=\'");
                    out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_EXTENDPO_DATE) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 785]
                    out.print("\'; return true;\" onMouseOut=\"window.status=\'\'; return true;\">\r\n        <img SRC=\"");
                    out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_CALENDAR) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 786]
                    out.print("\" border=\"0\" width=\"16\" height=\"16\"></a>\r\n");
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 787]
                out.print("\r\n   </td>         \r\n   <td class=\'pageHeaderLabel\'>&nbsp;</td>\r\n </tr>\r\n <tr>\r\n   <td class=\'pageHeaderLabel\'>&nbsp;</td>\r\n   <td class=\'pageHeaderLabel\' nowrap>");
                out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_EXTENDPO_TIME) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 793]
                out.print(":</td>\r\n   <td valign=middle class=\'pageHeaderLabel\' nowrap>\r\n     <select name=\"due_back_time_hr\" size=\"1\">\r\n");
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 796]
                String openhrstr = ""; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 797]
                for (int i=1; i<=12; i++) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 798]
                { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 799]
                    if (i<10) openhrstr = "0"+i; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 800]
                    else openhrstr = ""+i; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 801]
                    out.print("<option value=\"" + openhrstr +"\">" + openhrstr + "</option>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 802]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 803]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 804]
                out.print("\r\n     </select>\r\n     <font class=\'pageHeaderValue\'> : </font>\r\n     <select name=\"due_back_time_min\" size=\"1\">\r\n");
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 808]
                String openminstr = ""; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 809]
                for (int i=0; i<60; i++) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 810]
                { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 811]
                    if (i<10) openminstr = "0"+i; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 812]
                    else openminstr = ""+i; //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 813]
                    out.print("<option value=\"" + openminstr +"\">" + openminstr + "</option>"); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 814]
                } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 815]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 816]
                out.print("\r\n     </select>\r\n     <select name=\"due_back_time_ampm\" size=\"1\">\r\n       <option value=\"AM\">AM</option>\r\n       <option value=\"PM\">PM</option>\r\n     </select>\r\n   </td>\r\n   <td class=\'pageHeaderLabel\'>&nbsp;</td>\r\n </tr>\r\n \r\n \r\n \r\n <tr >\r\n   <td class=\'pageHeaderLabel\'>&nbsp;</td>\r\n   <td class=\'pageHeaderLabel\' nowrap>");
                out.print(weblogic.utils.StringUtils.valueOf(info.irb.getString(ISelectionResourceConstants.SEL_NXTR_MSG_LABEL) )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 830]
                out.print(":</td>\r\n   <td valign=middle width=90%class=\'pageHeaderLabel\' nowrap>\r\n   \r\n     <TEXTAREA NAME=\"message\" ROWS=\"5\" COLS=");
                out.print(weblogic.utils.StringUtils.valueOf(isNav?"60":"80")); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 833]
                out.print(" >");
                if (info.event.getMessage() != null){StringUtils.htmlSafeString(info.event.getMessage());} //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 833]
                out.print("</TEXTAREA>\r\n   \r\n   </td>\r\n   <td class=\'pageHeaderLabel\'>&nbsp;</td>\r\n </tr>\r\n \r\n</table>\r\n\r\n");
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 841]
                handleBodyInfo(out, response, info); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 842]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 843]
                out.print("\r\n\r\n</form>\r\n\r\n<CENTER class=\"CenterButtons\">\r\n   ");
                out.print(weblogic.utils.StringUtils.valueOf(  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 848]
                SelUtils.fmtAnchorLinkButton( "javascript:void handleCancel();",  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 848]
                null, null, info.irb.getString(ISelectionResourceConstants.SEL_NXTR_CANCEL_BUT_MOUSEOVER),  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 848]
                info.irb.getString(ISelectionResourceConstants.SEL_AWARD_CANCEL) ) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 848]
                )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 848]
                out.print("\r\n   &nbsp;\r\n   ");
                out.print(weblogic.utils.StringUtils.valueOf( //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 854]
                SelUtils.fmtAnchorLinkButton( "javascript:void handleFinish();",  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 854]
                null, null, info.irb.getString(ISelectionResourceConstants.SEL_NXTR_FINISH_BUT_MOUSEOVER),  //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 854]
                info.irb.getString(ISelectionResourceConstants.SEL_EXTENDPO_FINISH) ) //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 854]
                )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 854]
                out.print("\r\n   \r\n </CENTER>\r\n\r\n</div>\r\n<div id=\"callayer\" class=\"dueBackCalendar\"></div>\r\n                        \r\n</body>\r\n\r\n");
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 867]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 868]
            else       // we got abort error //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 869]
            { //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 870]
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 871]
                out.print("\r\n   \r\n</head>\r\n<body onload=\"onLoadHandler()\" onunload=\"onUnloadHandler()\">\r\n<p><b>Internal abort error, </b>");
                out.print(weblogic.utils.StringUtils.valueOf( errMsg )); //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 875]
                out.print("\r\n</body>\r\n   \r\n");
                //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 878]
            } //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 879]
            //[ b2e\\projects\\selection\\SelNextRound.jsp; Line: 880]
            out.print("\r\n\r\n</html>\r\n");
        } catch (Exception __ee) { // errorpage catch block
            application.log("exception raised on '" + request.getRequestURI() + "'", __ee);
            // try to forward to '/b2e/common/error/ErrorHandler.jsp
            try {
                out.clear();
            } catch (Exception __ignore) { // output already sent, too late!
                return;
            }
            _needToFlush = false;
            request.setAttribute("javax.servlet.jsp.jspException", __ee);
            pageContext.forward("/b2e/common/error/ErrorHandler.jsp");
        } // end errorpage catch block
        
        finally {
            if (_needToFlush) out.flush();
        }
        
        
        //before final close brace...
    }
    
    
}
