package shared;

import java.sql.*;
import java.text.*;

public class DateUtils
{
    public static String format(String date)
    {
        // Note: Input 'date' is 1st 10 char of date string
        String retDate = "";
        if (date != null && date.length() >= 10)
        {
            int month = Integer.parseInt(date.substring(5,7));
            //System.out.println("********** DateUtils:format: date = " + date + " month = " + month);
            
            switch (month)
            {
            case 1: retDate = "Jan " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 2: retDate = "Feb " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 3: retDate = "March " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 4: retDate = "April " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 5: retDate = "May " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 6: retDate = "June " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 7: retDate = "July " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 8: retDate = "Aug " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 9: retDate = "Sep " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 10: retDate = "Oct " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 11: retDate = "Nov " + date.substring(8,10) + ", " + date.substring(0,4); break;
            case 12: retDate = "Dec " + date.substring(8,10) + ", " + date.substring(0,4); break;
            }
        }
        return retDate;
    }

    public static String formatNoYear(String date)
    {
        // Note: Input 'date' is 1st 10 char of date string
        String retDate = "";
        if (date != null && date.length() >= 10)
        {
            int month = Integer.parseInt(date.substring(5,7));
            //System.out.println("********** STEP 3: date = " + date + " month = " + month);
            
            switch (month)
            {
            case 1: retDate = "Jan " + date.substring(8,10); break;
            case 2: retDate = "Feb " + date.substring(8,10); break;
            case 3: retDate = "Mar " + date.substring(8,10); break;
            case 4: retDate = "Apr " + date.substring(8,10); break;
            case 5: retDate = "May " + date.substring(8,10); break;
            case 6: retDate = "Jun " + date.substring(8,10); break;
            case 7: retDate = "Jul " + date.substring(8,10); break;
            case 8: retDate = "Aug " + date.substring(8,10); break;
            case 9: retDate = "Sep " + date.substring(8,10); break;
            case 10: retDate = "Oct " + date.substring(8,10); break;
            case 11: retDate = "Nov " + date.substring(8,10); break;
            case 12: retDate = "Dec " + date.substring(8,10); break;
            }
        }
        return retDate;
    }

    public static String formatNumericOnlyNoYear(String date)
    {
        // Note: Input 'date' is 1st 10 char of date string
        String retDate = "";
        if (date != null && date.length() >= 10)
        {
            int month = Integer.parseInt(date.substring(5,7));
            //System.out.println("********** STEP 3: date = " + date + " month = " + month);
            
            switch (month)
            {
            case 1: retDate = "01/" + date.substring(8,10); break;
            case 2: retDate = "02/" + date.substring(8,10); break;
            case 3: retDate = "03/" + date.substring(8,10); break;
            case 4: retDate = "04/" + date.substring(8,10); break;
            case 5: retDate = "05/" + date.substring(8,10); break;
            case 6: retDate = "06/" + date.substring(8,10); break;
            case 7: retDate = "07/" + date.substring(8,10); break;
            case 8: retDate = "08/" + date.substring(8,10); break;
            case 9: retDate = "09/" + date.substring(8,10); break;
            case 10: retDate = "10/" + date.substring(8,10); break;
            case 11: retDate = "11/" + date.substring(8,10); break;
            case 12: retDate = "12/" + date.substring(8,10); break;
            }
        }
        return retDate;
    }

    public static String getDatebyStartDate(java.util.Date startDate, int lesson, boolean wantEndDate)
    {
       long lStartDate = startDate.getTime();

       long day = 24 * 3600 * 1000;
       
       long week = Math.round(lesson/2.0);

	   long nbrOfDaysAllowedForLesson = 6;

       // long delta = 7 * (week - 1) * day + (wantEndDate? 6 * day: 0) + (lesson%2 == 0 && !wantEndDate? 2 * day: 0);
	   long delta = 7 * (week - 1) * day + (wantEndDate? nbrOfDaysAllowedForLesson * day: 0) + (lesson%2 == 0 && !wantEndDate? 2 * day: 0);
       
       java.util.Date retDate = new java.util.Date(lStartDate + delta);

       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

       return sdf.format(retDate);
    }

    public static String getDatebyStartDate(java.util.Date startDate, int days2NextStartDate, int lesson, boolean wantEndDate, int extended)
    {
	   long lStartDate = startDate.getTime();

       long day = 24 * 3600 * 1000;
       
       long week = Math.round(lesson/2.0);

	   long nbrOfDaysAllowedForLesson = extended==1? (6 + days2NextStartDate): 6;

       //long delta = 7 * (week - 1) * day + (wantEndDate? 6 * day: 0) + (lesson%2 == 0 && !wantEndDate? 2 * day: 0);
	   long delta = 7 * (week - 1) * day + (wantEndDate? nbrOfDaysAllowedForLesson * day: 0) + (lesson%2 == 0 && !wantEndDate? 2 * day: 0);
       
       java.util.Date retDate = new java.util.Date(lStartDate + delta);

       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

       return sdf.format(retDate);
    }

    public static int getNbrDaysToNextStartDate(String sectionId, Statement statement)
    {
		Date startDate = null;
        Date nextStartDate = null;
		int nrbOfDaysToNextStartDate = 0;
        ResultSet rs = null;

        if (sectionId != null && !sectionId.equals(""))
        {
            try
            {
                String sqlGetStartDate = "select start_date as \"start_date\" from course_section where section_id = '" + sectionId + "'";
                rs = statement.executeQuery(sqlGetStartDate);
            
                String strStartDate = null;
                while (rs.next())
                {
                    strStartDate = rs.getString("start_date");
					startDate = rs.getDate("start_date");
                }
                String sqlGetNextStartDate = "SELECT * FROM course_section where course_id=" + sectionId.substring(0,1) + " and start_date > '" + strStartDate + "' order by start_date";

                rs = statement.executeQuery(sqlGetNextStartDate);
            
                while (rs.next())
                {
                    nextStartDate = rs.getDate("start_date");
                    break;
                }
            }
            catch (Exception e) { }

			long day = 24 * 3600 * 1000;
			return (int)((nextStartDate.getTime() - startDate.getTime()) / day);
        }
		return 0;
	}

    public static String getEarliestCutOffDate(int userId, Statement statement)
    {
        ResultSet rs = null;
        String retTmpDueDate = null;
        try
        {
            Date tmpDueDate = null, paymentDueDate = null;
            String strTmpDueDate = null;
        
            String strGetCoursesEnrolled = "SELECT cs.cut_off_date as \"cut_off_date\" FROM courses_enrolled ce, course_section cs where cs.section_id = ce.section_id and ce.userid  = " + userId;
            System.out.println("******* getEarliestCutOffDate: strGetCoursesEnrolled = " + strGetCoursesEnrolled);
            rs = statement.executeQuery(strGetCoursesEnrolled);
            
            int i = 0;
            System.out.println("*** DateUtils: WILL LOOP:");
            while (rs.next())
            {
            tmpDueDate = rs.getDate("cut_off_date");
            strTmpDueDate = rs.getString("cut_off_date");
        
            System.out.println("*** DateUtils: i = " + i + " strTmpDueDate = " + strTmpDueDate);

            if (paymentDueDate == null || (paymentDueDate != null && tmpDueDate.before(paymentDueDate)))
            {
                paymentDueDate = tmpDueDate;
                retTmpDueDate = strTmpDueDate;
            }
            i++;
            }
        }
        catch (Exception e) { }
        
        return retTmpDueDate;
    }

    public static Date getCutOffDateBySectId(Statement statement, String sectionId)
    {
        ResultSet rs = null;
        Date cutOffDate = null;

        if (sectionId != null)
        {
            try
            {
            String sqlGetCutOffDate = "select cut_off_date from course_section where section_id = '" + sectionId + "'";
            rs = statement.executeQuery(sqlGetCutOffDate);
        
            while (rs.next())
            {
                cutOffDate = rs.getDate("cut_off_date");
            }
            }
            catch (Exception e) { }
        }

        return cutOffDate;
    }

    public static String getCutOffDateBySectIdStr(Statement statement, String sectionId)
    {
        ResultSet rs = null;
        String cutOffDate = null;

        if (sectionId != null)
        {
            try
            {
            String sqlGetCutOffDate = "select cut_off_date from course_section where section_id = '" + sectionId + "'";
            rs = statement.executeQuery(sqlGetCutOffDate);
        
            while (rs.next())
            {
                cutOffDate = rs.getString("cut_off_date");
            }
            }
            catch (Exception e) { }
        }

        return cutOffDate;
    }

    public static String getAdvStartDateDroplistByBegSectId(Statement statement, String begSectionId)
    {
        String retStr = "";
        ResultSet rs = null;
        if (begSectionId != null)
        {
            try
            {
            String sqlGetStartDateBeg = "select start_date as \"start_date\" from course_section where section_id = '" + begSectionId + "'";
            rs = statement.executeQuery(sqlGetStartDateBeg);
        
            String startDateBeg = null;
            while (rs.next())
            {
                startDateBeg = rs.getString("start_date");
            }

            String sqlGetAdvCourseSections = "SELECT * FROM course_section where course_id=2 and start_date > '" + startDateBeg + "' and start_date > CURRENT_TIMESTAMP";
            System.out.println("******* getAdvStartDateDroplistByBegSectId: sqlGetAdvCourseSections = " + sqlGetAdvCourseSections);
            rs = statement.executeQuery(sqlGetAdvCourseSections);
        
            String startDateAdv = "";
            boolean firstOne = true;
            String sectionId = null;
            while (rs.next())
            {
               startDateAdv = rs.getString("start_date");
               sectionId = rs.getString("section_id");
               retStr += "<OPTION VALUE=\"" + sectionId + "\" " + (firstOne? "SELECTED" : "") + ">" + formatNoYear(startDateAdv) + "</OPTION>";
               if (firstOne) firstOne = false;       
            }
            }
            catch (Exception e) { }
        }
        System.out.println("******** DateUtils: retStr = " + retStr);

        return retStr;
    }

    public static String getFinalEndDate(Statement statement, String sectionId)
    {
        Date retStartDate = null;
        ResultSet rs = null;

        if (sectionId != null && !sectionId.equals(""))
        {
            try
            {
                String sqlGetStartDate = "select start_date as \"start_date\" from course_section where section_id = '" + sectionId + "'";
                rs = statement.executeQuery(sqlGetStartDate);
            
                String startDate = null;
                while (rs.next())
                {
                    startDate = rs.getString("start_date");
                }
                String sqlGetNextStartDate = "SELECT * FROM course_section where course_id=" + sectionId.substring(0,1) + " and start_date > '" + startDate + "' order by start_date";

                rs = statement.executeQuery(sqlGetNextStartDate);
            
                while (rs.next())
                {
                    retStartDate = rs.getDate("start_date");
                    break;
                }
            }
            catch (Exception e) { }
        }

        long day = 24 * 3600 * 1000;
        java.util.Date retDate = new java.util.Date(retStartDate.getTime() - day);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        return sdf.format(retDate);
    }

    public static String getFinalEndDate(Statement statement, String sectionId, int extended)
    {
        Date retStartDate = null;
        ResultSet rs = null;

        if (sectionId != null && !sectionId.equals(""))
        {
            try
            {
                String sqlGetStartDate = "select start_date as \"start_date\" from course_section where section_id = '" + sectionId + "'";
                rs = statement.executeQuery(sqlGetStartDate);
            
                String startDate = null;
                while (rs.next())
                {
                    startDate = rs.getString("start_date");
                }
                
				String sqlGetNextStartDate = "SELECT * FROM course_section where course_id=" + sectionId.substring(0,1) + " and start_date > '" + startDate + "' order by start_date";
                rs = statement.executeQuery(sqlGetNextStartDate);
            
                while (rs.next())
                {
                    retStartDate = rs.getDate("start_date");
					if (extended==1)
					{
						startDate = rs.getString("start_date");
					}
                    break;
                }
				// If extended, repeat to get start date of next section:
				if (extended==1)
				{
					sqlGetNextStartDate = "SELECT * FROM course_section where course_id=" + sectionId.substring(0,1) + " and start_date > '" + startDate + "' order by start_date";
					rs = statement.executeQuery(sqlGetNextStartDate);

					while (rs.next())
					{
						retStartDate = rs.getDate("start_date");
						break;
					}
				}
            }
            catch (Exception e) { }
        }

        long day = 24 * 3600 * 1000;
        java.util.Date retDate = new java.util.Date(retStartDate.getTime() - day);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        return sdf.format(retDate);
    }

	/*
    public static java.util.Date getNextSDate(Statement statement, String startDate)
    {
        Date retStartDate = null;
        ResultSet rs = null;

        if (startDate != null && !startDate.equals(""))
        {
            try
            {
				String sqlGetNextStartDate = "SELECT * FROM course_section where course_id=" + sectionId.substring(0,1) + " and start_date > '" + startDate + "' order by start_date";
                rs = statement.executeQuery(sqlGetNextStartDate);
            
                while (rs.next())
                {
                    retStartDate = rs.getDate("start_date");
                    break;
                }
            }
            catch (Exception e) { }
        }

        return new java.util.Date(retStartDate.getTime());
    }

    public static String getNextStartDate(Statement statement, String startDate)
    {
        java.util.Date retStartDate = getNextSDate(statement, startDate);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(retStartDate);
    }

    public static java.util.Date getNextSDate(Statement statement, String sectionId)
    {
        // Date retStartDate = null;
        ResultSet rs = null;

        if (sectionId != null && !sectionId.equals(""))
        {
            try
            {
                String sqlGetStartDate = "select start_date as \"start_date\" from course_section where section_id = '" + sectionId + "'";
                rs = statement.executeQuery(sqlGetStartDate);
            
                String startDate = null;
                while (rs.next())
                {
                    startDate = rs.getString("start_date");
                }
				return getNextStartDate(statement, startDate);
            }
            catch (Exception e) { }
        }
    }

    public static String getNextStartDate(Statement statement, String sectionId)
    {
        // Date retStartDate = null;
        ResultSet rs = null;

        if (sectionId != null && !sectionId.equals(""))
        {
            try
            {
                String sqlGetStartDate = "select start_date as \"start_date\" from course_section where section_id = '" + sectionId + "'";
                rs = statement.executeQuery(sqlGetStartDate);
            
                String startDate = null;
                while (rs.next())
                {
                    startDate = rs.getString("start_date");
                }
				return getNextSDate(statement, startDate);
            }
            catch (Exception e) { }
        }
    }
	*/

    public static String getNextDestSectBySrcSectId(Statement statement, String sourceSectionId, int destCourseId, boolean getStartDate)
    {
        // System.out.println("******** DateUtils: getNextDestSectBySrcSectId: ********* ");
        // System.out.println("sourceSectionId = " + sourceSectionId + " destCourseId = " + destCourseId + " getStartDate = " + getStartDate);

        String retStartDate = "", retSectionId = "";
        ResultSet rs = null;

        if (sourceSectionId != null && !sourceSectionId.equals(""))
        {
            try
            {
                String sqlGetStartDate = "select start_date as \"start_date\" from course_section where section_id = '" + sourceSectionId + "'";
                rs = statement.executeQuery(sqlGetStartDate);
            
                String startDate = null;
                while (rs.next())
                {
                    startDate = rs.getString("start_date");
                }
                //System.out.println("getNextStartDateBySectId: startDate = " + startDate);
                String sqlGetDestCourseSections = "SELECT * FROM course_section where course_id=" + destCourseId + " and start_date > '" + startDate + "' and start_date > CURRENT_TIMESTAMP order by start_date";

                //System.out.println("getNextStartDateBySectId: sqlGetDestCourseSections = " + sqlGetDestCourseSections);

                rs = statement.executeQuery(sqlGetDestCourseSections);
            
                while (rs.next())
                {
                    retStartDate = rs.getString("start_date");
                    retSectionId = rs.getString("section_id");
                    break;
                }
                // System.out.println("getNextStartDateBySectId: retStartDate = " + retStartDate);
            }
            catch (Exception e) { }
        }
        // System.out.println("******** DateUtils: getNextStartDateBySectId: retStartDate = " + retStartDate);

        if (getStartDate)
            return retStartDate;
        else
            return retSectionId;
    }

    public static String getDestStartDateDroplistBySourceSectId(Statement statement, String sourceSectionId, int destCourseId)
    {
        System.out.println("******** DateUtils: getDestStartDateDroplistBySourceSectId: ********* ");
        System.out.println("sourceSectionId = " + sourceSectionId + " destCourseId = " + destCourseId);

        String retStr = "";
        //String destNextSectId = "";
        String destNextStartDate = "";
        ResultSet rs = null;
        if (sourceSectionId != null && !sourceSectionId.equals(""))
        {
            try
            {
            String nextSourceStartDate = null;
            if (destCourseId == 3 && Integer.parseInt(sourceSectionId.substring(0,1)) == 1)
            {
                //destNextSectId = getNextDestSectBySrcSectId(statement, sourceSectionId, 2, false);
                destNextStartDate = getNextDestSectBySrcSectId(statement, sourceSectionId, 2, true);
            }       
            else
            {
                String sqlGetStartDate = "select start_date as \"start_date\" from course_section where section_id = '" + sourceSectionId + "'";
                rs = statement.executeQuery(sqlGetStartDate);

                        while (rs.next())
                {
                destNextStartDate = rs.getString("start_date");
                }
                // destNextStartDate = getNextDestSectBySrcSectId(statement, sourceSectionId, destCourseId, true);
            }

            String sqlGetDestCourseSections = "SELECT * FROM course_section where course_id=3 and start_date > '" + destNextStartDate + "' and start_date > CURRENT_TIMESTAMP";
            System.out.println("getDestStartDateDroplistBySourceSectId: sqlGetDestCourseSections = " + sqlGetDestCourseSections);

                    rs = statement.executeQuery(sqlGetDestCourseSections);
        
                    boolean firstOne = true;
            String sectionId = null;
            while (rs.next())
            {
               String startDate = rs.getString("start_date");
               sectionId = rs.getString("section_id");
               retStr += "<OPTION VALUE=\"" + sectionId + "\" " + (firstOne? "SELECTED" : "") + ">" + formatNoYear(startDate) + "</OPTION>";
               if (firstOne) firstOne = false;       
            }
            }
            catch (Exception e) { }
        }
        System.out.println("******** DateUtils: getDestStartDateDroplistBySourceSectId: retStr = " + retStr);

        return retStr;
    }
}
