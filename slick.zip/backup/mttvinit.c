/*************************************************************************/
/*                                                                       */
/*  FILE:                                                                */
/*                                                                       */
/*  mttvinit.c                                                           */
/*                                                                       */
/*  DESCRIPTION:                                                         */
/*                                                                       */
/*  This file contains functions for initializing the simulation         */
/*  variables for each Monte-Carlo trial. GPS model variables are init-  */
/*  ialized in another function in gpssim.c.                             */
/*                                                                       */
/*  FUNCTIONS CONTAINED:                                                 */
/*                                                                       */
/*  sim_init                                                             */
/*  startup_init                                                         */
/*  sim_startup_init                                                     */
/*                                                                       */
/*  REVISION HISTORY:                                                    */
/*                                                                       */
/*  01/27/93  V0.01  JRC  Initial Release                                */
/*  10/28/94  V1.00  JRC  Added support for GPS models                   */
/*  12/30/94  V1.00  JRC  Comment banners added                          */
/*  01/17/95  V1.00  PM   Added include files pmrmsg.h, gps_nav.h and    */
/*                        gpskfnav.h                                     */
/*  01/27/95  V1.00  PM   Added call to init_gpmr_exec function          */
/*                                                                       */
/*************************************************************************/


#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "pmrmsg.h"
#include "gps_nav.h"
#include "gpskfnav.h"
#include "mttv.h"
#include "gpssim.h"
#include "mttvnav.h"
#include "platform.h"
#include "gncnav.h"
#include "simflt.h"
#include "gpmr_sim.h"
#include "earth.h"
#include "const.h"


/*************************************************************************/
/*                                                                       */
/*  FUNCTION:                                                            */
/*                                                                       */
/*  sim_init                                                             */
/*                                                                       */
/*  DESCRIPTION:                                                         */
/*                                                                       */
/*  This function initializes the simulation and GNC and FLIGHT nav-     */
/*  igation algorithms after the input command file has been read.  It   */
/*  is called the first time the simulation loop is run.  The function   */
/*  attempts to open the trajectory input file and output files          */
/*  specified in the command file and initializes the GPS models if the  */
/*  GPS models are activated.                                                       */
/*                                                                       */
/*  INPUT ARGUMENTS:                                                     */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  OUTPUT ARGUMENTS:                                                    */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  RETURNS:                                                             */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  LIMITATIONS:                                                         */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*************************************************************************/

void sim_init(void)
{

  /* initialize the trajectory or telemetry files */
  if(SIM.MODE.data_source == TGEN)
  {
    /* get first (t=0) record from trajectory */
    if(SIM.FILE.traj_file == NULL)
    {
      printf("No trajectory input file specified.\n");
      exit(0);
    }

    if(!read_truth_traj(SIM.MODE.stationary_trajectory,&(SIM.MODE.read_traj_file)))
    {
      printf("Problem reading input trajectory file.\n");
      exit(0);
    }
  }
  else if(SIM.MODE.data_source == TELEMETRY)
  {
    /* get first (t=0) record from telemetry */
    if(SIM.FILE.tlm_file == NULL)
    {
      printf("No telemetry input file specified.\n");
      exit(0);
    }

    if(!read_tlm_file())
    {
      printf("Problem reading input telemetry file.\n");
      exit(0);
    }

    /* read the gse initialization data */
    if(!read_gse_init())
    {
      printf("Problem reading the GSE initialization data file.\n");
      exit(0);
    }

  }

  /* initialize the zero time point with the initial longitude      */
  /* so that the inertial frame x axis goes through the start point */
  SIM.TIME.T0_inertial = TNAV.lon/WE;

  /* initialize the following items when doing simulation only */
  /* if using TLM input, there is no truth and there is no     */
  /* simulation of the platform                                */
  if(SIM.MODE.data_source != TELEMETRY)
  {
    /* initialize the navigation state errors */
    init_nav_mc_errors();

    /* initialize truth state */
    truth_nav();

    /* initialize commands to the IPA */
    IPA.IO.command_word = 0;

    if(SIM.MODE.skip_gyrocompass) IPA.STATE.cage_psi = 0.0;

    /* initialize the platform model */
    init_platform();

    /* initialize the GPS models */
    if(GPSSIM.status.gpssim_on) init_gps_model();
  }

  /* initialize flight code mode commands */
  SIM.MODE.begin_gyrocompass       = 0;
  SIM.MODE.begin_navigation        = 0;
  SIM.MODE.begin_quick_realignment = 0;

  /* initialize the navigation algorithms */
  if(SIM.MODE.algorithm == GNC_ALG)
  {
    init_gnc_alg();  /* GNC version of the navigation software */

    if(SIM.MODE.data_source != TELEMETRY)
    {
      nav_errors(&TNAV,&NAV_INIT_ERROR.MC,&IPA.ERROR.MC,&MNAV,&SYS_ERROR);
      gps_kf_nav_errors(&TNAV,&IPA.ERROR.MC,&MNAV_KF,&SYS_KF_ERROR);
      if(SIM.FILE.err_file != NULL)
        output_errors(SIM.FILE.err_file_name,SIM.FILE.err_file,
                      SIM.TIME.t,&SYS_ERROR);
      if(SIM.FILE.kf_nav_err_file != NULL)
        output_errors(SIM.FILE.kf_nav_err_file_name,SIM.FILE.kf_nav_err_file,
                      SIM.TIME.t,&SYS_KF_ERROR);
      if(SIM.FILE.kf_corrections_file != NULL)
        output_kf_corrections(SIM.FILE.kf_corrections_file_name,
                              SIM.FILE.kf_corrections_file,&FNAV_KF);
    }

    display_nav_state(SIM.TIME.t,&TNAV,&MNAV,&SYS_ERROR.NAV,&MNAV_KF,
                      &SYS_KF_ERROR.NAV);

  }
  else if(SIM.MODE.algorithm == FLT_ALG)
  {
    init_flt_alg();  /* flight version of the navigation software */

    init_gpmr_exec(); /* enables gpmr to start from INIT mode */

    if(SIM.MODE.data_source != TELEMETRY)
    {
      nav_errors(&TNAV,&NAV_INIT_ERROR.MC,&IPA.ERROR.MC,&FNAV,&SYS_ERROR);
      gps_kf_nav_errors(&TNAV,&IPA.ERROR.MC,&FNAV_KF,&SYS_KF_ERROR);
      if(SIM.FILE.err_file != NULL)
        output_errors(SIM.FILE.err_file_name,SIM.FILE.err_file,
                      SIM.TIME.t,&SYS_ERROR);
      if(SIM.FILE.kf_nav_err_file != NULL)
        output_errors(SIM.FILE.kf_nav_err_file_name,SIM.FILE.kf_nav_err_file,
                      SIM.TIME.t,&SYS_KF_ERROR);
      if(SIM.FILE.kf_corrections_file != NULL)
        output_kf_corrections(SIM.FILE.kf_corrections_file_name,
                              SIM.FILE.kf_corrections_file,&FNAV_KF);
    }

    display_nav_state(SIM.TIME.t,&TNAV,&FNAV,&SYS_ERROR.NAV,&FNAV_KF,
                      &SYS_KF_ERROR.NAV);

  }
  else
  {
    printf("No navigation algorithm specified.\n");
    exit(0);
  }

}


/*************************************************************************/
/*                                                                       */
/*  FUNCTION:                                                            */
/*                                                                       */
/*  startup_init                                                         */
/*                                                                       */
/*  DESCRIPTION:                                                         */
/*                                                                       */
/*  This function calls functions to initialize the platform model,      */
/*  GPS model, and simulation variables before the command input file is */
/*  read.                                                                */
/*                                                                       */
/*  INPUT ARGUMENTS:                                                     */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  OUTPUT ARGUMENTS:                                                    */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  RETURNS:                                                             */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  LIMITATIONS:                                                         */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*************************************************************************/

void startup_init(void)
{
  /* initialize IMS/IPA/Nav parameters */
  sim_startup_init();

  /* initialize GPS parameters */
  gpssim_startup_init();
}


/*************************************************************************/
/*                                                                       */
/*  FUNCTION:                                                            */
/*                                                                       */
/*  sim_startup_init                                                     */
/*                                                                       */
/*  DESCRIPTION:                                                         */
/*                                                                       */
/*  This function initializes simulation, platform model and GNC and     */
/*  FLIGHT algorithm data structures. It is called before user input in  */
/*  the command input file has been processed. This is required to clear */
/*  all necessary state variables before each new monte-carlo trial.     */
/*                                                                       */
/*  INPUT ARGUMENTS:                                                     */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  OUTPUT ARGUMENTS:                                                    */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  RETURNS:                                                             */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*  LIMITATIONS:                                                         */
/*                                                                       */
/*  none                                                                 */
/*                                                                       */
/*************************************************************************/

void sim_startup_init(void)
{
  short i=0,j=0,k=0;
  double *es;
  double tmp;
  nav_state_struct *s[3];
  size_t esize;

  /* initialize error source unit conversion factors */
  init_imserr_cf();
  init_naverr_cf();

  /* initialize the random number generators to a known state */
  IPA.DATA.RAND.seed = -1L;
  IPA.DATA.RAND.status.reset = 1;
  tmp = gasdev(&IPA.DATA.RAND);

  /* initialize the monte carlo variables */
  init_ims_mc_variables();
  init_nav_mc_variables();

  /* initialize file pointers to NULL */
  SIM.FILE.traj_file = NULL;
  SIM.FILE.err_file = NULL;
  SIM.FILE.kf_nav_err_file = NULL;
  SIM.FILE.kf_corrections_file = NULL;
  SIM.FILE.kf_telemetry_file = NULL;
  SIM.FILE.covariance_file = NULL;
  SIM.FILE.tmp_file = NULL;
  SIM.FILE.tlm_file = NULL;
  SIM.FILE.gseinit_file = NULL;

  /* open the debug data file for data storage as required */
  /* for miscellaneous data output for test purposes       */ 
  /* file for misc. data output */
  strcpy(SIM.FILE.tmp_file_name,"mttv.tmp");
  SIM.FILE.tmp_file = fopen(SIM.FILE.tmp_file_name,"wt");

  /* initialize time variables */
  SIM.TIME.frame = -1L;
  SIM.TIME.t = 0.0;
  SIM.TIME.run_frame = 0L;
  SIM.TIME.sqdt = sqrt(DT_MINOR);

  SIM.TIME.ipa_state_display_interval = 100L;
  SIM.TIME.nav_state_display_interval = 1000L;
  SIM.TIME.error_output_interval = 10L;
  SIM.TIME.flt_data_display_interval = 1000L;
  SIM.TIME.kf_data_display_interval  = 200L;

  /* initial simulation mode defaults */
  SIM.MODE.algorithm = GNC_ALG;
  SIM.MODE.skip_gyrocompass = 0;
  SIM.MODE.read_traj_file = 3;
  SIM.MODE.stationary_trajectory = 0;
  SIM.MODE.init_tilt_from_acc_bias = 0;
  SIM.MODE.data_source = TGEN;

  /* set platform simulation mode defualts */
  IPA.MODE.zero_torquing = 0;
  IPA.MODE.accel_quantization = 1;
  IPA.MODE.res_resolution = 1;
  IPA.MODE.rgu_resolution = 1;

  /* default XY accel limit cycle model flags */
  IPA.MODE.acc_lcx = 0;
  IPA.MODE.acc_lcy = 0;

  /* IPA leveling mode control: start after t=leveling start time */
  IPA.STATE.leveling_start_time = 5.0; 
  /* 5 sec picked at random, need to get typical number */

  /* zero the platform command and status words */
  IPA.IO.command_word = 0;
  IPA.IO.status_word  = 0;

  /* nominal starting point for caging */
  IPA.STATE.cage_thi = 90.0*D2R;
  IPA.STATE.cage_phi =  0.0*D2R;
  IPA.STATE.cage_psi = 90.0*D2R;

  /* zero out all the navigation state information */
  s[0] = &TNAV;
  s[1] = &MNAV;
  s[2] = &FNAV;

  esize = sizeof(nav_error_struct)/sizeof(double);

  for(i=0;i<3;i++)
  {
    /* clear error state data */
    es = (double *)(&s[i]->ERROR);
    for(j=0;j<(short)esize;j++) *es++ = 0.0;

    /* clear state data */
    s[i]->nav_mode = 0;
    s[i]->exec_frame_count = 0;
    s[i]->nav_frame_count = 0;
    s[i]->gc_frame_count = 0;
    s[i]->exec_frame_rate = 0;
    s[i]->nav_frame_rate = 0;
    s[i]->gc_frame_rate = 0;
    s[i]->lcx = 0; s[i]->lcy = 0;

    s[i]->cxp = 0.0; s[i]->cxn = 0.0; s[i]->cyp = 0.0; s[i]->cyn = 0.0;
    s[i]->etx = 0.0; s[i]->ety = 0.0; s[i]->etz = 0.0;
    s[i]->dxdrift = 0.0; s[i]->dydrift = 0.0;
    s[i]->sinthi = 0.0; s[i]->costhi = 0.0; s[i]->sinphi = 0.0;
    s[i]->cosphi = 0.0; s[i]->sinpsi = 0.0; s[i]->cospsi = 0.0;
    s[i]->lat = 0.0; s[i]->lon = 0.0; s[i]->alt = 0.0; s[i]->local_gravity = 0.0;

    for(j=0;j<3;j++)
    {
      s[i]->dvel_b[j] = 0.0; s[i]->dtht_b[j] = 0.0;
      s[i]->dvel_p[j] = 0.0; s[i]->dtht_p[j] = 0.0;
      s[i]->dvp[j] = 0.0;    s[i]->dvn[j] = 0.0;
      s[i]->dvpsum[j] = 0.0;  s[i]->dvnsum[j] = 0.0;
      s[i]->dvpssum[j] = 0.0; s[i]->dvpdsum[j] = 0.0;
      s[i]->dvnssum[j] = 0.0; s[i]->dvndsum[j] = 0.0;
      s[i]->dvpsold[j] = 0.0; s[i]->dvpdold[j] = 0.0;
      s[i]->dvnsold[j] = 0.0; s[i]->dvndold[j] = 0.0;
      s[i]->dvps[j] = 0.0;    s[i]->dvns[j] = 0.0;
      s[i]->dv_comp[j] = 0.0;
      s[i]->dvel_i[j] = 0.0;
      s[i]->p_i[j] = 0.0; s[i]->p_e[j] = 0.0;
      s[i]->v_i[j] = 0.0; s[i]->v_e[j] = 0.0; s[i]->v_n[j] = 0.0;
      s[i]->G[j] = 0.0;   s[i]->a_i[j] = 0.0;
      s[i]->tilt[j] = 0.0;

      for(k=0;k<3;k++)
      {
        s[i]->CBN[j][k] = 0.0; s[i]->CEN[j][k] = 0.0;
        s[i]->CBI[j][k] = 0.0; s[i]->CBP[j][k] = 0.0;
        s[i]->CPN[j][k] = 0.0; s[i]->CPI[j][k] = 0.0;
        s[i]->CEI[j][k] = 0.0; s[i]->CPP_EST[j][k] = 0.0;
      }

    }

  }
        
  /* zero the FNAV_KF and MNAV_KF structures */
  esize = sizeof(FNAV_KF);
  memset (&FNAV_KF, 0x00, esize);
  memset (&MNAV_KF, 0x00, esize);

}

