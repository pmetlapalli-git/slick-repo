/*******************************************************************
** "This program code contains trade secrets of B2eMarkets that   ** 
** (i) derive independent economic value, actual or potential,    ** 
** from not being generally known to, and not being readily       ** 
** ascertainable by proper means by other persons who can obtain  ** 
** economic value from their disclosure or use and; (ii) are the  ** 
** subject of efforts by B2eMarkets that are reasonable under the ** 
** circumstances to maintain their secrecy. You may not use this  ** 
** program code without prior written authorization from          ** 
** B2eMarkets."                                                   ** 
*******************************************************************/
/**
 * $Archive:   P:/PVCS/eNM-DEV/archives/eNM/b2emarkets/web/gui/IniCurrentPriceIsNullForItemOrKitByGroupID.java-arc  $
 * $Workfile:   IniCurrentPriceIsNullForItemOrKitByGroupID.java  $
 * $Revision:   1.6  $
 * $Date:   May 07 2001 18:46:04  $
 * $Author:   pmetlapalli  $
 * $NoKeywords$
 *
 ******************************************************************************
 * Copyright:   Copyright (c) 2000 B2Emarkets Inc.
 * Purpose:    
 * 
 ******************************************************************************
 */

package b2emarkets.web.gui;

import b2emarkets.web.common.EMSInitiatorRequests;
import b2emarkets.ems.database.IEMSResult;
import b2emarkets.ems.application.IEMSAPI;

import weblogic.rmi.RemoteException;

public class IniCurrentPriceIsNullForItemOrKitByGroupID extends ScreenData
{
    private Long groupId 	 = null;

    // Constructor
    public IniCurrentPriceIsNullForItemOrKitByGroupID( IEMSAPI api, Long groupId )
        throws weblogic.rmi.RemoteException, b2emarkets.common.exception.b2eException
    {
        super(api, null);        
         
        this.groupId = groupId;
	start();
    }

   /**
     *  retrieves new data into the same data structure
     */
    public boolean start ()
        throws weblogic.rmi.RemoteException, b2emarkets.common.exception.b2eException
    {
        if ( groupId == null ) return false;

	data = EMSInitiatorRequests.getCurrentPriceIsNullForItemOrKitByGroupId(api, groupId );

        if (data == null) return false;
        return true;
    }

    /**
     *  checks validity of data
     *  use instead isValid() parent method
     */
    public boolean isValid()
    {
	if ( groupId == null ) return false;
        if ( isValid() ) return true;
        return false;
    }

    public boolean currentPriceIsNullForAtLeastOneItemOrKit()
    {
        return (data != null && data.size() > 0);
    }

    public boolean currentPriceIsNotNullForAllItemsAndKits()
    {
        return (!currentPriceIsNullForAtLeastOneItemOrKit());
    }
}
