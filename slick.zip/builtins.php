//////////////////////////////////////////////////////////////////////////
// PHP Manual
//
//
// PHP is a server-side HTML-embedded scripting language.
// 
// Example 1-1. An introductory example
// 
// <html>
//     <head>
//         <title>Example</title>
//     </head>
//     <body>
//         <?php echo "Hi, I'm a PHP script!"; ?>
//     </body>
// </html>
// 
// 
// Notice how this is different from a CGI script written in other languages
// like Perl or C -- instead of writing a program with lots of commands to
// output HTML, you write an HTML script with a some embedded code to do
// something (in this case, output some text). The PHP code is enclosed in
// special start and end tags that allow you to jump into and out of "PHP
// mode".
// 
// What distinguishes PHP from something like client-side Javascript is that
// the code is executed on the server. If you were to have a script similar to
// the above on your server, the client would receive the results of running
// that script, with no way of determining what the underlying code may be.
// You can even configure your web server to process all your HTML files with
// PHP, and then there's really no way that users can tell what you have up
// your sleeve.
// 
// ------------------------------------------------------------------------
// What can PHP do?
// 
// At the most basic level, PHP can do anything any other CGI program can do,
// such as collect form data, generate dynamic page content, or send and
// receive cookies.
// 
// Perhaps the strongest and most significant feature in PHP is its support
// for a wide range of databases. Writing a database-enabled web page is
// incredibly simple. The following databases are currently supported:
// 
//      Adabas D InterBase Solid
//      dBase    mSQL      Sybase
//      Empress  MySQL     Velocis
//      FilePro  Oracle    Unix dbm
//      Informix PostgreSQL
// 
// PHP also has support for talking to other services using protocols such as
// IMAP, SNMP, NNTP, POP3, or even HTTP. You can also open raw network sockets
// and interact using other protocols.
// 
// ------------------------------------------------------------------------
// A brief history of PHP
// 
// PHP was conceived sometime in the fall of 1994 by Rasmus Lerdorf. Early
// non-released versions were used on his home page to keep track of who was
// looking at his online resume. The first version used by others was
// available sometime in early 1995 and was known as the Personal Home Page
// Tools. It consisted of a very simplistic parser engine that only understood
// a few special macros and a number of utilities that were in common use on
// home pages back then. A guestbook, a counter and some other stuff. The
// parser was rewritten in mid-1995 and named PHP/FI Version 2. The FI came
// from another package Rasmus had written which interpreted html form data.
// He combined the Personal Home Page tools scripts with the Form Interpreter
// and added mSQL support and PHP/FI was born. PHP/FI grew at an amazing pace
// and people started contributing code to it.
// 
// It is hard to give any hard statistics, but it is estimated that by late
// 1996 PHP/FI was in use on at least 15,000 web sites around the world. By
// mid-1997 this number had grown to over 50,000. Mid-1997 also saw a change
// in the development of PHP. It changed from being Rasmus' own pet project
// that a handful of people had contributed to, to being a much more organized
// team effort. The parser was rewritten from scratch by Zeev Suraski and Andi
// Gutmans and this new parser formed the basis for PHP Version 3. A lot of
// the utility code from PHP/FI was ported over to PHP3 and a lot of it was
// completely rewritten.
// 
// Today (mid-1999) either PHP/FI or PHP3 ships with a number of commercial
// products such as C2's StrongHold web server and RedHat Linux and a
// conservative estimate based on an extrapolation from numbers provided by
// NetCraft would be that PHP is in use on over 150,000 sites around the
// world. To put that in perspective, that is more sites than run Netscape's
// flagship Enterprise server on the Internet.
// 
// Also as of this writing, work is underway on the next generation of PHP
// that will utilize the powerful Zend scripting engine to deliver higher
// performance, and will also support running under webservers other than
// Apache as a native server module.
//


//////////////////////////////////////////////////////////////////////////
// PHP Types
//
// PHP supports the following types:
// 
//    * integer
//    * floating-point numbers
//    * string
//    * array
//    * object
// 
// The type of a variable is usually not set by the programmer; rather, it is
// decided at runtime by PHP depending on the context in which that variable
// is used.
// 
// If you would like to force a variable to be converted to a certain type,
// you may either cast the variable or use the settype() function on it.
// 
// Note that a variable may behave in different manners in certain situations,
// depending on what type it is a the time. For more information, see the
// section on Type Juggling.
// 
// ------------------------------------------------------------------------
// Integers
// 
// Integers can be specified using any of the following syntaxes:
// 
// $a = 1234; # decimal number
// $a = -123; # a negative number
// $a = 0123; # octal number (equivalent to 83 decimal)
// $a = 0x12; # hexadecimal number (equivalent to 18 decimal)
// 
// ------------------------------------------------------------------------
// Floating point numbers
// 
// Floating point numbers ("doubles") can be specified using any of the
// following syntaxes:
// 
// $a = 1.234;
// $a = 1.2e3;
// 
// ------------------------------------------------------------------------
// Strings
// 
// Strings can be specified using one of two sets of delimiters.
// 
// If the string is enclosed in double-quotes ("), variables within the string
// will be expanded (subject to some parsing limitations). As in C and Perl,
// the backslash ("\") character can be used in specifying special characters:
// 
// Table 6-1. Escaped characters
// 
//  sequencemeaning
//  \n      newline
//  \r      carriage
//  \t      horizontal tab
//  \\      backslash
//  \$      dollar sign
//  \"      double-quote
// 
// You can escape any other character, but a warning will be issued at the
// highest warning level.
// 
// The second way to delimit a string uses the single-quote ("'") character,
// which does not do any variable expansion or backslash processing (except
// for "\\" and "\'" so you can insert backslashes and single-quotes in a
// singly-quoted string).
// 
// ------------------------------------------------------------------------
// String conversion
// 
// When a string is evaluated as a numeric value, the resulting value and type
// are determined as follows.
// 
// The string will evaluate as a double if it contains any of the characters
// '.', 'e', or 'E'. Otherwise, it will evaluate as an integer.
// 
// The value is given by the initial portion of the string. If the string
// starts with valid numeric data, this will be the value used. Otherwise, the
// value will be 0 (zero). Valid numeric data is an optional sign, followed by
// one or more digits (optionally containing a decimal point), followed by an
// optional exponent. The exponent is an 'e' or 'E' followed by one or more
// digits.
// 
// When the first expression is a string, the type of the variable will depend
// on the second expression.
// 
// $foo = 1 + "10.5";              // $foo is double (11.5)
// $foo = 1 + "-1.3e3";            // $foo is double (-1299)
// $foo = 1 + "bob-1.3e3";         // $foo is integer (1)
// $foo = 1 + "bob3";              // $foo is integer (1)
// $foo = 1 + "10 Small Pigs";     // $foo is integer (11)
// $foo = 1 + "10 Little Piggies"; // $foo is integer (11)
// $foo = "10.0 pigs " + 1;        // $foo is integer (11)
// $foo = "10.0 pigs " + 1.0;      // $foo is double (11)
// 
// For more information on this conversion, see the Unix manual page for
// strtod(3).
// 
// ------------------------------------------------------------------------
// Arrays
// 
// Arrays actually act like both hash tables (associative arrays) and indexed
// arrays (vectors).
// 
// ------------------------------------------------------------------------
// Single Dimension Arrays
// 
// PHP supports both scalar and associative arrays. In fact, there is no
// difference between the two. You can create an array using the list() or
// array() functions, or you can explicitly set each array element value.
// 
// 
// $a[0] = "abc";
// $a[1] = "def";
// 
// $b["foo"] = 13;
// 
// 
// You can also create an array by simply adding values to the array.
// 
// 
// $a[] = "hello"; // $a[2] == "hello"
// $a[] = "world"; // $a[3] == "world"
// 
// 
// Arrays may be sorted using the asort(), arsort(), ksort(), rsort(), sort(),
// uasort(), usort(), and uksort() functions depending on the type of sort you
// want.
// 
// You can count the number of items in an array using the count() function.
// 
// You can traverse an array using next() and prev() functions. Another common
// way to traverse an array is to use the each() function.
// 
// ------------------------------------------------------------------------
// Multi-Dimensional Arrays
// 
// Multi-dimensional arrays are actually pretty simple. For each dimension of
// the array, you add another [key] value to the end:
// 
// 
// $a[1]      = $f;               # one dimensional examples
// $a["foo"]  = $f;
// 
// $a[1][0]     = $f;             # two dimensional
// $a["foo"][2] = $f;             # (you can mix numeric and associative indices)
// $a[3]["bar"] = $f;             # (you can mix numeric and associative indices)
// 
// $a["foo"][4]["bar"][0] = $f;   # four dimensional!
// 
// You can "fill up" multi-dimensional arrays in many ways, but the trickiest
// one to understand is how to use the array() command for associative arrays.
// These two snippets of code fill up the one-dimensional array in the same
// way:
// 
// # Example 1:
// 
// $a["color"]     = "red";
// $a["taste"]     = "sweet";
// $a["shape"]     = "round";
// $a["name"]      = "apple";
// $a[3]           = 4;
// 
// # Example 2:
// $a = array(
//      "color" => "red",
//      "taste" => "sweet",
//      "shape" => "round",
//      "name"  => "apple",
//      3       => 4
// );
// 
// The array() function can be nested for multi-dimensional arrays:
// 
// <?
// $a = array(
//      "apple"  => array(
//           "color"  => "red",
//           "taste"  => "sweet",
//           "shape"  => "round"
//      ),
//      "orange"  => array(
//           "color"  => "orange",
//           "taste"  => "sweet",
//           "shape"  => "round"
//      ),
//      "banana"  => array(
//           "color"  => "yellow",
//           "taste"  => "paste-y",
//           "shape"  => "banana-shaped"
//      )
// );
// 
// echo $a["apple"]["taste"];    # will output "sweet"
// ?>
// 
// ------------------------------------------------------------------------
// Objects
// 
// Object Initialization
// 
// To initialize an object, you use the new statement to instantiate the
// object to a variable.
// 
// class foo {
//     function do_foo () {
//         echo "Doing foo.";
//     }
// }
// 
// $bar = new foo;
// $bar -> do_foo ();
// 
// ------------------------------------------------------------------------
// Type juggling
// 
// PHP does not require (or support) explicit type definition in variable
// declaration; a variable's type is determined by the context in which that
// variable is used. That is to say, if you assign a string value to variable
// var, var becomes a string. If you then assign an integer value to var, it
// becomes an integer.
// 
// An example of PHP's automatic type conversion is the addition operator '+'.
// If any of the operands is a double, then all operands are evaluated as
// doubles, and the result will be a double. Otherwise, the operands will be
// interpreted as integers, and the result will also be an integer. Note that
// this does NOT change the types of the operands themselves; the only change
// is in how the operands are evaluated.
// 
// $foo = "0";  // $foo is string (ASCII 48)
// $foo++;      // $foo is the string "1" (ASCII 49)
// $foo += 1;   // $foo is now an integer (2)
// $foo = $foo + 1.3;  // $foo is now a double (3.3)
// $foo = 5 + "10 Little Piggies"; // $foo is integer (15)
// $foo = 5 + "10 Small Pigs";     // $foo is integer (15)
// 
// If the last two examples above seem odd, see String conversion.
// 
// If you wish to force a variable to be evaluated as a certain type, see the
// section on Type casting. If you wish to change the type of a variable, see
// settype().
// 
// ------------------------------------------------------------------------
// Type casting
// 
// Type casting in PHP works much as it does in C: the name of the desired
// type is written in parentheses before the variable which is to be cast.
// 
// $foo = 10;   // $foo is an integer
// $bar = (double) $foo;   // $bar is a double
// 
// The casts allowed are:
// 
//    * (int), (integer) - cast to integer
//    * (real), (double), (float) - cast to double
//    * (string) - cast to string
//    * (array) - cast to array
//    * (object) - cast to object
// 
// Note that tabs and spaces are allowed inside the parentheses, so the
// following are functionally equivalent:
// 
// $foo = (int) $bar;
// $foo = ( int ) $bar;
//
 
  
//////////////////////////////////////////////////////////////////////////
// PHP Variables
//
// Variable scope
// 
// The scope of a variable is the context within which it is defined. For the
// most part all PHP variables only have a single scope. However, within
// user-defined functions a local function scope is introduced. Any variable
// used inside a function is by default limited to the local function scope.
// For example:
// 
// $a = 1; /* global scope */
// 
// Function Test () {
//     echo $a; /* reference to local scope variable */
// }
// 
// Test ();
// 
// This script will not produce any output because the echo statement refers
// to a local version of the $a variable, and it has not been assigned a value
// within this scope. You may notice that this is a little bit different from
// the C language in that global variables in C are automatically available to
// functions unless specifically overridden by a local definition. This can
// cause some problems in that people may inadvertently change a global
// variable. In PHP global variables must be declared global inside a function
// if they are going to be used in that function. An example:
// 
// $a = 1;
// $b = 2;
// 
// Function Sum () {
//     global $a, $b;
// 
//     $b = $a + $b;
// }
// 
// Sum ();
// echo $b;
// 
// The above script will output "3". By declaring $a and $b global within the
// function, all references to either variable will refer to the global
// version. There is no limit to the number of global variables that can be
// manipulated by a function.
// 
// A second way to access variables from the global scope is to use the
// special PHP-defined $GLOBALS array. The previous example can be rewritten
// as:
// 
// $a = 1;
// $b = 2;
// 
// Function Sum () {
//     $GLOBALS["b"] = $GLOBALS["a"] + $GLOBALS["b"];
// }
// 
// Sum ();
// echo $b;
// 
// The $GLOBALS array is an associative array with the name of the global
// variable being the key and the contents of that variable being the value of
// the array element.
// 
// Another important feature of variable scoping is the static variable. A
// static variable exists only in a local function scope, but it does not lose
// its value when program execution leaves this scope. Consider the following
// example:
// 
// Function Test () {
//     $a = 0;
//     echo $a;
//     $a++;
// }
// 
// This function is quite useless since every time it is called it sets $a to
// 0 and prints "0". The $a++ which increments the variable serves no purpose
// since as soon as the function exits the $a variable disappears. To make a
// useful counting function which will not lose track of the current count,
// the $a variable is declared static:
// 
// Function Test () {
//     static $a = 0;
//     echo $a;
//     $a++;
// }
// 
// Now, every time the Test() function is called it will print the value of $a
// and increment it.
// 
// Static variables are also essential when functions are called recursively.
// A recursive function is one which calls itself. Care must be taken when
// writing a recursive function because it is possible to make it recurse
// indefinitely. You must make sure you have an adequate way of terminating
// the recursion. The following simple function recursively counts to 10:
// 
// Function Test () {
//     static $count = 0;
// 
//     $count++;
//     echo $count;
//     if ($count < 10) {
//         Test ();
//     }
//     $count--;
// }
// 
// ------------------------------------------------------------------------
// Variable variables
// 
// Sometimes it is convenient to be able to have variable variable names. That
// is, a variable name which can be set and used dynamically. A normal
// variable is set with a statement such as:
// 
// $a = "hello";
// 
// 
// A variable variable takes the value of a variable and treats that as the
// name of a variable. In the above example, hello, can be used as the name of
// a variable by using two dollar signs. ie.
// 
// $$a = "world";
// 
// 
// At this point two variables have been defined and stored in the PHP symbol
// tree: $a with contents "hello" and $hello with contents "world". Therefore,
// this statement:
// 
// echo "$a ${$a}";
// 
// 
// produces the exact same output as:
// 
// echo "$a $hello";
// 
// 
// ie. they both produce: hello world.
// 
// In order to use variable variables with arrays, you have to resolve an
// ambiguity problem. That is, if you write $$a[1] then the parser needs to
// know if you meant to use $a[1] as a variable, or if you wanted $$a as the
// variable and then the [1] index from that variable. The syntax for
// resolving this ambiguity is: ${$a[1]} for the first case and ${$a}[1] for
// the second.
// 
// ------------------------------------------------------------------------
// Variables from outside PHP
// 
// HTML Forms (GET and POST)
// 
// When a form is submitted to a PHP script, any variables from that form will
// be automatically made available to the script by PHP. For instance,
// consider the following form:
// 
// Example 7-1. Simple form variable
// 
// <form action="foo.php3" method="post">
//     Name: <input type="text" name="name"><br>
//     <input type="submit">
// </form>
// 
// When submitted, PHP will create the variable $name, which will will contain
// whatever what entered into the Name: field on the form.
// 
// PHP also understands arrays in the context of form variables, but only in
// one dimension. You may, for example, group related variables together, or
// use this feature to retrieve values from a multiple select input:
// 
// Example 7-2. More complex form variables
// 
// <form action="array.php" method="post">
//     Name: <input type="text" name="personal[name]"><br>
//     Email: <input type="text" name="personal[email]"><br>
//     Beer: <br>
//     <select multiple name="beer[]">
//         <option value="warthog">Warthog
//         <option value="guinness">Guinness
//         </select>
//     <input type="submit">
// </form>
// 
// If PHP's track_vars feature is turned on, either by the track_vars
// configuration setting or the <?php_track_vars?> directive, then variables
// submitted via the POST or GET methods will also be found in the global
// associative arrays $HTTP_POST_VARS and $HTTP_GET_VARS as appropriate.
// 
// ------------------------------------------------------------------------
// IMAGE SUBMIT variable names
// 
// When submitting a form, it is possible to use an image instead of the
// standard submit button with a tag like:
// 
// <input type=image src="image.gif" name="sub">
// 
// When the user clicks somewhere on the image, the accompanying form will be
// transmitted to the server with two additional variables, sub_x and sub_y.
// These contain the coordinates of the user click within the image. The
// experienced may note that the actual variable names sent by the browser
// contains a period rather than an underscore, but PHP converts the period to
// an underscore automatically.
// 
// ------------------------------------------------------------------------
// HTTP Cookies
// 
// PHP transparently supports HTTP cookies as defined by Netscape's Spec.
// Cookies are a mechanism for storing data in the remote browser and thus
// tracking or identifying return users. You can set cookies using the
// SetCookie() function. Cookies are part of the HTTP header, so the SetCookie
// function must be called before any output is sent to the browser. This is
// the same restriction as for the Header() function. Any cookies sent to you
// from the client will automatically be turned into a PHP variable just like
// GET and POST method data.
// 
// If you wish to assign multiple values to a single cookie, just add [] to
// the cookie name. For example:
// 
// SetCookie ("MyCookie[]", "Testing", time()+3600);
// 
// 
// Note that a cookie will replace a previous cookie by the same name in your
// browser unless the path or domain is different. So, for a shopping cart
// application you may want to keep a counter and pass this along. i.e.
// 
// Example 7-3. SetCookie Example
// 
// $Count++;
// SetCookie ("Count", $Count, time()+3600);
// SetCookie ("Cart[$Count]", $item, time()+3600);
// 
// Since information coming in via GET, POST and Cookie mechanisms also
// automatically create PHP variables, it is sometimes best to explicitly read
// a variable from the environment in order to make sure that you are getting
// the right version. The getenv() function can be used for this. You can also
//

   
//////////////////////////////////////////////////////////////////////////
// Builtin PHP Constants
//
// PHP defines several constants and provides a mechanism for defining more at
// run-time. Constants are much like variables, save for the two facts that
// constants must be defined using the define() function, and that they cannot
// later be redefined to another value.
//
// Example 8-1. Defining Constants
// 
// <?php
// define("CONSTANT", "Hello world.");
// echo CONSTANT; // outputs "Hello world."
// ?>
// 
// Example 8-2. Using __FILE__ and __LINE__
// 
// <?php
// function report_error($file, $line, $message) {
//    echo "An error occured in $file on line $line: $message.";
// }
//

/**
 * The name of the script file presently being parsed. If used within a
 * file which has been included or required, then the name of the included
 * file is given, and not the name of the parent file.
 */
global string __FILE__;

/**
 * The number of the line within the current script file which is being
 * parsed. If used within a file which has been included or required, then
 * the position within the included file is given.
 */
global int __LINE__;
                    
/**
 * The string representation of the version of the PHP parser presently in
 * use; e.g. '3.0.8-dev'.
 */
global string PHP_VERSION;
              
/**
 * The name of the operating system on which the PHP parser is executing;
 * e.g. 'Linux'.
 */
global string PHP_OS;

/**
 * A true value.
 */
global int TRUE;

/**
 * A false value.
 */
global int FALSE;

/**
 * Denotes an error other than a parsing error from which recovery is not
 * possible.
 */
global int E_ERROR;

/**
 * Denotes a condition where PHP knows something is wrong, but will
 * continue anyway; these can be caught by the script itself. An example
 * would be an invalid regexp in {@link ereg()}.
 */
global int E_WARNING;

/**
 * The parser choked on invalid syntax in the script file. Recovery is not
 * possible.
 */
global int E_PARSE;

/**
 * Something happened which may or may not be an error. Execution
 * continues. Examples include using an unquoted string as a hash index,
 * or accessing a variable which has not been set.
 */
global int E_NOTICE;

/**
 * This is like an E_ERROR, except it is generated by the core of PHP.
 * Functions should not generate this type of error.
 */
global int E_CORE_ERROR;

/**
 * This is like an E_WARNING, except it is generated by the core of PHP.
 * Functions should not generate this type of error.
 */
global int E_CORE_WARNING;


//////////////////////////////////////////////////////////////////////////
// Expressions
//
// Expressions are the most important building stones of PHP. In PHP, almost
// anything you write is an expression. The simplest yet most accurate way to
// define an expression is "anything that has a value".
// 
// The most basic forms of expressions are constants and variables. When you
// type "$a = 5", you're assigning '5' into $a. '5', obviously, has the value
// 5, or in other words '5' is an expression with the value of 5 (in this
// case, '5' is an integer constant).
// 
// After this assignment, you'd expect $a's value to be 5 as well, so if you
// wrote $b = $a, you'd expect it to behave just as if you wrote $b = 5. In
// other words, $a is an expression with the value of 5 as well. If everything
// works right, this is exactly what will happen.
// 
// Slightly more complex examples for expressions are functions. For instance,
// consider the following function:
// 
// function foo () {
//     return 5;
// }
// 
// Assuming you're familiar with the concept of functions (if you're not, take
// a look at the chapter about functions), you'd assume that typing $c = foo()
// is essentially just like writing $c = 5, and you're right. Functions are
// expressions with the value of their return value. Since foo() returns 5,
// the value of the expression 'foo()' is 5. Usually functions don't just
// return a static value but compute something.
// 
// Of course, values in PHP don't have to be integers, and very often they
// aren't. PHP supports three scalar value types: integer values, floating
// point values and string values (scalar values are values that you can't
// 'break' into smaller pieces, unlike arrays, for instance). PHP also
// supports two composite (non-scalar) types: arrays and objects. Each of
// these value types can be assigned into variables or returned from
// functions.
// 
// So far, users of PHP/FI 2 shouldn't feel any change. However, PHP takes
// expressions much further, in the same way many other languages do. PHP is
// an expression-oriented language, in the sense that almost everything is an
// expression. Consider the example we've already dealt with, '$a = 5'. It's
// easy to see that there are two values involved here, the value of the
// integer constant '5', and the value of $a which is being updated to 5 as
// well. But the truth is that there's one additional value involved here, and
// that's the value of the assignment itself. The assignment itself evaluates
// to the assigned value, in this case 5. In practice, it means that '$a = 5',
// regardless of what it does, is an expression with the value 5. Thus,
// writing something like '$b = ($a = 5)' is like writing '$a = 5; $b = 5;' (a
// semicolon marks the end of a statement). Since assignments are parsed in a
// right to left order, you can also write '$b = $a = 5'.
// 
// Another good example of expression orientation is pre- and post-increment
// and decrement. Users of PHP/FI 2 and many other languages may be familiar
// with the notation of variable++ and variable--. These are increment and
// decrement operators. In PHP/FI 2, the statement '$a++' has no value (is not
// an expression), and thus you can't assign it or use it in any way. PHP
// enhances the increment/decrement capabilities by making these expressions
// as well, like in C. In PHP, like in C, there are two types of increment -
// pre-increment and post-increment. Both pre-increment and post-increment
// essentially increment the variable, and the effect on the variable is
// idential. The difference is with the value of the increment expression.
// Pre-increment, which is written '++$variable', evaluates to the incremented
// value (PHP increments the variable before reading its value, thus the name
// 'pre-increment'). Post-increment, which is written '$variable++' evaluates
// to the original value of $variable, before it was incremented (PHP
// increments the variable after reading its value, thus the name
// 'post-increment').
// 
// A very common type of expressions are comparison expressions. These
// expressions evaluate to either 0 or 1, meaning FALSE or TRUE
// (respectively). PHP supports > (bigger than), >= (bigger than or equal to),
// == (equal), != (not equal), < (smaller than) and <= (smaller than or equal
// to). These expressions are most commonly used inside conditional execution,
// such as if statements.
// 
// The last example of expressions we'll deal with here is combined
// operator-assignment expressions. You already know that if you want to
// increment $a by 1, you can simply write '$a++' or '++$a'. But what if you
// want to add more than one to it, for instance 3? You could write '$a++'
// multiple times, but this is obviously not a very efficient or comfortable
// way. A much more common practice is to write '$a = $a + 3'. '$a + 3'
// evaluates to the value of $a plus 3, and is assigned back into $a, which
// results in incrementing $a by 3. In PHP, as in several other languages like
// C, you can write this in a shorter way, which with time would become
// clearer and quicker to understand as well. Adding 3 to the current value of
// $a can be written '$a += 3'. This means exactly "take the value of $a, add
// 3 to it, and assign it back into $a". In addition to being shorter and
// clearer, this also results in faster execution. The value of '$a += 3',
// like the value of a regular assignment, is the assigned value. Notice that
// it is NOT 3, but the combined value of $a plus 3 (this is the value that's
// assigned into $a). Any two-place operator can be used in this
// operator-assignment mode, for example '$a -= 5' (subtract 5 from the value
// of $a), '$b *= 7' (multiply the value of $b by 7), etc.
// 
// There is one more expression that may seem odd if you haven't seen it in
// other languages, the ternary conditional operator:
// 
// $first ? $second : $third
// 
// If the value of the first subexpression is true (non-zero), then it the
// second subexpression is evaluated, and that is the result of the
// conditional expression. Otherwise, the third subexpression is evaluated,
// and that is the value.
// 
// The following example should help you understand pre- and post-increment
// and expressions in general a bit better:
// 
// function double($i) {
//     return $i*2;
// }
// $b = $a = 5;        /* assign the value five into the variable $a and $b */
// $c = $a++;          /* post-increment, assign original value of $a
//                        (5) to $c */
// $e = $d = ++$b;     /* pre-increment, assign the incremented value of
//                        $b (6) to $d and $e */
// 
// /* at this point, both $d and $e are equal to 6 */
// 
// $f = double($d++);  /* assign twice the value of $d before
//                        the increment, 2*6 = 12 to $f */
// $g = double(++$e);  /* assign twice the value of $e after
//                        the increment, 2*7 = 14 to $g */
// $h = $g += 10;      /* first, $g is incremented by 10 and ends with the
//                        value of 24. the value of the assignment (24) is
//                        then assigned into $h, and $h ends with the value
//                        of 24 as well. */
// 
// In the beginning of the chapter we said that we'll be describing the
// various statement types, and as promised, expressions can be statements.
// However, not every expression is a statement. In this case, a statement has
// the form of 'expr' ';' that is, an expression followed by a semicolon. In
// '$b=$a=5;', $a=5 is a valid expression, but it's not a statement by itself.
// '$b=$a=5;' however is a valid statement.
// 
// One last thing worth mentioning is the truth value of expressions. In many
// events, mainly in conditional execution and loops, you're not interested in
// the specific value of the expression, but only care about whether it means
// TRUE or FALSE (PHP doesn't have a dedicated boolean type). The truth value
// of expressions in PHP is calculated in a similar way to perl. Any numeric
// non-zero numeric value is TRUE, zero is FALSE. Be sure to note that
// negative values are non-zero and are thus considered TRUE! The empty string
// and the string "0" are FALSE; all other strings are TRUE. With non-scalar
// values (arrays and objects) - if the value contains no elements it's
// considered FALSE, otherwise it's considered TRUE.
// 
// PHP provides a full and powerful implementation of expressions, and
// documenting it entirely goes beyond the scope of this manual. The above
// examples should give you a good idea about what expressions are and how you
// can construct useful expressions. Throughout the rest of this manual we'll
// write expr to indicate any valid PHP expression.
//


//////////////////////////////////////////////////////////////////////////
// Expressions and Operators
// 
// Arithmetic Operators
// ------------------------------------------------------------------------
// 
// Remember basic arithmetic from school? These work just like those.
// 
// Table 10-1. Arithmetic Operators
// 
//  examplename           result
//  $a + $bAddition       Sum of $a and $b.
//  $a - $bSubtraction    Remainder of $b subtracted from $a.
//  $a * $bMultiplication Product of $a and $b.
//  $a / $bDivision       Dividend of $a and $b.
//  $a % $bModulus        Remainder of $a divided by $b.
//
// ------------------------------------------------------------------------
// String Operators
// 
// There is only really one string operator -- the concatenation operator
// (".").
// 
// $a = "Hello ";
// $b = $a . "World!"; // now $b = "Hello World!"
// 
// 
// ------------------------------------------------------------------------
// Assignment Operators
// 
// The basic assignment operator is "=". Your first inclination might be to
// think of this as "equal to". Don't. It really means that the the left
// operand gets set to the value of the expression on the rights (that is,
// "gets set to").
// 
// The value of an assignment expression is the value assigned. That is, the
// value of "$a = 3" is 3. This allows you to do some tricky things:
// 
// $a = ($b = 4) + 5; // $a is equal to 9 now, and $b has been set to 4.
// 
// In addition to the basic assignment operator, there are "combined
// operators" for all of the binary arithmetic and string operators that allow
// you to use a value in an expression and then set its value to the result of
// that expression. For example:
// 
// $a = 3;
// $a += 5; // sets $a to 8, as if we had said: $a = $a + 5;
// $b = "Hello ";
// $b .= "There!"; // sets $b to "Hello There!", just like $b = $b . "There!";
// 
// ------------------------------------------------------------------------
// Bitwise Operators
// 
// Bitwise operators allow you to turn specific bits within an integer on or
// off.
// 
// Table 10-2. Bitwise Operators
// 
//  example name        result
//  $a & $b And         Bits that are set in both $a and $b are set.
//  $a | $b Or          Bits that are set in either $a or $b are set.
//  $a ^ $b Xor         Bits that are set in $a or $b but not both are set.
//  ~ $a    Not         Bits that are set in $a are not set, and vice versa.
//  $a << $bShift left  Shift the bits of $a $b steps to the left (each step
//                      means "multiply by two")
//  $a >> $bShift right Shift the bits of $a $b steps to the right (each step
//                      means "divide by two")
//
// ------------------------------------------------------------------------
// Logical Operators
// 
// Table 10-3. Logical Operators
// 
//  example  name result
//  $a and $bAnd  True of both $a and $b are true.
//  $a or $b Or   True if either $a or $b is true.
//  $a xor $bOr   True if either $a or $b is true, but not both.
//  ! $a     Not  True if $a is not true.
//  $a && $b And  True of both $a and $b are true.
//  $a || $b Or   True if either $a or $b is true.
// 
// The reason for the two different variations of "and" and "or" operators is
// that they operate at different precedences. (See below.)
// 
// ------------------------------------------------------------------------
// Comparison Operators
// 
// Comparison operators, as their name imply, allow you to compare two values.
// 
// Table 10-4. Comparson Operators
// 
//  example name                      result
//  $a == $bEqual                     True if $a is equal to $b.
//  $a != $bNot equal                 True if $a is not equal to $b.
//  $a < $b Less than                 True if $a is strictly less than $b.
//  $a > $b Greater than              True if $a is strictly greater than $b.
//  $a <= $bLess than or equal to     True if $a is less than or equal to $b.
//  $a >= $bGreater than or equal to  True if $a is greater than or equal to
//                                    $b.
// 
// Another conditional operator is the "?:" (or trinary) operator, which
// operates as in C and many other languages.
// 
// (expr1) ? (expr2) : (expr3);
// 
// This expression returns to expr2 if expr1 evalutes to true, and expr3 if
// expr1 evaluates to false.
// 
// ------------------------------------------------------------------------
// Operator Precedence
// 
// The precedence of an operator specifies how "tightly" it binds two
// expressions together. For example, in the expression 1 + 5 * 3, the answer
// is 16 and not 18 because the multiplication ("*") operator has a higher
// precedence than the addition ("+") operator.
// 
// The following table lists the precedence of operators with the
// lowest-precedence operators listed first.
// 
// Table 10-5. Operator Precedence
// 
//  Associativity  Operators
//  left           ,
//  left           or
//  left           xor
//  left           and
//  right          print
//  left           = += -= *= /= .= %= &= != ~= <<= >>=
//  left           ? :
//  left           ||
//  left           &&
//  left           |
//  left           ^
//  left           &
//  non-associative== !=
//  non-associative< <= > >=
//  left           << >>
//  left           + - .
//  left           * / %
//  right          ! ~ ++ -- (int) (double) (string) (array) (object) @
//  right          [
//  non-associativenew
// 


//////////////////////////////////////////////////////////////////////////
//  Control Structures
//
// Any PHP script is built out of a series of statements. A statement can be
// an assignment, a function call, a loop, a conditional statement of even a
// statement that does nothing (an empty statement). Statements usually end
// with a semicolon. In addition, statements can be grouped into a
// statement-group by encapsulating a group of statements with curly braces. A
// statement-group is a statement by itself as well. The various statement
// types are described in this chapter.
// 
// ------------------------------------------------------------------------
// if
// 
// The if construct is one of the most important features of many languages,
// PHP included. It allows for conditional execution of code fragments. PHP
// features an if structure that is similar to that of C:
// 
//  if (expr)
//      statement
// 
// As described in the section about expressions, expr is evaluated to its
// truth value. If expr evaluates to TRUE, PHP will execute statement, and if
// it evaluates to FALSE - it'll ignore it.
// 
// The following example would display a is bigger than b if $a is bigger than
// $b:
// 
// if ($a > $b)
//     print "a is bigger than b";
// 
// Often you'd want to have more than one statement to be executed
// conditionally. Of course, there's no need to wrap each statement with an if
// clause. Instead, you can group several statements into a statement group.
// For example, this code would display a is bigger than b if $a is bigger
// than $b, and would then assign the value of $a into $b:
// 
// if ($a > $b) {
//     print "a is bigger than b";
//      $b = $a;
//  }
// 
// If statements can be nested indefinitely within other if statements, which
// provides you with complete flexibility for conditional execution of the
// various parts of your program.
// 
// ------------------------------------------------------------------------
// else
// 
// Often you'd want to execute a statement if a certain condition is met, and
// a different statement if the condition is not met. This is what else is
// for. else extends an if statement to execute a statement in case the
// expression in the if statement evaluates to FALSE. For example, the
// following code would display a is bigger than b if $a is bigger than $b,
// and a is NOT bigger than b otherwise:
// 
//  if ($a > $b) {
//      print "a is bigger than b";
//  } else {
//      print "a is NOT bigger than b";
//  }
// 
// The else statement is only executed if the if expression evaluated to
// FALSE, and if there were any elseif expressions - only if they evaluated to
// FALSE as well (see below).
// 
// ------------------------------------------------------------------------
// elseif
// 
// elseif, as its name suggests, is a combination of if and else. Like else,
// it extends an if statement to execute a different statement in case the
// original if expression evaluates to FALSE. However, unlike else, it will
// execute that alternative expression only if the elseif conditional
// expression evaluates to TRUE. For example, the following code would display
// a is bigger than b, a equal to b or a is smaller than b:
// 
//  if ($a > $b) {
//      print "a is bigger than b";
//  } elseif ($a == $b) {
//      print "a is equal to b";
//  } else {
//      print "a is smaller than b";
//  }
// 
// There may be several elseifs within the same if statement. The first elseif
// expression (if any) that evaluates to true would be executed. In PHP, you
// can also write 'else if' (in two words) and the behavior would be identical
// to the one of 'elseif' (in a single word). The syntactic meaning is
// slightly different (if you're familiar with C, this is the same behavior)
// but the bottom line is that both would result in exactly the same behavior.
// 
// The elseif statement is only executed if the preceding if expression and
// any preceding elseif expressions evaluated to FALSE, and the current elseif
// expression evaluated to TRUE.
// 
// ------------------------------------------------------------------------
// Alternative syntax for if structures: if(): ... endif;
// 
// PHP offers a different way to group statements within an if statement. This
// is most commonly used when you nest HTML blocks inside if statements, but
// can be used anywhere. Instead of using curly braces, if (expr) should be
// followed by a colon, the list of one or more statements, and end with
// endif;. Consider the following example:
// 
//  <?php if ($a==5): ?>
//  A = 5
//  <?php endif; ?>
// 
// In the above example, the HTML block "A = 5" is nested within an if
// statement written in the alternative syntax. The HTML block would be
// displayed only if $a is equal to 5.
// 
// The alternative syntax applies to else and elseif as well. The following is
// an if structure with elseif and else in the alternative format:
// 
//  if ($a == 5):
//      print "a equals 5";
//      print "...";
//  elseif ($a == 6):
//      print "a equals 6";
//      print "!!!";
//  else:
//      print "a is neither 5 nor 6";
//  endif;
// 
// ------------------------------------------------------------------------
// while
// 
// while loops are the simplest type of loop in PHP. They behave just like
// their C counterparts. The basic form of a while statement is:
// 
//  while (expr) statement
// 
// The meaning of a while statement is simple. It tells PHP to execute the
// nested statement(s) repeatedly, as long as the while expression evaluates
// to TRUE. The value of the expression is checked each time at the beginning
// of the loop, so even if this value changes during the execution of the
// nested statement(s), execution will not stop until the end of the iteration
// (each time PHP runs the statements in the loop is one iteration).
// Sometimes, if the while expression evaluates to FALSE from the very
// beginning, the nested statement(s) won't even be run once.
// 
// Like with the if statement, you can group multiple statements within the
// same while loop by surrounding a group of statements with curly braces, or
// by using the alternate syntax:
// 
//      while (expr): statement ... endwhile;
// 
// The following examples are identical, and both print numbers from 1 to 10:
// 
//  /* example 1 */
//  $i = 1;
//  while ($i <= 10) {
//      print $i++;  /* the printed value would be
//                      $i before the increment
//                      (post-increment) */
//  }
// 
//  /* example 2 */
//  $i = 1;
//  while ($i <= 10):
//      print $i;
//      $i++;
//  endwhile;
// 
// ------------------------------------------------------------------------
// do..while
// 
// do..while loops are very similar to while loops, except the truth
// expression is checked at the end of each iteration instead of in the
// beginning. The main difference from regular while loops is that the first
// iteration of a do..while loop is guarenteed to run (the truth expression is
// only checked at the end of the iteration), whereas it's may not necessarily
// run with a regular while loop (the truth expression is checked at the
// beginning of each iteration, if it evaluates to FALSE right from the
// beginning, the loop execution would end immediately).
// 
// There is just one syntax for do..while loops:
// 
//  $i = 0;
//  do {
//      print $i;
//  } while ($i>0);
// 
// The above loop would run one time exactly, since after the first iteration,
// when truth expression is checked, it evaluates to FALSE ($i is not bigger
// than 0) and the loop execution ends.
// 
// Advanced C users may be familiar with a different usage of the do..while
// loop, to allow stopping execution in the middle of code blocks, by
// encapsulating them with do..while(0), and using the break statement. The
// following code fragment demonstrates this:
// 
//  do {
//      if ($i < 5) {
//          print "i is not big enough";
//          break;
//      }
//      $i *= $factor;
//      if ($i < $minimum_limit) {
//          break;
//      }
//      print "i is ok";
//      ...process i...
//  } while(0);
// 
// Don't worry if you don't understand this right away or at all. You can code
// scripts and even powerful scripts without using this `feature'.
// 
// ------------------------------------------------------------------------
// for
// 
// for loops are the most complex loops in PHP. They behave like their C
// counterparts. The syntax of a for loop is:
// 
// for (expr1; expr2; expr3) statement
// 
// The first expression (expr1) is evaluated (executed) once unconditionally
// at the beginning of the loop.
// 
// In the beginning of each iteration, expr2 is evaluated. If it evaluates to
// TRUE, the loop continues and the nested statement(s) are executed. If it
// evaluates to FALSE, the execution of the loop ends.
// 
// At the end of each iteration, expr3 is evaluated (executed).
// 
// Each of the expressions can be empty. expr2 being empty means the loop
// should be run indefinitely (PHP implicitly considers it as TRUE, like C).
// This may not be as useless as you might think, since often you'd want to
// end the loop using a conditional break statement instead of using the for
// truth expression.
// 
// Consider the following examples. All of them display numbers from 1 to 10:
// 
//  /* example 1 */
//  for ($i = 1; $i <= 10; $i++) {
//      print $i;
//  }
// 
//  /* example 2 */
//  for ($i = 1;;$i++) {
//      if ($i > 10) {
//          break;
//      }
//      print $i;
//  }
// 
//  /* example 3 */
//  $i = 1;
//  for (;;) {
//      if ($i > 10) {
//          break;
//      }
//      print $i;
//      $i++;
//  }
// 
//  /* example 4 */
//  for ($i = 1; $i <= 10; print $i, $i++) ;
// 
// Of course, the first example appears to be the nicest one (or perhaps the
// fourth), but you may find that being able to use empty expressions in for
// loops comes in handy in many occasions.
// 
// PHP also supports the alternate "colon syntax" for for loops.
// 
//  for (expr1; expr2; expr3): statement; ...; endfor;
// 
// Other languages have a foreach statement to traverse an array or hash. PHP
// uses the while statement and the list() and each() functions for this. See
// the documentation for these functions for an example.
// 
// ------------------------------------------------------------------------
// break
// 
// break breaks out of the current looping control-structures.
// 
//  $i = 0;
//  while ($i < 10) {
//      if ($arr[$i] == "stop") {
//          break;
//      }
//      $i++;
//  }
// 
// ------------------------------------------------------------------------
// continue
// 
// continue is used within looping structures to skip the rest of the current
// loop iteration and continue execution at the beginning of the next
// iteration.
// 
//  while (list($key,$value) = each($arr)) {
//      if ($key % 2) { // skip even members
//          continue;
//      }
//      do_something_odd ($value);
//  }
// 
// 
// ------------------------------------------------------------------------
// switch
// 
// The switch statement is similar to a series of IF statements on the same
// expression. In many occasions, you may want to compare the same variable
// (or expression) with many different values, and execute a different piece
// of code depending on which value it equals to. This is exactly what the
// switch statement is for.
// 
// The following two examples are two different ways to write the same thing,
// one using a series of if statements, and the other using the switch
// statement:
// 
//  if ($i == 0) {
//      print "i equals 0";
//  }
//  if ($i == 1) {
//      print "i equals 1";
//  }
//  if ($i == 2) {
//      print "i equals 2";
//  }
// 
//  switch ($i) {
//      case 0:
//          print "i equals 0";
//          break;
//      case 1:
//          print "i equals 1";
//          break;
//      case 2:
//          print "i equals 2";
//          break;
//  }
// 
// It is important to understand how the switch statement is executed in order
// to avoid mistakes. The switch statement executes line by line (actually,
// statement by statement). In the beginning, no code is executed. Only when a
// case statement is found with a value that matches the value of the switch
// expression does PHP begin to execute the statements. PHP continues to
// execute the statements until the end of the switch block, or the first time
// it sees a break statement. If you don't write a break statement at the end
// of a case's statement list, PHP will go on executing the statements of the
// following case. For example:
// 
//  switch ($i) {
//      case 0:
//          print "i equals 0";
//      case 1:
//          print "i equals 1";
//      case 2:
//          print "i equals 2";
//  }
// 
// Here, if $i equals to 0, PHP would execute all of the print statements! If
// $i equals to 1, PHP would execute the last two print statements, and only
// if $i equals to 2, you'd get the 'expected' behavior and only 'i equals 2'
// would be displayed. So, it's important not to forget break statements (even
// though you may want to avoid supplying them on purpose under certain
// circumstances).
// 
// The statement list for a case can also be empty, which simply passes
// control into the statement list for the next case.
// 
//  switch ($i) {
//      case 0:
//      case 1:
//      case 2:
//          print "i is less than 3 but not negative";
//          break;
//      case 3:
//          print "i is 3";
//  }
// 
// A special case is the default case. This case matches anything that wasn't
// matched by the other cases. For example:
// 
//  switch ($i) {
//      case 0:
//          print "i equals 0";
//          break;
//      case 1:
//          print "i equals 1";
//          break;
//      case 2:
//          print "i equals 2";
//          break;
//      default:
//          print "i is not equal to 0, 1 or 2";
//  }
// 
// The case expression may be any expression that evaluates to a scalar type,
// that is, integer or floating-point numbers and strings. Arrays or objects
// are meaningless in that context.
// 
// ------------------------------------------------------------------------
// require
// 
// The require statement replaces itself with the specified file, much like
// the C preprocessor's #include works.
// 
// This means that you can't put a require statement inside of a loop
// structure and expect it to include the contents of a different file on each
// iteration. To do that, use an include statement.
// 
// require 'header.inc';
// 
// ------------------------------------------------------------------------
// include
// 
// The include statement includes and evaluates the specified file.
// 
// This happens each time the include statement is encountered, so you can use
// an include statement within a looping structure to include a number of
// different file.
// 
//  $files = array ('first.inc', 'second.inc', 'third.inc');
//  for ($i = 0; $i < count($files); $i++) {
//      include $files[$i];
//  }
// 
// 
// include differs from require in that the include statement is re-evaluated
// each time it is encountered (and only when it is being executed), whereas
// the require statement is replaced by the required file when it is first
// encountered, whether the contents of the file will be evaluated or not (for
// example, if it is inside an if statement whose condition evaluated to
// false).
// 
// Because include is a special language construct, you must enclose it within
// a statement block if it is inside a conditional block.
// 
//  /* This is WRONG and will not work as desired. */
//  if ($condition)
//      include($file);
//  else
//      include($other);
// 
//  /* This is CORRECT. */
//  if ($condition) {
//      include($file);
//  } else {
//      include($other);
//  }
// 
// When the file is evaluated, the parser begins in "HTML-mode" which will
// output the contents of the file until the first PHP start tag (<?) is
// encountered.
// 
// See also readfile(), require(), virtual().
// 


//////////////////////////////////////////////////////////////////////////
// User-defined Functions
// 
// A function may be defined using syntax such as the following:
// 
// function foo ($arg_1, $arg_2, ..., $arg_n) {
//     echo "Example function.\n";
//     return $retval;
// }
// 
// Any valid PHP code may appear inside a function, even other functions and
// class definitions.
// 
// Functions must be defined before they are referenced.
// 
// ------------------------------------------------------------------------
// Returning values
// 
// Values are returned by using the optional return statement. Any type may be
// returned, including lists and objects.
// 
// function square ($num) {
//     return $num * $num;
// }
// echo square (4);   // outputs '16'.
// 
// You can't return multiple values from a function, but similar results can
// be obtained by returning a list.
// 
// function small_numbers() {
//    return array (0, 1, 2);
// }
// list ($zero, $one, $two) = small_numbers();
// 
// ------------------------------------------------------------------------
// Function arguments
// 
// Information may be passed to functions via the argument list, which is a
// comma-delimited list of variables and/or constants.
// 
// PHP supports passing arguments by value (the default), passing by
// reference, and default argument values. Variable-length argument lists are
// not supported, but a similar effect may be obtained by passing arrays.
// 
// function takes_array($input) {
//     echo "$input[0] + $input[1] = ", $input[0]+$input[1];
// }
// 
// ------------------------------------------------------------------------
// Making arguments be passed by reference
// 
// By default, function arguments are passed by value (so that if you change
// the value of the argument within the function, it does not get changed
// outside of the function). If you wish to allow a function to modify its
// arguments, you must pass them by reference.
// 
// If you want an argument to a function to always be passed by reference, you
// can prepend an ampersand (&) to the argument name in the function
// definition:
// 
// function add_some_extra(&$string) {
//     $string .= 'and something extra.';
// }
// $str = 'This is a string, ';
// add_some_extra($str);
// echo $str;    // outputs 'This is a string, and something extra.'
// 
// If you wish to pass a variable by reference to a function which does not do
// this by default, you may prepend an ampersand to the argument name in the
// function call:
// 
// function foo ($bar) {
//     $bar .= ' and something extra.';
// }
// $str = 'This is a string, ';
// foo ($str);
// echo $str;    // outputs 'This is a string, '
// foo (&$str);
// echo $str;    // outputs 'This is a string, and something extra.'
// 
// ------------------------------------------------------------------------
// Default argument values
// 
// A function may define C++-style default values for scalar arguments as
// follows:
// 
// function makecoffee ($type = "cappucino") {
//     return "Making a cup of $type.\n";
// }
// echo makecoffee ();
// echo makecoffee ("espresso");
// 
// The output from the above snippet is:
// 
// Making a cup of cappucino.
// Making a cup of espresso.
// 
// The default value must be a constant expression, not (for example) a
// variable or class member.
// 
// In PHP 4.0 it's also possible to specify unset for default argument. This
// means that the argument will not be set at all, if a value is not supplied.
// 
// Note that when using default arguments, any defaults should be on the right
// side of any non-default arguments; otherwise, things will not work as
// expected. Consider the following code snippet:
// 
// function makeyogurt ($type = "acidophilus", $flavour) {
//     return "Making a bowl of $type $flavour.\n";
// }
// 
// echo makeyogurt ("raspberry");   // won't work as expected
// 
// The output of the above example is:
// 
// Warning: Missing argument 2 in call to makeyogurt() in
// /usr/local/etc/httpd/htdocs/php3test/functest.html on line 41
// Making a bowl of raspberry .
// 
// Now, compare the above with this:
// 
// function makeyogurt ($flavour, $type = "acidophilus") {
//     return "Making a bowl of $type $flavour.\n";
// }
// echo makeyogurt ("raspberry");   // works as expected
// 
// The output of this example is:
// 
// Making a bowl of acidophilus raspberry.
// 
// ------------------------------------------------------------------------
// old_function
// 
// The old_function statement allows you to declare a function using a syntax
// identical to PHP/FI2 (except you must replace 'function' with
// 'old_function'.
// 
// This is a deprecated feature, and should only be used by the PHP/FI2->PHP3
// convertor.
// 
//                                   Warning
//  Functions declared as old_function cannot be called from PHP's internal
//  code. Among other things, this means you can't use them in functions such
//  as usort(), array_walk(), and register_shutdown_function(). You can get
//  around this limitation by writing a wrapper function (in normal PHP3
//  form) to call the old_function.
// 


//////////////////////////////////////////////////////////////////////////
// Classes and Objects
// 
// A class is a collection of variables and functions working with these
// variables. A class is defined using the following syntax:
// 
//  <?php
//  class Cart {
//      var $items;  // Items in our shopping cart
// 
//      // Add $num articles of $artnr to the cart
// 
//      function add_item ($artnr, $num) {
//          $this->items[$artnr] += $num;
//      }
// 
//      // Take $num articles of $artnr out of the cart
// 
//      function remove_item ($artnr, $num) {
//          if ($this->items[$artnr] > $num) {
//              $this->items[$artnr] -= $num;
//              return true;
//          } else {
//              return false;
//          }
//      }
//  }
//  ?>
// 
// This defines a class named Cart that consists of an associative array of
// articles in the cart and two functions to add and remove items from this
// cart.
// 
// Classes are types, that is, they are blueprints for actual variables. You
// have to create a variables of the desired type with the new operator.
// 
//  $cart = new Cart;
//  $cart->add_item("10", 1);
// 
// This creates an object $cart of the class Cart. The function add_item() of
// that object is being called to add 1 item of article number 10 to the cart.
// 
// Classes can be extensions of other classes. The extended or derived class
// has all variables and functions of the base class and what you add in the
// extended definition. This is done using the extends keyword.
// 
//  class Named_Cart extends Cart {
//      var $owner;
// 
//      function set_owner ($name) {
//          $this->owner = $name;
//      }
//  }
// 
// This defines a class Named_Cart that has all variables and functions of
// Cart plus an additional variable $owner and an additional function
// set_owner(). You create a named cart the usual way and can now set and get
// the carts owner. You can still use normal cart functions on named carts:
// 
//  $ncart = new Named_Cart;    // Create a named cart
//  $ncart->set_owner ("kris"); // Name that cart
//  print $ncart->owner;        // print the cart owners name
//  $ncart->add_item ("10", 1); // (inherited functionality from cart)
// 
// Within functions of a class the variable $this means this object. You have
// to use $this->something to access any variable or function named something
// within your current object.
// 
// Constructors are functions in a class that are automatically called when
// you create a new instance of a class. A function becomes a constructor when
// it has the same name as the class.
// 
//  class Auto_Cart extends Cart {
//      function Auto_Cart () {
//          $this->add_item ("10", 1);
//      }
//  }
// 
// This defines a class Auto_Cart that is a Cart plus a constructor which
// initializes the cart with one item of article number "10" each time a new
// Auto_Cart is being made with "new". Constructors can also take arguments
// and these arguments can be optional, which makes them much more useful.
// 
//  class Constructor_Cart {
//      function Constructor_Cart ($item = "10", $num = 1) {
//          $this->add_item ($item, $num);
//      }
//  }
//  // Shop the same old boring stuff.
//  $default_cart   = new Constructor_Cart;
//  // Shop for real...
//  $different_cart = new Constructor_Cart ("20", 17);
// 
//                                   Caution
// For derived classes, the constructor of the parent class is not
// automatically called when the derived class's constructor is called.
//

//////////////////////////////////////////////////////////////////////////
// Error handling
//
// There are 4 types of errors and warnings in PHP. They are:
// 
//   1 - Normal Function Errors
//   2 - Normal Warnings
//   4 - Parser Errors
//   8 - Notices (warnings you can ignore but which may imply a bug in your code)
// 
// The above 4 numbers are added up to define an error reporting level. The
// default error reporting level is 7 which is 1 + 2 + 4, or everything except
// notices. This level can be changed in the php3.ini file with the
// error_reporting directive. It can also be set in your Apache httpd.conf
// file with the php3_error_reporting directive or lastly it may be set at
// runtime within a script using the error_reporting() function.
// 
// All PHP expressions can also be called with the "@" prefix, which turns off
// error reporting for that particular expression. If an error occurred during
// such an expression and the track_errors feature is enabled, you can find
// the error message in the global variable $php_errormsg.
//


//////////////////////////////////////////////////////////////////////////
// Creating GIF images
// 
// PHP is not limited to creating just HTML output. It can also be used to
// create GIF image files, or even more convenient GIF image streams. You will
// need to compile PHP with the GD library of image functions for this to
// work.
// 
// Example 15-1. GIF creation with PHP
// 
// <?php
//     Header("Content-type: image/gif");
//     $string=implode($argv," ");
//     $im = imagecreatefromgif("images/button1.gif");
//     $orange = ImageColorAllocate($im, 220, 210, 60);
//     $px = (imagesx($im)-7.5*strlen($string))/2;
//     ImageString($im,3,$px,9,$string,$orange);
//     ImageGif($im);
//     ImageDestroy($im);
// ?>
// 
// This example would be called from a page with a tag like: <img
// src="button.php3?text"> The above button.php3 script then takes this "text"
// string an overlays it on top of a base image which in this case is
// "images/button1.gif" and outputs the resulting image. This is a very
// convenient way to avoid having to draw new button images every time you
// want to change the text of a button. With this method they are dynamically
// generated.
//


//////////////////////////////////////////////////////////////////////////
// HTTP Authentication
// 
// The HTTP Authentication hooks in PHP are only available when it is running
// as an Apache module and is hence not available in the CGI version. In an
// Apache module PHP script, it is possible to use the Header() function to
// send an "Authentication Required" message to the client browser causing it
// to pop up a Username/Password input window. Once the user has filled in a
// username and a password, the URL containing the PHP script will be called
// again with the variables, $PHP_AUTH_USER, $PHP_AUTH_PW and $PHP_AUTH_TYPE
// set to the user name, password and authentication type respectively. Only
// "Basic" authentication is supported at this point. See the Header()
// function for more information.
// 
// An example script fragment which would force client authentication on a
// page would be the following:
// Example 16-1. HTTP Authentication example
// 
// <?php
//   if(!isset($PHP_AUTH_USER)) {
//     Header("WWW-Authenticate: Basic realm=\"My Realm\"");
//     Header("HTTP/1.0 401 Unauthorized");
//     echo "Text to send if user hits Cancel button\n";
//     exit;
//   } else {
//     echo "Hello $PHP_AUTH_USER.<P>";
//     echo "You entered $PHP_AUTH_PW as your password.<P>";
//   }
// ?>
// 
// Instead of simply printing out the $PHP_AUTH_USER and $PHP_AUTH_PW, you
// would probably want to check the username and password for validity.
// Perhaps by sending a query to a database, or by looking up the user in a
// dbm file.
// 
// Watch out for buggy Internet Explorer browsers out there. They seem very
// picky about the order of the headers. Sending the WWW-Authenticate header
// before the HTTP/1.0 401 header seems to do the trick for now.
// 
// In order to prevent someone from writing a script which reveals the
// password for a page that was authenticated through a traditional external
// mechanism, the PHP_AUTH variables will not be set if external
// authentication is enabled for that particular page. In this case, the
// $REMOTE_USER variable can be used to identify the externally-authenticated
// user.
// 
// Note, however, that the above does not prevent someone who controls a
// non-authenticated URL from stealing passwords from authenticated URLs on
// the same server.
// 
// Both Netscape and Internet Explorer will clear the local browser window's
// authentication cache for the realm upon receiving a server response of 401.
// This can effectively "log out" a user, forcing them to re-enter their
// username and password. Some people use this to "time out" logins, or
// provide a "log-out" button.
// 
// Example 16-2. HTTP Authentication example forcing a new name/password
// 
// <?php
//   function  authenticate()  {
//     Header( "WWW-authenticate:  basic  realm='Test  Authentication  System'");
//     Header( "HTTP/1.0  401  Unauthorized");
//     echo  "You  must  enter  a  valid  login  ID  and  password  to  access  this  resource\n";
//     exit;
//   }
// 
//   if(!isset($PHP_AUTH_USER)  ||  ($SeenBefore ==  1  &&  !strcmp($OldAuth,  $PHP_AUTH_USER))  )  {
//     authenticate();
//   }
//   else  {
//     echo  "Welcome:  $PHP_AUTH_USER<BR>";
//     echo  "Old:  $OldAuth";
//     echo  "<FORM  ACTION=\"$PHP_SELF\"  METHOD=POST>\n";
//     echo  "<INPUT  TYPE=HIDDEN  NAME=\"SeenBefore\"  VALUE=\"1\">\n";
//     echo  "<INPUT  TYPE=HIDDEN  NAME=\"OldAuth\"  VALUE=\"$PHP_AUTH_USER\">\n";
//     echo  "<INPUT  TYPE=Submit  VALUE=\"Re  Authenticate\">\n";
//     echo  "</FORM>\n";
// }
// ?>
// 
// This behavior is not required by the HTTP Basic authentication standard, so
// you should never depend on this. Testing with Lynx has shown that Lynx does
// not clear the authentication credentials with a 401 server response, so
// pressing back and then forward again will open the resource (as long as the
// credential requirements haven't changed).
// 
// Also note that this does not work using Microsoft's IIS server and the CGI
// version of PHP due to a limitation of IIS.
//


//////////////////////////////////////////////////////////////////////////
// Cookies
//
// PHP transparently supports HTTP cookies. Cookies are a mechanism for
// storing data in the remote browser and thus tracking or identifying return
// users. You can set cookies using the setcookie() function. Cookies are part
// of the HTTP header, so setcookie() must be called before any output is sent
// to the browser. This is the same limitation that header() has.
// 
// Any cookies sent to you from the client will automatically be turned into a
// PHP variable just like GET and POST method data. If you wish to assign
// multiple values to a single cookie, just add [] to the cookie name. For
// more details see the setcookie() function.
// 
// ------------------------------------------------------------------------
// Handling file uploads
// 
// POST method uploads
// 
// PHP is capable of receiving file uploads from any RFC-1867 compliant
// browser (which includes Netscape Navigator 3 or later, Microsoft Internet
// Explorer 3 with a patch from Microsoft, or later without a patch). This
// feature lets people upload both text and binary files. With PHP's
// authentication and file manipulation functions, you have full control over
// who is allowed to upload and what is to be done with the file once it has
// been uploaded.
// 
// Note that PHP also supports PUT-method file uploads as used by Netscape
// Composer and W3C's Amaya clients. See the PUT Method Support for more
// details.
// 
// A file upload screen can be built by creating a special form which looks
// something like this:
// Example 18-1. File Upload Form
// 
// <FORM ENCTYPE="multipart/form-data" ACTION="_URL_" METHOD=POST>
// <INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="1000">
// Send this file: <INPUT NAME="userfile" TYPE="file">
// <INPUT TYPE="submit" VALUE="Send File">
// </FORM>
// 
// The _URL_ should point to a PHP file. The MAX_FILE_SIZE hidden field must
// precede the file input field and its value is the maximum filesize
// accepted. The value is in bytes. In this destination file, the following
// variables will be defined upon a successful upload:
// 
//    * $userfile - The temporary filename in which the uploaded file was
//      stored on the server machine.
// 
//    * $userfile_name - The original name of the file on the sender's system.
// 
//    * $userfile_size - The size of the uploaded file in bytes.
// 
//    * $userfile_type - The mime type of the file if the browser provided
//      this information. An example would be "image/gif".
// 
// Note that the "$userfile" part of the above variables is whatever the name
// of the INPUT field of TYPE=file is in the upload form. In the above upload
// form example, we chose to call it "userfile".
// 
// Files will by default be stored in the server's default temporary
// directory. This can be changed by setting the environment variable TMPDIR
// in the environment in which PHP runs. Setting it using putenv() from within
// a PHP script will not work.
// 
// The PHP script which receives the uploaded file should implement whatever
// logic is necessary for determining what should be done with the uploaded
// file. You can for example use the $file_size variable to throw away any
// files that are either too small or too big. You could use the $file_type
// variable to throw away any files that didn't match a certain type criteria.
// Whatever the logic, you should either delete the file from the temporary
// directory or move it elsewhere.
// 
// The file will be deleted from the temporary directory at the end of the
// request if it has not been moved away or renamed.
// 
// ------------------------------------------------------------------------
// Common Pitfalls
// 
// The MAX_FILE_SIZE item cannot specify a file size greater than the file
// size that has been set in the upload_max_filesize in the PHP3.ini file or
// the corresponding php3_upload_max_filesize Apache .conf directive. The
// default is 2 Megabytes.
// 
// Please note that the CERN httpd seems to strip off everything starting at
// the first whitespace in the content-type mime header it gets from the
// client. As long as this is the case, CERN httpd will not support the file
// upload feature.
// 
// ------------------------------------------------------------------------
// Uploading multiple files
// 
// It is possible to upload multiple files simultaneously and have the
// information organized automatically in arrays for you. To do so, you need
// to use the same array submission syntax in the HTML form as you do with
// multiple selects and checkboxes:
// 
//      Note: Support for multiple file uploads was added in version
//      3.0.10.
// 
// Example 18-2. Uploading multiple forms
// 
// <form action="file-upload.html" method="post" enctype="multipart/form-data">
//   Send these files:<br>
//   <input name="userfile[]" type="file"><br>
//   <input name="userfile[]" type="file"><br>
//   <input type="submit" value="Send files">
// </form>
// 
// When the above form is submitted, the arrays $userfile, $userfile_name, and
// $userfile_size will be formed in the global scope (as well as in
// $HTTP_POST_VARS). Each of these will be a numerically indexed array of the
// appropriate values for the submitted files.
// 
// For instance, assume that the filenames /home/test/review.html and
// /home/test/xwp.out are submitted. In this case, $userfile_name[0] would
// contain the value review.html, and $userfile_name[1] would contain the
// value xwp.out. Similarly, $userfile_size[0] would contain review.html's
// filesize, and so forth.
// 
// ------------------------------------------------------------------------
// PUT method support
// 
// PHP provides support for the HTTP PUT method used by clients such as
// Netscape Composer and W3C Amaya. PUT requests are much simpler than a file
// upload and they look something like this:
// 
// PUT /path/filename.html HTTP/1.1
// 
// This would normally mean that the remote client would like to save the
// content that follows as: /path/filename.html in your web tree. It is
// obviously not a good idea for Apache or PHP to automatically let everybody
// overwrite any files in your web tree. So, to handle such a request you have
// to first tell your web server that you want a certain PHP script to handle
// the request. In Apache you do this with the Script directive. It can be
// placed almost anywhere in your Apache configuration file. A common place is
// inside a <Directory> block or perhaps inside a <Virtualhost> block. A line
// like this would do the trick:
// 
// Script PUT /put.php3
// 
// This tells Apache to send all PUT requests for URIs that match the context
// in which you put this line to the put.php3 script. This assumes, of course,
// that you have PHP enabled for the .php3 extension and PHP is active.
// 
// Inside your put.php3 file you would then do something like this:
// 
// <? copy($PHP_UPLOADED_FILE_NAME,$DOCUMENT_ROOT.$REQUEST_URI); ?>
// 
// This would copy the file to the location requested by the remote client.
// You would probably want to perform some checks and/or authenticate the user
// before performing this file copy. The only trick here is that when PHP sees
// a PUT-method request it stores the uploaded file in a temporary file just
// like those handled bu the POST-method. When the request ends, this
// temporary file is deleted. So, your PUT handling PHP script has to copy
// that file somewhere. The filename of this temporary file is in the
// $PHP_PUT_FILENAME variable, and you can see the suggested destination
// filename in the $REQUEST_URI (may vary on non-Apache web servers). This
// destination filename is the one that the remote client specified. You do
// not have to listen to this client. You could, for example, copy all
// uploaded files to a special uploads directory.
//

//////////////////////////////////////////////////////////////////////////
// Using remote files
//
// As long as support for the "URL fopen wrapper" is enabled when you
// configure PHP (which it is unless you explicitly pass the
// --disable-url-fopen-wrapper flag to configure), you can use HTTP and FTP
// URLs with most functions that take a filename as a parameter, including the
// require() and include() statements.
// 
//      Note: You can't use remote files in include() and require()
//      statements on Windows.
// 
// For example, you can use this to open a file on a remote web server, parse
// the output for the data you want, and then use that data in a database
// query, or simply to output it in a style matching the rest of your website.
// 
// Example 19-1. Getting the title of a remote page
// 
// <?php
//   $file = fopen("http://www.php.net/", "r");
//   if (!$file) {
//     echo "<p>Unable to open remote file.\n";
//     exit;
//   }
//   while (!feof($file)) {
//     $line = fgets($file, 1024);
//     /* This only works if the title and its tags are on one line. */
//     if (eregi("<title>(.*)</title>", $line, $out)) {
//       $title = $out[1];
//       break;
//     }
//   }
//   fclose($file);
// ?>
// 
// You can also write to files on an FTP as long you connect as a user with
// the correct access rights, and the file doesn't exist already. To connect
// as a user other than 'anonymous', you need to specify the username (and
// possibly password) within the URL, such as
// 'ftp://user:password@ftp.example.com/path/to/file'. (You can use the same
// sort of syntax to access files via HTTP when they require Basic
// authentication.)
//
// Example 19-2. Storing data on a remote server
// 
// <?php
//   $file = fopen("ftp://ftp.php.net/incoming/outputfile", "w");
//   if (!$file) {
//     echo "<p>Unable to open remote file for writing.\n";
//     exit;
//   }
//   /* Write the data here. */
//   fputs($file, "$HTTP_USER_AGENT\n");
//   fclose($file);
// ?>
// 
// Note: You might get the idea from the example above to use this
// technique to write to a remote log, but as mentioned above, you
// can only write to a new file using the URL fopen() wrappers. To
// do distributed logging like that, you should take a look at
// syslog().
//


//////////////////////////////////////////////////////////////////////////
// Connection handling
//
// Note: The following applies to 3.0.7 and later.
// 
// Internally in PHP a connection status is maintained. There are 3 possible
// states:
// 
//    * 0 - NORMAL
//    * 1 - ABORTED
//    * 2 - TIMEOUT
// 
// When a PHP script is running normally the NORMAL state, is active. If the
// remote client disconnects the ABORTED state flag is turned on. A remote
// client disconnect is usually caused by the user hitting his STOP button. If
// the PHP-imposed time limit (see set_time_limit()) is hit, the TIMEOUT state
// flag is turned on.
// 
// You can decide whether or not you want a client disconnect to cause your
// script to be aborted. Sometimes it is handy to always have your scripts run
// to completion even if there is no remote browser receiving the output. The
// default behaviour is however for your script to be aborted when the remote
// client disconnects. This behaviour can be set via the ignore_user_abort
// php3.ini directive as well as through the corresponding
// php3_ignore_user_abort Apache .conf directive or with the
// ignore_user_abort() function. If you do not tell PHP to ignore a user abort
// and the user aborts, your script will terminate. The one exception is if
// you have registered a shutdown function using register_shutdown_function().
// With a shutdown function, when the remote user hits his STOP button, the
// next time your script tries to output something PHP will detect that the
// connection has been aborted and the shutdown function is called. This
// shutdown function will also get called at the end of your script
// terminating normally, so to do something different in case of a client
// diconnect you can use the connection_aborted() function. This function will
// return true if the connection was aborted.
// 
// Your script can also be terminated by the built-in script timer. The
// default timeout is 30 seconds. It can be changed using the
// max_execution_time php3.ini directive or the corresponding
// php3_max_execution_time Apache .conf directive as well as with the
// set_time_limit() function. When the timer expires the script will be
// aborted and as with the above client disconnect case, if a shutdown
// function has been registered it will be called. Within this shutdown
// function you can check to see if a timeout caused the shutdown function to
// be called by calling the connection_timeout() function. This function will
// return true if a timeout caused the shutdown function to be called.
// 
// One thing to note is that both the ABORTED and the TIMEOUT states can be
// active at the same time. This is possible if you tell PHP to ignore user
// aborts. PHP will still note the fact that a user may have broken the
// connection, but the script will keep running. If it then hits the time
// limit it will be aborted and your shutdown function, if any, will be
// called. At this point you will find that connection_timeout() and
// connection_aborted() return true. You can also check both states in a
// single call by using the connection_status(). This function returns a
// bitfield of the active states. So, if both states are active it would
// return 3, for example.
//


//////////////////////////////////////////////////////////////////////////
// Persistent database connections
//
// Persistent connections are SQL links that do not close when the execution
// of your script ends. When a persistent connection is requested, PHP checks
// if there's already an identical persistent connection (that remained open
// from earlier) - and if it exists, it uses it. If it does not exist, it
// creates the link. An 'identical' connection is a connection that was opened
// to the same host, with the same username and the same password (where
// applicable).
// 
// People who aren't thoroughly familiar with the way web servers work and
// distribute the load may mistake persistent connects for what they're not.
// In particular, they do not give you an ability to open 'user sessions' on
// the same SQL link, they do not give you an ability to build up a
// transaction efficently, and they don't do a whole lot of other things. In
// fact, to be extremely clear about the subject, persistent connections don't
// give you any functionality that wasn't possible with their non-persistent
// brothers.
// 
// Why?
// 
// This has to do with the way web servers work. There are three ways in which
// your web server can utilize PHP to generate web pages.
// 
// The first method is to use PHP as a CGI "wrapper". When run this way, an
// instance of the PHP interpreter is created and destroyed for every page
// request (for a PHP page) to your web server. Because it is destroyed after
// every request, any resources that it acquires (such as a link to an SQL
// database server) are closed when it is destroyed. In this case, you do not
// gain anything from trying to use persistent connections -- they simply
// don't persist.
// 
// The second, and most popular, method is to run PHP as a module in a
// multiprocess web server, which currently only includes Apache. A
// multiprocess server typically has one process (the parent) which
// coordinates a set of processes (its children) who actually do the work of
// serving up web pages. When each request comes in from a a client, it is
// handed off to one of the children that is not already serving another
// client. This means that when the same client makes a second request to the
// server, it may be serviced by a different child process than the first
// time. What a persistent connection does for you in this case it make it so
// each child process only needs to connect to your SQL server the first time
// that it serves a page that makes us of such a connection. When another page
// then requires a connection to the SQL server, it can reuse the connection
// that child established earlier.
// 
// The last method is to use PHP as a plug-in for a multithreaded web server.
// Currently this is only theoretical -- PHP does not yet work as a plug-in
// for any multithreaded web servers. Work is progressing on support for
// ISAPI, WSAPI, and NSAPI (on Windows), which will all allow PHP to be used
// as a plug-in on multithreaded servers like Netscape FastTrack, Microsoft's
// Internet Information Server (IIS), and O'Reilly's WebSite Pro. When this
// happens, the behavior will be essentially the same as for the multiprocess
// model described before.
// 
// If persistent connections don't have any added functionality, what are they
// good for?
// 
// The answer here is extremely simple -- efficiency. Persistent connections
// are good if the overhead to create a link to your SQL server is high.
// Whether or not this overhead is really high depends on many factors. Like,
// what kind of database it is, whether or not it sits on the same computer on
// which your web server sits, how loaded the machine the SQL server sits on
// is and so forth. The bottom line is that if that connection overhead is
// high, persistent connections help you considerably. They cause the child
// process to simply connect only once for its entire lifespan, instead of
// every time it processes a page that requires connecting to the SQL server.
// This means that for every child that opened a persistent connection will
// have its own open persistent connection to the server. For example, if you
// had 20 different child processes that ran a script that made a persistent
// connection to your SQL server, you'd have 20 different connections to the
// SQL server, one from each child.
// 
// An important summary. Persistent connections were designed to have
// one-to-one mapping to regular connections. That means that you should
// always be able to replace persistent connections with non-persistent
// connections, and it won't change the way your script behaves. It may (and
// probably will) change the efficiency of the script, but not its behavior!
//


///////////////////////////////////////////////////////////////////////////
// Adabas D functions
//
// The Adabas D functions are deprecated, you probably want to use the
// Unified ODBC functions instead.

/**
 * fetch a result row into an array
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_fetch_into()
 */
function ada_afetch();

/**
 * toggle autocommit behaviour
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_autocommit()
 */
function ada_autocommit();

/**
 * close a connection to an Adabas D server
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_close()
 */
function ada_close();

/**
 * commit a transaction
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_commit()
 */
function ada_commit();

/**
 * connect to an Adabas D datasource
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_connect()
 */
function ada_connect();

/**
 * prepare and execute a SQL statement
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_connect()
 */
function ada_do();

/**
 * fetch a row from a result
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_fetch_row()
 */
function ada_fetchrow();

/**
 * get the column name
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_field_name()
 */
function ada_fieldname();

/**
 * get the column number
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_field_num()
 */
function ada_fieldnum();

/**
 * get the datatype of a field
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_field_type()
 */
function ada_fieldtype();

/**
 * free resources associated with a result
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_free_result()
 */
function ada_freeresult();

/**
 * get the number of columns in a result
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_num_fields()
 */
function ada_numfields();

/**
 * get the number of rows in a result
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_num_rows()
 */
function ada_numrows();

/**
 * get data from results
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_result()
 */
function ada_result();

/**
 * print result as HTML table
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_result_all()
 */
function ada_resultall();

/**
 * rollback a transaction
 *
 * @deprecated use the Unified ODBC functions instead.
 * @see        odbc_rollback()
 */
function ada_rollback();

 
///////////////////////////////////////////////////////////////////////////
// Apache-specific functions
//
 
/**
 * Perform a partial request for the specified URI and return all info about it
 * <p>
 * This performs a partial request for a URI. It goes just far enough to
 * obtain all the important information about the given resource and returns
 * this information in a class. The properties of the returned class are:
 * <ul>
 * <li>status
 * <li>the_request
 * <li>status_line
 * <li>method
 * <li>content_type
 * <li>handler
 * <li>uri
 * <li>filename
 * <li>path_info
 * <li>args
 * <li>boundary
 * <li>no_cache
 * <li>no_local_copy
 * <li>allowed
 * <li>send_bodyct
 * <li>bytes_sent
 * <li>byterange
 * <li>clength
 * <li>unparsed_uri
 * <li>mtime
 * <li>request_time
 * </ul>
 * <b>Note:</b>
 * apache_lookup_uri only works when PHP is installed as
 * an Apache module
 */
function object apache_lookup_uri(string filename);
 
/**
 * Get and set apache request notes
 * <p>
 * apache_note() is an Apache-specific function which gets and sets values in
 * a request's notes table. If called with one argument, it returns the
 * current value of note note_name. If called with two arguments, it sets the
 * value of note note_name to note_value and returns the previous value of
 * note note_name.
 */
function string apache_note(string note_name, string [note_value]);
 
/**
 * Fetch all HTTP request headers
 * <p>
 * This function returns an associative array of all the HTTP headers in the
 * current request.
 * <p>
 * <b>Note:</b>
 * You can also get at the value of the common CGI variables
 * by reading them from the environment, which works whether or not
 * you are using PHP as an Apache module. Use {@link phpinfo()} to see a
 * list of all of the environment variables defined this way.
 * <p>
 * <b>Example 1.</b> getallheaders() Example
 * <pre>
 *    $headers = getallheaders();
 *    while (list($header, $value) = each($headers)) {
 *        echo "$header: $value&lt;br&gt;\n";
 *    }
 * </pre>
 * This example will display all the request headers for the current request.
 * <p>
 * <b>Note:</b>
 * getallheaders() is currently only supported when PHP runs
 * as an Apache module.
 *
 * @return array of headers
 */
function array getallheaders(void);
 
/**
 * Perform an Apache sub-request
 * <p>
 * virtual() is an Apache-specific function which is equivalent to
 * &lt;!--#include virtual...--&gt; in mod_include. It performs an Apache
 * sub-request. It is useful for including CGI scripts or .shtml files, or
 * anything else that you would parse through Apache. Note that for a CGI
 * script, the script must generate valid CGI headers. At the minimum that
 * means it must generate a Content-type header. For PHP files, you should use
 * {@link include()} or {@link require()}.
 *
 * @return error code
 */
function int virtual(string filename);


/**
 * Create an array
 * <p>
 * Returns an array of the parameters. The parameters can be given an index
 * with the =&gt; operator.
 * <p>
 * <b>Note:</b>
 * array() is a language construct used to represent literal
 * arrays, and not a regular function.
 * <p>
 * The following example demonstrates how to create a two-dimensional array,
 * how to specify keys for associative arrays, and how to skip-and-continue
 * numeric indices in normal arrays.
 * <p>
 * <b>Example 1.</b> array() example
 * <pre>
 *    $fruits = array(
 *        "fruits"  =&gt; array("a"=&gt;"orange","b"=&gt;"banana","c"=&gt;"apple"),
 *        "numbers" =&gt; array(1, 2, 3, 4, 5, 6),
 *        "holes"   =&gt; array("first", 5 =&gt; "second", "third")
 *    );
 * </pre>
 * 
 * @return array of the parameters
 *
 * @see list()
 */
function array array(...);
 
/**
 * Push one or more elements onto the end of array
 * <p>
 * array_push() treats array as a stack, and pushes the passed variables onto
 * the end of array. The length of array increases by the number of variables
 * pushed. Has the same effect as:
 * <pre>
 *    $array[] = $var;
 * </pre>
 * repeated for each var.
 * <p>
 * <b>Example 1.</b> array_push() example
 * <pre>
 *    $stack = array(1, 2);
 *    array_push($stack, "+", 3);
 * </pre>
 * This example would result in $stack having 4 elements: 1, 2, "+", and 3.
 * 
 * @return the new number of elements in the array.
 * 
 * @see array_pop()
 * @see array_shift()
 * @see array_unshift()
 * @since This function was added in PHP 4.0.
 */
function int array_push(array array, mixed var, [...]);
 
/**
 * Pop the element off the end of array
 * <p>
 * array_pop() pops and returns the last value of the array, shortening the
 * array by one element.
 * <p>
 * <b>Example 1.</b> array_pop() example
 * <pre>
 * $stack = array("orange", "apple", "raspberry");
 * $fruit = array_pop($stack);
 * </pre>
 * After this, $stack has only 2 elements: "orange" and "apple", and $fruit
 * has "raspberry".
 * 
 * @see array_push()
 * @see array_shift()
 * @see array_unshift()
 * @since This function was added in PHP 4.0.
 */
function mixed array_pop(array array);
 
/**
 * Push one or more elements onto the beginning of array
 * <p>
 * array_unshift() prepends passed elements to the front of the array. Note
 * that the list of elements is prepended as a whole, so that the prepended
 * elements stay in the same order.
 * <p>
 * <b>Example 1.</b> array_unshift() example
 * <pre>
 *    $queue = array("p1", "p3");
 *    array_unshift($queue, "p4", "p5", "p6");
 * </pre>
 * This would result in $queue having 5 elements: "p4", "p5", "p6", "p1", and
 * "p3".
 * 
 * @return the new number of elements in the array.
 * 
 * @see array_shift()
 * @see array_push()
 * @see array_pop()
 * @since This function was added in PHP 4.0.
 */
function int array_unshift(array array, mixed var, [...]);
 
/**
 * Pop an element of the beginning of array
 * <p>
 * array_shift() shifts the first value of the array off and returns it,
 * shortening the array by one element and moving everything down.
 * <p>
 * <b>Example 1.</b> array_shift() example
 * <pre>
 *    $args = array("-v", "-f");
 *    $opt = array_shift($args);
 * </pre>
 * This would result in $args having one element "-f" left, and $opt being "-v".
 * 
 * @see array_shift()
 * @see array_push()
 * @see array_pop()
 * @since This function was added in PHP 4.0.
 */
function mixed array_shift(array array);
 
/**
 * Extract a slice of the array
 * <p>
 * array_slice() returns a sequence of elements from the array specified by
 * the offset and length parameters.
 * <p>
 * If offset is positive, the sequence will start at that offset in the array.
 * If offset is negative, the sequence will start that far from the end of the
 * array.
 * <p>
 * If length is given and is positive, then the sequence will have that many
 * elements in it. If length is given and is negative then the sequence will
 * stop that many elements from the end of the array. If it is omitted, then
 * the sequence will have everything from offset up until the end of the
 * array.
 * <p>
 * <b>Example 1.</b> array_slice() examples
 * <pre>
 *    $input = array("a", "b", "c", "d", "e");
 * 
 *    $output = array_slice($input, 2);      // returns "c", "d", and "e"
 *    $output = array_slice($input, 2, -1);  // returns "c", "d"
 *    $output = array_slice($input, -2, 1);  // returns "d"
 *    $output = array_slice($input, 0, 3);   // returns "a", "b", and "c"
 * </pre>
 *
 * @see array_splice()
 * @since This function was added in PHP 4.0.
 */
function array array_slice(array array, int offset, int [length] );
 
/**
 * Remove a portion of the array and replace it with something
 * <p>
 * array_splice() removed the elements designated by offset and length from
 * the input array, and replaces them with the elements of the replacement
 * array, if supplied.
 * <p>
 * If offset is positive then the start of removed portion is at that offset
 * from the beginning of the input array. If offset is negative then it starts
 * that far from the end of the input array.
 * <p>
 * If length is omitted, removes everything from offset to the end of the
 * array. If length is specified and is positive, then that many elements will
 * be removed. If length is specified and is negative then the end of the
 * removed portion will be that many elements from the end of the array. Tip:
 * to remove everything from offset to the end of the array when replacement
 * is also specified, use count($input) for length.
 * <p>
 * If replacement array is specified, then the removed elements are replaced
 * with elements from this array. If offset and length are such that nothing
 * is removed, then the elements from the replacement array are inserted in
 * the place specified by the offset. Tip: if the replacement is just one
 * element it is not necessary to put {@link array()} around it, unless the element is
 * an array itself.
 * <p>
 * The following equivalences hold:
 * <pre>
 *    array_push($input, $x, $y)     array_splice($input, count($input), 0, array($x, $y))
 *    array_pop($input)              array_splice($input, -1)
 *    array_shift($input)            array_splice($input, 0, 1)
 *    array_unshift($input, $x, $y)  array_splice($input, 0, 0, array($x, $y))
 *    $a[$x] = $y                    array_splice($input, $x, 1, $y)
 * </pre>
 * <p>
 * <b>Example 1.</b> array_splice() examples
 * <pre>
 *    $input = array("red", "green", "blue", "yellow");
 *    array_splice($input, 2);      // $input is now array("red", "green")
 *    array_splice($input, 1, -1);  // $input is now array("red", "yellow")
 *    array_splice($input, 1, count($input), "orange");  // $input is now array("red", "orange")
 *    array_splice($input, -1, 1, array("black", "maroon")); // $input is now array("red", "green", "blue", "black", "maroon")
 * </pre>
 *
 * @return the array consisting of removed elements.
 *
 * @see array_slice()
 * @since This function was added in PHP 4.0.
 */
function array array_splice(array input, int offset, int [length] , array * [replacement]);
 
/**
 * Merge two or more arrays
 * <p>
 * array_merge() merges the elements of two or more arrays together so that
 * the values of one are appended to the end of the previous one. It returns
 * the resulting array.
 * <p>
 * If the input arrays had the same string keys, then the later value for that
 * key will overwrite previous one. If, however, the arrays have the same
 * numeric key, this does not happen since the values are appended.
 * <p>
 * <b>Example 1.</b> array_merge() example
 * <pre>
 *    $array1 = array("color" =&gt; "red", 2, 4);
 *    $array2 = array("a", "b", "color" =&gt; "green", "shape" =&gt; "trapezoid");
 *    array_merge($array1, $array2);
 * </pre>
 * Resulting array will be array("color" =&gt; "green", 2, 4, "a", "b", "shape"
 * =&gt; "trapezoid").
 * 
 * @since This function was added in PHP 4.0.
 */
function array array_merge(array array1, array array2, [ ...] );
 
/**
 * Return all the keys of an array
 * <p>
 * <b>Example 1.</b> array_keys() example
 * <pre>
 *    $array = array(0 =&gt; 100, "color" =&gt; "red");
 *    array_keys($array);    // returns array(0, "color")
 * </pre>
 * 
 * @return all the keys, numeric and string, from the input array.
 * @see array_values()
 * @since This function was added in PHP 4.0.
 */
function array array_keys(array input);
 
/**
 * Return all the values of an array
 * <p>
 * <b>Example 1.</b> array_values() example
 * <pre>
 *    $array = array("size" =&gt; "XL", "color" =&gt; "gold");
 *    array_values($array);    // returns array("XL", "gold")
 * </pre>
 *
 * @return all the values from the input array.
 * @since This function was added in PHP 4.0.
 */
function array array_values(array input);
 
/**
 * Apply a user function to every member of an array.
 * <p>
 * Applies the function named by func to each element of arr. func will be
 * passed array value as the first parameter and array key as the second
 * parameter. If userdata is supplied, it will be passed as the third
 * parameter to the user function. If func requires more than two or three
 * arguments, depending on userdata, a warning will be generated each time
 * array_walk() calls func. These warnings may be suppressed by prepending the
 * '@' sign to the array_walk() call, or by using {@link error_reporting()}.
 * <p>
 * <b>Note:</b>
 * If func needs to be working with the actual values of the
 * array, specify that the first parameter of func should be passed
 * by reference. Then any changes made to those elements will be
 * made in the array itself.
 * <p>
 * <b>Example 1.</b> array_walk() example
 * <pre>
 * $fruits = array("d"=&gt;"lemon","a"=&gt;"orange","b"=&gt;"banana","c"=&gt;"apple");
 * 
 * function test_alter( &$item1, $key, $prefix ) {
 *    $item1 = "$prefix: $item1";
 * }
 * function test_print( $item2, $key ) {
 *    echo "$key. $item2&lt;br&gt;\n";
 * }
 * 
 * array_walk( $fruits, 'test_print' );
 * array_walk( $fruits, 'test_alter', 'fruit' );
 * array_walk( $fruits, 'test_print' );
 * </pre>
 *
 * @see each()
 * @see list()
 */
function int array_walk(array arr, string func, mixed userdata);
 
/**
 * Sort an array in reverse order and maintain index association
 * <p>
 * This function sorts an array such that array indices maintain their
 * correlation with the array elements they are associated with. This is used
 * mainly when sorting associative arrays where the actual element order is
 * significant.
 * <p>
 * <b>Example 1.</b> arsort() example
 * <pre>
 * $fruits = array("d"=&gt;"lemon","a"=&gt;"orange","b"=&gt;"banana","c"=&gt;"apple");
 * arsort($fruits);
 * for(reset($fruits); $key = key($fruits); next($fruits)) {
 *     echo "fruits[$key] = ".$fruits[$key]."\n";
 * }
 * </pre>
 * This example would display: fruits[a] = orange fruits[d] = lemon fruits[b]
 * = banana fruits[c] = apple The fruits have been sorted in reverse
 * alphabetical order, and the index associated with each element has been
 * maintained.
 * 
 * @see asort()
 * @see rsort()
 * @see ksort()
 * @see sort()
 */
function void arsort(array array);
 
/**
 * Sort an array and maintain index association
 * <p>
 * This function sorts an array such that array indices maintain their
 * correlation with the array elements they are associated with. This is used
 * mainly when sorting associative arrays where the actual element order is
 * significant.
 * <p>
 * <b>Example 1.</b> asort() example
 * <pre> 
 * $fruits = array("d"=&gt;"lemon","a"=&gt;"orange","b"=&gt;"banana","c"=&gt;"apple");
 * asort($fruits);
 * for(reset($fruits); $key = key($fruits); next($fruits)) {
 *     echo "fruits[$key] = ".$fruits[$key]."\n";
 * }
 * </pre>
 * This example would display: fruits[c] = apple fruits[b] = banana fruits[d]
 * = lemon fruits[a] = orange The fruits have been sorted in alphabetical
 * order, and the index associated with each element has been maintained.
 * 
 * @see arsort()
 * @see rsort()
 * @see ksort()
 * @see sort()
 */
function void asort(array array);
 
/**
 * Create array containing variables and their values
 * <p>
 * compact() takes a variable number of parameters. Each parameter can be
 * either a string containing the name of the variable, or an array of
 * variable names. The array can contain other arrays of variable names inside
 * it; compact() handles it recursively.
 * <p>
 * For each of these, compact() looks for a variable with that name in the
 * current symbol table and adds it to the output array such that the variable
 * name becomes the key and the contents of the variable become the value for
 * that key. In short, it does the opposite of {@link extract()}.
 * <p>
 * <b>Example 1.</b> compact() example
 * <pre>
 *    $city = "San Francisco";
 *    $state = "CA";
 *    $event = "SIGGRAPH";
 *    $location_vars = array("city", "state");
 *    $result = compact("event", $location_vars);
 * </pre>
 * After this, $result will be array("event" =&gt; "SIGGRAPH", "city" =&gt; "San
 * Francisco", "state" =&gt; "CA").
 * 
 * @return the output array with all the variables added to it.
 * @see extract()
 * @since This function was added in PHP 4.0.
 */
function array compact(string varname | array varnames, [...]);
 
/**
 * count elements in a variable
 * <p>
 * <b>Warning:</b>
 * count() may return 0 for a variable that isn't set, but it may also
 * return 0 for a variable that has been initialized with an empty array.
 * Use {@link isset()} to test if a variable is set.
 * 
 * @return the number of elements in var, which is typically an array (since
 *         anything else will have one element).  Returns 1 if the variable is
 *         not an array.  Returns 0 if the variable is not set.
 *
 * @see sizeof()
 * @see isset()
 * @see is_array()
 */
function int count(mixed var);
 
/**
 * Return the current element in an array
 * <p>
 * Every array has an internal pointer to its "current" element, which is
 * initialized to the first element inserted into the array.
 * <p>
 * The current() function simply returns the array element that's currently
 * being pointed by the internal pointer. It does not move the pointer in any
 * way. If the internal pointer points beyond the end of the elements list,
 * current() returns false.
 * <p>
 * <b>Warning:</b>
 * If the array contains empty elements (0 or "", the empty string) then
 * this function will return false for these elements as well. This makes it
 * impossible to determine if you are really at the end of the list in such
 * an array using current(). To properly traverse an array that may contain
 * empty elements, use the {@link each()} function.
 * 
 * @see end()
 * @see next()
 * @see prev()
 * @see reset()
 */
function mixed current(array array);
 
/**
 * Return the next key and value pair from an array
 * <p>
 * Returns the current key and value pair from the array array and advances
 * the array cursor. This pair is returned in a four-element array, with the
 * keys 0, 1, key, and value. Elements 0 and key contain the key name of the
 * array element, and 1 and value contain the data.
 * <p>
 * If the internal pointer for the array points past the end of the array
 * contents, each() returns false.
 * <p>
 * <b>Example 1.</b> each() examples
 * <pre>
 *    $foo = array( "bob", "fred", "jussi", "jouni" );
 *    $bar = each( $foo );
 * </pre>
 * $bar now contains the following key/value pairs:
 * <pre>
 *    0 =&gt; 0
 *    1 =&gt; 'bob'
 *    key =&gt; 0
 *    value =&gt; 'bob'
 * 
 *    $foo = array( "Robert" =&gt; "Bob", "Seppo" =&gt; "Sepi" );
 *    $bar = each( $foo );
 * </pre>
 * $bar now contains the following key/value pairs:
 * <pre>
 *    0 =&gt; 'Robert'
 *    1 =&gt; 'Bob'
 *    key =&gt; 'Robert'
 *    value =&gt; 'Bob'
 * </pre>
 * each() is typically used in conjunction with {@link list()} to traverse an array;
 * for instance, $HTTP_POST_VARS:
 * <b>Example 2.</b> Traversing $HTTP_POST_VARS with each()
 * <pre>
 *    echo "Values submitted via POST method:&lt;br&gt;";
 *    while (list($key, $val) = each($HTTP_POST_VARS)) {
 *       echo "$key =&gt; $val&lt;br&gt;";
 *    }
 * </pre>
 * After each() has executed, the array cursor will be left on the next
 * element of the array, or on the last element if it hits the end of the
 * array.
 * 
 * @see key()
 * @see list()
 * @see current()
 * @see reset()
 * @see next()
 * @see prev()
 */
function array each(array array);
 
/**
 * Set the internal pointer of an array to its last element
 * <p>
 * end() advances array's internal pointer to the last element.
 * 
 * @see current()
 * @see each()
 * @see end()
 * @see next()
 * @see reset()
 */
function end(array array);
 
/**
 * Import variables into the symbol table from an array
 * <p>
 * This function is used to import variables from an array into the current
 * symbol table. It takes associative array var_array and treats keys as
 * variable names and values as variable values. For each key/value pair it
 * will create a variable in the current symbol table, subject to extract_type
 * and prefix parameters.
 * <p>
 * extract() checks for colissions with existing variables. The way collisions
 * are treated is determined by extract_type. It can be one of the following
 * values:
 * <dl>
 * <dt>EXTR_OVERWRITE
 * <dd>If there is a collision, overwrite the existing variable.
 * <dt>EXTR_SKIP
 * <dd>If there is a collision, don't overwrite the existing variable.
 * <dt>EXTR_PREFIX_SAME
 * <dd>If there is a collision, prefix the new variable with prefix.
 * <dt>EXTR_PREFIX_ALL
 * <dd>Prefix all variables with prefix.
 * </dl>
 * If extract_type is not specified, it is assumed to be EXTR_OVERWRITE.
 * <p>
 * Note that prefix is only required if extract_type is EXTR_PREFIX_SAME or
 * EXTR_PREFIX_ALL.
 * <p>
 * extract() checks each key to see if it constitues a valid variable name,
 * and if it does only then does it proceed to import it.
 * <p>
 * A possible use for extract is to import into symbol table variables
 * contained in an associative array returned by {@link wddx_deserialize()}.
 * <p>
 * <b>Example 1.</b> extract example
 * <pre>
 *    &lt;?
 *    // Suppose that $var_array is an array returned from
 *    // wddx_deserialize
 *    $size = "large";
 *    $var_array = array("color" =&gt; "blue",
 *                       "size"  =&gt; "medium",
 *                       "shape" =&gt; "sphere");
 *    extract($var_array, EXTR_PREFIX_SAME, "wddx");
 *    print "$color, $size, $shape, $wddx_size\n";
 *    ?&gt;
 * </pre>
 * The above example will produce:
 * <pre>
 *    blue, large, sphere, medium
 * <pre>
 * The $size wasn't overwritten, becaus we specified EXTR_PREFIX_SAME, which
 * resulted in $wddx_size being created. If EXTR_SKIP was specified, then
 * $wddx_size wouldn't even have been created. EXTR_OVERWRITE would have cause
 * $size to have value "medium", and EXTR_PREFIX_ALL would result in new
 * variables being named $wddx_color, $wddx_size, and $wddx_shape.
 */
function void extract(array var_array, int [extract_type], string [prefix]);
 
/**
 * Return true if a value exists in an array
 * <p>
 * Searches haystack for needle and returns true if it is found in the array,
 * false otherwise.
 * <p>
 * <b>Example 1.</b> in_array() example
 * <pre>
 *    $os = array("Mac", "NT", "Irix", "Linux");
 *    if (in_array("Irix", $os))
 *        print "Got Irix";
 * </pre>
 *
 * @since This function was added in PHP 4.0.
 */
function bool in_array(mixed needle, array haystack);
 
/**
 * Fetch a key from an associative array
 * 
 * @return the index element of the current array position.
 * @see current()
 * @see next()
 */
function mixed key(array array);
 
/**
 * Sort an array by key
 * <p>
 * Sorts an array by key, maintaining key to data correlations. This is useful
 * mainly for associative arrays.
 * <p>
 * <b>Example 1.</b> ksort() example
 * <pre>
 *    $fruits = array("d"=&gt;"lemon","a"=&gt;"orange","b"=&gt;"banana","c"=&gt;"apple");
 *    ksort($fruits);
 *    for(reset($fruits); $key = key($fruits); next($fruits)) {
 *       echo "fruits[$key] = ".$fruits[$key]."\n";
 *    }
 * </pre>
 * This example would display: fruits[a] = orange fruits[b] = banana fruits[c]
 * = apple fruits[d] = lemon
 * 
 * @see asort()
 * @see arsort()
 * @see sort()
 * @see rsort()
 */
function int ksort(array array);
 
/**
 * Assign variables as if they were an array
 * <p>
 * Like array(), this is not really a function, but a language construct.
 * {@link list()} is used to assign a list of variables in one operation.
 * <b>Example 1.</b> list() example
 * <pre>
 *    &lt;table&gt;
 *     &lt;tr&gt;
 *      &lt;th&gt;Employee name&lt;/th&gt;
 *      &lt;th&gt;Salary&lt;/th&gt;
 *     &lt;/tr&gt;
 *    &lt;?php
 *    
 *    $result = mysql($conn, "SELECT id, name, salary FROM employees");
 *    while (list($id, $name, $salary) = mysql_fetch_row($result)) {
 *        print(" &lt;tr&gt;\n".
 *              "  &lt;td&gt;&lt;a href=\"info.php3?id=$id\"&gt;$name&lt;/a&gt;&lt;/td&gt;\n".
 *              "  &lt;td&gt;$salary&lt;/td&gt;\n".
 *              " &lt;/tr&gt;\n");
 *    }
 * 
 *    ?&gt;&lt;/table&gt;
 * </pre>
 *
 * @see each()
 * @see array()
 */
function void list(...);
 
/**
 * Advance the internal array pointer of an array
 * <p>
 * next() behaves like {@link current()}, with one difference. It advances the
 * internal array pointer one place forward before returning the element. That
 * means it returns the next array element and advances the internal array
 * pointer by one. If advancing the internal array pointer results in going
 * beyond the end of the element list, next() returns false.
 * <p>
 * <b>Warning:</b>
 * If the array contains empty elements then this function will return false
 * for these elements as well. To properly traverse an array which may
 * contain empty elements see the {@link each()} function.
 * 
 * @return the array element in the next place that's pointed by the internal
 * array pointer, or false if there are no more elements.
 *
 * @see current()
 * @see end()
 * @see prev()
 * @see reset()
 */
function mixed next(array array);
 
/**
 * Get the current element from an array
 * <p>
 * This is an alias for {@link current()}.
 * 
 * @see end()
 * @see next()
 * @see prev()
 * @see reset()
 */
function mixed pos(array array);
 
/**
 * Rewind the internal array pointer
 * <p>
 * <b>Warning:</b>
 * If the array contains empty elements then this function will return false
 * for these elements as well. To properly traverse an array which may
 * contain empty elements see the {@link each()} function.
 * <p>
 * prev() behaves just like {@link next()}, except it rewinds the internal array
 * pointer one place instead of advancing it.
 * 
 * @return the array element in the previous place that's pointed by the
 * internal array pointer, or false if there are no more elements.
 * 
 * @see current()
 * @see end()
 * @see next()
 * @see reset()
 */
function mixed prev(array array);
 
/**
 * Create an array containing a range of integers
 * 
 * @return an array of integers from low to high, inclusive.
 * @see shuffle()
 */
function array range(int low, int high);
 
/**
 * Set the internal pointer of an array to its first element
 * <p>
 * reset() rewinds array's internal pointer to the first element.
 * 
 * @return the value of the first array element.
 * 
 * @see current()
 * @see each()
 * @see next()
 * @see prev()
 * @see reset()
 */
function mixed reset(array array);
 
/**
 * Sort an array in reverse order
 * <p>
 * This function sorts an array in reverse order (highest to lowest).
 * <p>
 * <b>Example 1.</b> rsort() example
 * <pre>
 *    $fruits = array("lemon","orange","banana","apple");
 *    rsort($fruits);
 *    for (reset($fruits); list($key,$value) = each($fruits); ) {
 *        echo "fruits[$key] = ", $value, "\n";
 *    }
 * </pre>
 * This example would display: fruits[0] = orange fruits[1] = lemon fruits[2]
 * = banana fruits[3] = apple The fruits have been sorted in reverse
 * alphabetical order.
 * 
 * @see arsort()
 * @see asort()
 * @see ksort()
 * @see sort()
 * @see usort()
 */
function void rsort(array array);
 
/**
 * Shuffle an array
 * <p>
 * This function shuffles (randomizes the order of the elements in) an array.
 * <p>
 * <b>Example 1.</b> shuffle() example
 * <pre>
 *    $numbers = range(1,20);
 *    srand(time());
 *    shuffle($numbers);
 *    while (list(,$number) = each($numbers)) {
 *        echo "$number ";
 *    }
 * </pre>
 *
 * @see arsort()
 * @see asort()
 * @see ksort()
 * @see rsort()
 * @see sort()
 * @see usort()
 */
function void shuffle(array array);
 
/**
 * Get the number of elements in an array
 * 
 * @return the number of elements in the array.
 * @see count()
 */
function int sizeof(array array);
 
/**
 * Sort an array
 * <p>
 * This function sorts an array. Elements will be arranged from lowest to
 * highest when this function has completed.
 * <p>
 * <b>Example 1.</b> sort() example
 * <pre>
 *    $fruits = array("lemon","orange","banana","apple");
 *    sort($fruits);
 *    for(reset($fruits); $key = key($fruits); next($fruits)) {
 *        echo "fruits[$key] = ".$fruits[$key]."\n";
 *    }
 * </pre>
 * This example would display: fruits[0] = apple fruits[1] = banana fruits[2]
 * = lemon fruits[3] = orange The fruits have been sorted in alphabetical
 * order.
 * 
 * @see arsort()
 * @see asort()
 * @see ksort()
 * @see rsort()
 * @see usort()
 */
function void sort(array array);
 
/**
 * ex association
 * <p>
 * This function sorts an array such that array indices maintain their
 * correlation with the array elements they are associated with. This is used
 * mainly when sorting associative arrays where the actual element order is
 * significant. The comparison function is user-defined.
 */
function void uasort(array array, function cmp_function);
 
/**
 * Sort an array by keys using a user-defined comparison function
 * <p>
 * This function will sort the keys of an array using a user-supplied
 * comparison function. If the array you wish to sort needs to be sorted by
 * some non-trivial criteria, you should use this function.
 * <p>
 * <b>Example 1.</b> uksort() example
 * <pre>
 *    function mycompare($a, $b) {
 *       if ($a == $b) return 0;
 *       return ($a &gt; $b) ? -1 : 1;
 *    }
 *    $a = array(4 =&gt; "four", 3 =&gt; "three", 20 =&gt; "twenty", 10 =&gt; "ten");
 *    uksort($a, mycompare);
 *    while(list($key, $value) = each($a)) {
 *       echo "$key: $value\n";
 *    }
 * </pre>
 * This example would display: 20: twenty 10: ten 4: four 3: three
 * 
 * @see arsort()
 * @see asort()
 * @see uasort()
 * @see ksort()
 * @see rsort()
 * @see sort()
 */
function void uksort(array array, function cmp_function);
 
/**
 * Sort an array by values using a user-defined comparison function
 * <p>
 * This function will sort an array by its values using a user-supplied
 * comparison function. If the array you wish to sort needs to be sorted by
 * some non-trivial criteria, you should use this function.
 * <p>
 * The comparison function must return an integer less than, equal to, or
 * greater than zero if the first argument is considered to be respectively
 * less than, equal to, or greater than the second. If two members compare as
 * equal, their order in the sorted array is undefined.
 * <p>
 * <b>Example 1.</b> usort() example
 * <pre>
 *    function cmp($a,$b) {
 *       if ($a == $b) return 0;
 *       return ($a &gt; $b) ? -1 : 1;
 *    }
 *    $a = array(3,2,5,6,1);
 *    usort($a, cmp);
 *    while(list($key,$value) = each($a)) {
 *       echo "$key: $value\n";
 *    }
 * </pre>
 * This example would display: 0: 6 1: 5 2: 3 3: 2 4: 1
 * <p>
 * <b>Note:</b>
 * Obviously in this trivial case the {@link rsort()} function would
 * be more appropriate.
 * <p>
 * <b>Warning:</b>
 * The underlying quicksort function in some C libraries (such as on Solaris
 * systems) may cause PHP to crash if the comparison function does not
 * return consistent values.
 * 
 * @see arsort()
 * @see asort()
 * @see ksort()
 * @see rsort()
 * @see sort()
 */
function void usort(array array, function cmp_function);


///////////////////////////////////////////////////////////////////////////
// Aspell functions
//
// The aspell() functions allows you to check the spelling on a word and
// offer suggestions.
// 
// You need the aspell library, available from:
// http://metalab.unc.edu/kevina/aspell/
//

/**
 * load a new dictionary
 * <p>
 * aspell_new() opens up a new dictionary and returns the dictionary link
 * identifier for use in other aspell functions.
 * <p>
 * <b>Example 1.</b> aspell_new
 * <pre>
 *    $aspell_link=aspell_new("english");
 * </pre>
 */
function int aspell_new(string master, string personal);
 
/**
 * check a word
 * <p>
 * aspell_check() checks the spelling of a word and returns true if the
 * spelling is correct, false if not.
 * <p>
 * <b>Example 1.</b> aspell_check
 * <pre>
 *    $aspell_link=aspell_new("english");
 *    if (aspell_check($aspell_link,"testt")) {
 *       echo "This is a valid spelling";
 *    } else {
 *       echo "Sorry, wrong spelling";
 *    }
 * </pre>
 */
function bool aspell_check(int dictionary_link, string word);
 
/**
 * <p>
 * aspell_check_raw() checks the spelling of a word, without changing its case
 * or trying to trim it in any way and returns true if the spelling is
 * correct, false if not.
 * <p>
 * <b>Example 1.</b> aspell_check_raw
 * <pre>
 *    $aspell_link=aspell_new("english");
 *    if (aspell_check_raw($aspell_link,"testt")) {
 *       echo "This is a valid spelling";
 *    } else {
 *       echo "Sorry, wrong spelling";
 *    }
 * </pre>
 */
function bool aspell_check_raw(int dictionary_link, string word);
 
/**
 * suggest spellings of a word
 * <p>
 * <b>Example 1.</b> aspell_suggest
 * <pre>
 *    $aspell_link=aspell_new("english");
 * 
 *    if (!aspell_check($aspell_link,"testt")) {
 *       $suggestions=aspell_suggest($aspell_link,"testt");
 * 
 *       for($i=0; $i &lt; count($suggestions); $i++) {
 *          echo "Possible spelling: " . $suggestions[$i] . "&lt;br&gt;";
 *       }
 *    }
 * </pre>
 * 
 * @return an array of possible spellings for the given word.
 */
function array aspell_suggest(int dictionary_link, string word);


///////////////////////////////////////////////////////////////////////////
// Arbitrary precision mathematics functions
//
// These functions are only available if PHP was configured with
// --enable-bcmath.
 
/**
 * Add two arbitrary precision numbers.
 * <p>
 * Adds the left operand to the right operand and returns the sum in a string.
 * The optional scale parameter is used to set the number of digits after the
 * decimal place in the result.
 * 
 * @see bcsub()
 */
function string bcadd(string left_operand, string right_operand, int [scale]);
 
/**
 * Compare two arbitrary precision numbers.
 * <p>
 * Compares the left operand to the right operand and returns the result as an
 * integer. The optional scale parameter is used to set the number of digits
 * after the decimal place which will be used in the comparion. The return
 * value is 0 if the two operands are equal. If the left operand is larger
 * than the right operand the return value is +1 and if the left operand is
 * less than the right operand the return value is -1.
 */
function int bccomp(string left_operand, string right_operand, int [scale]);
 
/**
 * Divide two arbitrary precision numbers.
 * <p>
 * Divides the left operand by the right operand and returns the result. The
 * optional scale sets the number of digits after the decimal place in the
 * result.
 * 
 * @see bcmul()
 */
function string bcdiv(string left_operand, string right_operand, int [scale]);
 
/**
 * Get modulus of an arbitrary precision number.
 * <p>
 * Get the modulus of the left operand using modulus.
 * 
 * @see bcdiv()
 */
function string bcmod(string left_operand, string modulus);
 
/**
 * Multiply two arbitrary precision number.
 * <p>
 * Multiply the left operand by the right operand and returns the result. The
 * optional scale sets the number of digits after the decimal place in the
 * result.
 * 
 * @see bcdiv()
 */
function string bcmul(string left_operand, string right_operand, int [scale]);
 
/**
 * Raise an arbitrary precision number to another.
 * <p>
 * Raise x to the power y. The scale can be used to set the number of digits
 * after the decimal place in the result.
 * 
 * @see bcsqrt()
 */
function string bcpow(string x, string y, int [scale]);
 
/**
 * Set default scale parameter for all bc math functions.
 * <p>
 * This function sets the default scale parameter for all subsequent bc math
 * functions that do not explicitly specify a scale parameter.
 */
function string bcscale(int scale);
 
/**
 * Get the square root of an arbitray precision number.
 * <p>
 * Return the square root of the operand. The optional scale parameter sets
 * the number of digits after the decimal place in the result.
 * 
 * @see bcpow()
 */
function string bcsqrt(string operand, int scale);
 
/**
 * Subtract one arbitrary precision number from another.
 * <p>
 * Subtracts the right operand from the left operand and returns the result in
 * a string. The optional scale parameter is used to set the number of digits
 * after the decimal place in the result.
 * 
 * @see bcadd()
 */
function string bcsub(string left_operand, string right_operand, int [scale]);
 

///////////////////////////////////////////////////////////////////////////
// Calendar functions
//
// The calendar functions are only available if you have compiled the calendar
// extension in dl/calendar. Read dl/README for instructions on using it.
// 
// The calendar extension presents a series of functions to simplify
// converting between different calendar formats. The intermediary or standard
// it is based on is the Julian Day Count. The Julian Day Count is a count of
// days starting way earlier than any date most people would need to track
// (somewhere around 4000bc). To convert between calendar systems, you must
// first convert to Julian Day Count, then to the calendar system of your
// choice. Julian Day Count is very different from the Julian Calendar! For
// more information on calendar systems visit
// http://genealogy.org/~scottlee/cal-overview.html. Excerpts from this page
// are included in these instructions, and are in quotes.
// 

/**
 * Converts Julian Day Count to Gregorian date
 * <p>
 * Converts Julian Day Count to a string containing the Gregorian date in the
 * format of "month/day/year"
 */
function string jdtogregorian(int julianday);
 
/**
 * Converts a Gregorian date to Julian Day Count
 * <p>
 * Valid Range for Gregorian Calendar 4714 B.C. to 9999 A.D.
 * <p>
 * Although this software can handle dates all the way back to 4714 B.C., such
 * use may not be meaningful. The Gregorian calendar was not instituted until
 * October 15, 1582 (or October 5, 1582 in the Julian calendar). Some
 * countries did not accept it until much later. For example, Britain
 * converted in 1752, The USSR in 1918 and Greece in 1923. Most European
 * countries used the Julian calendar prior to the Gregorian.
 *
 * <b>Example 1.</b> Calendar functions
 * <pre>
 *    &lt;?php
 *    $jd = GregorianToJD(10,11,1970);
 *    echo("$jd\n");
 *    $gregorian = JDToGregorian($jd);
 *    echo("$gregorian\n");
 *    ?&gt;
 * </pre>
 */
function int gregoriantojd(int month, int day, int year);
 
/**
 * Converts a Julian Calendar date to Julian Day Count
 * <p>
 * Converts Julian Day Count to a string containing the Julian Calendar Date
 * in the format of "month/day/year".
 */
function string jdtojulian(int julianday);
 
/**
 * Converts a Julian Calendar date to Julian Day Count
 * <p>
 * Valid Range for Julian Calendar 4713 B.C. to 9999 A.D.
 * <p>
 * Although this software can handle dates all the way back to 4713 B.C., such
 * use may not be meaningful. The calendar was created in 46 B.C., but the
 * details did not stabilize until at least 8 A.D., and perhaps as late at the
 * 4th century. Also, the beginning of a year varied from one culture to
 * another - not all accepted January as the first month.
 */
function int juliantojd(int month, int day, int year);
 
/**
 * Converts a Julian Day Count to the Jewish Calendar
 * <p>
 * Converts a Julian Day Count the the Jewish Calendar.
 */
function string jdtojewish(int julianday);
 
/**
 * Converts a date in the Jewish Calendar to Julian Day Count
 * <p>
 * Valid Range Although this software can handle dates all the way back to the
 * year 1 (3761 B.C.), such use may not be meaningful.
 * <p>
 * The Jewish calendar has been in use for several thousand years, but in the
 * early days there was no formula to determine the start of a month. A new
 * month was started when the new moon was first observed.
 */
function int jewishtojd(int month, int day, int year);
 
/**
 * Converts a Julian Day Count to the French Republican Calendar
 */
function string jdtofrench(int month, int day, int year);
 
/**
 * Converts a date from the French Republican Calendar to a Julian Day Count
 * <p>
 * These routines only convert dates in years 1 through 14 (Gregorian dates 22
 * September 1792 through 22 September 1806). This more than covers the period
 * when the calendar was in use.
 */
function int frenchtojd(int month, int day, int year);
 
/**
 * Returns a month name
 * <p>
 * Returns a string containing a month name. mode tells this function which
 * calendar to convert the Julian Day Count to, and what type of month names
 * are to be returned.
 * <p>
 * Table 1. Calendar modes
 * <ul>
 * <li> 0 - Gregorian - apreviated
 * <li> 1 - Gregorian
 * <li> 2 - Julian - apreviated
 * <li> 3 - Julian
 * <li> 4 - Jewish
 * <li> 5 - French Republican
 * </ul>
 */
function string jdmonthname(int julianday, int mode);
 
/**
 * Returns the day of the week
 * <p>
 * Table 1. Calendar week modes
 * <ul>
 * <li> 0 - returns the day number as an int (0=sunday, 1=monday, etc)
 * <li> 1 - returns string containing the day of week (english-gregorian)
 * <li> 2 - returns a string containing the abreviated day of week
 *          (english-gregorian)
 * </ul>
 *
 * @return the day of the week. Can return a string or an int depending on the mode.
 */
function mixed jddayofweek(int julianday, int mode);
 
/**
 * get UNIX timestamp for midnight on Easter of a given year
 * <p>
 * Returns the UNIX timestamp corresponding to midnight on Easter of the given
 * year. If no year is specified, the current year is assumed.
 * <p>
 * Warning: This function will generate a warning if the year is outside of
 * the range for UNIX timestamps (i.e. before 1970 or after 2037).
 * <p>
 * <b>Example 1.</b> easter_date() example
 * <pre>
 *    echo date( "M-d-Y", easter_date(1999) );        // "Apr-04-1999" 
 *    echo date( "M-d-Y", easter_date(2000) );        // "Apr-23-2000" 
 *    echo date( "M-d-Y", easter_date(2001) );        // "Apr-15-2001" 
 * </pre>
 * The date of Easter Day was defined by the Council of Nicaea in AD325 as the
 * Sunday after the first full moon which falls on or after the Spring
 * Equinox. The Equinox is assumed to always fall on 21st March, so the
 * calculation reduces to determining the date of the full moon and the date
 * of the following Sunday. The algorithm used here was introduced around the
 * year 532 by Dionysius Exiguus. Under the Julian Calendar (for years before
 * 1753) a simple 19-year cycle is used to track the phases of the Moon. Under
 * the Gregorian Calendar (for years after 1753 - devised by Clavius and
 * Lilius, and introduced by Pope Gregory XIII in October 1582, and into
 * Britain and its then colonies in September 1752) two correction factors are
 * added to make the cycle more accurate.
 * <p>
 * (The code is based on a C program by Simon Kershaw,
 * &lt;webmaster@ely.anglican.org&gt;)
 * 
 * @see easter_days()     for calculating Easter before 1970 or after 2037.
 * 
 */
function int easter_date(int year);
 
/**
 * Returns the number of days after March 21 on which Easter falls for a given
 * year. If no year is specified, the current year is assumed.
 * <p>
 * This function can be used instead of {@link easter_date()} to calculate Easter for
 * years which fall outside the range of UNIX timestamps (i.e. before 1970 or
 * after 2037).
 * <p>
 * <b>Example 1.</b> easter_date() example
 * <pre>
 *    echo easter_days(1999);        // 14, i.e. April 4   
 *    echo easter_days(1492);        // 32, i.e. April 22  
 *    echo easter_days(1913);        //  2, i.e. March 23  
 * </pre>
 * The date of Easter Day was defined by the Council of Nicaea in AD325 as the
 * Sunday after the first full moon which falls on or after the Spring
 * Equinox. The Equinox is assumed to always fall on 21st March, so the
 * calculation reduces to determining the date of the full moon and the date
 * of the following Sunday. The algorithm used here was introduced around the
 * year 532 by Dionysius Exiguus. Under the Julian Calendar (for years before
 * 1753) a simple 19-year cycle is used to track the phases of the Moon. Under
 * the Gregorian Calendar (for years after 1753 - devised by Clavius and
 * Lilius, and introduced by Pope Gregory XIII in October 1582, and into
 * Britain and its then colonies in September 1752) two correction factors are
 * added to make the cycle more accurate.
 * <p>
 * (The code is based on a C program by Simon Kershaw,
 * &lt;webmaster@ely.anglican.org&gt;)
 * 
 * @see easter_date()
 */
function int easter_days(int year);


///////////////////////////////////////////////////////////////////////////
// ClibPDF functions
//
// ClibPDF allows to create pdf documents with PHP. It is available at FastIO
// but is not free software. You should definitely read the licence before you
// start playing with ClibPDF. If you cannot fullfil the licence agreement
// consider using pdflib by Thomas Merz, which is also very powerful. ClibPDF
// functionality and API is similar to Thomas Merz pdflib but ClibPDF is,
// according to FastIO, faster and creates smaller documents. This may have
// changed with the new version 2.0 of pdflib. A simple benchmark (the
// pdfclock.c example from pdflib 2.0 turned into a php script) actually show
// no difference in speed at all. The file size is also similar if compression
// is turned off.
// 
// This documentation should be read with the ClibPDF manual since it explains
// much of the library in much more detail. Once you understand the manual of
// ClibPDF you should be able to start using the library with PHP.
// 
// Many functions in the native ClibPDF and the PHP module, as well as in
// pdflib, have the same name. All functions except for cpdf_open() take as
// their first parameter the handle for the document on which the function is
// to be performed. Currently this handle is not used internally since ClibPDF
// does not support the creation of several PDF documents at the same time.
// Actually, you should not even try it, the results are unpredictable. I
// cannot oversee what the consequences in a multi threaded environment are.
// According to the author of ClibPDF this will change in one of the next
// releases (current version when this was written is 1.10). If you need this
// functionality use the pdflib module.
// 
// One big advantage of ClibPDF over pdflib is the possibility to create the
// pdf document completely in memory without using temporary files. It also
// provides the ability to pass coordinates in a predefined unit length. This
// is a handy feature but can be simulated with pdf_translate().
// 
// Most of the functions are fairly easy to use. The most difficult part is
// probably creating a very simple PDF document at all. The following example
// should help you get started. It creates a document with one page. The page
// contains the text "Times-Roman" in an outlined 30pt font. The text is
// underlined.
// 
// Example 1. Simple ClibPDF Example
// 
// <?php
// $cpdf = cpdf_open(0);
// cpdf_page_init($cpdf, 1, 0, 595, 842);
// cpdf_add_outline($cpdf, 0, 0, 0, 1, "Page 1");
// cpdf_set_font($cpdf, "Times-Roman", 30, 4);
// cpdf_set_text_rendering($cpdf, 1);
// cpdf_text($cpdf, "Times Roman outlined", 50, 750);
// cpdf_moveto($cpdf, 50, 740);
// cpdf_lineto($cpdf, 330, 740);
// cpdf_stroke($cpdf);
// cpdf_finalize($cpdf);
// Header("Content-type: application/pdf");
// cpdf_output_buffer($cpdf);
// cpdf_close($cpdf);
// ?>
// 
// The pdflib distribution contains a more complex example which creates a
// series of pages with an analog clock. Here is that example converted into
// PHP using the ClibPDF extension:
// 
// Example 2. pdfclock example from pdflib 2.0 distribution
// 
// <?php
// $radius = 200;
// $margin = 20;
// $pagecount = 40;
// 
// $pdf = cpdf_open(0);
// cpdf_set_creator($pdf, "pdf_clock.php3");
// cpdf_set_title($pdf, "Analog Clock");
// 
// while($pagecount-- > 0) {
//   cpdf_page_init($pdf, $pagecount+1, 0, 2 * ($radius + $margin), 2 * ($radius + $margin), 1.0);
// 
//   cpdf_set_page_animation($pdf, 4, 0.5, 0, 0, 0);  /* wipe */
// 
//   cpdf_translate($pdf, $radius + $margin, $radius + $margin);
//   cpdf_save($pdf);
//   cpdf_setrgbcolor($pdf, 0.0, 0.0, 1.0);
// 
//   /* minute strokes */
//   cpdf_setlinewidth($pdf, 2.0);
//   for ($alpha = 0; $alpha < 360; $alpha += 6)
//     {
//     cpdf_rotate($pdf, 6.0);
//     cpdf_moveto($pdf, $radius, 0.0);
//     cpdf_lineto($pdf, $radius-$margin/3, 0.0);
//     cpdf_stroke($pdf);
//     }
// 
//   cpdf_restore($pdf);
//   cpdf_save($pdf);
// 
//   /* 5 minute strokes */
//   cpdf_setlinewidth($pdf, 3.0);
//   for ($alpha = 0; $alpha < 360; $alpha += 30)
//   {
//     cpdf_rotate($pdf, 30.0);
//     cpdf_moveto($pdf, $radius, 0.0);
//     cpdf_lineto($pdf, $radius-$margin, 0.0);
//     cpdf_stroke($pdf);
//   }
// 
//   $ltime = getdate();
// 
//   /* draw hour hand */
//   cpdf_save($pdf);
//   cpdf_rotate($pdf, -(($ltime['minutes']/60.0) + $ltime['hours'] - 3.0) * 30.0);
//   cpdf_moveto($pdf, -$radius/10, -$radius/20);
//   cpdf_lineto($pdf, $radius/2, 0.0);
//   cpdf_lineto($pdf, -$radius/10, $radius/20);
//   cpdf_closepath($pdf);
//   cpdf_fill($pdf);
//   cpdf_restore($pdf);
// 
//   /* draw minute hand */
//   cpdf_save($pdf);
//   cpdf_rotate($pdf, -(($ltime['seconds']/60.0) + $ltime['minutes'] - 15.0) * 6.0);
//   cpdf_moveto($pdf, -$radius/10, -$radius/20);
//   cpdf_lineto($pdf, $radius * 0.8, 0.0);
//   cpdf_lineto($pdf, -$radius/10, $radius/20);
//   cpdf_closepath($pdf);
//   cpdf_fill($pdf);
//   cpdf_restore($pdf);
// 
//   /* draw second hand */
//   cpdf_setrgbcolor($pdf, 1.0, 0.0, 0.0);
//   cpdf_setlinewidth($pdf, 2);
//   cpdf_save($pdf);
//   cpdf_rotate($pdf, -(($ltime['seconds'] - 15.0) * 6.0));
//   cpdf_moveto($pdf, -$radius/5, 0.0);
//   cpdf_lineto($pdf, $radius, 0.0);
//   cpdf_stroke($pdf);
//   cpdf_restore($pdf);
// 
//   /* draw little circle at center */
//   cpdf_circle($pdf, 0, 0, $radius/30);
//   cpdf_fill($pdf);
// 
//   cpdf_restore($pdf);
// 
//   cpdf_finalize_page($pdf, $pagecount+1);
// }
// 
// cpdf_finalize($pdf);
// Header("Content-type: application/pdf");
// cpdf_output_buffer($pdf);
// cpdf_close($pdf);
// ?>
// 
 
/**
 * Sets the creator field in the pdf document
 * <p>
 * The cpdf_set_creator() function sets the creator of a pdf document.
 * 
 * @see cpdf_set_subject()
 * @see cpdf_set_title()
 * @see cpdf_set_keywords()
 */
function void cpdf_set_creator(string creator);
 
/**
 * Sets the title field of the pdf document
 * <p>
 * The cpdf_set_title() function sets the title of a pdf document.
 * 
 * @see cpdf_set_subject()
 * @see cpdf_set_creator()
 * @see cpdf_set_keywords()
 */
function void cpdf_set_title(string title);
 
/**
 * Sets the subject field of the pdf document
 * <p>
 * The cpdf_set_subject() function sets the subject of a pdf document.
 * 
 * @see cpdf_set_title()
 * @see cpdf_set_creator()
 * @see cpdf_set_keywords()
 */
function void cpdf_set_subject(string subject);
 
/**
 * Sets the keywords field of the pdf document
 * <p>
 * The cpdf_set_keywords() function sets the keywords of a pdf document.
 * 
 * @see cpdf_set_title()
 * @see cpdf_set_creator()
 * @see cpdf_set_subject()
 */
function void cpdf_set_keywords(string keywords);
 
/**
 * Opens a new pdf document
 * <p>
 * The cpdf_open() function opens a new pdf document. The first parameter
 * turns document compression on if it is unequal to 0. The second optional
 * parameter sets the file in which the document is written. If it is omitted
 * the document is created in memory and can either be written into a file
 * with the {@link cpdf_save_to_file()} or written to standard output with
 * {@link cpdf_output_buffer()}.
 * <p>
 * <b>Note:</b>
 * The return value will be needed in futher versions of
 * ClibPDF as the first parameter in all other functions which are
 * writing to the pdf document.
 * <p>
 * The ClibPDF library takes the filename "-" as a synonym for
 * stdout. If PHP is compiled as an apache module this will not work
 * because the way ClibPDF outputs to stdout does not work with
 * apache. You can solve this problem by skipping the filename and
 * using {@link cpdf_output_buffer()} to output the pdf document.
 * 
 * @see cpdf_close()
 * @see cpdf_output_buffer()
 */
function int cpdf_open(int compression, string filename);
 
/**
 * Closes the pdf document
 * <p>
 * The cpdf_close() function closes the pdf document. This should be the last
 * function even after {@link cpdf_finalize()}, {@link cpdf_output_buffer()} and
 * {@link cpdf_save_to_file()}.
 * 
 * @see cpdf_open()
 */
function void cpdf_close(int pdf_document);
 
/**
 * Starts new page
 * <p>
 * The cpdf_page_init() function starts a new page with height height and
 * width width. The page has number page number and orientation orientation.
 * orientation can be 0 for portrait and 1 for landscape. The last optional
 * parameter unit sets the unit for the koordinate system. The value should be
 * the number of postscript points per unit. Since one inch is equal to 72
 * points, a value of 72 would set the unit to one inch. The default is also
 * 72.
 * 
 * @see cpdf_set_current_page()
 */
function void cpdf_page_init(int pdf_document, int page_number, int orientation, double height, double width, double unit);
 
/**
 * Ends page
 * <p>
 * The cpdf_finalize_page() function ends the page with page number page
 * number. This function is only for saving memory. A finalized page takes
 * less memory but cannot be modified anymore.
 * 
 * @see cpdf_page_init()
 */
function void cpdf_finalize_page(int pdf_document, int page_number);
 
/**
 * Ends document
 * <p>
 * The cpdf_finalize() function ends the document. You still have to call
 * {@link cpdf_close()}.
 * 
 * @see cpdf_close()
 */
function void cpdf_finalize(int pdf_document);
 
/**
 * Outputs the pdf document in memory buffer
 * <p>
 * The cpdf_output_buffer() function outputs the pdf document to stdout. The
 * document has to be created in memory which is the case if {@link cpdf_open()} has
 * been called with no filename parameter.
 * 
 * @see cpdf_open()
 */
function void cpdf_output_buffer(int pdf_document);
 
/**
 * Writes the pdf document into a file
 * <p>
 * The cpdf_save_to_file() function outputs the pdf document into a file if it
 * has been created in memory. This function is not needed if the pdf document
 * has been open by specifying a filename as a parameter of {@link cpdf_open()}.
 * 
 * @see cpdf_output_buffer()
 * @see cpdf_open()
 */
function void cpdf_save_to_file(int pdf_document, string filename);
 
/**
 * Sets current page
 * <p>
 * The cpdf_set_current_page() function set the page on which all operations
 * are performed. One can switch between pages until a page is finished with
 * {@link cpdf_finalize_page()}.
 * 
 * @see cpdf_finalize_page()
 */
function void cpdf_set_current_page(int pdf_document, int page_number);
 
/**
 * Starts text section
 * <p>
 * The cpdf_begin_text() function starts a text section. It must be ended with
 * {@link cpdf_end_text()}.
 * <p>
 * <b>Example 1.</b> Text output
 * <pre>
 *    &lt;?php cpdf_begin_text($pdf);
 *    cpdf_set_font($pdf, 16, "Helvetica", 4);
 *    cpdf_text($pdf, 100, 100, "Some text");
 *    cpdf_end_text($pdf) ?&gt;
 * </pre>
 *
 * @see cpdf_end_text()
 */
function void cpdf_begin_text(int pdf_document);
 
/**
 * Starts text section
 * <p>
 * The cpdf_end_text() function ends a text section which was started with
 * {@link cpdf_begin_text()}.
 * <p>
 * <b>Example 1.</b> Text output
 * <pre>
 *    &lt;?php cpdf_begin_text($pdf);
 *    cpdf_set_font($pdf, 16, "Helvetica", 4);
 *    cpdf_text($pdf, 100, 100, "Some text");
 *    cpdf_end_text($pdf) ?&gt;
 * </pre>
 *
 * @see cpdf_begin_text()
 */
function void cpdf_end_text(int pdf_document);
 
/**
 * Output text at current position
 * <p>
 * The cpdf_show() function outputs the string in text at the current
 * position.
 * 
 * @see cpdf_text()
 * @see cpdf_begin_text()
 * @see cpdf_end_text()
 */
function void cpdf_show(int pdf_document, string text);
 
/**
 * Output text at position
 * <p>
 * The cpdf_show_xy() function outputs the string text at position with
 * coordinates (x-koor, y-koor). The last optional parameter determines the
 * unit length. If is 0 or omitted the default unit as specified for the page
 * is used. Otherwise the koodinates are measured in postscript points
 * disregarding the current unit.
 * <p>
 * <b>Note:</b>
 * The function {@link cpdf_show_xy()} is identical to {@link cpdf_text()}
 * without the optional parameters.
 * 
 * @see cpdf_text()
 */
function void cpdf_show_xy(int pdf_document, string text, double x_koor, double y_koor, int mode);
 
/**
 * Output text with parameters
 * <p>
 * The cpdf_text() function outputs the string text at position with
 * coordinates (x-koor, y-koor). The optional parameter determines the unit
 * length. If is 0 or omitted the default unit as specified for the page is
 * used. Otherwise the koodinates are measured in postscript points
 * disregarding the current unit. The optional parameter orientation is the
 * rotation of the text in degree. The optional parameter alignmode determines
 * how the text is align. See the ClibPDF documentation for possible values.
 * 
 * @see cpdf_show_xy()
 */
function void cpdf_text(int pdf_document, string text, double x_koor, double y_koor, int mode, double orientation, int alignmode);
 
/**
 * Select the current font face and size
 * <p>
 * The cpdf_set_font() function sets the the current font face, font size and
 * encoding. Currently only the standard postscript fonts are supported. The
 * last parameter encoding can take the following values: 2 = macroman, 3 =
 * macexpert, 4 = winansi. Any other value selects the font's buildin
 * encoding.
 */
function void cpdf_set_font(int pdf_document, string font_name, double size, int encoding);
 
/**
 * Sets distance between text lines
 * <p>
 * The cpdf_set_leading() function sets the distance between text lines. This
 * will be used if text is output by {@link cpdf_continue_text()}.
 * 
 * @see cpdf_continue_text()
 */
function void cpdf_set_leading(int pdf_document, double distance);
 
/**
 * Determines how text is rendered
 * <p>
 * The cpdf_set_text_rendering() function determines how text is rendered. The
 * possible values for mode are 0=fill text, 1=stroke text, 2=fill and stroke
 * text, 3=invisible, 4=fill text and add it to cliping path, 5=stroke text
 * and add it to clipping path, 6=fill and stroke text and add it to cliping
 * path, 7=add it to clipping path.
 */
function void cpdf_set_text_rendering(int pdf_document, int mode);
 
/**
 * Sets horizontal scaling of text
 * <p>
 * The {@link cpdf_set_horiz_scaling()} function sets the horizontal scaling to scale
 * percent.
 */
function void cpdf_set_horiz_scaling(int pdf_document, double scale);
 
/**
 * Sets the text rise
 * <p>
 * The cpdf_set_text_rise() function sets the text rising to value units.
 */
function void cpdf_set_text_rise(int pdf_document, double value);
 
/**
 * Sets the text matrix
 * <p>
 * The {@link cpdf_set_text_matrix()} function sets a matrix which describes a
 * transformation applied on the current text font.
 */
function void cpdf_set_text_matrix(int pdf_document, array matrix);
 
/**
 * Sets text position
 * <p>
 * The cpdf_set_text_pos() function sets the position of text for the next
 * {@link cpdf_show()} function call.
 * <p>
 * The last optional parameter mode determines the unit length. If is 0 or
 * omitted the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_show()
 * @see cpdf_text()
 */
function void cpdf_set_text_pos(int pdf_document, double x_koor, double y_koor, int mode);
 
/**
 * Sets character spacing
 * <p>
 * The cpdf_set_char_spacing() function sets the spacing between characters.
 * 
 * @see cpdf_set_word_spacing()
 * @see cpdf_set_leading()
 */
function void cpdf_set_char_spacing(int pdf_document, double space);
 
/**
 * Sets spacing between words
 * <p>
 * The cpdf_set_word_spacing() function sets the spacing between words.
 * 
 * @see cpdf_set_char_spacing()
 * @see cpdf_set_leading()
 */
function void cpdf_set_word_spacing(int pdf_document, double space);
 
/**
 * Output text in next line
 * <p>
 * The cpdf_continue_text() function outputs the string in text in the next
 * line.
 * 
 * @see cpdf_show_xy()
 * @see cpdf_text()
 * @see cpdf_set_leading()
 * @see cpdf_set_text_pos()
 */
function void cpdf_continue_text(int pdf_document, string text);
 
/**
 * Returns width of text in current font
 * 
 * The cpdf_stringwidth() function returns the width of the string in text. It
 * requires a font to be set before.
 * 
 * @see cpdf_set_font()
 */
function double cpdf_stringwidth(int pdf_document, string text);
 
/**
 * Saves current enviroment
 * <p>
 * The cpdf_save() function saves the current enviroment. It works like the
 * postscript command gsave. Very useful if you want to translate or rotate an
 * object without effecting other objects.
 * 
 * @see cpdf_restore()
 */
function void cpdf_save(int pdf_document);
 
/**
 * Restores formerly saved enviroment
 * <p>
 * The cpdf_restore() function restores the enviroment saved with {@link cpdf_save()}.
 * It works like the postscript command grestore. Very useful if you want to
 * translate or rotate an object without effecting other objects.
 * <p>
 * <b>Example 1.</b> Save/Restore
 * <pre>
 *    &lt;?php cpdf_save($pdf);
 *    // do all kinds of rotations, transformations, ...
 *    cpdf_restore($pdf) ?&gt;
 * </pre>
 *
 * @see cpdf_save()
 */
function void cpdf_restore(int pdf_document);
 
/**
 * Sets origin of coordinate system
 * <p>
 * The cpdf_translate() function set the origin of coordinate system to the
 * point (x-koor, y-koor).
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * coordinates are measured in postscript points disregarding the current unit.
 */
function void cpdf_translate(int pdf_document, double x_koor, double y_koor, int mode);
 
/**
 * Sets scaling
 * <p>
 * The cpdf_scale() function set the scaling factor in both directions.
 */
function void cpdf_scale(int pdf_document, double x_scale, double y_scale);
 
/**
 * Sets rotation
 * <p>
 * The cpdf_rotate() function set the rotation in degress to angle.
 */
function void cpdf_rotate(int pdf_document, double angle);
 
/**
 * Sets flatness
 * <p>
 * The cpdf_setflat() function set the flatness to a value between 0 and 100.
 */
function void cpdf_setflat(int pdf_document, double value);
 
/**
 * Sets linejoin parameter
 * <p>
 * The cpdf_setlinejoin() function set the linejoin parameter between a value
 * of 0 and 2. 0 = miter, 1 = round, 2 = bevel.
 */
function void cpdf_setlinejoin(int pdf_document, long value);
 
/**
 * Sets linecap aparameter
 * <p>
 * The cpdf_setlinecap() function set the linecap parameter between a value of
 * 0 and 2. 0 = butt end, 1 = round, 2 = projecting square.
 */
function void cpdf_setlinecap(int pdf_document, int value);
 
/**
 * Sets miter limit
 * <p>
 * The cpdf_setmiterlimit() function set the miter limit to a value greater or
 * equal than 1.
 */
function void cpdf_setmiterlimit(int pdf_document, double value);
 
/**
 * Sets line width
 * <p>
 * The cpdf_setlinewidth() function set the line width to width.
 */
function void cpdf_setlinewidth(int pdf_document, double width);
 
/**
 * Sets dash pattern
 * <p>
 * The cpdf_setdash() function set the dash pattern white white units and
 * black black units. If both are 0 a solid line is set.
 */
function void cpdf_setdash(int pdf_document, double white, double black);
 
/**
 * Sets current point
 * <p>
 * The cpdf_moveto() function set the current point to the coordinates x-koor
 * and y-koor.
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 */
function void cpdf_moveto(int pdf_document, double x_koor, double y_koor, int mode);
 
/**
 * Sets current point
 * <p>
 * The cpdf_rmoveto() function set the current point relative to the
 * coordinates x-koor and y-koor.
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_moveto()
 */
function void cpdf_rmoveto(int pdf_document, double x_koor, double y_koor, int mode);
 
/**
 * Draws a curve
 * <p>
 * The cpdf_curveto() function draws a Bezier curve from the current point to
 * the point (x3, y3) using (x1, y1) and (x2, y2) as control points.
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_moveto()
 * @see cpdf_rmoveto()
 * @see cpdf_rlineto()
 * @see cpdf_lineto()
 */
function void cpdf_curveto(int pdf_document, double x1, double y1, double x2, double y2, double x3, double y3, int mode);
 
/**
 * Draws a line
 * <p>
 * The cpdf_lineto() function draws a line from the current point to the point
 * with coordinates (x-koor, y-koor).
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_moveto()
 * @see cpdf_rmoveto()
 * @see cpdf_curveto()
 */
function void cpdf_lineto(int pdf_document, double x_koor, double y_koor, int mode);
 
/**
 * Draws a line
 * <p>
 * The cpdf_rlineto() function draws a line from the current point to the
 * relative point with coordinates (x-koor, y-koor).
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_moveto()
 * @see cpdf_rmoveto()
 * @see cpdf_curveto()
 */
function void cpdf_rlineto(int pdf_document, double x_koor, double y_koor, int mode);
 
/**
 * Draw a circle
 * <p>
 * The cpdf_circle() function draws a circle with center at point (x-koor,
 * y-koor) and radius radius.
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_arc()
 */
function void cpdf_circle(int pdf_document, double x_koor, double y_koor, double radius, int mode);
 
/**
 * Draws an arc
 * <p>
 * The cpdf_arc() function draws an arc with center at point (x-koor, y-koor)
 * and radius radius, starting at angle start and ending at angle end.
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_circle()
 */
function void cpdf_arc(int pdf_document, double x_koor, double y_koor, double radius, double start, double end, int mode);
 
/**
 * Draw a rectangle
 * <p>
 * The cpdf_rect() function draws a rectangle with its lower left corner at
 * point (x-koor, y-koor). This width is set to widgth. This height is set to
 * height.
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 */
function void cpdf_rect(int pdf_document, double x_koor, double y_koor, double width, double height, int mode);
 
/**
 * Close path
 * <p>
 * The cpdf_closepath() function closes the current path.
 */
function void cpdf_closepath(int pdf_document);
 
/**
 * Draw line along path
 * <p>
 * The cpdf_stroke() function draws a line along current path.
 * 
 * @see cpdf_closepath()
 * @see cpdf_closepath_stroke()
 */
function void cpdf_stroke(int pdf_document);
 
/**
 * Close path and draw line along path
 * <p>
 * The cpdf_closepath_stroke() function is a combination of {@link cpdf_closepath()}
 * and {@link cpdf_stroke()}. Than clears the path.
 * 
 * @see cpdf_closepath()
 * @see cpdf_stroke()
 */
function void cpdf_closepath_stroke(int pdf_document);
 
/**
 * Fill current path
 * <p>
 * The cpdf_fill() function fills the interior of the current path with the
 * current fill color.
 * 
 * @see cpdf_closepath()
 * @see cpdf_stroke()
 * @see cpdf_setgray_fill()
 * @see cpdf_setgray()
 * @see cpdf_setrgbcolor_fill()
 * @see cpdf_setrgbcolor()
 */
function void cpdf_fill(int pdf_document);
 
/**
 * Fill and stroke current path
 * <p>
 * The cpdf_fill_stroke() function fills the interior of the current path with
 * the current fill color and draws current path.
 * 
 * @see cpdf_closepath()
 * @see cpdf_stroke()
 * @see cpdf_fill()
 * @see cpdf_setgray_fill()
 * @see cpdf_setgray()
 * @see cpdf_setrgbcolor_fill()
 * @see cpdf_setrgbcolor()
 */
function void cpdf_fill_stroke(int pdf_document);
 
/**
 * Close, fill and stroke current path
 * <p>
 * The cpdf_closepath_fill_stroke() function closes, fills the interior of the
 * current path with the current fill color and draws current path.
 * 
 * @see cpdf_closepath()
 * @see cpdf_stroke()
 * @see cpdf_fill()
 * @see cpdf_setgray_fill()
 * @see cpdf_setgray()
 * @see cpdf_setrgbcolor_fill()
 * @see cpdf_setrgbcolor()
 */
function void cpdf_closepath_fill_stroke(int pdf_document);
 
/**
 * Clips to current path
 * <p>
 * The cpdf_clip() function clips all drawing to the current path.
 */
function void cpdf_clip(int pdf_document);
 
/**
 * Sets filling color to gray value
 * <p>
 * The cpdf_setgray_fill() function sets the current gray value to fill a
 * path.
 * 
 * @see cpdf_setrgbcolor_fill()
 */
function void cpdf_setgray_fill(int pdf_document, double value);
 
/**
 * Sets drawing color to gray value
 * <p>
 * The cpdf_setgray_stroke() function sets the current drawing color to the
 * given gray value.
 * 
 * @see cpdf_setrgbcolor_stroke()
 */
function void cpdf_setgray_stroke(int pdf_document, double gray_value);
 
/**
 * Sets drawing and filling color to gray value
 * <p>
 * The cpdf_setgray_stroke() function sets the current drawing and filling
 * color to the given gray value.
 * 
 * @see cpdf_setrgbcolor_stroke()
 * @see cpdf_setrgbcolor_fill()
 */
function void cpdf_setgray(int pdf_document, double gray_value);
 
/**
 * Sets filling color to rgb color value
 * <p>
 * The cpdf_setrgbcolor_fill() function sets the current rgb color value to
 * fill a path.
 * 
 * @see cpdf_setrgbcolor_stroke()
 * @see cpdf_setrgbcolor()
 */
function void cpdf_setrgbcolor_fill(int pdf_document, double red_value, double green_value, double blue_value);
 
/**
 * Sets drawing color to rgb color value
 * <p>
 * The cpdf_setrgbcolor_stroke() function sets the current drawing color to
 * the given rgb color value.
 * 
 * @see cpdf_setrgbcolor_fill()
 * @see cpdf_setrgbcolor()
 */
function void cpdf_setrgbcolor_stroke(int pdf_document, double red_value, double green_value, double blue_value);
 
/**
 * Sets drawing and filling color to rgb color value
 * <p>
 * The cpdf_setrgbcolor_stroke() function sets the current drawing and filling
 * color to the given rgb color value.
 * 
 * @see cpdf_setrgbcolor_stroke()
 * @see cpdf_setrgbcolor_fill()
 */
function void cpdf_setrgbcolor(int pdf_document, double red_value, double green_value, double blue_value);
 
/**
 * Adds bookmark for current page
 * <p>
 * The cpdf_add_outline() function adds a bookmark with text text that points
 * to the current page.
 * <p>
 * <b>Example 1.</b> Adding a page outline
 * <pre>
 *    &lt;?php
 *    $cpdf = cpdf_open(0);
 *    cpdf_page_init($cpdf, 1, 0, 595, 842);
 *    cpdf_add_outline($cpdf, 0, 0, 0, 1, "Page 1");
 *    // ...
 *    // some drawing
 *    // ...
 *    cpdf_finalize($cpdf);
 *    Header("Content-type: application/pdf");
 *    cpdf_output_buffer($cpdf);
 *    cpdf_close($cpdf);
 *    ?&gt;
 * </pre>
 */
function void cpdf_add_outline(int pdf_document, string text);
 
/**
 * Sets duration between pages
 * <p>
 * The cpdf_set_page_animation() function set the transition between following
 * pages.
 * <p>
 * The value of transition can be
 * <ul>
 * <li>0 for none,
 * <li>1 for two lines sweeping across the screen reveal the page,
 * <li>2 for multiple lines sweeping across the screen reveal the page,
 * <li>3 for a box reveals the page,
 * <li>4 for a single line sweeping across the screen reveals the page,
 * <li>5 for the old page dissolves to reveal the page,
 * <li>6 for the dissolve effect moves from one screen edge to another,
 * <li>7 for the old page is simply replaced by the new page (default)
 * </ul>
 * The value of duration is the number of seconds between page flipping.
 */
function void cpdf_set_page_animation(int pdf_document, int transition, double duration);
 
/**
 * Opens a JPEG image
 * <p>
 * The cpdf_import_jpeg() function opens an image stored in the file with the
 * name file name. The format of the image has to be jpeg. The image is placed
 * on the current page at position (x-koor, y-koor). The image is rotated by
 * angle degres.
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_place_inline_image()
 */
function int cpdf_open_jpeg(int pdf_document, string file_name, double x_koor, double y_koor, double angle, double width, double height, double x_scale, double y_scale, int mode);
 
/**
 * Places an image on the page
 * <p>
 * The cpdf_place_inline_image() function places an image created with the php
 * image functions on the page at postion (x-koor, y-koor). The image can be
 * scaled at the same time.
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 * 
 * @see cpdf_import_jpeg()
 */
function void cpdf_place_inline_image(int pdf_document, int image, double x_koor, double y_koor, double angle, double width, double height, int mode);
 
/**
 * Adds annotation
 * <p>
 * The cpdf_add_annotation() adds a note with the lower left corner at (llx,
 * lly) and the upper right corner at (urx, ury).
 * <p>
 * The last optional parameter determines the unit length. If is 0 or omitted
 * the default unit as specified for the page is used. Otherwise the
 * koodinates are measured in postscript points disregarding the current unit.
 */
function void cpdf_add_annotation(int pdf_document, double llx, double lly, double urx, double ury, string title, string content, int mode);


///////////////////////////////////////////////////////////////////////////
// Date and Time functions
//
 
/**
 * validate a date/time
 * <p>
 * Returns true if the date given is valid; otherwise returns false. Checks
 * the validity of the date formed by the arguments. A date is considered
 * valid if:
 * <ul>
 * <li> year is between 0 and 32767 inclusive
 * <li> month is between 1 and 12 inclusive
 * <li> day is within the allowed number of days for the given month. Leap
 *      years are taken into consideration.
 * </ul>
 */
function int checkdate(int month, int day, int year);
 
/**
 * format a local time/date
 * <p>
 * Returns a string formatted according to the given format string using the
 * given timestamp or the current local time if no timestamp is given.
 * <p>
 * The following characters are recognized in the format string:
 * <ul>
 * <li> a - "am" or "pm"
 * <li> A - "AM" or "PM"
 * <li> d - day of the month, 2 digits with leading zeros; i.e. "01" to "31"
 * <li> D - day of the week, textual, 3 letters; i.e. "Fri"
 * <li> F - month, textual, long; i.e. "January"
 * <li> h - hour, 12-hour format; i.e. "01" to "12"
 * <li> H - hour, 24-hour format; i.e. "00" to "23"
 * <li> g - hour, 12-hour format without leading zeros; i.e. "1" to "12"
 * <li> G - hour, 24-hour format without leading zeros; i.e. "0" to "23"
 * <li> i - minutes; i.e. "00" to "59"
 * <li> j - day of the month without leading zeros; i.e. "1" to "31"
 * <li> l (lowercase 'L') - day of the week, textual, long; i.e. "Friday"
 * <li> L - boolean for whether it is a leap year; i.e. "0" or "1"
 * <li> m - month; i.e. "01" to "12"
 * <li> n - month without leading zeros; i.e. "1" to "12"
 * <li> M - month, textual, 3 letters; i.e. "Jan"
 * <li> s - seconds; i.e. "00" to "59"
 * <li> S - English ordinal suffix, textual, 2 characters; i.e. "th", "nd"
 * <li> t - number of days in the given month; i.e. "28" to "31"
 * <li> U - seconds since the epoch
 * <li> w - day of the week, numeric, i.e. "0" (Sunday) to "6" (Saturday)
 * <li> Y - year, 4 digits; i.e. "1999"
 * <li> y - year, 2 digits; i.e. "99"
 * <li> z - day of the year; i.e. "0" to "365"
 * <li> Z - timezone offset in seconds (i.e. "-43200" to "43200")
 * </ul>
 * Unrecognized characters in the format string will be printed as-is. The "Z"
 * format will always return "0" when using {@link gmdate()}().
 * <p>
 * <b>Example 1.</b> date() example
 * <pre>
 *    print (date("l dS of F Y h:i:s A"));
 *    print ("July 1, 2000 is on a " . date("l", mktime(0,0,0,7,1,2000)));
 * </pre>
 * It is possible to use date() and {@link mktime()} together to find dates in the
 * future or the past.
 * <p>
 * <b>Example 2.</b> date() and mktime() example
 * <pre>
 *    $tomorrow  = mktime(0,0,0,date("m")  ,date("d")+1,date("Y"));
 *    $lastmonth = mktime(0,0,0,date("m")-1,date("d"),  date("Y"));
 *    $nextyear  = mktime(0,0,0,date("m"),  date("d",   date("Y")+1);
 * </pre>
 * To format dates in other languages, you should use the {@link setlocale()} and
 * {@link strftime()} functions.
 * 
 * @see gmdate()
 * @see mktime()
 */
function string date(string format, int [timestamp] );
 
/**
 * format a local time/date according to locale settings
 * <p>
 * Returns a string formatted according to the given format string using the
 * given timestamp or the current local time if no timestamp is given. Month
 * and weekday names and other language dependent strings respect the current
 * locale set with {@link setlocale()}.
 * <p>
 * The following conversion specifiers are recognized in the format string:
 * <ul>
 * <li> %a - abbreviated weekday name according to the current locale
 * <li> %A - full weekday name according to the current locale
 * <li> %b - abbreviated month name according to the current locale
 * <li> %B - full month name according to the current locale
 * <li> %c - preferred date and time representation for the current locale
 * <li> %d - day of the month as a decimal number (range 00 to 31)
 * <li> %H - hour as a decimal number using a 24-hour clock (range 00 to 23)
 * <li> %I - hour as a decimal number using a 12-hour clock (range 01 to 12)
 * <li> %j - day of the year as a decimal number (range 001 to 366)
 * <li> %m - month as a decimal number (range 1 to 12)
 * <li> %M - minute as a decimal number
 * <li> %p - either `am' or `pm' according to the given time value, or the
 *      corresponding strings for the current locale
 * <li> %S - second as a decimal number
 * <li> %U - week number of the current year as a decimal number, starting
 *      with the first Sunday as the first day of the first week
 * <li> %W - week number of the current year as a decimal number, starting
 *      with the first Monday as the first day of the first week
 * <li> %w - day of the week as a decimal, Sunday being 0
 * <li> %x - preferred date representation for the current locale without the
 *      time
 * <li> %X - preferred time representation for the current locale without the
 *      date
 * <li> %y - year as a decimal number without a century (range 00 to 99)
 * <li> %Y - year as a decimal number including the century
 * <li> %Z - time zone or name or abbreviation
 * <li> %% - a literal `%' character
 * </ul>
 * <b>Example 1.</b> strftime() example
 * <pre>
 *    setlocale ("LC_TIME", "C");
 *    print(strftime("%A in Finnish is "));
 *    setlocale ("LC_TIME", "fi_FI");
 *    print(strftime("%A, in French "));
 *    setlocale ("LC_TIME", "fr_CA");
 *    print(strftime("%A and in German "));
 *    setlocale ("LC_TIME", "de_DE");
 *    print(strftime("%A.\n"));
 * </pre>
 * This example works if you have the respective locales installed in your
 * system.
 * 
 * @see setlocale()
 * @see mktime()
 */
function string strftime(string format, int timestamp);
 
/**
 * format a GMT/CUT time/date according to locale settings
 * <p>
 * Behaves the same as {@link strftime()} except that the time returned is Greenwich
 * Mean Time (GMT). For example, when run in Eastern Standard Time (GMT
 * -0500), the first line below prints "Dec 31 1998 20:00:00", while the
 * second prints "Jan 01 1999 01:00:00".
 * <p>
 * <b>Example 1.</b> gmstrftime() example
 * <pre>
 *    setlocale ('LC_TIME','en_US');
 *    echo strftime ("%b %d %Y %H:%M:%S",mktime(20,0,0,12,31,98))."\n";
 *    echo gmstrftime ("%b %d %Y %H:%M:%S",mktime(20,0,0,12,31,98))."\n";
 * </pre>
 *
 * @see strftime()
 */
function string gmstrftime(string format, int timestamp);
 
/**
 * get date/time information
 * <p>
 * Returns an associative array containing the date information of the
 * timestamp as the following array elements:
 * <ul>
 * <li> "seconds" - seconds
 * <li> "minutes" - minutes
 * <li> "hours" - hours
 * <li> "mday" - day of the month
 * <li> "wday" - day of the week, numeric
 * <li> "mon" - month, numeric
 * <li> "year" - year, numeric
 * <li> "yday" - day of the year, numeric; i.e. "299"
 * <li> "weekday" - day of the week, textual, full; i.e. "Friday"
 * <li> "month" - month, textual, full; i.e. "January"
 * </ul>
 */
function array getdate(int timestamp);
 
/**
 * get current time
 * <p>
 * This is an interface to gettimeofday(2). It returns an associative array
 * containing the data returned from the system call.
 * <ul>
 * <li> "sec" - seconds
 * <li> "usec" - microseconds
 * <li> "minuteswest" - minutes west of Greenwich
 * <li> "dsttime" - type of dst correction
 * </ul>
 */
function array gettimeofday(void);
 
/**
 * format a GMT/CUT date/time
 * <p>
 * Identical to the {@link date()} function except that the time returned is Greenwich
 * Mean Time (GMT). For example, when run in Finland (GMT +0200), the first
 * line below prints "Jan 01 1998 00:00:00", while the second prints "Dec 31
 * 1997 22:00:00".
 * <p>
 * <b>Example 1.</b> gmdate() example
 * <pre>
 *    echo date( "M d Y H:i:s",mktime(0,0,0,1,1,1998) );
 *    echo gmdate( "M d Y H:i:s",mktime(0,0,0,1,1,1998) );
 * </pre>
 *
 * @see date()
 * @see mktime()
 * @see gmmktime()
 */
function string gmdate(string format, int timestamp);
 
/**
 * get UNIX timestamp for a date
 * <p>
 * Warning: Note the strange order of arguments, which differs from the order
 * of arguments in a regular UNIX {@link mktime()} call and which does not lend itself
 * well to leaving out parameters from right to left (see below). It is a
 * common error to mix these values up in a script.
 * <p>
 * Returns the Unix timestamp corresponding to the arguments given. This
 * timestamp is a long integer containing the number of seconds between the
 * Unix Epoch (January 1 1970) and the time specified.
 * <p>
 * Arguments may be left out in order from right to left; any arguments thus
 * omitted will be set to the current value according to the local date and
 * time.
 * <p>
 * is_dst can be set to 1 if the time is during daylight savings time, 0 if it
 * is not, or -1 (the default) if it is unknown whether the time is within
 * daylight savings time or not.
 * <p>
 * {@link mktime()} is useful for doing date arithmetic and validation, as it will
 * automatically calculate the correct value for out-of-range input. For
 * example, each of the following lines produces the string "Jan-01-1998".
 * <p>
 * <b>Example 1.</b> mktime() example
 * <pre>
 *    echo date( "M-d-Y", mktime(0,0,0,12,32,1997) );
 *    echo date( "M-d-Y", mktime(0,0,0,13,1,1997) );
 *    echo date( "M-d-Y", mktime(0,0,0,1,1,1998) );
 * </pre>
 *
 * @see date()
 * @see time()
 * @since is_dst was added in 3.0.10.
 */
function int mktime(int hour, int minute, int second, int month, int day, int year, int [is_dst]);
 
/**
 * get UNIX timestamp for a GMT date
 * <p>
 * Identical to {@link mktime()} except the passed parameters represents a GMT date.
 */
function int gmmktime(int hour, int minute, int second, int month, int day, int year, int [is_dst]);
 
/**
 * return current UNIX timestamp
 * <p>
 * Returns the current time measured in the number of seconds since the Unix
 * Epoch (January 1 1970 00:00:00 GMT).
 * 
 * @see date()
 */
function int time(void);
 

/**
 * return current UNIX timestamp with microseconds
 * <p>
 * Returns the string "msec sec" where sec is the current time measured in the
 * number of seconds since the Unix Epoch (0:00:00 January 1, 1970 GMT), and
 * msec is the microseconds part. This function is only available on operating
 * systems that support the {@link gettimeofday()} system call.
 * 
 * @see time()
 */
function string microtime(void);


///////////////////////////////////////////////////////////////////////////
// Database (dbm-style) abstraction layer functions
//
// These functions build the foundation for accessing Berkeley DB style
// databases.
// 
// This is a general abstraction layer for several file-based databases. As
// such, functionality is limited to a subset of features modern databases
// such as Sleepycat Software's DB2 support. (This is not to be confused with
// IBM's DB2 software, which is supported through the ODBC functions.)
// 
// The behaviour of various aspects depend on the implementation of the
// underlying database. Functions such as dba_optimize() and dba_sync() will
// do what they promise for one database and will do nothing for others.
// 
// The following handlers are supported:
// 
//    * dbm is the oldest (original) type of Berkeley DB style databases. You
//      should avoid it, if possible. We do not support the compatibility
//      functions built into DB2 and gdbm, because they are only compatible on
//      the source code level, but cannot handle the original dbm format.
// 
//    * ndbm is a newer type and more flexible than dbm. It still has most of
//      the arbitrary limits of dbm (therefore it is deprecated).
// 
//    * gdbm is the GNU database manager.
// 
//    * db2 is Sleepycat Software's DB2. It is described as "a programmatic
//      toolkit that provides high-performance built-in database support for
//      both standalone and client/server applications."
// 
//    * cdb is "a fast, reliable, lightweight package for creating and reading
//      constant databases." It is from the author of qmail and can be found
//      here. Since it is constant, we support only reading operations.
// 
// Example 1. DBA example
// 
// <?php
// $id = dba_open("/tmp/test.db", "n", "db2");
// if(!$id) {
//     echo "dba_open failed\n";
//     exit;
// }
// dba_replace("key", "This is an example!", $id);
// if(dba_exists("key", $id)) {
//     echo dba_fetch("key", $id);
//     dba_delete("key", $id);
// }
// dba_close($id);
// ?>
// 
// DBA is binary safe and does not have any arbitrary limits. It inherits all
// limits set by the underlying database implementation.
// 
// All file-based databases must provide a way of setting the file mode of a
// new created database, if that is possible at all. The file mode is commonly
// passed as the fourth argument to dba_open() or dba_popen().
// 
// You can access all entries of a database in a linear way by using the
// dba_firstkey() and dba_nextkey() functions. You may not change the database
// while traversing it.
// 
// Example 2. Traversing a database
// 
// <?php
// # ...open database...
// $key = dba_firstkey($id);
// while($key != false) {
//     if(...) { # remember the key to perform some action later
//         $handle_later[] = $key;
//     }
//     $key = dba_nextkey($id);
// }
// for($i = 0; $i < count($handle_later); $i++)
//     dba_delete($handle_later[$i], $id);
// ?>
 
/**
 * Close database
 * <p>
 * dba_close() closes the established database and frees all resources
 * specified by handle.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_close() does not return any value.
 * 
 * @see dba_open()
 * @see dba_popen()
 */
function void dba_close(int handle);
 
/**
 * Delete entry specified by key
 * <p>
 * dba_delete() deletes the entry specified by key from the database specified
 * with handle.
 * <p>
 * key is the key of the entry which is deleted.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_delete() returns true or false, if the entry is deleted or not deleted,
 * respectively.
 * 
 * @see dba_exists()
 * @see dba_fetch()
 * @see dba_insert()
 * @see dba_replace()
 */
function string dba_delete(string key, int handle);
 
/**
 * Check whether key exists
 * <p>
 * dba_exists() checks whether the specified key exists in the database
 * specified by handle.
 * <p>
 * key is the key the check is performed for.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_exists() returns true or false, if the key is found or not found,
 * respectively.
 * 
 * @see dba_fetch()
 * @see dba_delete()
 * @see dba_insert()
 * @see dba_replace()
 */
function bool dba_exists(string key, int handle);
 
/**
 * Fetch data specified by key
 * <p>
 * dba_fetch() fetches the data specified by key from the database specified
 * with handle.
 * <p>
 * key is the key the data is specified by.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_fetch() returns the associated string or false, if the key/data pair is
 * found or not found, respectively.
 * 
 * @see dba_exists()
 * @see dba_delete()
 * @see dba_insert()
 * @see dba_replace()
 */
function string dba_fetch(string key, int handle);
 
/**
 * Fetch first key
 * <p>
 * dba_firstkey() returns the first key of the database specified by handle
 * and resets the internal key pointer. This permits a linear search through
 * the whole database.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_firstkey() returns the key or false depending on whether it succeeds or
 * fails, respectively.
 * 
 * @see dba_nextkey()
 */
function string dba_firstkey(int handle);
 
/**
 * Insert entry
 * <p>
 * dba_insert() inserts the entry described with key and value into the
 * database specified by handle. It fails, if an entry with the same key
 * already exists.
 * <p>
 * key is the key of the entry to be inserted.
 * <p>
 * value is the value to be inserted.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_insert() returns true or false, depending on whether it succeeds of
 * fails, respectively.
 * 
 * @see dba_exists()
 * @see dba_delete()
 * @see dba_fetch()
 * @see dba_replace()
 */
function bool dba_insert(string key, string value, int handle);
 
/**
 * Fetch next key
 * <p>
 * dba_nextkey() returns the next key of the database specified by handle and
 * increments the internal key pointer.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_nextkey() returns the key or false depending on whether it succeeds or
 * fails, respectively.
 * 
 * @see dba_firstkey()
 */
function string dba_nextkey(int handle);
 
/**
 * Open database persistently
 * <p>
 * dba_popen() establishes a persistent database instance for path with mode
 * using handler.
 * <p>
 * path is commonly a regular path in your filesystem.
 * <p>
 * mode is "r" for read access, "w" for read/write access to an already
 * existing database, "c" for read/write access and database creation if it
 * doesn't currently exist, and "n" for create, truncate and read/write
 * access.
 * <p>
 * handler is the name of the handler which shall be used for accessing path.
 * It is passed all optional parameters given to {@link dba_popen()} and can act on
 * behalf of them.
 * <p>
 * dba_popen() returns a positive handler id or false, in the case the open is
 * successful or fails, respectively.
 * 
 * @see dba_open()
 * @see dba_close()
 */
function int dba_popen(string path, string mode, string handler, [...]);
 
/**
 * Open database
 * <p>
 * dba_open() establishes a database instance for path with mode using
 * handler.
 * <p>
 * path is commonly a regular path in your filesystem.
 * <p>
 * mode is "r" for read access, "w" for read/write access to an already
 * existing database, "c" for read/write access and database creation if it
 * doesn't currently exist, and "n" for create, truncate and read/write
 * access.
 * <p>
 * handler is the name of the handler which shall be used for accessing path.
 * It is passed all optional parameters given to {@link dba_open()} and can act on
 * behalf of them.
 * <p>
 * dba_open() returns a positive handler id or false, in the case the open is
 * successful or fails, respectively.
 * 
 * @see dba_popen()
 * @see dba_close()
 */
function int dba_open(string path, string mode, string handler, [...]);
 
/**
 * Optimize database
 * <p>
 * dba_optimize() optimizes the underlying database specified by handle.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_optimize() returns true or false, if the optimization succeeds or
 * fails, respectively.
 * 
 * @see dba_sync()
 */
function bool dba_optimize(int handle);
 
/**
 * Replace or insert entry
 * <p>
 * dba_replace() replaces or inserts the entry described with key and value
 * into the database specified by handle.
 * <p>
 * key is the key of the entry to be inserted.
 * <p>
 * value is the value to be inserted.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_replace() returns true or false, depending on whether it succeeds of
 * fails, respectively.
 * 
 * @see dba_exists()
 * @see dba_delete()
 * @see dba_fetch()
 * @see dba_insert()
 */
function bool dba_replace(string key, string value, int handle);
 
/**
 * Synchronize database
 * <p>
 * dba_sync() synchronizes the database specified by handle. This will
 * probably trigger a physical write to disk, if supported.
 * <p>
 * handle is a database handle returned by {@link dba_open()}.
 * <p>
 * dba_sync() returns true or false, if the synchronization succeeds or fails,
 * respectively.
 * 
 * @see dba_optimize()
 */ 
function bool dba_sync(int handle);


///////////////////////////////////////////////////////////////////////////
// dBase functions
//
// These functions allow you to access records stored in dBase-format (dbf)
// databases.
// 
// There is no support for indexes or memo fields. There is no support for
// locking, too. Two concurrent webserver processes modifying the same dBase
// file will very likely ruin your database.
// 
// Unlike SQL databases, dBase "databases" cannot change the database
// definition afterwards. Once the file is created, the database definition is
// fixed. There are no indexes that speed searching or otherwise organize your
// data. dBase files are simple sequential files of fixed length records.
// Records are appended to the end of the file and delete records are kept
// until you call dbase_pack()().
// 
// We recommend that you do not use dBase files as your production database.
// Choose any real SQL server instead; MySQL or Postgres are common choices
// with PHP. dBase support is here to allow you to import and export data to
// and from your web database, since the file format is commonly understood
// with Windows spreadsheets and organizers. Import and export of data is
// about all that dBase support is good for.
 
/**
 * creates a dBase database
 * <p>
 * The fields parameter is an array of arrays, each array describing the
 * format of one field in the database. Each field consists of a name, a
 * character indicating the field type, a length, and a precision.
 * <p>
 * The types of fields available are:
 * <ul>
 * <li> L - Boolean. These do not have a length or precision.
 * <li> M - Memo. (Note that these aren't supported by PHP.) These do not have a
 *          length or precision.
 * <li> D - Date (stored as YYYYMMDD). These do not have a length or precision.
 * <li> N - Number. These have both a length and a precision (the number of digits
 *          after the decimal point).
 * <li> C - String.
 * </ul>
 * If the database is successfully created, a dbase_identifier is returned,
 * otherwise false is returned.
 * <p>
 * <b>Example 1.</b> Creating a dBase database file
 * <pre>
 *    // "database" name
 *    $dbname = "/tmp/test.dbf";
 *    // database "definition"
 *    $def =
 *       array(
 *         array("date",     "D"),
 *         array("name",     "C",  50),
 *         array("age",      "N",   3, 0),
 *         array("email",    "C", 128),
 *         array("ismember", "L")
 *       );
 * 
 *    // creation
 *    if (!dbase_create($dbname, $def))
 *       print "&lt;strong&gt;Error!&lt;/strong&gt;";
 * </pre>
 */
function int dbase_create(string filename, array fields);
 
/**
 * opens a dBase database
 * <p>
 * The flags correspond to those for the {@link open()} system call. (Typically 0
 * means read-only, 1 means write-only, and 2 means read and write.)
 * <p>
 * Returns a dbase_identifier for the opened database, or false if the
 * database couldn't be opened.
 */
function int dbase_open(string filename, int flags);
 
/**
 * close a dBase database
 * <p>
 * Closes the database associated with dbase_identifier.
 */
function bool dbase_close(int dbase_identifier);
 
/**
 * packs a dBase database
 * <p>
 * Packs the specified database (permanently deleting all records marked for
 * deletion using {@link dbase_delete_record()}.
 */
function bool dbase_pack(int dbase_identifier);
 
/**
 * add a record to a dBase database
 * <p>
 * Adds the data in the record to the database. If the number of items in the
 * supplied record isn't equal to the number of fields in the database, the
 * operation will fail and false will be returned.
 */
function bool dbase_add_record(int dbase_identifier, array record);
 
/**
 * replace a record in a dBase database
 * <p>
 * Replaces the data associated with the record record_number with the data in
 * the record in the database. If the number of items in the supplied record
 * is not equal to the number of fields in the database, the operation will
 * fail and false will be returned.
 * <p>
 * dbase_record_number is an integer which spans from 1 to the number of
 * records in the database (as returned by {@link dbase_numrecords()}).
 */
function bool dbase_replace_record(int dbase_identifier, array record,  dbase_record_number);
 
/**
 * deletes a record from a dBase database
 * <p>
 * Marks record to be deleted from the database. To actually remove the record
 * from the database, you must also call {@link dbase_pack()}.
 */
function bool dbase_delete_record(int dbase_identifier, int record);
 
/**
 * gets a record from a dBase database
 * <p>
 * Returns the data from record in an array. The array is indexed starting at
 * 0, and includes an associative member named 'deleted' which is set to 1 if
 * the record has been marked for deletion (see {@link dbase_delete_record()}.
 * <p>
 * Each field is converted to the appropriate PHP type. (Dates are left as
 * strings.)
 */
function array dbase_get_record(int dbase_identifier, int record);
 
/**
 * Returns the data from record in an associative array. The array also
 * includes an associative member named 'deleted' which is set to 1 if the
 * record has been marked for deletion (see {@link dbase_delete_record()}.
 * <p>
 * Each field is converted to the appropriate PHP type. (Dates are left as
 * strings.)
 */
function array dbase_get_record_with_names(int dbase_identifier, int record);
 
/**
 * find out how many fields are in a dBase database
 * <p>
 * Returns the number of fields (columns) in the specified database. Field
 * numbers are between 0 and dbase_numfields($db)-1, while record numbers are
 * between 1 and dbase_numrecords($db).
 * <p>
 * <b>Example 1.</b> Using {@link dbase_numfields()}
 * <pre>
 *    $rec = dbase_get_record($db, $recno);
 *    $nf  = dbase_numfields($db);
 *    for ($i=0; $i &lt; $nf; $i++) {
 *       print $rec[$i]."&lt;br&gt;\n";
 *    }
 * </pre>
 */
function int dbase_numfields(int dbase_identifier);
 
/**
 * find out how many records are in a dBase database
 * <p>
 * Returns the number of records (rows) in the specified database. Record
 * numbers are between 1 and dbase_numrecords($db), while field numbers are
 * between 0 and dbase_numfields($db)-1.
 */
function int dbase_numrecords(int dbase_identifier);


///////////////////////////////////////////////////////////////////////////
// dbm functions
// 
// These functions allow you to store records stored in a dbm-style database.
// This type of database (supported by the Berkeley db, gdbm, and some system
// libraries, as well as a built-in flatfile library) stores key/value pairs
// (as opposed to the full-blown records supported by relational databases).
// 
// Example 1. dbm example
// 
// $dbm = dbmopen("lastseen", "w");
// if (dbmexists($dbm, $userid)) {
//   $last_seen = dbmfetch($dbm, $userid);
// } else {
//   dbminsert($dbm, $userid, time());
// }
// do_stuff();
// dbmreplace($dbm, $userid, time());
// dbmclose($dbm);
//  

/**
 * opens a dbm database
 * <p>
 * The first argument is the full-path filename of the dbm file to be opened
 * and the second is the file open mode which is one of "r", "n", "c" or "w"
 * for read-only, new (implies read-write, and most likely will truncate an
 * already-existing database of the same name), create (implies read-write,
 * and will not truncate an already-existing database of the same name) and
 * read-write respectively.
 * <p>
 * Returns an identifer to be passed to the other dbm functions on success, or
 * false on failure.
 * <p>
 * If ndbm support is used, ndbm will actually create filename.dir and
 * filename.pag files. gdbm only uses one file, as does the internal flat-file
 * support, and Berkeley db creates a filename.db file. Note that PHP does its
 * own file locking in addition to any file locking that may be done by the
 * dbm library itself. PHP does not delete the .lck files it creates. It uses
 * these files simply as fixed inodes on which to do the file locking. For
 * more information on dbm files, see your Unix man pages, or obtain GNU's
 * gdbm from ftp://prep.ai.mit.edu/pub/gnu.
 */
function int dbmopen(string filename, string flags);
 
/**
 * closes a dbm database
 * <p>
 * Unlocks and closes the specified database.
 */
function bool dbmclose(int dbm_identifier);
 
/**
 * tells if a value exists for a key in a dbm database
 * <p>
 * Returns true if there is a value associated with the key.
 */
function bool dbmexists(int dbm_identifier, string key);
 
/**
 * fetches a value for a key from a dbm database
 * <p>
 * Returns the value associated with key.
 */
function string dbmfetch(int dbm_identifier, string key);
 
/**
 * inserts a value for a key in a dbm database
 * <p>
 * Adds the value to the database with the specified key.
 * <p>
 * Returns -1 if the database was opened read-only, 0 if the insert was
 * successful, and 1 if the specified key already exists. (To replace the
 * value, use {@link dbmreplace()}.)
 */
function int dbminsert(int dbm_identifier, string key, string value);
 
/**
 * replaces the value for a key in a dbm database
 * <p>
 * Replaces the value for the specified key in the database.
 * <p>
 * This will also add the key to the database if it didn't already exist.
 */
function bool dbmreplace(int dbm_identifier, string key, string value);
 
/**
 * deletes the value for a key from a dbm database
 * <p>
 * Deletes the value for key in the database.
 * <p>
 * Returns false if the key didn't exist in the database.
 */
function bool dbmdelete(int dbm_identifier, string key);
 
/**
 * retrieves the first key from a dbm database
 * <p>
 * Returns the first key in the database. Note that no particular order is
 * guaranteed since the database may be built using a hash-table, which
 * doesn't guarantee any ordering.
 */
function string dbmfirstkey(int dbm_identifier);
 
/**
 * retrieves the next key from a dbm database
 * <p>
 * Returns the next key after key. By calling {@link dbmfirstkey()} followed by
 * successive calls to {@link dbmnextkey()} it is possible to visit every key/value
 * pair in the dbm database. For example:
 * <p>
 * <b>Example 1.</b> Visiting every key/value pair in a dbm database.
 * <pre>
 *    $key = dbmfirstkey($dbm_id);
 *    while ($key) {
 *       echo "$key = " . dbmfetch($dbm_id, $key) . "\n";
 *       $key = dbmnextkey($dbm_id, $key);
 *    }
 * </pre>
 */
function string dbmnextkey(int dbm_identifier, string key);
 
/**
 * describes the dbm-compatible library being used
 */
function string dblist(void);


///////////////////////////////////////////////////////////////////////////
// Directory functions
// 
 
/**
 * change directory
 * <p>
 * Changes PHP's current directory to directory. Returns FALSE if unable to
 * change directory, TRUE otherwise.
 */
function int chdir(string directory);
 
/**
 * directory class
 * <p>
 * A pseudo-object oriented mechanism for reading a directory. The given
 * directory is opened. Two properties are available once directory has been
 * opened. The handle property can be used with other directory functions such
 * as {@link readdir()}, {@link rewinddir()} and {@link closedir()}. The path property is set to path
 * the directory that was opened. Three methods are available: read, rewind
 * and close.
 * <p>
 * <b>Example 1.</b> Dir() Example
 * <pre>
 *    $d = dir("/etc");
 *    echo "Handle: ".$d-&gt;handle."&lt;br&gt;\n";
 *    echo "Path: ".$d-&gt;path."&lt;br&gt;\n";
 *    while($entry=$d-&gt;read()) {
 *       echo $entry."&lt;br&gt;\n";
 *    }
 *    $d-&gt;close();
 * </pre>
 */
function new dir(string directory);
 
/**
 * close directory handle
 * <p>
 * Closes the directory stream indicated by dir_handle. The stream must have
 * previously been opened by {@link opendir()}.
 */
function void closedir(int dir_handle);
 
/**
 * open directory handle
 * <p>
 * Returns a directory handle to be used in subsequent {@link closedir()}, {@link readdir()},
 * and {@link rewinddir()} calls.
 */
function int opendir(string path);
 
/**
 * read entry from directory handle
 * <p>
 * Returns the filename of the next file from the directory. The filenames are
 * not returned in any particular order.
 * <p>
 * <b>Example 1.</b> List all files in the current directory
 * <pre>
 *    &lt;?php
 *       $handle=opendir('.');
 *       echo "Directory handle: $handle\n";
 *       echo "Files:\n";
 *       while ($file = readdir($handle)) {
 *          echo "$file\n";
 *       }
 *       closedir($handle);
 *    ?&gt;
 * </pre>
 */
function string readdir(int dir_handle);
 
/**
 * rewind directory handle
 * <p>
 * Resets the directory stream indicated by dir_handle to the beginning of the
 * directory.
 */
function void rewinddir(int dir_handle);


///////////////////////////////////////////////////////////////////////////
// Dynamic Loading functions
//
 
/**
 * load a PHP extension at runtime
 * <p>
 * Loads the PHP extension defined in library. See also the extension_dir
 * configuration directive.
 */ 
function int dl(string library);


///////////////////////////////////////////////////////////////////////////
// Program Execution functions
// 
 
/**
 * escape shell metacharacters
 * <p>
 * EscapeShellCmd() escapes any characters in a string that might be used to
 * trick a shell command into executing arbitrary commands. This function
 * should be used to make sure that any data coming from user input is escaped
 * before this data is passed to the {@link exec()} or {@link system()} functions.
 * A standard use would be:
 * <pre>
 *    system(EscapeShellCmd($cmd))
 * </pre>
 */
function string escapeshellcmd(string command);
 
/**
 * Execute an external program
 * <p>
 * exec() executes the given command, however it does not output anything. It
 * simply returns the last line from the result of the command. If you need to
 * execute a command and have all the data from the command passed directly
 * back without any interference, use the {@link PassThru()} function.
 * <p>
 * If the array argument is present, then the specified array will be filled
 * with every line of output from the command. Note that if the array already
 * contains some elements, exec() will append to the end of the array. If you
 * do not want the function to append elements, call {@link unset()} on the array
 * before passing it to exec().
 * <p>
 * If the return_var argument is present along with the array argument, then
 * the return status of the executed command will be written to this variable.
 * <p>
 * Note that if you are going to allow data coming from user input to be
 * passed to this function, then you should be using {@link EscapeShellCmd()} to make
 * sure that users cannot trick the system into executing arbitrary commands.
 * 
 * @see system()
 * @see PassThru()
 * @see popen()
 * @see EscapeShellCmd()
 */
function string exec(string command, string [array], int [return_var]);
 
/**
 * Execute an external program and display output
 * <p>
 * System() is just like the C version of the function in that it executes the
 * given command and outputs the result. If a variable is provided as the
 * second argument, then the return status code of the executed command will
 * be written to this variable.
 * <p>
 * Note, that if you are going to allow data coming from user input to be
 * passed to this function, then you should be using the {@link EscapeShellCmd()}
 * function to make sure that users cannot trick the system into executing
 * arbitrary commands.
 * <p>
 * The System() call also tries to automatically flush the web server's output
 * buffer after each line of output if PHP is running as a server module.
 * <p>
 * If you need to execute a command and have all the data from the command
 * passed directly back without any interference, use the {@link PassThru()} function.
 * 
 * @see exec()
 * @see popen().
 */
function string system(string command, int [return_var]);
 
/**
 * Execute an external program and display raw output
 * <p>
 * The passthru() function is similar to the {@link Exec()} function in that it
 * executes a command. If the return_var argument is present, the return
 * status of the Unix command will be placed here. This function should be
 * used in place of {@link Exec()} or {@link System()} when the output from the Unix command
 * is binary data which needs to be passed directly back to the browser. A
 * common use for this is to execute something like the pbmplus utilities that
 * can output an image stream directly. By setting the content-type to
 * image/gif and then calling a pbmplus program to output a gif, you can
 * create PHP scripts that output images directly.
 * 
 * @see exec()
 * @see fpassthru()
 */
function string passthru(string command, int [return_var]);


///////////////////////////////////////////////////////////////////////////
// Forms Data Format functions
//
// Forms Data Format (FDF) is a format for handling forms within PDF
// documents. You should read the documentation at
// http://partners.adobe.com/asn/developer/acrosdk/main.html for more
// information on what FDF is and how it is used in general.
// 
//      Note: Currently Adobe only provides a libc5 compatible version
//      for Linux. Tests with glibc2 resulted in a segmentation fault. If
//      somebody is able to make it work, please comment on this page.
// 
// The general idea of FDF is similar to HTML forms. The diffence is basically
// the format how filled in data is transmitted to the server when the submit
// button is pressed (this is actually the Form Data Format) and the format of
// the form itself (which is the Portable Document Format, PDF). Processing
// the FDF data is one of the features provided by the fdf functions. But
// there is more. One may as well take an existing PDF form and populated the
// input fields with data without modifying the form itself. In such a case
// one would create a FDF document (fdf_create()) set the values of each input
// field (fdf_set_value()) and associate it with a PDF form (fdf_set_file()).
// Finally it has to be sent to the browser with MimeType application/vnd.fdf.
// The Acrobat reader plugin of your browser recognizes the MimeType, reads
// the associated PDF form and fills in the data from the FDF document.
// 
// The following examples shows just the evaluation of form data.
// 
// Example 1. Evaluating a FDF document
// 
// <?php
// // Save the FDF data into a temp file
// $fdffp = fopen("test.fdf", "w");
// fwrite($fdffp, $HTTP_FDF_DATA, strlen($HTTP_FDF_DATA));
// fclose($fdffp);
// 
// // Open temp file and evaluate data
// // The pdf form contained several input text fields with the names
// // volume, date, comment, publisher, preparer, and two checkboxes
// // show_publisher and show_preparer.
// $fdf = fdf_open("test.fdf");
// $volume = fdf_get_value($fdf, "volume");
// echo "The volume field has the value '<B>$volume</B>'<BR>";
// 
// $date = fdf_get_value($fdf, "date");
// echo "The date field has the value '<B>$date</B>'<BR>";
// 
// $comment = fdf_get_value($fdf, "comment");
// echo "The comment field has the value '<B>$comment</B>'<BR>";
// 
// if(fdf_get_value($fdf, "show_publisher") == "On") {
//   $publisher = fdf_get_value($fdf, "publisher");
//   echo "The publisher field has the value '<B>$publisher</B>'<BR>";
// } else
//   echo "Publisher shall not be shown.<BR>";
// 
// if(fdf_get_value($fdf, "show_preparer") == "On") {
//   $preparer = fdf_get_value($fdf, "preparer");
//   echo "The preparer field has the value '<B>$preparer</B>'<BR>";
// } else
//   echo "Preparer shall not be shown.<BR>";
// fdf_close($fdf);
// ?>
// 
 
/**
 * Open a FDF document
 * <p>
 * The fdf_open() function opens a file with form data. This file must contain
 * the data as returned from a PDF form. Currently, the file has to be created
 * 'manually' by using {@link fopen()} and writing the content of HTTP_FDF_DATA with
 * {@link fwrite()} into it. A mechanism like for HTML form data where for each input
 * field a variable is created does not exist.
 * <p>
 * <b>Example 1.</b> Accessing the form data
 * <pre>
 *    &lt;?php
 *    // Save the FDF data into a temp file
 *    $fdffp = fopen("test.fdf", "w");
 *    fwrite($fdffp, $HTTP_FDF_DATA, strlen($HTTP_FDF_DATA));
 *    fclose($fdffp);
 * 
 *    // Open temp file and evaluate data
 *    $fdf = fdf_open("test.fdf");
 *    ...
 *   fdf_close($fdf);
 *    ?& gt;
 * </pre>
 *
 * @see fdf_close()
 */
function int fdf_open(string filename);
 
/**
 * Close an FDF document
 * <p>
 * The fdf_close() function closes the FDF document.
 * 
 * @see fdf_open()
 */
function void fdf_close(int fdf_document);
 
/**
 * Create a new FDF document
 * <p>
 * The fdf_create() creates a new FDF document. This function is needed if one
 * would like to populate input fields in a PDF document with data.
 * <p>
 * <b>Example 1.</b> Populating a PDF document
 * <pre>
 *    &lt;?php
 *    $outfdf = fdf_create();
 *    fdf_set_value($outfdf, "volume", $volume, 0);
 *    fdf_set_file($outfdf, "http:/testfdf/resultlabel.pdf");
 *    fdf_save($outfdf, "outtest.fdf");
 *    fdf_close($outfdf);
 *    Header("Content-type: application/vnd.fdf");
 *    $fp = fopen("outtest.fdf", "r");
 *    fpassthru($fp);
 *    unlink("outtest.fdf");
 *    ?&gt;
 * </pre>
 *
 * @see fdf_close()
 * @see fdf_save()
 * @see fdf_open()
 */
function int fdf_create(void );
 
/**
 * Save a FDF document
 * <p>
 * The fdf_save() function saves a FDF document. The FDF Toolkit provides a
 * way to output the document to stdout if the parameter filename is '.'. This
 * does not work if PHP is used as an apache module. In such a case one will
 * have to write to a file and use e.g. {@link fpassthru()}. to output it.
 * 
 * @see fdf_close()
 * @see fdf_create()
 */
function int fdf_save(string filename);
 
/**
 * Get the value of a field
 * <p>
 * The fdf_get_value() function returns the value of a field.
 * 
 * @see fdf_set_value()
 */
function string fdf_get_value(int fdf_document, string fieldname);
 
/**
 * Set the value of a field
 * <p>
 * The fdf_set_value() function sets the value of a field. The last parameter
 * determines if the field value is to be converted to a PDF Name (isName = 1)
 * or set to a PDF String (isName = 0).
 * 
 * @see fdf_get_value()
 */
function void fdf_set_value(int fdf_document, string fieldname, string value, int isName);
 
/**
 * Get the next field name
 * <p>
 * The fdf_next_field_name() function returns the name of the field after the
 * field in fieldname or the field name of the first field if the second
 * paramter is NULL.
 * 
 * @see fdf_set_field()
 * @see fdf_get_field()
 */
function string fdf_next_field_name(int fdf_document, string fieldname);
 
/**
 * Set the appearance of a field
 * <p>
 * The fdf_set_ap() function sets the appearance of a field (i.e. the value of
 * the /AP key). The possible values of face are 1=FDFNormalAP,
 * 2=FDFRolloverAP, 3=FDFDownAP.
 */
function void fdf_set_ap(int fdf_document, string field_name, int face, string filename, int page_number);
 
/**
 * Set the value of the /STATUS key
 * <p>
 * The fdf_set_status() sets the value of the /STATUS key.
 * 
 * @see fdf_get_status()
 */
function void fdf_set_status(int fdf_document, string status);
 
/**
 * Get the value of the /STATUS key
 * <p>
 * The fdf_get_status() returns the value of the /STATUS key.
 * 
 * @see fdf_set_status()
 */
function string fdf_get_status(int fdf_document);
 
/**
 * Set the value of the /F key
 * <p>
 * The fdf_set_file() sets the value of the /F key. The /F key is just a
 * reference to a PDF form which is to be populated with data. In a web
 * environment it is a URL (e.g. http:/testfdf/resultlabel.pdf).
 * 
 * @see fdf_get_file()
 * @see fdf_create()
 */
function void fdf_set_file(int fdf_document, string filename);
 
/**
 * Get the value of the /F key
 * <p>
 * The fdf_set_file() returns the value of the /F key.
 * 
 * @see fdf_set_file()
 */ 
function string fdf_get_file(int fdf_document);


///////////////////////////////////////////////////////////////////////////
// filePro functions
// 
// These functions allow read-only access to data stored in filePro databases.
// 
// filePro is a registered trademark of Fiserv, Inc. You can find more
// information about filePro at http://www.fileproplus.com/.
// 
 
/**
 * read and verify the map file
 * <p>
 * This reads and verifies the map file, storing the field count and info.
 * <p>
 * No locking is done, so you should avoid modifying your filePro database
 * while it may be opened in PHP.
 */
function bool filepro(string directory);
 
/**
 * gets the name of a field
 * <p>
 * Returns the name of the field corresponding to field_number.
 */
function string filepro_fieldname(int field_number);
 
/**
 * gets the type of a field
 * <p>
 * Returns the edit type of the field corresponding to field_number.
 */
function string filepro_fieldtype(int field_number);
 
/**
 * gets the width of a field
 * <p>
 * Returns the width of the field corresponding to field_number.
 */
function int filepro_fieldwidth(int field_number);
 
/**
 * retrieves data from a filePro database
 * <p>
 * Returns the data from the specified location in the database.
 */
function string filepro_retrieve(int row_number, int field_number);
 
/**
 * find out how many fields are in a filePro database
 * <p>
 * Returns the number of fields (columns) in the opened filePro database.
 * 
 * @see filepro()
 */
function int filepro_fieldcount(void);
 
/**
 * find out how many rows are in a filePro database
 * <p>
 * Returns the number of rows in the opened filePro database.
 * 
 * @see filepro()
 */
function int filepro_rowcount(void);
 

///////////////////////////////////////////////////////////////////////////
// Filesystem functions
//
 
/**
 * return filename component of path
 * <p>
 * Given a string containing a path to a file, this function will return the
 * base name of the file.
 * <p>
 * On Windows, both slash (/) and backslash (\) are used as path separator
 * character. In other environments, it is the forward slash (/).
 * <p>
 * <b>Example 1.</b> basename() example
 * <pre>
 *    $path = "/home/httpd/html/index.php3";
 *    $file = basename($path); // $file is set to "index.php3"
 * </pre>
 *
 * @see dirname()
 */
function string basename(string path);
 
/**
 * change file group
 * <p>
 * Attempts to change the group of the file filename to group. Only the
 * superuser may change the group of a file arbitrarily; other users may
 * change the group of a file to any group of which that user is a member.
 * <p>
 * Returns true on success; otherwise returns false.
 * <p>
 * On Windows, does nothing and returns true.
 * 
 * @see chown()
 * @see chmod()
 */
function int chgrp(string filename, mixed group);
 
/**
 * change file mode
 * <p>
 * Attempts to change the mode of the file specified by filename to that given
 * in mode.
 * <p>
 * Note that mode is not automatically assumed to be an octal value. To ensure
 * the expected operation, you need to prefix mode with a zero (0):
 * <pre>
 *    chmod( "/somedir/somefile", 755 );   // decimal; probably incorrect
 *    chmod( "/somedir/somefile", 0755 );  // octal; correct value of mode
 * </pre>
 * Returns true on success and false otherwise.
 * 
 * @see chown()
 * @see chgrp()
 */
function int chmod(string filename, int mode);
 
/**
 * change file owner
 * <p>
 * Attempts to change the owner of the file filename to user user. Only the
 * superuser may change the owner of a file.
 * <p>
 * Returns true on success; otherwise returns false.
 * <p>
 * <b>Note:</b>
 * On Windows, does nothing and returns true.
 * 
 * @see chown()
 * @see chmod()
 */
function int chown(string filename, mixed user);
 
/**
 * clear file stat cache
 * <p>
 * Invoking the stat or lstat system call on most systems is quite expensive.
 * Therefore, the result of the last call to any of the status functions
 * (listed below) is stored for use on the next such call using the same
 * filename. If you wish to force a new status check, for instance if the file
 * is being checked many times and may change or disappear, use this function
 * to clear the results of the last call from memory.
 * <p>
 * This value is only cached for the lifetime of a single request.
 * <p>
 * Affected functions include {@link stat()}, {@link lstat()}, {@link file_exists()}, {@link is_writeable()},
 * {@link is_readable()}, {@link is_executable()}, {@link is_file()}, {@link is_dir()}, {@link is_link()},
 * {@link filectime()}, {@link fileatime()}, {@link filemtime()}, {@link fileinode()}, {@link filegroup()},
 * {@link fileowner()}, {@link filesize()}, {@link filetype()}, and {@link fileperms()}.
 */
function void clearstatcache(void);
 
/**
 * copy file
 * <p>
 * Makes a copy of a file. Returns true if the copy succeeded, false
 * otherwise.
 * <p>
 * <b>Example 1.</b> copy() example
 * <pre>
 *    if (!copy($file, $file.'.bak')) {
 *      print("failed to copy $file...&lt;br&gt;\n");
 *    }
 * </pre>
 *
 * @see rename()
 */
function int copy(string source, string dest);
 
/**
 * a dummy manual entry
 * <p>
 * This is a dummy manual entry to satisfy those people who are looking for
 * {@link unlink()} or {@link unset()} in the wrong place.
 * 
 * @see unlink()
 * @see unset()
 */
function void delete(string file);
 
/**
 * return directory name component of path
 * <p>
 * Given a string containing a path to a file, this function will return the
 * name of the directory.
 * <p>
 * On Windows, both slash (/) and backslash (\) are used as path separator
 * character. In other environments, it is the forward slash (/).
 * <p>
 * <b>Example 1.</b> dirname() example
 * <pre>
 *    $path = "/etc/passwd";
 *    $file = dirname($path); // $file is set to "/etc"
 * </pre>
 *
 * @see basename()
 */
function string dirname(string path);
 
/**
 * return available space in directory
 * <p>
 * Given a string containing a directory, this function will return the number
 * of bytes available on the corresponding disk.
 * <p>
 * <b>Example 1.</b> diskfreespace() example
 * <pre>
 *    $df = diskfreespace("/"); // $df contains the number of bytes available on "/"
 * </pre>
 */
function float diskfreespace(string directory);
 
/**
 * close an open file pointer
 * <p>
 * The file pointed to by fp is closed.
 * <p>
 * Returns true on success and false on failure.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link fopen()} or {@link fsockopen()}.
 */
function int fclose(int fp);
 
/**
 * test for end-of-file on a file pointer
 * <p>
 * Returns true if the file pointer is at EOF or an error occurs; otherwise
 * returns false.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link fopen()}, {@link popen()}, or {@link fsockopen()}.
 */
function int feof(int fp);
 
/**
 * get character from file pointer
 * <p>
 * Returns a string containing a single character read from the file pointed
 * to by fp. Returns FALSE on EOF (as does {@link feof()}).
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link fopen()}, {@link popen()}, or {@link fsockopen()}.
 * 
 * @see fread()
 * @see fopen()
 * @see popen()
 * @see fsockopen()
 * @see fgets()
 */
function string fgetc(int fp);
 
/**
 * get line from file pointer and parse for CSV fields
 * <p>
 * Similar to {@link fgets()} except that fgetcsv() parses the line it reads for
 * fields in CSV format and returns an array containing the fields read. The
 * field delimiter is a comma, unless you specifiy another delimiter with the
 * optional third parameter.
 * <p>
 * fp must be a valid file pointer to a file successfully opened by {@link fopen()},
 * {@link popen()}, or {@link fsockopen()}
 * <p>
 * length must be greater than the longest line to be found in the CSV file
 * (allowing for trailing line-end characters).
 * <p>
 * fgetcsv() returns false on error, including end of file.
 * <p>
 * NB A blank line in a CSV file will be returned as an array comprising just
 * one single null field, and will not be treated as an error.
 * <p>
 * <b>Example 1.</b> fgetcsv() example - Read and print entire contents of a CSV file
 * <pre>
 *    $row=1;
 *    $fp = fopen("test.csv","r");
 *    while ($data = fgetcsv($fp,1000, ",")) {
 *       $num = count($data);
 *       print "&lt;p&gt; $num fields in line $row: &lt;br&gt;";
 *       $row++;
 *       for ( $c=0; $c&lt;$num; $c++ ) print $data[$c] . "&lt;br&gt;";
 *    }
 *    fclose($fp);
 * </pre>
 */
function array fgetcsv(int fp, int length, string [delimiter]);
 
/**
 * get line from file pointer
 * <p>
 * Returns a string of up to length - 1 bytes read from the file pointed to by
 * fp. Reading ends when length - 1 bytes have been read, on a newline (which
 * is included in the return value), or on EOF (whichever comes first).
 * <p>
 * If an error occurs, returns false.
 * <p>
 * Common Pitfalls:
 * <p>
 * People used to the 'C' semantics of fgets should note the difference in how
 * EOF is returned.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link fopen()}, {@link popen()}, or {@link fsockopen()}.
 * <p>
 * <b>Example 1.</b> Reading a file line by line
 * <pre>
 *    $fd = fopen("/tmp/inputfile.txt", "r");
 *    while ($buffer = fgets($fd, 4096)) {
 *      echo $buffer;
 *    }
 *    fclose($fd);
 * </pre>
 *
 * @see fread()
 * @see fopen()
 * @see popen()
 * @see fgetc()
 * @see fsockopen()
 */
function string fgets(int fp, int length);
 
/**
 * get line from file pointer and strip HTML tags
 * <p>
 * Identical to {@link fgets()}, except that fgetss attempts to strip any HTML and PHP
 * tags from the text it reads.
 * 
 * @see fgets()
 * @see fopen()
 * @see fsockopen()
 * @see popen()
 * @see strip_tags()
 */
function string fgetss(int fp, int length);
 
/**
 * read entire file into an array
 * <p>
 * Identical to {@link readfile()}, except that file() returns the file in an array.
 * Each element of the array corresponds to a line in the file, with the
 * newline still attached.
 * 
 * @see readfile()
 * @see fopen()
 * @see popen()
 */
function array file(string filename);
 
/**
 * Check whether a file exists.
 * <p>
 * Returns true if the file specified by filename exists; false otherwise.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function int file_exists(string filename);
 
/**
 * get last access time of file
 * <p>
 * Returns the time the file was last accessed, or false in case of an error.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function int fileatime(string filename);
 
/**
 * get inode change time of file
 * <p>
 * Returns the time the file was last changed, or false in case of an error.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function int filectime(string filename);
 
/**
 * get file group
 * <p>
 * Returns the group ID of the owner of the file, or false in case of an
 * error.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function int filegroup(string filename);
 
/**
 * get file inode
 * <p>
 * Returns the inode number of the file, or false in case of an error.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function int fileinode(string filename);
 
/**
 * get file modification time
 * <p>
 * Returns the time the file was last modified, or false in case of an error.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function int filemtime(string filename);
 
/**
 * get file owner
 * <p>
 * Returns the user ID of the owner of the file, or false in case of an
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details. error.
 */
function int fileowner(string filename);
 
/**
 * get file permissions
 * <p>
 * Returns the permissions on the file, or false in case of an error.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function int fileperms(string filename);
 
/**
 * get file size
 * <p>
 * Returns the size of the file, or false in case of an error.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function int filesize(string filename);
 
/**
 * get file type
 * <p>
 * Returns the type of the file. Possible values are fifo, char, dir, block,
 * link, file, and unknown.
 * <p>
 * Returns false if an error occurs.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function string filetype(string filename);
 
/**
 * portable advisory file locking
 * <p>
 * PHP supports a portable way of locking complete files in an advisory way
 * (which means all accessing programs have to use the same way of locking or
 * it will not work).
 * <p>
 * flock() operates on fp which must be an open file pointer. operation is one
 * of the following values:
 * <ul>
 * <li> To acquire a shared lock (reader), set operation to 1.
 * <li> To acquire an exclusive lock (writer), set operation to 2.
 * <li> To release a lock (shared or exclusive), set operation to 3.
 * <li> If you don't want flock() to block while locking, add 4 to operation.
 * </ul>
 * flock() allows you to perform a simple reader/writer model which can be
 * used on virtually every platform (including most Unices and even Windows).
 * <p>
 * flock() returns true on success and false on error (e.g. when a lock could
 * not be acquired).
 */
function bool flock(int fp, int operation);
 
/**
 * open file or URL
 * <p>
 * If filename begins with "http://" (not case sensitive), an HTTP 1.0
 * connection is opened to the specified server and a file pointer is returned
 * to the beginning of the text of the response.
 * <p>
 * Does not handle HTTP redirects, so you must include trailing slashes on
 * directories.
 * <p>
 * If filename begins with "ftp://" (not case sensitive), an ftp connection to
 * the specified server is opened and a pointer to the requested file is
 * returned. If the server does not support passive mode ftp, this will fail.
 * You can open files for either reading and writing via ftp (but not both
 * simultaneously).
 * <p>
 * If filename begins with anything else, the file will be opened from the
 * filesystem, and a file pointer to the file opened is returned.
 * <p>
 * If the open fails, the function returns false.
 * <p>
 * mode may be any of the following:
 * <ul>
 * <li> 'r' - Open for reading only; place the file pointer at the beginning
 *      of the file.
 * <li> 'r+' - Open for reading and writing; place the file pointer at the
 *      beginning of the file.
 * <li> 'w' - Open for writing only; place the file pointer at the beginning
 *      of the file and truncate the file to zero length. If the file does not
 *      exist, attempt to create it.
 * <li> 'w+' - Open for reading and writing; place the file pointer at the
 *      beginning of the file and truncate the file to zero length. If the
 *      file does not exist, attempt to create it.
 * <li> 'a' - Open for writing only; place the file pointer at the end of the
 *      file. If the file does not exist, attempt to create it.
 * <li> 'a+' - Open for reading and writing; place the file pointer at the end
 *      of the file. If the file does not exist, attempt to create it.
 * </ul>
 * As well, mode may contain the letter 'b'. This is useful only on systems
 * which differentiate between binary and text files (i.e., it's useless on
 * Unix). If not needed, this will be ignored.
 * <p>
 * <b>Example 1.</b> fopen() example
 * <pre>
 *    $fp = fopen("/home/rasmus/file.txt", "r");
 *    $fp = fopen("http://www.php.net/", "r");
 *    $fp = fopen("ftp://user:password@example.com/", "w");
 * </pre>
 * If you are experiencing problems with reading and writing to files and
 * you're using the server module version of PHP, remember to make sure that
 * the files and directories you're using are accessible to the server
 * process.
 * <p>
 * On the Windows platform, be careful to escape any backslashes used in the
 * path to the file, or use forward slashes.
 * <pre>
 *    $fp = fopen("c:\\data\\info.txt", "r");
 * </pre>
 *
 * @see fclose()
 * @see fsockopen()
 * @see popen()
 */
function int fopen(string filename, string mode);
 
/**
 * output all remaining data on a file pointer
 * <p>
 * Reads to EOF on the given file pointer and writes the results to standard
 * output.
 * <p>
 * If an error occurs, fpassthru() returns false.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link fopen()}, {@link popen()}, or {@link fsockopen()}. The file is closed when
 * {@link fpassthru()} is done reading it (leaving fp useless).
 * <p>
 * If you just want to dump the contents of a file to stdout you may want to
 * use the {@link readfile()}, which saves you the {@link fopen()} call.
 * 
 * @see readfile()
 * @see fopen()
 * @see popen()
 * @see fsockopen()
 */
function int fpassthru(int fp);
 
/**
 * write to a file pointer
 * <p>
 * fputs() is an alias to {@link fwrite()}, and is identical in every way. Note that
 * the length parameter is optional and if not specified the entire string
 * will be written.
 */
function int fputs(int fp, string str, int [length]);
 
/**
 * Binary-safe file read
 * <p>
 * fread() reads up to length bytes from the file pointer referenced by fp.
 * Reading stops when length bytes have been read or EOF is reached, whichever
 * comes first.
 * <pre>
 *    // get contents of a file into a string
 *    $filename = "/usr/local/something.txt";
 *    $fd = fopen( $filename, "r" );
 *    $contents = fread( $fd, filesize( $filename ) );
 *    fclose( $fd );
 * </pre>
 * 
 * @see fwrite()
 * @see fopen()
 * @see fsockopen()
 * @see popen()
 * @see fgets()
 * @see fgetss()
 * @see file()
 * @see fpassthru()
 */
function string fread(int fp, int length);
 
/**
 * seek on a file pointer
 * <p>
 * Sets the file position indicator for the file referenced by fp to offset
 * bytes into the file stream. Equivalent to calling (in C) fseek( fp, offset,
 * SEEK_SET ).
 * <p>
 * Upon success, returns 0; otherwise, returns -1. Note that seeking past EOF
 * is not considered an error.
 * <p>
 * May not be used on file pointers returned by {@link fopen()} if they use the
 * "http://" or "ftp://" formats.
 * 
 * @see ftell()
 * @see rewind()
 */
function int fseek(int fp, int offset);
 
/**
 * tell file pointer read/write position
 * <p>
 * Returns the position of the file pointer referenced by fp; i.e., its offset
 * into the file stream.
 * <p>
 * If an error occurs, returns false.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link fopen()} or {@link popen()}.
 * 
 * @see fopen()
 * @see popen()
 * @see fseek()
 * @see rewind()
 */
function int ftell(int fp);
 
/**
 * Binary-safe file write
 * <p>
 * fwrite() writes the contents of string to the file stream pointed to by fp.
 * If the length argument is given, writing will stop after length bytes have
 * been written or the end of string is reached, whichever comes first.
 * <p>
 * Note that if the length argument is given, then the magic_quotes_runtime
 * configuration option will be ignored and no slashes will be stripped from
 * string.
 * 
 * @see fread()
 * @see fopen()
 * @see fsockopen()
 * @see popen()
 * @see fputs()
 */
function int fwrite(int fp, string string, int [length]);
 
/**
 * Sets file buffering on the given file pointer
 * <p>
 * set_file_buffer() sets the buffering for write operations on the given
 * filepointer fp to buffer bytes. If buffer is 0 then write operations are
 * unbuffered.
 * <p>
 * The function returns 0 on success, or EOF if the request cannot be honored.
 * <p>
 * Note that the default for any fopen with calling set_file_buffer is 8K.
 * 
 * @see fopen()
 */
function int set_file_buffer(int fp, int buffer);
 
/**
 * tells whether the filename is a directory
 * <p>
 * Returns true if the filename exists and is a directory.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 * 
 * @see is_file()
 * @see is_link()
 */
function bool is_dir(string filename);
 
/**
 * tells whether the filename is executable
 * <p>
 * Returns true if the filename exists and is executable.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 * 
 * @see is_file()
 * @see is_link()
 */
function bool is_executable(string filename);
 
/**
 * tells whether the filename is a regular file
 * <p>
 * Returns true if the filename exists and is a regular file.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 * 
 * @see is_dir()
 * @see is_link()
 */
function bool is_file(string filename);
 
/**
 * tells whether the filename is a symbolic link
 * <p>
 * Returns true if the filename exists and is a symbolic link.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 * 
 * @see is_dir()
 * @see is_file()
 */
function bool is_link(string filename);
 
/**
 * tells whether the filename is readable
 * <p>
 * Returns true if the filename exists and is readable.
 * <p>
 * Keep in mind that PHP may be accessing the file as the user id that the web
 * server runs as (often 'nobody'). Safe mode limitations are not taken into
 * account.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 * 
 * @see is_writeable()
 */
function bool is_readable(string filename);
 
/**
 * tells whether the filename is writeable
 * <p>
 * Returns true if the filename exists and is writeable. The filename argument
 * may be a directory name allowing you to check if a directory is writeable.
 * <p>
 * Keep in mind that PHP may be accessing the file as the user id that the web
 * server runs as (often 'nobody'). Safe mode limitations are not taken into
 * account.
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 * 
 * @see is_readable()
 */
function bool is_writeable(string filename);
 
/**
 * Create a hard link
 * <p>
 * Link() creates a hard link.
 * 
 * @see symlink()
 * @see linkinfo()
 * @see linkinfo()
 */
function int link(string target, string link);
 
/**
 * Get information about a link
 * <p>
 * Linkinfo() returns the st_dev field of the UNIX C stat structure returned
 * by the lstat system call. This function is used to verify if a link
 * (pointed to by path) really exists (using the same method as the S_ISLNK
 * macro defined in stat.h). Returns 0 or FALSE in case of error.
 * 
 * @see symlink()
 * @see link()
 * @see readlink()
 */
function int linkinfo(string path);
 
/**
 * make directory
 * <p>
 * Attempts to create the directory specified by pathname.
 * <p>
 * Note that you probably want to specify the mode as an octal number, which
 * means it should have a leading zero.
 * <pre>
 *    mkdir("/path/to/my/dir", 0700);
 * </pre>
 * Returns true on success and false on failure.
 * 
 * @see rmdir()
 */
function int mkdir(string pathname, int mode);
 
/**
 * close process file pointer
 * <p>
 * Closes a file pointer to a pipe opened by {@link popen()}.
 * <p>
 * The file pointer must be valid, and must have been returned by a successful
 * call to {@link popen()}.
 * <p>
 * Returns the termination status of the process that was run.
 * 
 * @see popen()
 */
function int pclose(int fp);
 
/**
 * open process file pointer
 * <p>
 * Opens a pipe to a process executed by forking the command given by command.
 * <p>
 * Returns a file pointer identical to that returned by {@link fopen()}, except that
 * it is unidirectional (may only be used for reading or writing) and must be
 * closed with {@link pclose()}. This pointer may be used with {@link fgets()}, {@link fgetss()}, and
 * {@link fputs()}.
 * <p>
 * If an error occurs, returns false.
 * <pre>
 *    $fp = popen( "/bin/ls", "r" );
 * </pre>
 * 
 * @see pclose()
 */
function int popen(string command, string mode);
 
/**
 * output a file
 * <p>
 * Reads a file and writes it to standard output.
 * <p>
 * Returns the number of bytes read from the file. If an error occurs, false
 * is returned and unless the function was called as @readfile, an error
 * message is printed.
 * <p>
 * If filename begins with "http://" (not case sensitive), an HTTP 1.0
 * connection is opened to the specified server and the text of the response
 * is written to standard output.
 * <p>
 * Does not handle HTTP redirects, so you must include trailing slashes on
 * directories.
 * <p>
 * If filename begins with "ftp://" (not case sensitive), an ftp connection to
 * the specified server is opened and the requested file is written to
 * standard output. If the server does not support passive mode ftp, this will
 * fail.
 * <p>
 * If filename begins with neither of these strings, the file will be opened
 * from the filesystem and its contents written to standard output.
 * 
 * @see fpassthru()
 * @see file()
 * @see fopen()
 * @see include()
 * @see require()
 * @see virtual()
 */
function int readfile(string filename);
 
/**
 * Return the target of a symbolic link
 * <p>
 * Readlink() does the same as the readlink C function and returns the
 * contents of the symbolic link path or 0 in case of error.
 * 
 * @see symlink()
 * @see readlink()
 * @see linkinfo()
 */
function string readlink(string path);
 
/**
 * rename a file
 * <p>
 * Attempts to rename oldname to newname.
 * <p>
 * Returns true on success and false on failure.
 */
function int rename(string oldname, string newname);
 
/**
 * rewind the position of a file pointer
 * <p>
 * Sets the file position indicator for fp to the beginning of the file
 * stream.
 * <p>
 * If an error occurs, returns 0.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link fopen()}.
 * 
 * @see fseek()
 * @see ftell()
 */
function int rewind(int fp);
 
/**
 * remove directory
 * <p>
 * Attempts to remove the directory named by pathname. The directory must be
 * empty, and the relevant permissions must permit this.
 * <p>
 * If an error occurs, returns 0.
 * 
 * @see mkdir()
 */
function int rmdir(string dirname);
 
/**
 * give information about a file
 * <p>
 * Gathers the statistics of the file named by filename.
 * <p>
 * Returns an array with the statistics of the file with the following
 * elements:
 * <ol>
 * <li> device
 * <li> inode
 * <li> inode protection mode
 * <li> number of links
 * <li> user id of owner
 * <li> group id owner
 * <li> device type if inode device *
 * <li> size in bytes
 * <li> time of last access
 * <li> time of last modification
 * <li> time of last change
 * <li> blocksize for filesystem I/O *
 * <li> number of blocks allocated
 * </ol>
 * * - only valid on systems supporting the st_blksize type--other systems
 * (i.e. Windows) return -1
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function array stat(string filename);
 
/**
 * give information about a file or symbolic link
 * <p>
 * Gathers the statistics of the file or symbolic link named by filename. This
 * function is identical to the stat() function except that if the filename
 * parameter is a symbolic link, the status of the symbolic link is returned,
 * not the status of the file pointed to by the symbolic link.
 * <p>
 * Returns an array with the statistics of the file with the following
 * elements:
 * <ol>
 * <li> device
 * <li> inode
 * <li> number of links
 * <li> user id of owner
 * <li> group id owner
 * <li> device type if inode device *
 * <li> size in bytes
 * <li> time of last access
 * <li> time of last modification
 * <li> time of last change
 * <li> blocksize for filesystem I/O *
 * <li> number of blocks allocated
 * </ol>
 * * - only valid on systems supporting the st_blksize type--other systems
 * (i.e. Windows) return -1
 * <p>
 * The results of this function are cached. See {@link clearstatcache()} for more
 * details.
 */
function array lstat(string filename);
 
/**
 * Create a symbolic link
 * <p>
 * symlink() creates a symbolic link from the existing target with the
 * specified name link.
 * 
 * @see link()
 * @see readlink()
 * @see linkinfo()
 */
function int symlink(string target, string link);
 
/**
 * create unique file name
 * <p>
 * Creates a unique temporary filename in the specified directory. If the
 * directory does not exist, tempnam() may generate a filename in the system's
 * temporary directory.
 * <p>
 * The behaviour of the tempnam() function is system dependent. On Windows the
 * TMP environment variable will override the dir parameter, on Linux the
 * TMPDIR environment variable has precedence, while SVR4 will always use your
 * dir parameter if the directory it points to exists. Consult your system
 * documentation on the tempnam(3) function if in doubt.
 * <p>
 * Returns the new temporary filename, or the null string on failure.
 * <p>
 * <b>Example 1.</b> tempnam() example
 * <pre>
 *    $tmpfname = tempnam( "/tmp", "FOO" );
 * </pre>
 */
function string tempnam(string dir, string prefix);
 
/**
 * set modification time of file
 * <p>
 * Attempts to set the modification time of the file named by filename to the
 * value given by time. If the option time is not given, uses the present
 * time.
 * <p>
 * If the file does not exist, it is created.
 * <p>
 * Returns true on success and false otherwise.
 */
function int touch(string filename, int time);
 
/**
 * changes the current umask
 * <p>
 * Umask() sets PHP's umask to mask & 0777 and returns the old umask. When PHP
 * is being used as a server module, the umask is restored when each request
 * is finished.
 * <p>
 * Umask() without arguments simply returns the current umask.
 */
function int umask(int mask);
 
/**
 * Delete a file
 * <p>
 * Deletes filename. Similar to the Unix C {@link unlink()} function.
 * <p>
 * Returns 0 or FALSE on an error.
 * 
 * @see rmdir()
 */ 
function int unlink(string filename);


///////////////////////////////////////////////////////////////////////////
// HTTP functions
//
// These functions let you manipulate the output sent back to the remote
// browser right down to the HTTP protocol level.
// 
 
/**
 * Send a raw HTTP header
 * <p>
 * The Header() function is used at the top of an HTML file to send raw HTTP
 * header strings. See the HTTP 1.1 Specification for more information on raw
 * http headers. Note: Remember that the Header() function must be called
 * before any actual output is sent either by normal HTML tags or from PHP. It
 * is a very common error to read code with include() or with auto_prepend and
 * have spaces or empty lines in this code that force output before header()
 * is called.
 * <pre>
 *    header("Location: http://www.php.net");  // Redirect browser to PHP web site 
 *    exit;  // Make sure that code below does not get executed when we redirect. 
 * </pre>
 * PHP scripts often generate dynamic HTML that must not be cached by the
 * client browser or any proxy caches between the server and the client
 * browser. Many proxies and clients can be forced to disable caching with
 * <pre>
 *   header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             // Date in the past
 *   header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
 *   header("Cache-Control: no-cache, must-revalidate");           // HTTP/1.1
 *   header("Pragma: no-cache");                                   // HTTP/1.0
 * </pre>
 */
function int header(string string);
 
/**
 * Send a cookie
 * <p>
 * setcookie() defines a cookie to be sent along with the rest of the header
 * information. Cookies must be sent before any other headers are sent (this
 * is a restriction of cookies, not PHP). This requires you to place calls to
 * this function before any &lt;html&gt; or &lt;head&gt; tags.
 * <p>
 * All the arguments except the name argument are optional. If only the name
 * argument is present, the cookie by that name will be deleted from the
 * remote client. You may also replace any argument with an empty string ("")
 * in order to skip that argument. The expire and secure arguments are
 * integers and cannot be skipped with an empty string. Use a zero (0)
 * instead. The expire argument is a regular Unix time integer as returned by
 * the {@link time()} or {@link mktime()} functions. The secure indicates that the cookie
 * should only be transmitted over a secure HTTPS connection.
 * <p>
 * Common Pitfalls:
 * <p>
 * Cookies will not become visible until the next loading of a page that the
 * cookie should be visable for.
 * <p>
 * Multiple calls to setcookie() in the same script will be performed in the
 * reverse order. If you are trying to delete one cookie before inserting
 * another you should put the insert before the delete.
 * <p>
 * <b>Example 1.</b> setcookie() examples
 * <pre>
 *    setcookie("TestCookie","Test Value");
 *    setcookie("TestCookie",$value,time()+3600);  // expire in 1 hour 
 *    setcookie("TestCookie",$value,time()+3600,"/~rasmus/",".utoronto.ca",1);
 * </pre>
 * Note that the value portion of the cookie will automatically be urlencoded
 * when you send the cookie, and when it is received, it is automatically
 * decoded and assigned to a variable by the same name as the cookie name. To
 * see the contents of our test cookie in a script, simply use one of the
 * following examples:
 * <pre>
 *    echo $TestCookie;
 *    echo $HTTP_COOKIE_VARS["TestCookie"];
 * </pre>
 * For more information on cookies, see Netscape's cookie specification at
 * http://www.netscape.com/newsref/std/cookie_spec.html.
 * <P>
 * Microsoft Internet Explorer 4 with Service Pack 1 applied does not
 * correctly deal with cookies that have their path parameter set.
 * <P>
 * Netscape Communicator 4.05 and Microsoft Internet Explorer 3.x appear to
 * handle cookies incorrectly when the path and time are not set.
 */
function int setcookie(string name, string value, int expire, string path, string domain, int secure);


///////////////////////////////////////////////////////////////////////////
// Hyperwave functions
// 
// Hyperwave has been developed at IICM in Graz. It started with the name
// Hyper-G and changed to Hyperwave when it was commercialised (If I remember
// properly it was in 1996).
// 
// Hyperwave is not free software. The current version, 4.1, is available at
// www.hyperwave.com. A time limited version can be ordered for free (30
// days).
// 
// Hyperwave is an information system similar to a database (HIS, Hyperwave
// Information Server). Its focus is the storage and management of documents.
// A document can be any possible piece of data that may as well be stored in
// file. Each document is accompanied by its object record. The object record
// contains meta data for the document. The meta data is a list of attributes
// which can be extended by the user. Certain attributes are always set by the
// Hyperwave server, other may be modified by the user. An attribute is a
// name/value pair of the form name=value. The complete object record contains
// as many of those pairs as the user likes. The name of an attribute does not
// have to be unique, e.g. a title may appear several times within an object
// record. This makes sense if you want to specify a title in several
// languages. In such a case there is a convention, that each title value is
// preceded by the two letter language abbreviation followed by a colon, e.g.
// 'en:Title in English' or 'ge:Titel in deutsch'. Other attributes like a
// description or keywords are potential candidates. You may also replace the
// language abbreviation by any other string as long as it separated by colon
// from the rest of the attribute value.
// 
// Each object record has native a string representation with each name/value
// pair separated by a newline. The Hyperwave extension also knows a second
// representation which is an associated array with the attribute name being
// the key. Multilingual attribute values itself form another associated array
// with the key being the language abbreviation. Actually any multiple
// attribute forms an associated array with the string left to the colon in
// the attribute value being the key. (This is not fully implemented. Only the
// attributes Title, Description and Keyword are treated properly yet.)
// 
// Besides the documents, all hyper links contained in a document are stored
// as object records as well. Hyper links which are in a document will be
// removed from it and stored as individual objects, when the document is
// inserted into the database. The object record of the link contains
// information about where it starts and where it ends. In order to gain the
// original document you will have to retrieve the plain document without the
// links and the list of links and reinsert them (The functions
// hw_pipedocument() and hw_gettext() do this for you. The advantage of
// separating links from the document is obvious. Once a document to which a
// link is pointing to changes its name, the link can easily be modified
// accordingly. The document containing the link is not affected at all. You
// may even add a link to a document without modifying the document itself.
// 
// Saying that hw_pipedocument() and hw_gettext() do the link insertion
// automatically is not as simple as it sounds. Inserting links implies a
// certain hierarchy of the documents. On a web server this is given by the
// file system, but Hyperwave has its own hierarchy and names do not reflect
// the position of an object in that hierarchy. Therefore creation of links
// first of all requires a mapping from the Hyperwave hierarchy and namespace
// into a web hierarchy respective web namespace. The fundamental difference
// between Hyperwave and the web is the clear distinction between names and
// hierarchy in Hyperwave. The name does not contain any information about the
// objects position in the hierarchy. In the web the name also contains the
// information on where the object is located in the hierarchy. This leads to
// two possibles ways of mapping. Either the Hyperwave hierarchy and name of
// the Hyperwave object is reflected in the URL or the name only. To make
// things simple the second approach is used. Hyperwave object with name
// 'my_object' is mapped to 'http://host/my_object' disregarding where it
// resides in the Hyperwave hierarchy. An object with name 'parent/my_object'
// could be the child of 'my_object' in the Hyperwave hierarchy, though in a
// web namespace it appears to be just the opposite and the user might get
// confused. This can only be prevented by selecting reasonable object names.
// 
// Having made this decision a second problem arises. How do you involve PHP?
// The URL http://host/my_object will not call any PHP script unless you tell
// your web server to rewrite it to e.g. 'http://host/php3_script/my_object'
// and the script 'php3_script' evaluates the $PATH_INFO variable and
// retrieves the object with name 'my_object' from the Hyperwave server. Their
// is just one little drawback which can be fixed easily. Rewriting any URL
// would not allow any access to other document on the web server. A PHP
// script for searching in the Hyperwave server would be impossible. Therefore
// you will need at least a second rewriting rule to exclude certain URLS like
// all e.g. starting with http://host/Hyperwave. This is basically sharing of
// a namespace by the web and Hyperwave server.
// 
// Based on the above mechanism links are insert into documents.
// 
// It gets more complicated if PHP is not run as a server module or CGI script
// but as a standalone application e.g. to dump the content of the Hyperwave
// server on a CD-ROM. In such a case it makes sense to retain the Hyperwave
// hierarchy and map in onto the file system. This conflicts with the object
// names if they reflect its own hierarchy (e.g. by choosing names including
// '/'). Therefore '/' has to be replaced by another character, e.g. '_'. to
// be continued.
// 
// The network protocol to communicate with the Hyperwave server is called
// HG-CSP (Hyper-G Client/Server Protocol). It is based on messages to
// initiate certain actions, e.g. get object record. In early versions of the
// Hyperwave Server two native clients (Harmony, Amadeus) were provided for
// communication with the server. Those two disappeared when Hyperwave was
// commercialised. As a replacement a so called wavemaster was provided. The
// wavemaster is like a protocol converter from HTTP to HG-CSP. The idea is to
// do all the administration of the database and visualisation of documents by
// a web interface. The wavemaster implements a set of placeholders for
// certain actions to customise the interface. This set of placeholders is
// called the PLACE Language. PLACE lacks a lot of features of a real
// programming language and any extension to it only enlarges the list of
// placeholders. This has led to the use of JavaScript which IMO does not make
// life easier.
// 
// Adding Hyperwave support to PHP should fill in the gap of a missing
// programming language for interface customisation. It implements all the
// messages as defined by the HG-CSP but also provides more powerful commands
// to e.g. retrieve complete documents.
// 
// Hyperwave has its own terminology to name certain pieces of information.
// This has widely been taken over and extended. Almost all functions operate
// on one of the following data types.
// 
//    * object ID: An unique integer value for each object in the Hyperwave
//      server. It is also one of the attributes of the object record
//      (ObjectID). Object ids are often used as an input parameter to specify
//      an object.
// 
//    * object record: A string with attribute-value pairs of the form
//      attribute=value. The pairs are separated by a carriage return from
//      each other. An object record can easily be converted into an object
//      array with hw_object2array(). Several functions return object records.
//      The names of those functions end with obj.
// 
//    * object array: An associated array with all attributes of an object.
//      The key is the attribute name. If an attribute occurs more than once
//      in an object record it will result in another indexed or associated
//      array. Attributes which are language depended (like the title,
//      keyword, description) will form an associated array with the key set
//      to the language abbreviation. All other multiple attributes will form
//      an indexed array. PHP functions never return object arrays.
// 
//    * hw_document: This is a complete new data type which holds the actual
//      document, e.g. HTML, PDF etc. It is somewhat optimised for HTML
//      documents but may be used for any format.
// 
// Several functions which return an array of object records do also return an
// associated array with statistical information about them. The array is the
// last element of the object record array. The statistical array contains the
// following entries:
// 
// Hidden
// 
//      Number of object records with attribute PresentationHints set to
//      Hidden.
// 
// CollectionHead
// 
//      Number of object records with attribute PresentationHints set to
//      CollectionHead.
// 
// FullCollectionHead
// 
//      Number of object records with attribute PresentationHints set to
//      FullCollectionHead.
// 
// CollectionHeadNr
// 
//      Index in array of object records with attribute PresentationHints set
//      to CollectionHead.
// 
// FullCollectionHeadNr
// 
//      Index in array of object records with attribute PresentationHints set
//      to FullCollectionHead.
// 
// Total
// 
//      Total: Number of object records.
// 
//   ------------------------------------------------------------------------
// 
// Integration with Apache
// 
// The Hyperwave extension is best used when PHP is compiled as an Apache
// module. In such a case the underlying Hyperwave server can be hidden from
// users almost completely if Apache uses its rewriting engine. The following
// instructions will explain this.
// 
// Since PHP with Hyperwave support built into Apache is intended to replace
// the native Hyperwave solution based on Wavemaster I will assume that the
// Apache server will only serve as a Hyperwave web interface. This is not
// necessary but it simplifies the configuration. The concept is quite simple.
// First of all you need a PHP script which evaluates the PATH_INFO variable
// and treats its value as the name of a Hyperwave object. Let's call this
// script 'Hyperwave'. The URL http://your.hostname/Hyperwave/name_of_object
// would than return the Hyperwave object with the name 'name_of_object'.
// Depending on the type of the object the script has to react accordingly. If
// it is a collection, it will probably return a list of children. If it is a
// document it will return the mime type and the content. A slight improvement
// can be achieved if the Apache rewriting engine is used. From the users
// point of view it would be more straight forward if the URL
// http://your.hostname/name_of_object would return the object. The rewriting
// rule is quite easy:
// 
// RewriteRule ^/(.*) /usr/local/apache/htdocs/HyperWave/$1 [L]
// 
// Now every URL relates to an object in the Hyperwave server. This causes a
// simple to solve problem. There is no way to execute a different script,
// e.g. for searching, than the 'Hyperwave' script. This can be fixed with
// another rewriting rule like the following:
// 
// RewriteRule ^/hw/(.*) /usr/local/apache/htdocs/hw/$1 [L]
// 
// This will reserve the directory /usr/local/apache/htdocs/hw for additional
// scripts and other files. Just make sure this rule is evaluated before the
// one above. There is just a little drawback: all Hyperwave objects whose
// name starts with 'hw/' will be shadowed. So, make sure you don't use such
// names. If you need more directories, e.g. for images just add more rules or
// place them all in one directory. Finally, don't forget to turn on the
// rewriting engine with
// 
// RewriteEngine on
// 
// My experiences have shown that you will need the following scripts:
// 
//    * to return the object itself
// 
//    * to allow searching
// 
//    * to identify yourself
// 
//    * to set your profile
// 
//    * one for each additional function like to show the object attributes,
//      to show information about users, to show the status of the server,
//      etc.
// 
 
/**
 * object ids of children
 * <p>
 * Returns an array of object ids. Each id belongs to a child of the
 * collection with ID objectID. The array contains all children both documents
 * and collections.
 */
function array hw_children(int connection, int objectID);
 
/**
 * object records of children
 * <p>
 * Returns an array of object records. Each object record belongs to a child
 * of the collection with ID objectID. The array contains all children both
 * documents and collections.
 */
function array hw_childrenobj(int connection, int objectID);
 
/**
 * closes the Hyperwave connection
 * <p>
 * Returns false if connection is not a valid connection index, otherwise
 * true. Closes down the connection to a Hyperwave server with the given
 * connection index.
 */
function int hw_close(int connection);
 
/**
 * opens a connection
 * <p>
 * Opens a connection to a Hyperwave server and returns a connection index on
 * success, or false if the connection could not be made. Each of the
 * arguments should be a quoted string, except for the port number. The
 * username and password arguments are optional and can be left out. In such a
 * case no identification with the server will be done. It is similar to
 * identify as user anonymous. This function returns a connection index that
 * is needed by other Hyperwave functions. You can have multiple connections
 * open at once. Keep in mind, that the password is not encrypted.
 * 
 * @see hw_pConnect()
 */
function int hw_connect(string host, int port, string username, string password);
 
/**
 * copies objects
 * <p>
 * Copies the objects with object ids as specified in the second parameter to
 * the collection with the id destination id.
 * <p>
 * The value return is the number of copied objects.
 * 
 * @see hw_mv()
 */
function int hw_cp(int connection, array object_id_array, int destination_id);
 
/**
 * deletes object
 * <p>
 * Deletes the object with the given object id in the second parameter. It
 * will delete all instances of the object.
 * <p>
 * Returns TRUE if no error occurs otherwise FALSE.
 * 
 * @see hw_mv()
 */
function int hw_deleteobject(int connection, int object_to_delete);
 
/**
 * object id object belonging to anchor
 * <p>
 * Returns an th object id of the document to which anchorID belongs.
 */
function int hw_docbyanchor(int connection, int anchorID);
 
/**
 * object record object belonging to anchor
 * <p>
 * Returns an th object record of the document to which anchorID belongs.
 */
function string hw_docbyanchorobj(int connection, int anchorID);
 
/**
 * object record of hw_document
 * <p>
 * Returns the object record of the document.
 * 
 * @see hw_DocumentBodyTag()
 * @see hw_DocumentSize()
 */
function string hw_documentattributes(int hw_document);
 
/**
 * body tag of hw_document
 * <p>
 * Returns the BODY tag of the document. If the document is an HTML document
 * the BODY tag should be printed before the document.
 * 
 * @see hw_DocumentAttributes()
 * @see hw_DocumentSize()
 */
function string hw_documentbodytag(int hw_document);
 
/**
 * returns content of hw_document
 * <p>
 * Returns the content of the document. If the document is an HTML document
 * the content is everything after the BODY tag. Information from the HEAD and
 * BODY tag is in the stored in the object record.
 * 
 * @see hw_DocumentAttributes()
 * @see hw_DocumentSize()
 * @see hw_DocumentSetContent()
 */
function string hw_documentcontent(int hw_document);
 
/**
 * sets/replaces content of hw_document
 * <p>
 * Sets or replaces the content of the document. If the document is an HTML
 * document the content is everything after the BODY tag. Information from the
 * HEAD and BODY tag is in the stored in the object record. If you provide
 * this information in the content of the document too, the Hyperwave server
 * will change the object record accordingly when the document is inserted.
 * Probably not a very good idea. If this functions fails the document will
 * retain its old content.
 * 
 * @see hw_DocumentAttributes()
 * @see hw_DocumentSize()
 * @see hw_DocumentContent()
 */
function string hw_documentsetcontent(int hw_document, string content);
 
/**
 * size of hw_document
 * <p>
 * Returns the size in bytes of the document.
 * 
 * @see hw_DocumentBodyTag()
 * @see hw_DocumentAttributes()
 */
function int hw_documentsize(int hw_document);
 
/**
 * returns error message
 * <p>
 * Returns a string containing the last error message or 'No Error'. If false
 * is returned, this function failed. The message relates to the last command.
 */
function string hw_errormsg(int connection);
 
/**
 * retrieve text document
 * <p>
 * Uploads the text document to the server. The object record of the document
 * may not be modified while the document is edited. This function will only
 * works for pure text documents. It will not open a special data connection
 * and therefore blocks the control connection during the transfer.
 * 
 * @see hw_PipeDocument()
 * @see hw_FreeDocument()
 * @see hw_DocumentBodyTag()
 * @see hw_DocumentSize()
 * @see hw_OutputDocument()
 * @see hw_GetText()
 */
function int hw_edittext(int connection, int hw_document);
 
/**
 * error number
 * <p>
 * Returns the last error number. If the return value is 0 no error has
 * occurred. The error relates to the last command.
 */
function int hw_error(int connection);
 
/**
 * frees hw_document
 * <p>
 * Frees the memory occupied by the Hyperwave document.
 */
function int hw_free_document(int hw_document);
 
/**
 * object ids of parents
 * <p>
 * Returns an indexed array of object ids. Each object id belongs to a parent
 * of the object with ID objectID.
 */
function array hw_getparents(int connection, int objectID);
 
/**
 * object records of parents
 * <p>
 * Returns an indexed array of object records plus an associated array with
 * statistical information about the object records. The associated array is
 * the last entry of the returned array. Each object record belongs to a
 * parent of the object with ID objectID.
 */
function array hw_getparentsobj(int connection, int objectID);
 
/**
 * object ids of child collections
 * <p>
 * Returns an array of object ids. Each object ID belongs to a child
 * collection of the collection with ID objectID. The function will not return
 * child documents.
 * 
 * @see hw_GetChildren()
 * @see hw_GetChildDocColl()
 */
function array hw_getchildcoll(int connection, int objectID);
 
/**
 * object records of child collections
 * <p>
 * Returns an array of object records. Each object records belongs to a child
 * collection of the collection with ID objectID. The function will not return
 * child documents.
 * 
 * @see hw_ChildrenObj()
 * @see hw_GetChildDocCollObj()
 */
function array hw_getchildcollobj(int connection, int objectID);
 
/**
 * Gets a remote document
 * <p>
 * Returns a remote document. Remote documents in Hyperwave notation are
 * documents retrieved from an external source. Common remote documents are
 * for example external web pages or queries in a database. In order to be
 * able to access external sources throught remote documents Hyperwave
 * introduces the HGI (Hyperwave Gateway Interface) which is similar to the
 * CGI. Currently, only ftp, http-servers and some databases can be accessed
 * by the HGI. Calling hw_GetRemote() returns the document from the external
 * source. If you want to use this function you should be very familiar with
 * HGIs. You should also consider to use PHP instead of Hyperwave to access
 * external sources. Adding database support by a Hyperwave gateway should be
 * more difficult than doing it in PHP.
 * 
 * @see hw_GetRemoteChildren()
 */
function int hw_getremote(int connection, int objectID);
 
/**
 * Gets children of remote document
 * <p>
 * Returns the children of a remote document. Children of a remote document
 * are remote documents itself. This makes sense if a database query has to be
 * narrowed and is explained in Hyperwave Programmers' Guide. If the number of
 * children is 1 the function will return the document itself formated by the
 * Hyperwave Gateway Interface (HGI). If the number of children is greater
 * than 1 it will return an array of object record with each maybe the input
 * value for another call to hw_GetRemoteChildren(). Those object records are
 * virtual and do not exist in the Hyperwave server, therefore they do not
 * have a valid object ID. How exactely such an object record looks like is up
 * to the HGI. If you want to use this function you should be very familiar
 * with HGIs. You should also consider to use PHP instead of Hyperwave to
 * access external sources. Adding database support by a Hyperwave gateway
 * should be more difficult than doing it in PHP.
 * 
 * @see hw_GetRemote()
 */
function int hw_getremotechildren(int connection, string object record);
 
/**
 * Returns anchors pointing at object
 * <p>
 * Returns the object records of all anchors pointing to the object with ID
 * objectID. The object can either be a document or an anchor of type
 * destination.
 * 
 * @see hw_GetAnchors()
 */
function array hw_getsrcbydestobj(int connection, int objectID);
 
/**
 * object record
 * <p>
 * Returns the object record for the object with ID objectID if the second
 * parameter is an integer. If the second parameter is an array of integer the
 * function will return an array of object records. In such a case the last
 * parameter is also evaluated which is a query string.
 * <p>
 * The query string has the following syntax:
 * <ul>
 * <li> &lt;expr&gt; ::= "(" &lt;expr&gt; ")" |
 * <li> "!" &lt;expr&gt; | // NOT 
 * <li> &lt;expr&gt; "||" &lt;expr&gt; | // OR 
 * <li> &lt;expr&gt; "&&" &lt;expr&gt; | // AND 
 * <li> &lt;attribute&gt; &lt;operator&gt; &lt;value&gt;
 * <li> &lt;attribute&gt; ::= // any attribute name (Title, Author, DocumentType ...) 
 * <li> &lt;operator&gt; ::= "=" | // equal 
 * <li> "&lt;" | // less than (string compare) 
 * <li> "&gt;" | // greater than (string compare) 
 * <li> "~" // regular expression matching 
 * </ul>
 * The query allows to further select certain objects from the list of given
 * objects. Unlike the other query functions, this query may use not indexed
 * attributes. How many object records are returned depends on the query and
 * if access to the object is allowed.
 * 
 * @see hw_GetAndLock()
 * @see hw_GetObjectByQuery()
 */
function array hw_getobject(int connection, [int|array] objectID, string query);
 
/**
 * return bject record and lock object
 * <p>
 * Returns the object record for the object with ID objectID. It will also
 * lock the object, so other users cannot access it until it is unlocked.
 * 
 * @see hw_Unlock()
 * @see hw_GetObject()
 */
function string hw_getandlock(int connection, int objectID);
 
/**
 * retrieve text document
 * <p>
 * Returns the document with object ID objectID. If the document has anchors
 * which can be inserted, they will be inserted already. The optional
 * parameter rootID/prefix can be a string or an integer. If it is an integer
 * it determines how links are inserted into the document. The default is 0
 * and will result in links that are constructed from the name of the link's
 * destination object. This is useful for web applications. If a link points
 * to an object with name 'internet_movie' the HTML link will be &lt;A
 * HREF="/internet_movie"&gt;. The actual location of the source and destination
 * object in the document hierachy is disregarded. You will have to set up
 * your web browser, to rewrite that URL to for example
 * '/my_script.php3/internet_movie'. 'my_script.php3' will have to evaluate
 * $PATH_INFO and retrieve the document. All links will have the prefix
 * '/my_script.php3/'. If you do not want this you can set the optional
 * parameter rootID/prefix to any prefix which is used instead. Is this case
 * it has to be a string.
 * <p>
 * If rootID/prefix is an integer and unequal to 0 the link is constructed
 * from all the names starting at the object with the id rootID/prefix
 * separated by a slash relative to the current object. If for example the
 * above document 'internet_movie' is located at 'a-b-c-internet_movie' with
 * '-' being the seperator between hierachy levels on the Hyperwave server and
 * the source document is located at 'a-b-d-source' the resulting HTML link
 * would be: &lt;A HREF="../c/internet_movie"&gt;. This is useful if you want to
 * download the whole server content onto disk and map the document hierachy
 * onto the file system.
 * <p>
 * This function will only work for pure text documents. It will not open a
 * special data connection and therefore blocks the control connection during
 * the transfer.
 * 
 * @see hw_PipeDocument()
 * @see hw_FreeDocument()
 * @see hw_DocumentBodyTag()
 * @see hw_DocumentSize()
 * @see hw_OutputDocument()
 */
function int hw_gettext(int connection, int objectID, mixed [rootID/prefix] );
 
/**
 * search object
 * <p>
 * Searches for objects on the whole server and returns an array of object
 * ids. The maximum number of matches is limited to max_hits. If max_hits is
 * set to -1 the maximum number of matches is unlimited.
 * <p>
 * The query will only work with indexed attributes.
 * 
 * @see hw_GetObjectByQueryObj()
 */
function array hw_getobjectbyquery(int connection, string query, int max_hits);
 
/**
 * search object
 * <p>
 * Searches for objects on the whole server and returns an array of object
 * records. The maximum number of matches is limited to max_hits. If max_hits
 * is set to -1 the maximum number of matches is unlimited.
 * <p>
 * The query will only work with indexed attributes.
 * 
 * @see hw_GetObjectByQuery()
 */
function array hw_getobjectbyqueryobj(int connection, string query, int max_hits);
 
/**
 * search object in collection
 * <p>
 * Searches for objects in collection with ID objectID and returns an array of
 * object ids. The maximum number of matches is limited to max_hits. If
 * max_hits is set to -1 the maximum number of matches is unlimited.
 * <p>
 * The query will only work with indexed attributes.
 * 
 * @see hw_GetObjectByQueryCollObj()
 */
function array hw_getobjectbyquerycoll(int connection, int objectID, string query, int max_hits);
 
/**
 * search object in collection
 * <p>
 * Searches for objects in collection with ID objectID and returns an array of
 * object records. The maximum number of matches is limited to max_hits. If
 * max_hits is set to -1 the maximum number of matches is unlimited.
 * <p>
 * The query will only work with indexed attributes.
 * 
 * @see hw_GetObjectByQueryColl()
 */
 * array hw_getobjectbyquerycollobj(int connection, int objectID, str_query, int max_hits);
 
/**
 * object ids of child documents of collection
 * <p>
 * Returns array of object ids for child documents of a collection.
 * 
 * @see hw_GetChildren()
 * @see hw_GetChildColl()
 */
function array hw_getchilddoccoll(int connection, int objectID);
 
/**
 * object records of child documents of collection
 * <p>
 * Returns an array of object records for child documents of a collection.
 * 
 * @see hw_ChildrenObj()
 * @see hw_GetChildCollObj()
 */
function array hw_getchilddoccollobj(int connection, int objectID);
 
/**
 * object ids of anchors of document
 * <p>
 * Returns an array of object ids with anchors of the document with object ID
 * objectID.
 */
function array hw_getanchors(int connection, int objectID);
 
/**
 * object records of anchors of document
 * <p>
 * Returns an array of object records with anchors of the document with object
 * ID objectID.
 */
function array hw_getanchorsobj(int connection, int objectID);
 
/**
 * moves objects
 * <p>
 * Moves the objects with object ids as specified in the second parameter from
 * the collection with id source id to the collection with the id destination
 * id. If the destination id is 0 the objects will be unlinked from the source
 * collection. If this is the last instance of that object it will be deleted.
 * If you want to delete all instances at once, use {@link hw_deleteobject()}.
 * <p>
 * The value return is the number of moved objects.
 * 
 * @see hw_cp()
 * @see hw_deleteobject()
 */
function int hw_mv(int connection, array object id_array, int source_id, int destination_id);
 
/**
 * identifies as user
 * <p>
 * Identifies as user with username and password. Identification is only valid
 * for the current session. I do not thing this function will be needed very
 * often. In most cases it will be easier to identify with the opening of the
 * connection.
 * 
 * @see hw_Connect()
 */
function int hw_identify(string username, string password);
 
/**
 * check if object ids in collections
 * <p>
 * Checks whether a set of objects (documents or collections) specified by the
 * object_id_array is part of the collections listed in collection_id_array.
 * When the fourth parameter return_collections is 0, the subset of object ids
 * that is part of the collections (i.e., the documents or collections that
 * are children of one or more collections of collection ids or their
 * subcollections, recursively) is returned as an array. When the fourth
 * parameter is 1, however, the set of collections that have one or more
 * objects of this subset as children are returned as an array. This option
 * allows a client to, e.g., highlight the part of the collection hierarchy
 * that contains the matches of a previous query, in a graphical overview.
 */
function array hw_incollections(int connection, array object_id_array, array collection_id_array, int return_collections);
 
/**
 * info about connection
 * <p>
 * Returns information about the current connection. The returned string has
 * the following format: &lt;Serverstring&gt;, &lt;Host&gt;, &lt;Port&gt;,
 * &lt;Username&gt;, &lt;Port of Client&gt;, &lt;Byte swapping&gt;
 */
function string hw_info(int connection);
 
/**
 * insert collection
 * <p>
 * Inserts a new collection with attributes as in object_array into collection
 * with object ID objectID.
 */
function int hw_inscoll(int connection, int objectID, array object_array);
 
/**
 * insert document
 * <p>
 * Inserts a new document with attributes as in object_record into collection
 * with object ID parentID. This function inserts either an object record only
 * or an object record and a pure ascii text in text if text is given. If you
 * want to insert a general document of any kind use {@link hw_insertdocument()}
 * instead.
 * 
 * @see hw_InsertDocument()
 * @see hw_InsColl()
 */
function int hw_insdoc(int connection, int parentID, string object_record, string text);
 
/**
 * upload any document
 * <p>
 * Uploads a document into the collection with parent_id. The document has to
 * be created before with {@link hw_NewDocument()}. Make sure that the object record
 * of the new document contains at least the attributes: Type, DocumentType,
 * Title and Name. Possibly you also want to set the MimeType. The functions
 * returns the object id of the new document or false.
 * 
 * @see hw_PipeDocument()
 */
function int hw_insertdocument(int connection, int parent_id, int hw_document);
 
/**
 * inserts an object record
 * <p>
 * Inserts an object into the server. The object can be any valid hyperwave
 * object. See the HG-CSP documentation for a detailed information on how the
 * parameters have to be.
 * <p>
 * <b>Note:</b>
 * If you want to insert an Anchor, the attribute Position has always
 * been set either to a start/end value or to 'invisible'. Invisible positions
 * are needed if the annotation has no correspondig link in the annotation
 * text.
 * 
 * @see hw_PipeDocument()
 * @see hw_InsertDocument()
 * @see hw_InsDoc()
 * @see hw_InsColl()
 */
function int hw_insertobject(int connection, string object rec, string parameter);
 
/**
 * modifies object record
 * <p>
 * This command allows to remove, add, or modify individual attributes of an
 * object record. The object is specified by the Object ID object_to_change.
 * The first array remove is a list of attributes to remove. The second array
 * add is a list of attributes to add. In order to modify an attribute one
 * will have to remove the old one and add a new one. hw_modifyobject() will
 * always remove the attributes before it adds attributes unless the value of
 * the attribute to remove is not a string or array.
 * <p>
 * The last parameter determines if the modification is performed recursively.
 * 1 means recurive modification. If some of the objects cannot be modified
 * they will be skiped without notice. {@link hw_error()} may not indicate an error
 * though some of the objects could not be modified.
 * <p>
 * The keys of both arrays are the attributes name. The value of each array
 * element can either be an array, a string or anything else. If it is an
 * array each attribute value is constructed by the key of each element plus a
 * colon and the value of each element. If it is a string it is taken as the
 * attribute value. An empty string will result in a complete removal of that
 * attribute. If the value is neither a string nor an array but something
 * else, e.g. an integer, no operation at all will be performed on the
 * attribute. This is neccessary if you want to to add a completely new
 * attribute not just a new value for an existing attribute. If the remove
 * array contained an empty string for that attribute, the attribute would be
 * tried to be removed which would fail since it doesn't exist. The following
 * addition of a new value for that attribute would also fail. Setting the
 * value for that attribute to e.g. 0 would not even try to remove it and the
 * addition will work.
 * <p>
 * If you would like to change the attribute 'Name' with the current value
 * 'books' into 'articles' you will have to create two arrays and call
 * {@link hw_modifyobject()}.
 * <p>
 * <b>Example 1.</b> modifying an attribute
 * <pre>
 *    // $connect is an existing connection to the Hyperwave server
 *    // $objid is the ID of the object to modify
 *    $remarr = array("Name" =&gt; "books");
 *    $addarr = array("Name" =&gt; "articles");
 *    $hw_modifyobject($connect, $objid, $remarr, $addarr);
 * </pre>
 * In order to delete/add a name=value pair from/to the object record just
 * pass the remove/add array and set the last/third parameter to an empty
 * array. If the attribute is the first one with that name to add, set
 * attribute value in the remove array to an integer.
 * <p>
 * <b>Example 2.</b> adding a completely new attribute
 * <pre>
 *    // $connect is an existing connection to the Hyperwave server
 *    // $objid is the ID of the object to modify
 *    $remarr = array("Name" =&gt; 0);
 *    $addarr = array("Name" =&gt; "articles");
 *    $hw_modifyobject($connect, $objid, $remarr, $addarr);
 * </pre>
 * <b>Note:</b>
 * Multilingual attributes, e.g. 'Title', can be modified in
 * two ways. Either by providing the attributes value in its native
 * form 'language':'title' or by providing an array with elements
 * for each language as described above. The above example would
 * than be:
 * <p>
 * <b>Example 3.</b> modifying Title attribute
 * <pre>
 *    $remarr = array("Title" =&gt; "en:Books");
 *    $addarr = array("Title" =&gt; "en:Articles");
 *    $hw_modifyobject($connect, $objid, $remarr, $addarr);
 * </pre>
 * <b>Example 4.</b> modifying Title attribute
 * <pre>
 *    $remarr = array("Title" =&gt; array("en" =&gt; "Books"));
 *    $addarr = array("Title" =&gt; array("en" =&gt; "Articles", "ge"=&gt;"Artikel"));
 *    $hw_modifyobject($connect, $objid, $remarr, $addarr);
 * </pre>
 * This removes the english title 'Books' and adds the english title
 * 'Articles' and the german title 'Artikel'.
 * <p>
 * <b>Example 5.</b> removing attribute
 * <pre>
 *    $remarr = array("Title" =&gt; "");
 *    $addarr = array("Title" =&gt; "en:Articles");
 *    $hw_modifyobject($connect, $objid, $remarr, $addarr);
 * </pre>
 * <b>Note:</b>
 * This will remove all attributes with the name 'Title' and
 * adds a new 'Title' attribute. This comes in handy if you want to
 * remove attributes recursively.
 * <p>
 * <b>Note:</b>
 * If you need to delete all attributes with a certain name
 * you will have to pass an empty string as the attribute value.
 * <p>
 * <b>Note:</b>
 * Only the attributes 'Title', 'Description' and 'Keyword'
 * will properly handle the language prefix. If those attributes
 * don't carry a language prefix, the prefix 'xx' will be assigned.
 * <p>
 * <b>Note:</b>
 * The 'Name' attribute is somewhat special. In some cases it
 * cannot be complete removed. You will get an error message 'Change
 * of base attribute' (not clear when this happens). Therefore you
 * will always have to add a new Name first and than remove the old
 * one.
 * <p>
 * <b>Note:</b>
 * You may not suround this function by calls to
 * {@link hw_getandlock()} and {@link hw_unlock()}. {@link hw_modifyobject()} does this
 * internally.
 * <p>
 * Returns TRUE if no error occurs otherwise FALSE.
 */
function int hw_modifyobject(int connection, int object_to_change, array remove, array add, int mode);
 
/**
 * create new document
 * <p>
 * Returns a new Hyperwave document with document data set to document_data
 * and object record set to object_record. The length of the document_data has
 * to passed in document_sizeThis function does not insert the document into
 * the Hyperwave server.
 * 
 * @see hw_FreeDocument()
 * @see hw_DocumentSize()
 * @see hw_DocumentBodyTag()
 * @see hw_OutputDocument()
 * @see hw_InsertDocument()
 */
function int hw_new_document(string object_record, string document_data, int document_size);
 
/**
 * convert attributes from object record to object array
 * <p>
 * Converts an object_record into an object array. The keys of the resulting
 * array are the attributes names. Multiple attributes like 'Title' in
 * different languages form its own array. The keys of this array are the left
 * part to the colon of the attribute value. Currently only the attributes
 * 'Title', 'Description' and 'Keyword' are treated properly.
 */
function array hw_objrec2array(string object_record);
 
/**
 * prints hw_document
 * <p>
 * Prints the document without the BODY tag.
 */
function int hw_outputdocument(int hw_document);
 
/**
 * make a persistent database connection
 * <p>
 * Returns a connection index on success, or false if the connection could not
 * be made. Opens a persistent connection to a Hyperwave server. Each of the
 * arguments should be a quoted string, except for the port number. The
 * username and password arguments are optional and can be left out. In such a
 * case no identification with the server will be done. It is similar to
 * identify as user anonymous. This function returns a connection index that
 * is needed by other Hyperwave functions. You can have multiple persistent
 * connections open at once.
 * 
 * @see hw_Connect()
 */
function int hw_pconnect(string host, int port, string username, string password);
 
/**
 * retrieve any document
 * <p>
 * Returns the Hyperwave document with object ID objectID. If the document has
 * anchors which can be inserted, they will have been inserted already. The
 * document will be transfered via a special data connection which does not
 * block the control connection.
 * 
 * @see hw_GetText()
 * @see hw_FreeDocument()
 * @see hw_DocumentSize()
 * @see hw_DocumentBodyTag()
 * @see hw_OutputDocument()
 */
function int hw_pipedocument(int connection, int objectID);
 
/**
 * root object id
 * <p>
 * Returns the object ID of the hyperroot collection. Currently this is always
 * 0. The child collection of the hyperroot is the root collection of the
 * connected server.
 */
function int hw_root();
 
/**
 * unlock object
 * <p>
 * Unlocks a document, so other users regain access.
 * 
 * @see hw_GetAndLock()
 */
function int hw_unlock(int connection, int objectID);
 
/**
 * List of currently logged in users
 * <p>
 * Returns an array of users currently logged into the Hyperwave server. Each
 * entry in this array is an array itself containing the elements id, name,
 * system, onSinceDate, onSinceTime, TotalTime and self. 'self' is 1 if this
 * entry belongs to the user who initianted the request.
 */
function int hw_who(int connection);
 
/**
 * name of currently logged in user
 * <p>
 * Returns the username of the connection.
 */
function string hw_getusername(int connection);


///////////////////////////////////////////////////////////////////////////
// ICAP functions
//
// To get these functions to work, you have to compile PHP with --with-icap.
// That requires the icap library to be installed. Grab the latest version
// from http://icap.chek.com/ and compile and install it.
//  

/**
 * Opens up an ICAP connection
 * <p>
 * Returns an ICAP stream on success, false on error.
 * <p>
 * icap_open() opens up an ICAP connection to the specified calendar store. If
 * the optional options is specified, passes the options to that mailbox also.
 */
function stream icap_open(stringcalendar, stringusername, stringpassword, stringoptions);
 
/**
 * Close an ICAP stream
 * <p>
 * Closes the given icap stream.
 */
function int icap_close(int icap_stream, int flags);
 
/**
 * Fetches an event from the calendar stream/
 * <p>
 * icap_fetch_event() fetches an event from the calendar stream specified by
 * id.
 * <p>
 * Returns an event object consisting of:
 * <ul>
 * <li> int id - ID of that event.
 * <li> int public - TRUE if the event if public, FALSE if it is private.
 * <li> string category - Category string of the event.
 * <li> string title - Title string of the event.
 * <li> string description - Description string of the event.
 * <li> int alarm - number of minutes before the event to send an
 *      alarm/reminder.
 * <li> object start - Object containing a datetime entry.
 * <li> object end - Object containing a datetime entry.
 * </ul>
 * All datetime entries consist of an object that contains:
 * <ul>
 * <li> int year - year
 * <li> int month - month
 * <li> int mday - day of month
 * <li> int hour - hour
 * <li> int min - minutes
 * <li> int sec - seconds
 * </ul>
 */
function object icap_fetch_event(streamicap_stream, idevent_id, optionsoptions);
 
/**
 * Return a list of events between two given datetimes
 * <p>
 * Returns an array of event ID's that are between the two given datetimes.
 * <p>
 * icap_list_events() function takes in a beginning datetime and an end
 * datetime for a calendar stream. An array of event id's that are between the
 * given datetimes are returned.
 * <p>
 * All datetime entries consist of an object that contains:
 * <ul>
 * <li> int year - year
 * <li> int month - month
 * <li> int mday - day of month
 * <li> int hour - hour
 * <li> int min - minutes
 * <li> int sec - seconds
 * </ul>
 */
function array icap_list_events(stream icap_stream, datetime begin_date, datetime end_date);
 
/**
 * Store an event into an ICAP calendar
 * <p>
 * icap_store_event() Stores an event into an ICAP calendar. an event object
 * consists of:
 * <ul>
 * <li> int public - 1 if public, 0 if private;
 * <li> string caegory - Category string of the event.
 * <li> string title - Title string of the event.
 * <li> string description - Description string of the event.
 * <li> int alarm - Number of minutes before the event to sned out an alarm.
 * <li> datetime start - datetime object of the start of the event.
 * <li> datetime end - datetime object of the end of the event.
 * </ul>
 * All datetime entries consist of an object that contains:
 * <ul>
 * <li> int year - year
 * <li> int month - month
 * <li> int mday - day of month
 * <li> int hour - hour
 * <li> int min - minutes
 * <li> int sec - seconds
 * </ul>
 * Returns true on success and false on error.
 */
function int icap_store_event(int icap_stream, object event);
 
/**
 * Delete an event from an ICAP calendar
 * <p>
 * icap_delete_event() deletes the calendar event specified by the uid.
 * 
 * @return true.
 */
function int icap_delete_event(int uid);
 
/**
 * turn off an alarm for an event
 * <p>
 * icap_snooze() turns off an alarm for a calendar event specified by the uid.
 * 
 * @return true.
 */
function int icap_snooze(int uid);
 
/**
 * en datetime
 * <p>
 * Returns an array of event ID's that has an alarm going off at the given
 * datetime.
 * <p>
 * icap_list_alarms() function takes in a datetime for a calendar stream. An
 * array of event id's that has an alarm should be going off at the datetime
 * are returned.
 * <p>
 * All datetime entries consist of an object that contains:
 * <ul>
 * <li> int year - year
 * <li> int month - month
 * <li> int mday - day of month
 * <li> int hour - hour
 * <li> int min - minutes
 * <li> int sec - seconds
 * </ul>
 */
function array icap_list_alarms(stream icap_stream, datetime alarm_date);


///////////////////////////////////////////////////////////////////////////
// Image functions
//
// You can use the image functions in PHP to get the size of JPEG, GIF, and
// PNG images, and if you have the GD library (available at
// http://www.boutell.com/gd/) you will also be able to create and manipulate
// images.
//  

/**
 * get the size of a GIF, JPG or PNG image
 * <p>
 * The GetImageSize() function will determine the size of any GIF, JPG or PNG
 * image file and return the dimensions along with the file type and a
 * height/width text string to be used inside a normal HTML IMG tag.
 * <p>
 * Returns an array with 4 elements. Index 0 contains the width of the image
 * in pixels. Index 1 contains the height. Index 2 a flag indicating the type
 * of the image. 1 = GIF, 2 = JPG, 3 = PNG. Index 3 is a text string with the
 * correct "height=xxx width=xxx" string that can be used directly in an IMG
 * tag.
 * <p>
 * <b>Example 1.</b> GetImageSize
 * <pre>
 *    &lt;?php $size = GetImageSize("img/flag.jpg"); ?&gt;
 *    &lt;IMG SRC="img/flag.jpg" &lt;?php echo $size[3]; ?&gt;>
 * </pre>
 * The optional imageinfo parameter allows you to extract some extended
 * information from the image file. Currently this will return the diffrent
 * JPG APP markers in an associative Array. Some Programs use these APP
 * markers to embedd text information in images. A very common one in to embed
 * IPTC http://www.xe.net/iptc/ information in the APP13 marker. You can use
 * the {@link iptcparse()} function to parse the binary APP13 marker into something
 * readable.
 *
 * <b>Example 2.</b> GetImageSize returning IPTC
 * <pre>
 *    &lt;?php
 *    $size = GetImageSize("testimg.jpg",&$info);
 *    if (isset($info["APP13"])) {
 *       $iptc = iptcparse($info["APP13"]);
 *       var_dump($iptc);
 *    }
 *    ?&gt;
 * </pre>
 * <b>Note:</b>
 * This function does not require the GD image library.
 */
function array getimagesize(string filename, array [imageinfo]);
 
/**
 * draw a partial ellipse
 * <p>
 * ImageArc draws a partial ellipse centered at cx, cy (top left is 0,0) in
 * the image represented by im. w and h specifies the ellipse's width and
 * height respectively while the start and end points are specified in degrees
 * indicated by the s and e arguments.
 */
function int imagearc(int im, int cx, int cy, int w, int h, int s, int e, int col);
 
/**
 * draw a character horizontally
 * <p>
 * ImageChar draws the first character of c in the image identified by id with
 * its upper-left at x,y (top left is 0,0) with the color col. If font is 1,
 * 2, 3, 4 or 5, a built-in font is used (with higher numbers corresponding to
 * larger fonts).
 * 
 * @see imageloadfont()
 */
function int imagechar(int im, int font, int x, int y, string c, int col);
 
/**
 * draw a character vertically
 * <p>
 * ImageCharUp draws the character c vertically in the image identified by im
 * at coordinates x, y (top left is 0, 0) with the color col. If font is 1, 2,
 * 3, 4 or 5, a built-in font is used.
 * 
 * @see imageloadfont()
 */
function int imagecharup(int im, int font, int x, int y, string c, int col);
 
/**
 * allocate a color for an image
 * <p>
 * ImageColorAllocate returns a color identifier representing the color
 * composed of the given RGB components. The im argument is the return from
 * the {@link imagecreate()} function. ImageColorAllocate must be called to create
 * each color that is to be used in the image represented by im.
 * <pre>
 *    $white = ImageColorAllocate($im, 255,255,255);
 *    $black = ImageColorAllocate($im, 0,0,0);
 * </pre>
 */
function int imagecolorallocate(int im, int red, int green, int blue);
 
/**
 * define a color as transparent
 * <p>
 * ImageColorTransparent sets the transparent color in the im image to col. im
 * is the image identifier returned by {@link imagecreate()} and col is a color
 * identifier returned by {@link imagecolorallocate()}.
 * <p>
 * The identifier of the new (or current, if none is specified) transparent
 * color is returned.
 */
function int imagecolortransparent(int im, int [col]);
 
/**
 * copy and resize part of an image
 * <p>
 * ImageCopyResized copies a rectangular portion of one image to another
 * image. dst_im is the destination image, src_im is the source image
 * identifier. If the source and destination coordinates and width and heights
 * differ, appropriate stretching or shrinking of the image fragment will be
 * performed. The coordinates refer to the upper left corner. This function
 * can be used to copy regions within the same image (if dst_im is the same as
 * src_im) but if the regions overlap the results will be unpredictable.
 */
function int imagecopyresized(int dst_im, int src_im, int dstX, int dstY, int srcX, int srcY, int dstW, int dstH, int srcW, int srcH);
 
/**
 * create a new image
 * <p>
 * ImageCreate returns an image identifier representing a blank image of size
 * x_size by y_size.
 */
function int imagecreate(int x_size, int y_size);
 
/**
 * create a new image from file or URL
 * <p>
 * imagecreatefromgif() returns an image identifier representing the image
 * obtained from the given filename.
 * <p>
 * {@link imagecreatefromgif()} returns an empty string on failure. It also outputs an
 * error message, which unfortunately displays as a broken link in a browser.
 * To ease debugging the following example will produce an error GIF:
 * <p>
 * <b>Example 1.</b> Example to handle an error during creation (courtesy
 * vic@zymsys.com )
 * <pre>
 *    function LoadGif($imgname)
 *    {
 *      $im = @imagecreatefromgif($imgname); // Attempt to open 
 *      if ($im == "") { // See if it failed 
 *        $im = ImageCreate(150,30); // Create a blank image 
 *        $bgc = ImageColorAllocate($im,255,255,255);
 *        $tc  = ImageColorAllocate($im,0,0,0);
 *        ImageFilledRectangle($im,0,0,150,30,$bgc);
 *        ImageString($im,1,5,5,"Error loading $imgname",$tc); // Output an errmsg 
 *      }
 *      return $im;
 *    }
 * </pre>
 * <b>Note:</b>
 * Since all GIF support was removed from the GD library in
 * version 1.6, this function is not available if you are using that
 * version of the GD library.
 */
function int imagecreatefromgif(string filename);
 
/**
 * draw a dashed line
 * <p>
 * ImageLine draws a dashed line from x1,y1 to x2,y2 (top left is 0,0) in
 * image im of color col.
 * 
 * @see imageline()
 */
function int imagedashedline(int im, int x1, int y1, int x2, int y2, int col);
 
/**
 * destroy an image
 * <p>
 * ImageDestroy frees any memory associated with image im. im is the image
 * identifier returned by the {@link imagecreate()} function.
 */
function int imagedestroy(int im);
 
/**
 * flood fill
 * <p>
 * ImageFill performs a flood fill starting at coordinate x, y (top left is
 * 0,0) with color col in the image im.
 */
function int imagefill(int im, int x, int y, int col);
 
/**
 * draw a filled polygon
 * <p>
 * ImageFilledPolygon creates a filled polygon in image im. points is a PHP
 * array containing the polygon's vertices, ie. points[0] = x0, points[1] =
 * y0, points[2] = x1, points[3] = y1, etc. num_points is the total number of
 * vertices.
 */
function int imagefilledpolygon(int im, array points, int num_points, int col);
 
/**
 * draw a filled rectangle
 * <p>
 * ImageFilledRectangle creates a filled rectangle of color col in image im
 * starting at upper left coordinates x1, y1 and ending at bottom right
 * coordinates x2, y2. 0, 0 is the top left corner of the image.
 */
function int imagefilledrectangle(int im, int x1, int y1, int x2, int y2, int col);
 
/**
 * flood fill to specific color
 * <p>
 * ImageFillToBorder performs a flood fill whose border color is defined by
 * border. The starting point for the fill is x,y (top left is 0,0) and the
 * region is filled with color col.
 */
function int imagefilltoborder(int im, int x, int y, int border, int col);
 
/**
 * get font height
 * <p>
 * Returns the pixel height of a character in the specified font.
 * 
 * @see imagefontwidth()
 * @see imageloadfont()
 */
function int imagefontheight(int font);
 
/**
 * get font width
 * <p>
 * Returns the pixel width of a character in font.
 * 
 * @see imagefontheight()
 * @see imageloadfont()
 */
function int imagefontwidth(int font);
 
/**
 * output image to browser or file
 * <p>
 * imagegif() creates the GIF file in filename from the image im. The im
 * argument is the return from the {@link imagecreate()} function.
 * <p>
 * The image format will be GIF87a unless the image has been made transparent
 * with {@link imagecolortransparent()}, in which case the image format will be
 * GIF89a.
 * <p>
 * The filename argument is optional, and if left off, the raw image stream
 * will be output directly. By sending an image/gif content-type using
 * {@link header()}, you can create a PHP script that outputs GIF images directly.
 * <p>
 * <b>Note:</b>
 * Since all GIF support was removed from the GD library in
 * version 1.6, this function is not available if you are using that
 * version of the GD library.
 */
function int imagegif(int im, string filename);
 
/**
 * enable or disable interlace
 * <p>
 * ImageInterlace() turns the interlace bit on or off. If interlace is 1 the
 * im image will be interlaced, and if interlace is 0 the interlace bit is
 * turned off.
 * <p>
 * This functions returns whether the interlace bit is set for the image.
 */
function int imageinterlace(int im, int [interlace]);
 
/**
 * draw a line
 * <p>
 * ImageLine draws a line from x1,y1 to x2,y2 (top left is 0,0) in image im of
 * color col.
 * 
 * @see imagecreate()
 * @see imagecolorallocate()
 */
function int imageline(int im, int x1, int y1, int x2, int y2, int col);
 
/**
 * load a new font
 * <p>
 * ImageLoadFont loads a user-defined bitmap font and returns an identifier
 * for the font (that is always greater than 5, so it will not conflict with
 * the built-in fonts).
 * <p>
 * The font file format is currently binary and architecture dependent. This
 * means you should generate the font files on the same type of CPU as the
 * machine you are running PHP on.
 * <p>
 * Table 1. Font file format
 * <pre>
 * byte pos.    data    description
 *              type
 * byte 0-3     int     number of characters in the font
 * byte 4-7     int     value of first character in the font (often 32
 *                      for space)
 * byte 8-11    int     pixel width of each character
 * byte 12-15   int     pixel height of each character
 * byte 16-     char    array with character data, one byte per pixel in
 *                      each character, for a total of
 *                      (nchars*width*height) bytes.
 * </pre>
 *
 * @see ImageFontWidth()
 * @see ImageFontHeight()
 */
function int imageloadfont(string file);
 
/**
 * draw a polygon
 * <p>
 * ImagePolygon creates a polygon in image id. points is a PHP array
 * containing the polygon's vertices, ie. points[0] = x0, points[1] = y0,
 * points[2] = x1, points[3] = y1, etc. num_points is the total number of
 * vertices.
 * 
 * @see imagecreate()
 */
function int imagepolygon(int im, array points, int num_points, int col);
 
/**
 * draw a rectangle
 * <p>
 * ImageRectangle creates a rectangle of color col in image im starting at
 * upper left coordinate x1,y1 and ending at bottom right coordinate x2,y2.
 * 0,0 is the top left corner of the image.
 */
function int imagerectangle(int im, int x1, int y1, int x2, int y2, int col);
 
/**
 * set a single pixel
 * <p>
 * ImageSetPixel draws a pixel at x,y (top left is 0,0) in image im of color
 * col.
 * 
 * @see imagecreate()
 * @see imagecolorallocate()
 */
function int imagesetpixel(int im, int x, int y, int col);
 
/**
 * draw a string horizontally
 * <p>
 * ImageString draws the string s in the image identified by im at coordinates
 * x,y (top left is 0,0) in color col. If font is 1, 2, 3, 4 or 5, a built-in
 * font is used.
 * 
 * @see imageloadfont()
 */
function int imagestring(int im, int font, int x, int y, string s, int col);
 
/**
 * draw a string vertically
 * <p>
 * ImageStringUp draws the string s vertically in the image identified by im
 * at coordinates x,y (top left is 0,0) in color col. If font is 1, 2, 3, 4 or
 * 5, a built-in font is used.
 * 
 * @see imageloadfont()
 */
function int imagestringup(int im, int font, int x, int y, string s, int col);
 
/**
 * get image width
 * <p>
 * ImageSX returns the width of the image identified by im.
 * 
 * @see imagecreate()
 * @see imagesy()
 */
function int imagesx(int im);
 
/**
 * get image height
 * <p>
 * ImageSY returns the height of the image identified by im.
 * 
 * @see imagecreate()
 * @see imagesx()
 */
function int imagesy(int im);
 
/**
 * give the bounding box of a text using TypeType fonts
 * <p>
 * This function calculates and returns the bounding box in pixels a TrueType
 * text.
 * <p>
 * ImageTTFBBox() returns an array with 8 elements representing four points
 * making the bounding box of the text:
 * <ul>
 * <li> 0 - lower left corner, X position
 * <li> 1 - lower left corner, Y position
 * <li> 2 - lower right corner, X position
 * <li> 3 - lower right corner, Y position
 * <li> 4 - upper right corner, X position
 * <li> 5 - upper right corner, Y position
 * <li> 6 - upper left corner, X position
 * <li> 7 - upper left corner, Y position
 * </ul>
 * The points are relative to the text regardless of the angle, so "upper
 * left" means in the top left-hand corner seeing the text horizontallty.
 * <p>
 * This function requires both the GD library and the Freetype library.
 * 
 * @param text           The string to be measured.
 * @param size           The font size.
 * @param fontfile       The name of the TrueType font file. (Can also be an URL.)
 * @param angle          Angle in degrees in which text will be measured.
 * 
 * @see ImageTTFText()
 */
function array ImageTTFBBox(int size, int angle, string fontfile, string text);
 
/**
 * write text to the image using a TrueType fonts
 * <p>
 * ImageTTFText draws the string text in the image identified by im, starting
 * at coordinates x,y (top left is 0,0), at an angle of angle in color col,
 * using the TrueType font file identified by fontfile.
 * <p>
 * The coordinates given by x,y will define the basepoint of the first
 * character (roughly the lower-left corner of the character). This is
 * different from the {@link ImageString()}, where x,y define the upper-right corner
 * of the first character.
 * <p>
 * angle is in degrees, with 0 degrees being left-to-right reading text (3
 * o'clock direction), and higher values representing a counter-clockwise
 * rotation. (i.e., a value of 90 would result in bottom-to-top reading text).
 * <p>
 * fontfile is the path to the TrueType font you wish to use.
 * <p>
 * text is the text string which may include UTF-8 character sequences (of the
 * form: &#123; ) to access characters in a font beyond the first 255.
 * <p>
 * col is the color index. Using the negative of a color index has the effect
 * of turning off antialiasing.
 * <p>
 * ImageTTFText() returns an array with 8 elements representing four points
 * making the bounding box of the text. The order of the points is upper left,
 * upper right, lower right, lower left. The points are relative to the text
 * regardless of the angle, so "upper left" means in the top left-hand corner
 * when you see the text horizontallty.
 * <p>
 * This example script will produce a black GIF 400x30 pixels, with the words
 * "Testing..." in white in the font Arial.
 * <p>
 * <b>Example 1.</b> ImageTTFText
 * <pre>
 *    &lt;?php
 *    Header("Content-type: image/gif");
 *    $im = imagecreate(400,30);
 *    $black = ImageColorAllocate($im, 0,0,0);
 *    $white = ImageColorAllocate($im, 255,255,255);
 *    ImageTTFText($im, 20, 0, 10, 20, $white, "/path/arial.ttf", "Testing... Omega: &#937;");
 *    ImageGif($im);
 *    ImageDestroy($im);
 *    ?&gt;
 * </pre>
 * This function requires both the GD library and the FreeType library.
 * 
 * @see ImageTTFBBox()
 */
function array ImageTTFText(int im, int size, int angle, int x, int y, int col, string fontfile, string text);
 
/**
 * get the index of the color of a pixel
 * <p>
 * Returns the index of the color of the pixel at the specified location in
 * the image.
 * 
 * @see imagecolorset()
 * @see imagecolorsforindex()
 * 
 */
function int imagecolorat(int im, int x, int y);
 
/**
 * Returns the index of the color in the palette of the image which is
 * "closest" to the specified RGB value.
 * <p>
 * The "distance" between the desired color and each color in the palette is
 * calculated as if the RGB values represented points in three-dimensional
 * space.
 * 
 * @see imagecolorexact()
 */
function int imagecolorclosest(int im, int red, int green, int blue);
 
/**
 * get the index of the specified color
 * <p>
 * Returns the index of the specified color in the palette of the image.
 * <p>
 * If the color does not exist in the image's palette, -1 is returned.
 * 
 * @see imagecolorclosest()
 */
function int imagecolorexact(int im, int red, int green, int blue);
 
/**
 * This function is guaranteed to return a color index for a requested color,
 * either the exact color or the closest possible alternative.
 * 
 * @see imagecolorclosest()
 */
function int imagecolorresolve(int im, int red, int green, int blue);
 
/**
 * set the color for the specified palette index
 * <p>
 * This sets the specified index in the palette to the specified color. This
 * is useful for creating flood-fill-like effects in paletted images without
 * the overhead of performing the actual flood-fill.
 * 
 * @see imagecolorat()
 */
function bool imagecolorset(int im, int index, int red, int green, int blue);
 
/**
 * get the colors for an index
 * <p>
 * This returns an associative array with red, green, and blue keys that
 * contain the appropriate values for the specified color index.
 * 
 * @see imagecolorat()
 * @see imagecolorexact()
 */
function array imagecolorsforindex(int im, int index);
 
/**
 * find out the number of colors in an image's palette
 * <p>
 * This returns the number of colors in the specified image's palette.
 * 
 * @see imagecolorat()
 * @see imagecolorsforindex()
 */
function int imagecolorstotal(int im);
 
/**
 * load a PostScript Type 1 from file
 * <p>
 * In the case everything went right, a valid font index will be returned and
 * can be used for further purposes. Otherwise the function returns false and
 * prints a message describing what went wrong.
 * 
 * @see imagepsfreefont()
 */
function int imagepsloadfont(string filename);
 
/**
 * free memory used by a PostScript Type 1 font
 * 
 * @see imagepsloadfont()
 */
function void imagepsfreefont(int fontindex);
 
/**
 * change the character encoding vector of a font
 * <p>
 * Loads a character encoding vector from from a file and changes the fonts
 * encoding vector to it. As a PostScript fonts default vector lacks most of
 * the character positions above 127, you'll definitely want to change this if
 * you use an other language than english. The exact format of this file is
 * described in T1libs documentation. T1lib comes with two ready-to-use files,
 * IsoLatin1.enc and IsoLatin2.enc.
 * <p>
 * If you find yourself using this function all the time, a much better way to
 * define the encoding is to set ps.default_encoding in the configuration file
 * to point to the right encoding file and all fonts you load will
 * automatically have the right encoding.
 */
function int imagepsencodefont(string encodingfile);

/**
 * ImagePSText -- to draw a text string over an image using PostScript Type1
 * fonts
 * <p>
 * size is expressed in pixels.
 * <p>
 * foreground is the color in which the text will be painted. background is
 * the color to which the text will try to fade in with antialiasing. No
 * pixels with the color background are actually painted, so the background
 * image does not need to be of solid color.
 * <p>
 * The coordinates given by x, y will define the origin (or reference point)
 * of the first character (roughly the lower-left corner of the character).
 * This is different from the {@link ImageString()}, where x, y define the upper-right
 * corner of the first character. Refer to PostScipt documentation about fonts
 * and their measuring system if you have trouble understanding how this
 * works.
 * <p>
 * space allows you to change the default value of a space in a font. This
 * amount is added to the normal value and can also be negative.
 * <p>
 * tightness allows you to control the amount of white space between
 * characters. This amount is added to the normal character width and can also
 * be negative.
 * <p>
 * angle is in degrees.
 * <p>
 * antialias_steps allows you to control the number of colours used for
 * antialiasing text. Allowed values are 4 and 16. The higher value is
 * recommended for text sizes lower than 20, where the effect in text quality
 * is quite visible. With bigger sizes, use 4. It's less computationally
 * intensive.
 * <p>
 * Parameters space and tightness are expressed in character space units,
 * where 1 unit is 1/1000th of an em-square.
 * <p>
 * Parameters space, tightness, angle and antialias are optional.
 * <p>
 * This function returns an array containing the following elements:
 * <ul>
 * <li> 0 - lower left x-coordinate
 * <li> 1 - lower left y-coordinate
 * <li> 2 - upper right x-coordinate
 * <li> 3 - upper right y-coordinate
 * </ul>
 * 
 * @see imagepsbbox()
 */
function array imagepstext(int image, string text, int font, int size,
                           int foreground, int background,
                           int x, int y, int [space], int [tightness],
                           float [angle], int [antialias_steps]);
 
/**
 * size is expressed in pixels.
 * <p>
 * space allows you to change the default value of a space in a font. This
 * amount is added to the normal value and can also be negative.
 * <p>
 * tightness allows you to control the amount of white space between
 * characters. This amount is added to the normal character width and can also
 * be negative.
 * <p>
 * angle is in degrees.
 * <p>
 * Parameters space and tightness are expressed in character space units,
 * where 1 unit is 1/1000th of an em-square.
 * <p>
 * Parameters space, tightness and angle are optional.
 * <p>
 * The bounding box is calculated using information available from character
 * metrics, and unfortunately tends to differ slightly from the results
 * achieved by actually rasterizing the text. If the angle is 0 degrees, you
 * can expect the text to need 1 pixel more to every direction.
 * <p>
 * This function returns an array containing the following elements:
 * <ul>
 * <li> 0 - lower left x-coordinate
 * <li> 1 - lower left y-coordinate
 * <li> 2 - upper right x-coordinate
 * <li> 3 - upper right y-coordinate
 * </ul>
 * 
 * @see imagepstext()
 */
function array imagepsbbox(string text, int font, int size, int space, int width, float angle);


///////////////////////////////////////////////////////////////////////////
// IMAP functions
// 
// To get these functions to work, you have to compile PHP with --with-imap.
// That requires the c-client library to be installed. Grab the latest version
// from ftp://ftp.cac.washington.edu/imap/ and compile it. Then copy
// c-client/c-client.a to /usr/local/lib or some other directory on your link
// path and copy c-client/rfc822.h, mail.h and linkage.h to /usr/local/include
// or some other directory in your include path.
//  

/**
 * Append a string message to a specified mailbox
 * <p>
 * Returns true on sucess, false on error.
 * <p>
 * imap_append() appends a string message to the specified mailbox mbox. If
 * the optional flags is specified, writes the flags to that mailbox also.
 * <p>
 * When talking to the Cyrus IMAP server, you must use "\r\n" as your
 * end-of-line terminator instead of "\n" or the operation will fail.
 */
function int imap_append(int imap_stream, string mbox, string message, stringflags);
 
/**
 * Decode BASE64 encoded text
 * <p>
 * imap_base64() function decodes BASE-64 encoded text. The decoded message is
 * returned as a string.
 */
function string imap_base64(string text);
 
/**
 * Read the message body
 * <p>
 * imap_body() returns the body of the message, numbered msg_number in the
 * current mailbox. The optional flags are a bit mask with one or more of the
 * following:
 * <ul>
 * <li> FT_UID - The msgno is a UID
 * <li> FT_PEEK - Do not set the \Seen flag if not already set
 * <li> FT_INTERNAL - The return string is in internal format, will not
 *      canonicalize to CRLF.
 * </ul>
 */
function string imap_body(int imap_stream, int msg_number, int flags);
 
/**
 * Check current mailbox
 * <p>
 * Returns information about the current mailbox. Returns FALSE on failure.
 * <p>
 * The imap_check() function checks the current mailbox status on the server
 * and returns the information in an object with following properties.
 * <p>
 * Date : date of the message<br>
 * Driver : driver<br>
 * Mailbox : name of the mailbox<br>
 * Nmsgs : number of messages<br>
 * Recent : number of recent messages
 */
function array imap_check(int imap_stream);
 
/**
 * Close an IMAP stream
 * <p>
 * Close the imap stream. Takes an optional flag CL_EXPUNGE, which will
 * silently expunge the mailbox before closing.
 */
function int imap_close(int imap_stream, int flags);
 
/**
 * Create a new mailbox
 * <p>
 * imap_createmailbox() creates a new mailbox specified by mbox.
 * <p>
 * Returns true on success and false on error.
 */
function int imap_createmailbox(int imap_stream, string mbox);
 
/**
 * Mark a messge for deletion from current mailbox
 * <p>
 * Returns true.
 * <p>
 * imap_delete() function marks message pointed by msg_number for deletion.
 * Actual deletion of the messages is done by {@link imap_expunge()}.
 */
function int imap_delete(int imap_stream, int msg_number);
 
/**
 * Delete a mailbox
 * <p>
 * imap_deletemailbox() deletes the specified mailbox.
 * <p>
 * Returns true on success and false on error.
 */
function int imap_deletemailbox(int imap_stream, string mbox);
 
/**
 * Delete all messages marked for deletion
 * <p>
 * imap_expunge() deletes all the messages marked for deletion by
 * {@link imap_delete()}.
 * <p>
 * Returns true.
 */
function int imap_expunge(int imap_stream);
 
/**
 * Fetch a particular section of the body of the message
 * <p>
 * This function causes a fetch of a particular section of the body of the
 * specified messages as a text string and returns that text string. The
 * section specification is a string of integers delimited by period which
 * index into a body part list as per the IMAP4 specification. Body parts are
 * not decoded by this function.
 * <p>
 * The options for imap_fetchbody ()e a bitmask with one or more of the
 * following
 * <ul>
 * <li> FT_UID - The msgono is a UID
 * <li> FT_PEEK - Do not set the \Seen flag if not already set
 * <li> FT_UID - The return string is in "internal" format, without any
 *      attempt to canonicalize CRLF
 * </ul>
 */
function string imap_fetchbody(int imap_stream, int msg_number, string part_number, flags flags);
 
/**
 * Read the structure of a particular message
 * <p>
 * This function causes a fetch of all the structured information for the
 * given msg_number. The returned value is an object with following elements.
 * <p>
 *  type, encoding, ifsubtype, subtype, ifdescription, description, ifid,
 *  id, lines, bytes, ifparameters
 * <p>
 * It also returns an array of objects called parameters[]. This object has
 * following properties.
 * <pre>
 *    attribute, value
 * </pre>
 * In case of multipart, it also returns an array of objects of all the
 * properties, called parts[].
 */
function array imap_fetchstructure(int imap_stream, int msg_number);
 
/**
 * Read the header of the message
 * <p>
 * This function returns an object of various header elements
 * <pre>
 *    remail,date,Date,subject,Subject,in_reply_to,
 *    message_id,newsgroups,followup_to,references
 * <p>
 * message flags:
 * <ul>
 * <li>Recent - 'R' if recent and seen, 'N' if recent and not seen, ' ' if not recent
 * <li>Unseen - 'U' if not seen AND not recent, ' ' if seen OR not seen and recent
 * <li>Answered - 'A' if answered, ' ' if unanswered
 * <li>Deleted - 'D' if deleted, ' ' if not deleted
 * <li>Draft - 'X' if draft, ' ' if not draft
 * <li>Flagged - 'F' if flagged, ' ' if not flagged
 * </ul>
 * Note that the Recent/Unseen behavior is a little odd. If you want to know if a message is Unseen, you must check for
 * Unseen == 'U' || Recent == 'N'
 * <p>
 * toaddress (full to: line, up to 1024 characters)
 * <p>
 * to[] (returns an array of objects from the To line, containing:)
 * <ul>
 * <li>personal
 * <li>adl
 * <li>mailbox
 * <li>host
 * </ul>
 * fromaddress (full from: line, up to 1024 characters)
 * <p>
 * from[] (returns an array of objects from the From line, containing:)
 * <ul>
 * <li>personal
 * <li>adl
 * <li>mailbox
 * <li>host
 * </ul>
 * ccaddress (full cc: line, up to 1024 characters)
 * cc[] (returns an array of objects from the Cc line, containing:)
 * <ul>
 * <li>personal
 * <li>adl
 * <li>mailbox
 * <li>host
 * </ul>
 * bccaddress (full bcc line, up to 1024 characters)
 * bcc[] (returns an array of objects from the Bcc line, containing:)
 * <ul>
 * <li>personal
 * <li>adl
 * <li>mailbox
 * <li>host
 * </ul>
 * reply_toaddress (full reply_to: line, up to 1024 characters)
 * reply_to[] (returns an array of objects from the Reply_to line, containing:)
 * <ul>
 * <li>personal
 * <li>adl
 * <li>mailbox
 * <li>host
 * </ul>
 * senderaddress (full sender: line, up to 1024 characters)
 * sender[] (returns an array of objects from the sender line, containing:)
 * <ul>
 * <li>personal
 * <li>adl
 * <li>mailbox
 * <li>host
 * </ul>
 * return_path (full return-path: line, up to 1024 characters)
 * return_path[] (returns an array of objects from the return_path line, containing:)
 * <ul>
 * <li>personal
 * <li>adl
 * <li>mailbox
 * <li>host
 * </ul>
 * udate ( mail message date in unix time)
 * <p>
 * fetchfrom (from line formatted to fit fromlength characters)
 * fetchsubject (subject line formatted to fit subjectlength characters)
 */
function object imap_header(int imap_stream, int msg_number, int fromlength, int subjectlength, int defaulthost);
 
/**
 * Returns headers for all messages in a mailbox
 * <p>
 * Returns an array of string formatted with header info. One element per mail
 * message.
 */
function array imap_headers(int imap_stream);
 
/**
 * Read the list of mailboxes
 * <p>
 * Returns an array containing the names of the mailboxes.
 */
function array imap_listmailbox(int imap_stream, string ref, string pat);
 
/**
 * each one
 * <p>
 * Returns an array of objects containing mailbox information. Each object has
 * the attributes name, specifying the full name of the mailbox; delimiter,
 * which is the hierarchy delimiter for the part of the hierarchy this mailbox
 * is in; and attributes. Attributes is a bitmask that can be tested against:
 * <ul>
 * <li> LATT_NOINFERIORS - This mailbox has no "children" (there are no
 *      mailboxes below this one)
 * <li> LATT_NOSELECT - This is only a container, not a mailbox - you cannot
 *      open it.
 * <li> LATT_MARKED - This mailbox is marked. Only used by UW-IMAPD.
 * <li> LATT_UNMARKED - This mailbox is not marked. Only used by UW-IMAPD.
 * </ul>
 * ref should normally be just the IMAP server, in the form:
 * {imap_server:imap_port}, and pattern specifies where in the mailbox
 * hierarchy to start searching. If you want all mailboxes, pass pattern as an
 * empty string.
 * <p>
 * There are two special characters you can pass as part of the pattern: '*'
 * and '%'. '*' means to return all mailboxes. If you pass pattern as '*', you
 * will get a list of the entire mailbox hierarchy. '%' means to return the
 * current level only. '%' as the pattern parameter will return only the top
 * level mailboxes; '~/mail/%' on UW_IMAPD will return every mailbox in the
 * ~/mail directory, but none in subfolders of that directory.
 */
function array imap_getmailboxes(int imap_stream, string ref, string pat);
 
/**
 * List all the subscribed mailboxes
 * <p>
 * Returns an array of all the mailboxes that you have subscribed. The ref and
 * pattern arguments specify the base location to search from and the pattern
 * the mailbox name must match.
 */
function array imap_listsubscribed(int imap_stream, string ref, string pattern);
 
/**
 * List all the subscribed mailboxes
 * <p>
 * This function is identical to imap_getmailboxes(), except that it only
 * returns mailboxes that the user is subscribed to.
 */
function array imap_getsubscribed(int imap_stream, string ref, string pattern);
 
/**
 * Copy specified messages to a mailbox
 * <p>
 * Returns true on success and false on error.
 * <p>
 * Copies mail messages specified by msglist to specified mailbox. msglist is
 * a range not just message numbers.
 * <p>
 * flags is a bitmask of one or more of
 * <ul>
 * <li> CP_UID - the sequence numbers contain UIDS
 * <li> CP_MOVE - Delete the messages from the current mailbox after copying
 * </ul>
 */
function int imap_mail_copy(int imap_stream, string msglist, string mbox, int flags);
 
/**
 * Move specified messages to a mailbox
 * <p>
 * Moves mail messages specified by msglist to specified mailbox. msglist is a
 * range not just message numbers.
 * <p>
 * Returns true on success and false on error.
 */
function int imap_mail_move(int imap_stream, string msglist, string mbox);
 
/**
 * Gives the number of messages in the current mailbox
 * <p>
 * Return the number of messages in the current mailbox.
 */
function int imap_num_msg(int stream_id);
 
/**
 * Gives the number of recent messages in current mailbox
 * <p>
 * Returns the number of recent messages in the current mailbox.
 */
function int imap_num_recent(int imap_stream);
 
/**
 * Open an IMAP stream to a mailbox
 * <p>
 * Returns an IMAP stream on success and false on error. This function can
 * also be used to open streams to POP3 and NNTP servers. To connect to an
 * IMAP server running on port 143 on the local machine, do the following:
 * <pre>
 *    $mbox = imap_open("{localhost:143}INBOX","user_id","password");
 * </pre>
 * To connect to a POP3 server on port 110 on the local server, use:
 * <pre>
 *    $mbox = imap_open("{localhost/pop3:110}INBOX","user_id","password");
 * </pre>
 * To connect to an NNTP server on port 119 on the local server, use:
 * <pre>
 *    $nntp = imap_open("{localhost/nntp:119}comp.test","","");
 * </pre>
 * To connect to a remote server replace "localhost" with the name or the IP
 * address of the server you want to connect to.
 * <p>
 * The options are a bit mask with one or more of the following:
 * <ul>
 * <li> OP_READONLY - Open mailbox read-only
 * <li> OP_ANONYMOUS - Dont use or update a .newsrc for news
 * <li> OP_HALFOPEN - For IMAP and NNTP names, open a connection but dont open
 *      a mailbox
 * <li> CL_EXPUNGE - Expunge mailbox automatically upon mailbox close
 * </ul>
 */
function int imap_open(string mailbox, string username, string password, int flags);
 
/**
 * Check if the IMAP stream is still active
 * <p>
 * Returns true if the stream is still alive, false otherwise.
 * <p>
 * imap_ping() function pings the stream to see it is still active. It may
 * discover new mail; this is the preferred method for a periodic "new mail
 * check" as well as a "keep alive" for servers which have inactivity timeout.
 */
function int imap_ping(int imap_stream);
 
/**
 * Rename an old mailbox to new mailbox
 * <p>
 * This function renames on old mailbox to new mailbox.
 * <p>
 * Returns true on success and false on error.
 */
function int imap_renamemailbox(int imap_stream, string old_mbox, string new_mbox);
 
/**
 * Reopen IMAP stream to new mailbox
 * <p>
 * Returns true on success and false on error.
 * <p>
 * This function reopens the specified stream to new mailbox.
 * <p>
 * The options are a bit mask with one or more of the following:
 * <ul>
 * <li> OP_READONLY - Open mailbox read-only
 * <li> OP_ANONYMOUS - Dont use or update a .newsrc for news
 * <li> OP_HALFOPEN - For IMAP and NNTP names, open a connection but dont open
 *      a mailbox
 * <li> CL_EXPUNGE - Expunge mailbox automatically upon mailbox close
 * </ul>
 */
function int imap_reopen(string imap_stream, string mailbox, string [flags]);
 
/**
 * Subscribe to a new mailbox.
 * <p>
 * Returns true on success and false on error.
 */
function int imap_subscribe(int imap_stream, string mbox);
 
/**
 * Unmark the message which is marked deleted
 * <p>
 * This function removes the deletion flag for a specified message, which is
 * set by {@link imap_delete()}.
 * <p>
 * Returns true on success and false on error.
 */
function int imap_undelete(int imap_stream, int msg_number);
 
/**
 * Unsubscribe from a specified mailbox.
 * <p>
 * Returns true on success and false on error.
 */
function int imap_unsubscribe(int imap_stream, string mbox);
 
/**
 * Convert a quoted-printable string to an 8 bit string
 * <p>
 * Returns an 8 bit (binary) string
 */
function string imap_qprint(string string);
 
/**
 * Convert an 8bit string to a quoted-printable string.
 * <p>
 * Returns a quoted-printable string
 */
function string imap_8bit(string string);
 
/**
 * Convert an 8bit string to a base64 string.
 * <p>
 * Returns a base64 string
 * 
 */
function string imap_binary(string string);
 
/**
 * the text of the mailbox
 * <p>
 * Returns an array containing the names of the mailboxes that have string in
 * the text of the mailbox.
 */
function array imap_scanmailbox(int imap_stream, string string);
 
/**
 * Get information about the current mailbox
 * <p>
 * Returns information about the current mailbox. Returns FALSE on failure.
 * <p>
 * The imap_mailboxmsginfo() function checks the current mailbox status on the
 * server and returns the information in an object with following properties.
 * <ul>
 * <li>Date : date of the message
 * <li>Driver : driver
 * <li>Mailbox : name of the mailbox
 * <li>Nmsgs : number of messages
 * <li>Recent : number of recent messages
 * <li>Unread : number of unread messages
 * <li>Size : mailbox size
 * </ul>
 */
function array imap_mailboxmsginfo(int imap_stream);
 
/**
 * mailbox, host, and personal info.
 * <p>
 * Returns a properly formatted email address given the mailbox, host, and
 * personal info.
 */
function string imap_rfc822_write_address(string mailbox, string host, string personal);
 
/**
 * Parses an address string
 * <p>
 * This function parses the address tring and for each address, returns an
 * array of objects. The 4 objects are:
 * <ul>
 * <li>mailbox - the mailbox name (username)
 * <li>host   - the host name
 * <li>personal - the personal name
 * <li>adl - at domain source route
 * </ul>
 */
function string imap_rfc822_parse_adrlist(string address, string default_host);
 
/**
 * Sets flags on messages
 * <p>
 * This function causes a store to add the specified flag to the flags set for
 * the messages in the specified sequence.
 * <p>
 * The options are a bit mask with one or more of the following:
 * <ul>
 * <li>ST_UID  The sequence argument contains UIDs instead of sequence numbers
 * </ul>
 */
function string imap_setflag_full(int stream, string sequence, string flag, string options);
 
/**
 * Clears flags on messages
 * <p>
 * This function causes a store to delete the specified flag to the flags set
 * for the messages in the specified sequence.
 * <p>
 * The options are a bit mask with one or more of the following:
 * <ul>
 * <li>ST_UID  The sequence argument contains UIDs instead of sequence numbers
 * </ul>
 */
function string imap_clearflag_full(int stream, string sequence, string flag, string options);
 
/**
 * Returns an array of message numbers sorted by the given parameters
 * <p>
 * Rev is 1 for reverse-sorting.
 * <p>
 * Criteria can be one (and only one) of the following:
 * <ul>
 * <li>SORTDATE      -  message Date
 * <li>SORTARRIVAL   -  arrival date
 * <li>SORTFROM      -  mailbox in first From address
 * <li>SORTSUBJECT   -  message Subject
 * <li>SORTTO        -  mailbox in first To address
 * <li>SORTCC        -  mailbox in first cc address
 * <li>SORTSIZE      -  size of message in octets
 * </ul>
 * The flags are a bitmask of one or more of the following:
 * <ul>
 * <li>SE_UID        -  Return UIDs instead of sequence numbers
 * <li>SE_NOPREFETCH -  Don't prefetch searched messages.
 * </ul>
 */
function string imap_sort(int stream, int criteria, int reverse, int options);
 
/**
 * Returns header for a message
 * <p>
 * This function causes a fetch of the complete, unfiltered RFC 822 format
 * header of the specified message as a text string and returns that text
 * string.
 * <p>
 * The options are:
 * <ul>
 * <li>FT_UID          - The msgno argument is a UID
 * <li>FT_INTERNAL     - The return string is in "internal" format,
 *                       without any attempt to canonicalize to CRLF
 *                       newlines
 * <li>FT_PREFETCHTEXT - The RFC822.TEXT should be pre-fetched at the
 *                       same time.  This avoids an extra RTT on an
 *                       IMAP connection if a full message text is
 *                       desired (e.g. in a "save to local file"
 *                       operation)
 * </ul>
 */
function stringimap_fetchheader(int imap_stream, int msgno, int flags);
 
/**
 * This function returns the UID for the given message sequence number. It is
 * the inverse of {@link imap_msgno()}.
 */
function int imap_uid(int imap_stream, int msgno);
 
/**
 * This function returns the message sequence number for the given UID. It is
 * the inverse of {@link imap_uid()}.
 */
function int imap_msgno(int imap_stream, int uid);
 
/**
 * This function performs a search on the mailbox currently opened in the
 * given imap stream. criteria is a string, delimited by spaces, in which the
 * following keywords are allowed. Any multi-word arguments (eg FROM "joe
 * smith") must be quoted.
 * <ul>
 * <li> ALL - return all messages matching the rest of the criteria
 * <li> ANSWERED - match messages with the \\ANSWERED flag set
 * <li> BCC "string" - match messages with "string" in the Bcc: field
 * <li> BEFORE "date" - match messages with Date: before "date"
 * <li> BODY "string" - match messages with "string" in the body of the
 *      message
 * <li> CC "string" - match messages with "string" in the Cc: field
 * <li> DELETED - match deleted messages
 * <li> FLAGGED - match messages with the \\FLAGGED (sometimes referred to as
 *      Important or Urgent) flag set
 * <li> FROM "string" - match messages with "string" in the From: field
 * <li> KEYWORD "string" - match messages with "string" as a keyword
 * <li> NEW - match new messages
 * <li> OLD - match old messages
 * <li> ON "date" - match messages with Date: matching "date"
 * <li> RECENT - match messages with the \\RECENT flag set
 * <li> SEEN - match messages that have been read (the \\SEEN flag is set)
 * <li> SINCE "date" - match messages with Date: after "date"
 * <li> SUBJECT "string" - match messages with "string" in the Subject:
 * <li> TEXT "string" - match messages with text "string"
 * <li> TO "string" - match messages with "string" in the To:
 * <li> UNANSWERED - match messages that have not been answered
 * <li> UNDELETED - match messages that are not deleted
 * <li> UNFLAGGED - match messages that are not flagged
 * <li> UNKEYWORD "string" - match messages that do not have the keyword "string"
 * <li> UNSEEN - match messages which have not been read yet
 * </ul>
 * For example, to match all unanswered messages sent by Mom, you'd use:
 * "UNANSWERED FROM mom". Searches appear to be case insensitive. This list of
 * criteria is from a reading of the UW c-client source code and may be
 * uncomplete or inaccurate. Searcher beware.
 * <p>
 * Valid values for flags are SE_UID, which causes the returned array to
 * contain UIDs instead of messages sequence numbers.
 */
function array imap_search(int imap_stream, string criteria, int flags);
 
/**
 * This function returns the full text of the last IMAP error message that
 * occurred on the current page. The error stack is untouched; calling
 * {@link imap_last_error()} subsequently, with no intervening errors, will return the
 * same error.
 */
function string imap_last_error(void );
 
/**
 * This function returns an array of all of the IMAP error messages generated
 * since the last {@link imap_errors()} call, or the beginning of the page. When
 * imap_errors() is called, the error stack is subsequently cleared.
 */
function array imap_errors(void );
 
/**
 * This function returns an array of all of the IMAP alert messages generated
 * since the last imap_alerts() call, or the beginning of the page. When
 * imap_alerts() is called, the alert stack is subsequently cleared. The IMAP
 * specification requires that these messages be passed to the user.
 */
function array imap_alerts(void );
 
/**
 * This function returns an object containing status information. Valid flags
 * are:
 * <ul>
 * <li> SA_MESSAGES - set status-&gt;messages to the number of messages in the
 *      mailbox
 * <li> SA_RECENT - set status-&gt;recent to the number of recent messages in the
 *      mailbox
 * <li> SA_UNSEEN - set status-&gt;unseen to the number of unseen (new) messages
 *      in the mailbox
 * <li> SA_UIDNEXT - set status-&gt;uidnext to the next uid to be used in the
 *      mailbox
 * <li> SA_UIDVALIDITY - set status-&gt;uidvalidity to a constant that changes
 *      when uids for the mailbox may no longer be valid
 * <li> SA_ALL - set all of the above
 * </ul>
 * status-&gt;flags is also set, which contains a bitmask which can be checked
 * against any of the above constants.
 */
function object imap_status(int imap_stream, string mailbox, int options);

///////////////////////////////////////////////////////////////////////////
// PHP options & information
//

/**
 * send an error message somewhere
 * <p>
 * Sends an error message to the web server's error log, a TCP port or to a
 * file. The first parameter, message, is the error message that should be
 * logged. The second parameter, message_type says where the message should
 * go:
 * <p>
 * Table 1. error_log() log types
 * <ul>
 * <li>0 - message is sent to PHP's system logger, using the Operating System's
 *   system logging mechanism or a file, depending on what the error_log
 *   configuration directive is set to.
 * <li>1 - message is sent by email to the address in the destination parameter.
 *   This is the only message type where the fourth parameter, extra_headers
 *   is used. This message type uses the same internal function as {@link Mail()}
 *   does.
 * <li>2 - message is sent through the PHP debugging connection. This option is
 *   only available if remote debugging has been enabled. In this case, the
 *   destination parameter specifies the host name or IP address and
 *   optionally, port number, of the socket receiving the debug information.
 * <li>3 - message is appended to the file destination.
 * </ul>
 * <b>Example 1.</b> error_log() examples
 * <pre>
 *    // Send notification through the server log if we can not
 *    // connect to the database.
 *    if (!Ora_Logon($username, $password)) {
 *        error_log("Oracle database not available!", 0);
 *    }
 *    // Notify administrator by email if we run out of FOO
 *    if (!($foo = allocate_new_foo()) {
 *        error_log("Big trouble, we're all out of FOOs!", 1,
 *                  "operator@mydomain.com");
 *    }
 * 
 *    // other ways of calling error_log():
 *    error_log("You messed up!", 2, "127.0.0.1:7000");
 *    error_log("You messed up!", 2, "loghost");
 *    error_log("You messed up!", 3, "/var/tmp/my-errors.log");
 * </pre>
 */
function int error_log(string message, int message_type, string [destination], string [extra_headers]);
 
/**
 * set which PHP errors are reported
 * <p>
 * Sets PHP's error reporting level and returns the old level. The error
 * reporting level is a bitmask of the following values (follow the links for
 * the internal values to get their meanings):
 * <p>
 * Table 1. error_reporting() bit values
 * <ul>
 * <li> 1   - E_ERROR
 * <li> 2   - E_WARNING
 * <li> 4   - E_PARSE
 * <li> 8   - E_NOTICE
 * <li> 16  - E_CORE_ERROR
 * <li> 32  - E_CORE_WARNING
 * </ul>
 */
function int error_reporting(int [level]);
 
/**
 * Get the value of an environment variable
 * <p>
 * Returns the value of the environment variable varname, or false on an
 * error.
 * <pre>
 *    $ip = getenv("REMOTE_ADDR"); // get the ip number of the user
 * </pre>
 * You can see a list of all the environmental variables by using {@link phpinfo()}.
 * You can find out what many of them mean by taking a look at the CGI
 * specification, specifically the page on environmental variables.
 */
function string getenv(string varname);
 
/**
 * Get the value of a PHP configuration option.
 * <p>
 * Returns the current value of the PHP configuration variable specified by
 * varname, or false if an error occurs.
 * <p>
 * It will not return configuration information set when the PHP was compiled,
 * or read from an Apache configuration file (using the
 * php3_configuration_option directives).
 * <p>
 * To check whether the system is using a configuration file, try retrieving
 * the value of the cfg_file_path configuration setting. If this is available,
 * a configuration file is being used.
 */
function string get_cfg_var(string varname);
 
/**
 * Get the name of the owner of the current PHP script.
 * <p>
 * Returns the name of the owner of the current PHP script.
 * 
 * @see getmyuid()
 * @see getmypid()
 * @see getmyinode()
 * @see getlastmod()
 */
function string get_current_user(void);
 
/**
 * Returns the current active configuration setting of magic_quotes_gpc. (0
 * for off, 1 for on)
 * 
 * @see get_magic_quotes_runtime()
 * @see set_magic_quotes_runtime()
 */
function long get_magic_quotes_gpc(void);
 
/**
 * Returns the current active configuration setting of magic_quotes_runtime.
 * (0 for off, 1 for on)
 * 
 * @see get_magic_quotes_gpc()
 * @see set_magic_quotes_runtime()
 */
function long get_magic_quotes_runtime(void);
 
/**
 * Get time of last page modification.
 * <p>
 * Returns the time of the last modification of the current page. The value
 * returned is a Unix timestamp, suitable for feeding to {@link date()}. Returns false
 * on error.
 * <b>Example 1.</b> getlastmod() example
 * <pre>
 *    // outputs e.g. 'Last modified: March 04 1998 20:43:59.'
 *    echo "Last modified: ".date( "F d Y H:i:s.", getlastmod() );
 * </pre>
 *
 * @see date()
 * @see getmyuid()
 * @see get_current_user()
 * @see getmyinode()
 * @see getmypid()
 */
function int getlastmod(void);
 
/**
 * Get the inode of the current script.
 * <p>
 * Returns the current script's inode, or false on error.
 * 
 * @see getmyuid()
 * @see get_current_user()
 * @see getmypid()
 * @see getlastmod()
 */
function int getmyinode(void);
 
/**
 * Get PHP's process ID.
 * <p>
 * Returns the current PHP process ID, or false on error.
 * <p>
 * Note that when running as a server module, separate invocations of the
 * script are not guaranteed to have distinct pids.
 * 
 * @see getmyuid()
 * @see get_current_user()
 * @see getmyinode()
 * @see getlastmod()
 */
function int getmypid(void);
 
/**
 * Get PHP script owner's UID.
 * <p>
 * Returns the user ID of the current script, or false on error.
 * 
 * @see getmypid()
 * @see get_current_user()
 * @see getmyinode()
 * @see getlastmod()
 */
function int getmyuid(void);
 
/**
 * Get the current resource usages.
 * <p>
 * This is an interface to getrusage(2). It returns an associative array
 * containing the data returned from the system call. If who is 1, getrusage
 * will be called with RUSAGE_CHILDREN. All entries are accessible by using
 * their documented field names.
 * <p>
 * <b>Example 1.</b> Getrusage Example
 * <pre>
 *    $dat = getrusage();
 *    echo $dat["ru_nswap"];         # number of swaps
 *    echo $dat["ru_majflt"];        # number of page faults
 *    echo $dat["ru_utime.tv_sec"];  # user time used (seconds)
 *    echo $dat["ru_utime.tv_usec"]; # user time used (microseconds)
 * </pre>
 * See your system's man page for more details.
 */
function array getrusage(int [who]);
 
/**
 * Output lots of PHP information.
 * <p>
 * Outputs a large amount of information about the current state of PHP. This
 * includes information about PHP compilation options and extensions, the PHP
 * version, server information and environment (if compiled as a module), the
 * PHP environment, OS version information, paths, master and local values of
 * configuration options, HTTP headers, and the GNU Public License.
 * 
 * @see phpversion()
 */
function int phpinfo(void);
 
/**
 * Get the current PHP version.
 * <p>
 * Returns a string containing the version of the currently running PHP
 * parser.
 * <p>
 * <b>Example 1.</b> phpversion() example
 * <pre>
 *    // prints e.g. 'Current PHP version: 3.0rel-dev'
 *    echo "Current PHP version: ".phpversion();
 * </pre>
 *
 * @see phpinfo()
 */
function string phpversion(void);
 
/**
 * find out whether an extension is loaded
 * <p>
 * Returns true if the extension identified by name is loaded. You can see the
 * names of various extensions by using {@link phpinfo()}.
 * 
 * @see phpinfo()
 * @since This function was added in 3.0.10.
 */
function bool extension_loaded(string name);
 
/**
 * Set the value of an environment variable.
 * <p>
 * Adds setting to the environment.
 * <p>
 * <b>Example 1.</b> Setting an Environment Variable
 * <pre>
 *    putenv("UNIQID=$uniqid");
 * </pre>
 */
function void putenv(string setting);
 
/**
 * Set the current active configuration setting of magic_quotes_runtime. (0
 * for off, 1 for on)
 * 
 * @see get_magic_quotes_gpc()
 * @see get_magic_quotes_runtime()
 */
function long set_magic_quotes_runtime(int new_setting);
 
/**
 * limit the maximum execution time
 * <p>
 * Set the number of seconds a script is allowed to run. If this is reached,
 * the script returns a fatal error. The default limit is 30 seconds or, if it
 * exists, the max_execution_time value defined in the configuration file. If
 * seconds is set to zero, no time limit is imposed.
 * <p>
 * When called, set_time_limit() restarts the timeout counter from zero. In
 * other words, if the timeout is the default 30 seconds, and 25 seconds into
 * script execution a call such as set_time_limit(20) is made, the script will
 * run for a total of 45 seconds before timing out.
 */
function void set_time_limit(int seconds);


///////////////////////////////////////////////////////////////////////////
// Informix functions
//
// The Informix driver for Online (ODS) 7.x, SE 7.x and Universal Server (IUS)
// 9.x is implemented in "functions/ifx.ec" and "functions/php3_ifx.h". ODS
// 7.x support is fairly complete, with full support for BYTE and TEXT
// columns. IUS 9.x support is partly finished: the new data types are there,
// but SLOB and CLOB support is still under construction.
// 
//      Configuration notes:
// 
//      Before you run the "configure" script, make sure that the
//      "INFORMIXDIR" variable has been set.
// 
//      The configure script will autodetect the libraries and include
//      directories, if you run "configure --with_informix=yes". You can
//      overide this detection by specifying "IFX_LIBDIR", "IFX_LIBS" and
//      "IFX_INCDIR" in the environment. The configure script will also
//      try to detect your Informix server version. It will set the
//      "HAVE_IFX_IUS" conditional compilation variable if your Informix
//      version >= 9.00.
// 
//      Some notes on the use of BLOBs (TEXT and BYTE columns):
// 
//      BLOBs are normally addressed by integer BLOB identifiers. Select
//      queries return a "blob id" for every BYTE and TEXT column. You
//      can get at the contents with "string_var =
//      ifx_get_blob($blob_id);" if you choose to get the BLOBs in memory
//      (with : "ifx_blobinfile(0);"). If you prefer to receive the
//      content of BLOB columns in a file, use "ifx_blobinfile(1);", and
//      "ifx_get_blob($blob_id);" will get you the filename. Use normal
//      file I/O to get at the blob contents.
// 
//      For insert/update queries you must create these "blob id's"
//      yourself with "ifx_create_blob(..);". You then plug the blob id's
//      into an array, and replace the blob columns with a question mark
//      (?) in the query string. For updates/inserts, you are responsible
//      for setting the blob contents with ifx_update_blob(...).
// 
//      The behaviour of BLOB columns can be altered by configuration
//      variables that also can be set at runtime :
// 
//      configuration variable : ifx.textasvarchar
// 
//      configuration variable : ifx.byteasvarchar
// 
//      runtime functions :
// 
//      ifx_textasvarchar(0) : use blob id's for select queries with TEXT
//      columns
// 
//      ifx_byteasvarchar(0) : use blob id's for select queries with BYTE
//      columns
// 
//      ifx_textasvarchar(1) : return TEXT columns as if they were
//      VARCHAR columns, without the use of blob id's for select queries.
// 
//      ifx_byteasvarchar(1) : return BYTE columns as if they were
//      VARCHAR columns, without the use of blob id's for select queries.
// 
//      configuration variable : ifx.blobinfile
// 
//      runtime function :
// 
//      ifx_blobinfile_mode(0) : return BYTE columns in memory, the blob
//      id lets you get at the contents.
// 
//      ifx_blobinfile_mode(1) : return BYTE columns in a file, the blob
//      id lets you get at the file name.
// 
//      If you set ifx_text/byteasvarchar to 1, you can use TEXT and BYTE
//      columns in select queries just like normal (but rather long)
//      VARCHAR fields. Since all strings are "counted" in PHP, this
//      remains "binary safe". It is up to you to handle this correctly.
//      The returned data can contain anything, you are responsible for
//      the contents.
// 
//      If you set ifx_blobinfile to 1, use the file name returned by
//      ifx_get_blob(..) to get at the blob contents. Note that in this
//      case YOU ARE RESPONSIBLE FOR DELETING THE TEMPORARY FILES CREATED
//      BY INFORMIX when fetching the row. Every new row fetched will
//      create new temporary files for every BYTE column.
// 
//      The location of the temporary files can be influenced by the
//      environment variable "blobdir", default is "." (the current
//      directory). Something like : putenv(blobdir=tmpblob"); will ease
//      the cleaning up of temp files accidentally left behind (their
//      names all start with "blb").
// 
//      Automatically trimming "char" (SQLCHAR and SQLNCHAR) data:
// 
//      This can be set with the configuration variable
// 
//      ifx.charasvarchar : if set to 1 trailing spaces will be
//      automatically trimmed.
// 
//      NULL values:
// 
//      The configuration variable ifx.nullformat (and the runtime
//      function ifx_nullformat()) when set to true will return NULL
//      columns as the string "NULL", when set to false they return the
//      empty string. This allows you to discriminate between NULL
//      columns and empty columns.
//  

/**
 * Open Informix server connection
 * <p>
 * Returns an connection identifier on success, or FALSE on error.
 * <p>
 * ifx_connect() establishes a connection to an Informix server. All of the
 * arguments are optional, and if they're missing, defaults are taken from
 * values supplied in configuration file (ifx.default_host for the host
 * (Informix libraries will use INFORMIXSERVER environment value if not
 * defined), ifx.default_user for user, ifx.default_password for the password
 * (none if not defined).
 * <p>
 * In case a second call is made to ifx_connect() with the same arguments, no
 * new link will be established, but instead, the link identifier of the
 * already opened link will be returned.
 * <p>
 * The link to the server will be closed as soon as the execution of the
 * script ends, unless it's closed earlier by explicitly calling {@link ifx_close()}.
 * <p>
 * <b>Example 1.</b> Connect to a Informix database
 * <pre>
 *    $conn_id = ifx_pconnect (mydb@ol_srv1, "imyself", "mypassword");
 * </pre>
 *
 * @see ifx_pconnect()
 * @see ifx_close()
 */
function int ifx_connect(string [database] , string [userid] , string [password] );
 
/**
 * Open persistent Informix connection
 * <p>
 * Returns: A positive Informix persistent link identifier on success, or
 * false on error
 * <p>
 * ifx_pconnect() acts very much like ifx_connect() with two major
 * differences.
 * <p>
 * This function behaves exactly like ifx_connect() when PHP is not running as
 * an Apache module. First, when connecting, the function would first try to
 * find a (persistent) link that's already open with the same host, username
 * and password. If one is found, an identifier for it will be returned
 * instead of opening a new connection.
 * <p>
 * Second, the connection to the SQL server will not be closed when the
 * execution of the script ends. Instead, the link will remain open for future
 * use (ifx_close() will not close links established by ifx_pconnect()).
 * <p>
 * This type of links is therefore called 'persistent'.
 * 
 * @see ifx_connect()
 */
function int ifx_pconnect(string [database] , string [userid] , string [password] );
 
/**
 * Close Informix connection
 * <p>
 * Returns: always true.
 * <p>
 * ifx_close() closes the link to an Informix database that's associated with
 * the specified link identifier. If the link identifier isn't specified, the
 * last opened link is assumed.
 * <p>
 * Note that this isn't usually necessary, as non-persistent open links are
 * automatically closed at the end of the script's execution.
 * <p>
 * ifx_close() will not close persistent links generated by {@link ifx_pconnect()}.
 * <p>
 * <b>Example 1.</b> Closing a Informix connection
 * <pre>
 *    $conn_id = ifx_connect (mydb@ol_srv, "itsme", "mypassword");
 *    ... some queries and stuff ...
 *    ifx_close($conn_id);
 * </pre>
 *
 * @see ifx_connect()
 * @see ifx_pconnect()
 */
function int ifx_close(int [link_identifier] );
 
/**
 * Send Informix query
 * <p>
 * Returns: A positive Informix result identifier on success, or false on
 * error.
 * <p>
 * An integer "result_id" used by other functions to retrieve the query
 * results. Sets "affected_rows" for retrieval by the ifx_affected_rows()
 * function.
 * <p>
 * ifx_query() sends a query to the currently active database on the server
 * that's associated with the specified link identifier. If the link
 * identifier isn't specified, the last opened link is assumed. If no link is
 * open, the function tries to establish a link as if {@link ifx_connect()} was
 * called, and use it.
 * <p>
 * Executes query on connection conn_id. For "select-type" queries a cursor is
 * declared and opened. The optional cursor_type parameter allows you to make
 * this a "scroll" and/or "hold" cursor. It's a mask and can be either
 * IFX_SCROLL, IFX_HOLD, or both or'ed together. Non-select queries are
 * "execute immediate".
 * <p>
 * For either query type the number of (estimated or real) affected rows is
 * saved for retrieval by {@link ifx_affected_rows()}.
 * <p>
 * If you have BLOB (BYTE or TEXT) columns in an update query, you can add a
 * blobidarray parameter containing the corresponding "blob ids", and you
 * should replace those columns with a "?" in the query text.
 * <p>
 * If the contents of the TEXT (or BYTE) column allow it, you can also use
 * "ifx_textasvarchar(1)" and "ifx_byteasvarchar(1)". This allows you to treat
 * TEXT (or BYTE) columns just as if they were ordinary (but long) VARCHAR
 * columns for select queries, and you don't need to bother with blob id's.
 * <p>
 * With ifx_textasvarchar(0) or ifx_byteasvarchar(0) (the default situation),
 * select queries will return BLOB columns as blob id's (integer value). You
 * can get the value of the blob as a string or file with the blob functions
 * (see below).
 * <p>
 * <b>Example 1.</b> Show all rows of the "orders" table as a html table
 * <pre>
 *    ifx_textasvarchar(1);      // use "text mode" for blobs
 *    $res_id = ifx_query("select * from orders", $conn_id);
 *    if (! $res_id) {
 *        printf("Can't select orders : %s\n&lt;br&gt;%s&lt;br&gt;\n", ifx_error());
 *        ifx_errormsg();
 *        die;
 *    }
 *    ifx_htmltbl_result($res_id, "border=\"1\"");
 *    ifx_free_result($res_id);
 * </pre>
 * <b>Example 2.</b> Insert some values into the "catalog" table
 * <pre>
 *    // create blob id's for a byte and text column
 *    $textid = ifx_create_blob(0, 0, "Text column in memory");
 *    $byteid = ifx_create_blob(1, 0, "Byte column in memory");
 *                          // store blob id's in a blobid array
 *    $blobidarray[] = $textid;
 *    $blobidarray[] = $byteid;
 *    // launch query
 *    $query = "insert into catalog (stock_num, manu_code, " .
 *             "cat_descr,cat_picture) values(1,'HRO',?,?)";
 *    $res_id = ifx_query($query, $conn_id, $blobidarray);
 *    if (! $res_id) {
 *      ... error ...
 *    }
 *    // free result id
 *    ifx_free_result($res_id);
 * </pre>
 *
 * @see ifx_connect()
 */
function int ifx_query(string query, int [link_identifier] , int [cursor_type] , mixed [blobidarray] );
 
/**
 * Prepare an SQL-statement for execution
 * <p>
 * Returns a integer result_id for use by ifx_do(). Sets affected_rows for
 * retrieval by the {@link ifx_affected_rows()} function.
 * <p>
 * Prepares query on connection conn_id. For "select-type" queries a cursor is
 * declared and opened. The optional cursor_type parameter allows you to make
 * this a "scroll" and/or "hold" cursor. It's a mask and can be either
 * IFX_SCROLL, IFX_HOLD, or both or'ed together.
 * <p>
 * For either query type the estimated number of affected rows is saved for
 * retrieval by {@link ifx_affected_rows()}.
 * <p>
 * If you have BLOB (BYTE or TEXT) columns in the query, you can add a
 * blobidarray parameter containing the corresponding "blob ids", and you
 * should replace those columns with a "?" in the query text.
 * <p>
 * If the contents of the TEXT (or BYTE) column allow it, you can also use
 * "ifx_textasvarchar(1)" and "ifx_byteasvarchar(1)". This allows you to treat
 * TEXT (or BYTE) columns just as if they were ordinary (but long) VARCHAR
 * columns for select queries, and you don't need to bother with blob id's.
 * <p>
 * With ifx_textasvarchar(0) or ifx_byteasvarchar(0) (the default situation),
 * select queries will return BLOB columns as blob id's (integer value). You
 * can get the value of the blob as a string or file with the blob functions
 * (see below).
 * 
 * @see ifx_do()
 */
function int ifx_prepare(string query, int conn_id, int [cursor_def], mixed blobidarray);
 
/**
 * Execute a previously prepared SQL-statement
 * <p>
 * Returns TRUE on success, FALSE on error.
 * <p>
 * Executes a previously prepared query or opens a cursor for it.
 * <p>
 * Does NOT free result_id on error.
 * <p>
 * Also sets the real number of {@link ifx_affected_rows()} for non-select statements
 * for retrieval by {@link ifx_affected_rows()}
 * 
 * @see ifx_prepare()
 */
function int ifx_do(int result_id);
 
/**
 * Returns error code of last Informix call
 * <p>
 * The Informix error codes (SQLSTATE & SQLCODE) formatted as follows :
 * <p>
 * x [SQLSTATE = aa bbb SQLCODE=cccc]
 * <p>
 * where x = space : no error
 * <p>
 * E : error
 * <p>
 * N : no more data
 * <p>
 * W : warning
 * <p>
 * ? : undefined
 * <p>
 * If the "x" character is anything other than space, SQLSTATE and SQLCODE
 * describe the error in more detail.
 * <p>
 * See the Informix manual for the description of SQLSTATE and SQLCODE
 * <p>
 * Returns in a string one character describing the general results of a
 * statement and both SQLSTATE and SQLCODE associated with the most recent SQL
 * statement executed. The format of the string is "(char) [SQLSTATE=(two
 * digits) (three digits) SQLCODE=(one digit)]". The first character can be '
 * ' (space) (success), 'W' (the statement caused some warning), 'E' (an error
 * happened when executing the statement) or 'N' (the statement didn't return
 * any data).
 * 
 * @see ifx_errormsg()
 */
function string ifx_error(void);
 
/**
 * Returns error message of last Informix call
 * <p>
 * Returns the Informix error message associated with the most recent Informix
 * error, or, when the optional "errorcode" param is present, the error
 * message corresponding to "errorcode".
 * <pre>
 *    printf("%s\n&lt;br&gt;", ifx_errormsg(-201));
 * </pre>
 *
 * @see ifx_error()
 */
function string ifx_errormsg(int [errorcode]);
 
/**
 * Get number of rows affected by a query
 * <p>
 * result_id is a valid result id returned by {@link ifx_query()} or {@link ifx_prepare()}.
 * <p>
 * Returns the number of rows affected by a query associated with result_id.
 * <p>
 * For inserts, updates and deletes the number is the real number (sqlerrd[2])
 * of affected rows. For selects it is an estimate (sqlerrd[0]). Don't rely on
 * it.
 * <p>
 * Useful after {@link ifx_prepare()} to limit queries to reasonable result sets.
 * <p>
 * <b>Example 1.</b> Informix affected rows
 * <pre>
 *    $rid = ifx_prepare ("select * from emp where name like " . $name, $connid);
 *    if (! $rid) {
 *        ... error ...
 *    }
 *    $rowcount = ifx_affected_rows ($rid);
 *    if ($rowcount &gt; 1000) {
 *        printf ("Too many rows in result set (%d)\n&lt;br&gt;", $rowcount);
 *        die ("Please restrict your query&lt;br&gt;\n");
 *    }
 * </pre>
 * 
 * @see ifx_num_rows()
 */
function int ifx_affected_rows(int result_id);
 
/**
 * Get the contents of sqlca.sqlerrd[0..5] after a query
 * <p>
 * result_id is a valid result id returned by {@link ifx_query()} or {@link ifx_prepare()}.
 * <p>
 * Returns a pseudo-row (assiociative arry) with sqlca.sqlerrd[0] to
 * sqlca.sqlerrd[5] after the query associated with result_id.
 * <p>
 * For inserts, updates and deletes the values returned are those as set by
 * the server after executing the query. This gives access to the number of
 * affected rows and the serial insert value. For selects the values are those
 * saved after the prepare statement. This gives access to the estimated
 * number of affected rows. The use of this function saves the overhead of
 * executing a "select dbinfo('sqlca.sqlerrdx')" query, as it retrieves the
 * values that were saved by the ifx driver at the appropriate moment.
 * <p>
 * <b>Example 1.</b> Retrieve Informix sqlca.sqlerrd[x] values
 * <pre>
 *    // assume the first column of 'sometable' is a serial 
 *    $qid = ifx_query("insert into sometable values(0, '2nd column', 'another column' ", $connid);
 *    if (! $qid) {
 *        ... error ...
 *    }
 *    $sqlca = ifx_getsqlca ($qid);
 *    $serial_value = $sqlca["sqlerrd1"];
 *    echo "The serial value of the inserted row is : " . $serial_value&lt;br&gt;\n";
 * </pre>
 */
function array ifx_getsqlca(int result_id);
 
/**
 * Get row as enumerated array
 * <p>
 * Returns an associative array that corresponds to the fetched row, or false
 * if there are no more rows.
 * <p>
 * Blob columns are returned as integer blob id values for use in
 * {@link ifx_get_blob()} unless you have used ifx_textasvarchar(1) or
 * ifx_byteasvarchar(1), in which case blobs are returned as string values.
 * Returns FALSE on error
 * <p>
 * result_id is a valid resultid returned by {@link ifx_query()} or {@link ifx_prepare()}
 * (select type queries only!).
 * <p>
 * [position] is an optional parameter for a "fetch" operation on "scroll"
 * cursors: "NEXT", "PREVIOUS", "CURRENT", "FIRST", "LAST" or a number. If you
 * specify a number, an "absolute" row fetch is executed. This parameter is
 * optional, and only valid for scrollcursors.
 * <p>
 * ifx_fetch_row() fetches one row of data from the result associated with the
 * specified result identifier. The row is returned as an array. Each result
 * column is stored in an array offset, starting at offset 0.
 * <p>
 * Subsequent call to ifx_fetch_row() would return the next row in the result
 * set, or false if there are no more rows.
 * <p>
 * <b>Example 1.</b> Informix fetch rows
 * <pre>
 *    $rid = ifx_prepare ("select * from emp where name like " . $name,
 *                         $connid, IFX_SCROLL);
 *    if (! $rid) {
 *        ... error ...
 *    }
 *    $rowcount = ifx_affected_rows($rid);
 *    if ($rowcount &gt; 1000) {
 *        printf ("Too many rows in result set (%d)\n&lt;br&gt;", $rowcount);
 *        die ("Please restrict your query&lt;br&gt;\n");
 *    }
 *    if (! ifx_do ($rid)) {
 *       ... error ...
 *    }
 *    $row = ifx_fetch_row ($rid, "NEXT");
 *    while (is_array($row)) {
 *        for(reset($row); $fieldname=key($row); next($row)) {
 *            $fieldvalue = $row[$fieldname];
 *            printf ("%s = %s,", $fieldname, $fieldvalue);
 *        }
 *        printf("\n&lt;br&gt;");
 *        $row = ifx_fetch_row ($rid, "NEXT");
 *    }
 *    ifx_free_result ($rid);
 * </pre>
 */
function array ifx_fetch_row(int result_id, mixed [position] );
 
/**
 * Formats all rows of a query into a HTML table
 * <p>
 * Returns the number of rows fetched or FALSE on error.
 * <p>
 * Formats all rows of the result_id query into a html table. The optional
 * second argument is a string of &lt;table&gt; tag options
 * <p>
 * <b>Example 1.</b> Informix results as HTML table
 * <pre>
 *    $rid = ifx_prepare ("select * from emp where name like " . $name,
 *                         $connid, IFX_SCROLL);
 *    if (! $rid) {
 *       ... error ...
 *    }
 *    $rowcount = ifx_affected_rows ($rid);
 *    if ($rowcount &gt; 1000) {
 *        printf ("Too many rows in result set (%d)\n&lt;br&gt;", $rowcount);
 *        die ("Please restrict your query&lt;br&gt;\n");
 *    }
 *    if (! ifx_do($rid) {
 *      ... error ...
 *    }
 *    ifx_htmltbl_result ($rid, "border=\"2\"");
 *    ifx_free_result($rid);
 * </pre>
 */
function int ifx_htmltbl_result(int result_id, string [html_table_options]);
 
/**
 * List of Informix SQL fields
 * <p>
 * Returns an associative array with fieldnames as key and the SQL fieldtypes
 * as data for query with result_id. Returns FALSE on error.
 * <p>
 * <b>Example 1.</b> Fielnames and SQL fieldtypes
 * <pre>
 *    $types = ifx_fieldtypes ($resultid);
 *    if (! isset ($types)) {
 *      ... error ...
 *    }
 *    for ($i = 0; $i &lt; count($types); $i++) {
 *        $fname = key($types);
 *        printf("%s :\t type =  %s\n", $fname, $types[$fname]);
 *        next($types);
 *    }
 * </pre>
 */
function array ifx_fieldtypes(int result_id);
 
/**
 * List of SQL fieldproperties
 * <p>
 * Returns an associative array with fieldnames as key and the SQL
 * fieldproperties as data for a query with result_id. Returns FALSE on error.
 * <p>
 * Returns the Informix SQL fieldproperies of every field in the query as an
 * associative array. Properties are encoded as:
 * "SQLTYPE;length;precision;scale;ISNULLABLE" where SQLTYPE = the Informix
 * type like "SQLVCHAR" etc. and ISNULLABLE = "Y" or "N".
 * <p>
 * <b>Example 1.</b> Informix SQL fieldproperties
 * <pre>
 *    $properties = ifx_fieldtypes ($resultid);
 *    if (! isset($properties)) {
 *      ... error ...
 *    }
 *    for ($i = 0; $i &lt; count($properties); $i++) {
 *        $fname = key ($properties);
 *        printf ("%s:\t type =  %s\n", $fname, $properties[$fname]);
 *        next ($properties);
 *    }
 * </pre>
 */
function array ifx_fieldproperties(int result_id);
 
/**
 * Returns the number of columns in the query
 * <p>
 * Returns the number of columns in query for result_id or FALSE on error
 * <p>
 * After preparing or executing a query, this call gives you the number of
 * columns in the query.
 */
function int ifx_num_fields(int result_id);
 
/**
 * Count the rows already fetched a query
 * <p>
 * Gives the number of rows fetched so far for a query with result_id after a
 * {@link ifx_query()} or {@link ifx_do()} query.
 */
function int ifx_num_rows(int result_id);
 
/**
 * Releases resources for the query
 * <p>
 * Releases resources for the query associated with result_id. Returns FALSE
 * on error.
 */
function int ifx_free_result(int result_id);
 
/**
 * Creates an char object
 * <p>
 * Creates an char object. param should be the char content.
 */
function int ifx_create_char(string param);
 
/**
 * Deletes the char object
 * <p>
 * Deletes the charobject for the given char object-id bid. Returns FALSE on
 * error otherwise TRUE.
 */
function int ifx_free_char(int bid);
 
/**
 * Updates the content of the char object
 * <p>
 * Updates the content of the char object for the given char object bid.
 * content is a string with new data. Returns FALSE on error otherwise TRUE.
 */
function int ifx_update_char(int bid, string content);
 
/**
 * Return the content of the char object
 * <p>
 * Returns the content of the char object for the given char object-id bid.
 */
function int ifx_get_char(int bid);
 
/**
 * Creates an blob object
 * <p>
 * Creates an blob object.
 * <p>
 * type: 1 = TEXT, 0 = BYTE
 * <p>
 * mode: 0 = blob-object holds the content in memory, 1 = blob-object holds
 * the content in file.
 * <p>
 * param: if mode = 0: pointer to the content, if mode = 1: pointer to the
 * filestring.
 * <p>
 * Return FALSE on error, otherwise the new blob object-id.
 */
function int ifx_create_blob(int type, int mode, string param);
 
/**
 * Duplicates the given blob object
 * <p>
 * Duplicates the given blob object. bid is the ID of the blob object.
 * <p>
 * Returns FALSE on error otherwise the new blob object-id.
 */
function int ifx_copy_blob(int bid);
 
/**
 * Deletes the blob object
 * <p>
 * Deletes the blobobject for the given blob object-id bid. Returns FALSE on
 * error otherwise TRUE.
 */
function int ifx_free_blob(int bid);
 
/**
 * Return the content of a blob object
 * <p>
 * Returns the content of the blob object for the given blob object-id bid.
 */
function int ifx_get_blob(int bid);
 
/**
 * Updates the content of the blob object
 * <p>
 * Updates the content of the blob object for the given blob object bid.
 * content is a string with new data. Returns FALSE on error otherwise TRUE.
 */
function ifx_update_blob(int bid, string content);
 
/**
 * Set the default blob mode for all select queries
 * <p>
 * Set the default blob mode for all select queries. Mode "0" means save
 * Byte-Blobs in memory, and mode "1" means save Byte-Blobs in a file.
 */
function void ifx_blobinfile_mode(int mode);
 
/**
 * Set the default text mode
 * <p>
 * Sets the default text mode for all select-queries. Mode "0" will return a
 * blob id, and mode "1" will return a varchar with text content.
 */
function void ifx_textasvarchar(int mode);
 
/**
 * Set the default byte mode
 * <p>
 * Sets the default byte mode for all select-queries. Mode "0" will return a
 * blob id, and mode "1" will return a varchar with text content.
 */
function void ifx_byteasvarchar(int mode);
 
/**
 * Sets the default return value on a fetch row
 * <p>
 * Sets the default return value of a NULL-value on a fetch row. Mode "0"
 * returns "", and mode "1" returns "NULL".
 */
function void ifx_nullformat(int mode);
 
/**
 * Creates an slob object and opens it
 * <p>
 * Creates an slob object and opens it. Modes: 1 = LO_RDONLY, 2 = LO_WRONLY, 4
 * = LO_APPEND, 8 = LO_RDWR, 16 = LO_BUFFER, 32 = LO_NOBUFFER -&gt; or-mask. You
 * can also use constants named IFX_LO_RDONLY, IFX_LO_WRONLY etc. Return FALSE
 * on error otherwise the new slob object-id.
 */
function int ifxus_create_slob(int mode);
 
/**
 * Deletes the slob object
 * <p>
 * Deletes the slob object. bid is the Id of the slob object. Returns FALSE on
 * error otherwise TRUE.
 */
function int ifxus_free_slob(int bid);
 
/**
 * Deletes the slob object
 * <p>
 * Deletes the slob object on the given slob object-id bid. Return FALSE on
 * error otherwise TRUE.
 */
function int ifxus_close_slob(int bid);
 
/**
 * Opens an slob object
 * <p>
 * Opens an slob object. bid should be an existing slob id. Modes: 1 =
 * LO_RDONLY, 2 = LO_WRONLY, 4 = LO_APPEND, 8 = LO_RDWR, 16 = LO_BUFFER, 32 =
 * LO_NOBUFFER -&gt; or-mask. Returns FALSE on error otherwise the new slob
 * object-id.
 */
function int ifxus_open_slob(long bid, int mode);
 
/**
 * Returns the current file or seek position
 * <p>
 * Returns the current file or seek position of an open slob object bid should
 * be an existing slob id. Return FALSE on error otherwise the seek position.
 */
function int ifxus_tell_slob(long bid);
 
/**
 * Sets the current file or seek position
 * <p>
 * Sets the current file or seek position of an open slob object. bid should
 * be an existing slob id. Modes: 0 = LO_SEEK_SET, 1 = LO_SEEK_CUR, 2 =
 * LO_SEEK_END and offset is an byte offset. Return FALSE on error otherwise
 * the seek position.
 */
function int ifxus_seek_slob(long bid, int mode, long offset);
 
/**
 * Reads nbytes of the slob object
 * <p>
 * Reads nbytes of the slob object. bid is a existing slob id and nbytes is
 * the number of bytes zu read. Return FALSE on error otherwise the string.
 */
function int ifxus_read_slob(long bid, long nbytes);
 
/**
 * Writes a string into the slob object
 * <p>
 * Writes a string into the slob object. bid is a existing slob id and content
 * the content to write. Return FALSE on error otherwise bytes written.
 */
function int ifxus_write_slob(long bid, string content);


///////////////////////////////////////////////////////////////////////////
// InterBase functions
// 

/**
 * close a connection to an InterBase server
 */
function ibase_close();

/**
 * connect to an InterBase datasource
 */
function ibase_connect();

/**
 * connect persistently to an InterBase datasource
 */
function ibase_pconnect();

/**
 * send Interbase query
 */
function ibase_query();

/**
 * prepare and execute a SQL statement
 */
function ibase_prepare();

/**
 * fetch a row from a result
 */
function ibase_fetch_row();

/**
 * free resources associated with a result
 */
function ibase_free_result();

/**
 * bind a PHP variable to an InterBase parameter
 */ 
function ibase_bind( );
 
/**
 * execute parsed statement on an Oracle cursor
 */ 
function ibase_execute( );
 
/**
 * free resources associated with a query
 */ 
function ibase_free_query( );
 
/**
 * return the Interbase date and time format
 */
function ibase_timefmt( );


///////////////////////////////////////////////////////////////////////////
// LDAP functions
//
// LDAP is the Lightweight Directory Access Protocol, and is a protocol used
// to access "Directory Servers". The Directory is a special kind of database
// that holds information in a tree structure.
// 
// The concept is similar to your hard disk directory structure, except that
// in this context, the root directory is "The world" and the first level
// subdirectories are "countries". Lower levels of the directory structure
// contain entries for companies, organisations or places, while yet lower
// still we find directory entries for people, and perhaps equipment or
// documents.
// 
// To refer to a file in a subdirectory on your hard disk, you might use
// something like
// 
//     /usr/local/myapp/docs
// 
// The forwards slash marks each division in the reference, and the sequence
// is read from left to right.
// 
// The equivalent to the fully qualified file reference in LDAP is the
// "distinguished name", referred to simply as "dn". An example dn might be.
// 
//     cn=John Smith,ou=Accounts,o=My Company,c=US
// 
// The comma marks each division in the reference, and the sequence is read
// from right to left. You would read this dn as ..
// 
//     country = US
//     organization = My Company
//     organizationalUnit = Accounts
//     commonName = John Smith
// 
// In the same way as there are no hard rules about how you organise the
// directory structure of a hard disk, a directory server manager can set up
// any structure that is meaningful for the purpose. However, there are some
// conventions that are used. The message is that you can not write code to
// access a directory server unless you know something about its structure,
// any more than you can use a database without some knowledge of what is
// available.
// 
// ------------------------------------------------------------------------
// Complete code example
// 
// Retrieve information for all entries where the surname starts with "S" from
// a directory server, displaying an extract with name and email address.
// 
// Example 1. LDAP search example
// 
// <?php
// // basic sequence with LDAP is connect, bind, search, interpret search
// // result, close connection
// 
// echo "<h3>LDAP query test</h3>";
// echo "Connecting ...";
// $ds=ldap_connect("localhost");  // must be a valid LDAP server!
// echo "connect result is ".$ds."<p>";
// 
// if ($ds) {
//     echo "Binding ...";
//     $r=ldap_bind($ds);     // this is an "anonymous" bind, typically
//                            // read-only access echo "Bind result is
//     echo "Bind result is ".$r."<p>";
// 
//     echo "Searching for (sn=S*) ...";
//     // Search surname entry
//     $sr=ldap_search($ds,"o=My Company, c=US", "sn=S*");
//     echo "Search result is ".$sr."<p>";
// 
//     echo "Number of entires returned is ".ldap_count_entries($ds,$sr)."<p>";
// 
//     echo "Getting entries ...<p>";
//     $info = ldap_get_entries($ds, $sr);
//     echo "Data for ".$info["count"]." items returned:<p>";
// 
//     for ($i=0; $i<$info["count"]; $i++) {
//         echo "dn is: ". $info[$i]["dn"] ."<br>";
//         echo "first cn entry is: ". $info[$i]["cn"][0] ."<br>";
//         echo "first email entry is: ". $info[$i]["mail"][0] ."<p>";
//     }
// 
//     echo "Closing connection";
//     ldap_close($ds);
// 
// } else {
//     echo "<h4>Unable to connect to LDAP server</h4>";
// }
// ?>
// 
// ------------------------------------------------------------------------
// Using the PHP LDAP calls
// 
// You will need to get and compile LDAP client libraries from either the
// University of Michigan ldap-3.3 package or the Netscape Directory SDK. You
// will also need to recompile PHP with LDAP support enabled before PHP's LDAP
// calls will work.
// 
// Before you can use the LDAP calls you will need to know ..
// 
//    * The name or address of the directory server you will use
// 
//    * The "base dn" of the server (the part of the world directory that is
//      held on this server, which could be "o=My Company,c=US")
// 
//    * Whether you need a password to access the server (many servers will
//      provide read access for an "anonymous bind" but require a password for
//      anything else)
// 
// The typical sequence of LDAP calls you will make in an application will
// follow this pattern:
// 
//   ldap_connect()    // establish connection to server
//      |
//   ldap_bind()       // anonymous or authenticated "login"
//      |
//   do something like search or update the directory
//   and display the results
//      |
//   ldap_close()      // "logout"
// 
// ------------------------------------------------------------------------
// More Information
// 
// Lots of information about LDAP can be found at
// 
//    * Netscape
//    * University of Michigan
//    * OpenLDAP Project
//    * LDAP World
// 
// The Netscape SDK contains a helpful Programmer's Guide in .html format.
//

/**
 * Add entries to LDAP directory
 * <p>
 * returns true on success and false on error.
 * <p>
 * The ldap_add() function is used to add entries in the LDAP directory. The
 * DN of the entry to be added is specified by dn. Array entry specifies the
 * information about the entry. The values in the entries are indexed by
 * individual attributes. In case of multiple values for an attribute, they
 * are indexed using integers starting with 0.
 * <pre>
 *     entry["attribute1"] = value
 *     entry["attribute2"][0] = value1
 *     entry["attribute2"][1] = value2
 * </pre>
 * <b>Example 1.</b> Complete example with authenticated bind
 * <pre>
 *    &lt;?php
 *    $ds=ldap_connect("localhost");  // assuming the LDAP server is on this host
 * 
 *    if ($ds) {
 *       // bind with appropriate dn to give update access
 *       $r=ldap_bind($ds,"cn=root, o=My Company, c=US", "secret");
 *       // prepare data
 *       $info["cn"]="John Jones";
 *       $info["sn"]="Jones";
 *       $info["mail"]="jonj@here.and.now";
 *       $info["objectclass"]="person";
 *       // add data to directory
 *       $r=ldap_add($ds, "cn=John Jones, o=My Company, c=US", $info);
 *       ldap_close($ds);
 *    } else {
 *       echo "Unable to connect to LDAP server";
 *   }
 *   ?&gt;
 * </pre>
 */
function int ldap_add(int link_identifier, string dn, array entry);
 
/**
 * Add attribute values to current attributes
 * <p>
 * returns true on success and false on error.
 * <p>
 * This function adds attribute(s) to the specified dn. It performs the
 * modification at the attribute level as opposed to the object level.
 * Object-level additions are done by the {@link ldap_add()} function.
 */
function int ldap_mod_add(int link_identifier, string dn, array entry);
 
/**
 * Delete attribute values from current attributes
 * <p>
 * returns true on success and false on error.
 * <p>
 * This function removes attribute(s) from the specified dn. It performs the
 * modification at the attribute level as opposed to the object level.
 * Object-level deletions are done by the {@link ldap_del()} function.
 */
function int ldap_mod_del(int link_identifier, string dn, array entry);
 
/**
 * Replace attribute values with new ones
 * <p>
 * returns true on success and false on error.
 * <p>
 * This function replaces attribute(s) from the specified dn. It performs the
 * modification at the attribute level as opposed to the object level.
 * Object-level modifications are done by the {@link ldap_modify()} function.
 */
function int ldap_mod_replace(int link_identifier, string dn, array entry);
 
/**
 * Bind to LDAP directory
 * <p>
 * Binds to the LDAP directory with specified RDN and password. Returns true
 * on success and false on error.
 * <p>
 * ldap_bind() does a bind operation on the directory. bind_rdn and
 * bind_password are optional. If not specified, anonymous bind is attempted.
 */
function int ldap_bind(int link_identifier, string [bind_rdn], string [bind_password]);
 
/**
 * Close link to LDAP server
 * <p>
 * Returns true on success, false on error.
 * <p>
 * ldap_close() closes the link to the LDAP server that's associated with the
 * specified link_identifier.
 * <p>
 * This call is internally identical to {@link ldap_unbind()}. The LDAP API uses the
 * call {@link ldap_unbind()}, so perhaps you should use this in preference to
 * ldap_close().
 */
function int ldap_close(int link_identifier);
 
/**
 * Connect to an LDAP server
 * <p>
 * Returns a positive LDAP link identifier on success, or false on error.
 * <p>
 * ldap_connect() establishes a connection to a LDAP server on a specified
 * hostname and port. Both the arguments are optional. If no arguments are
 * specified then the link identifier of the already opened link will be
 * returned. If only hostname is specified, then the port defaults to 389.
 */
function int ldap_connect(string [hostname], int [port]);
 
/**
 * Count the number of entries in a search
 * <p>
 * Returns number of entries in the result or false on error.
 * <p>
 * ldap_count_entries() returns the number of entries stored in the result of
 * previous search operations. result_identifier identifies the internal ldap
 * result.
 */
function int ldap_count_entries(int link_identifier, int result_identifier);
 
/**
 * Delete an entry from a directory
 * <p>
 * Returns true on success and false on error.
 * <p>
 * ldap_delete() function delete a particular entry in LDAP directory
 * specified by dn.
 */
function int ldap_delete(int link_identifier, string dn);
 
/**
 * Convert DN to User Friendly Naming format
 * <p>
 * ldap_dn2ufn() function is used to turn a DN into a more user-friendly form,
 * stripping off type names.
 */
function string ldap_dn2ufn(string dn);
 
/**
 * Splits DN into its component parts
 * <p>
 * ldap_explode_dn() function is used to split the a DN returned by
 * {@link ldap_get_dn()} and breaks it up into its component parts. Each part is known
 * as Relative Distinguished Name, or RDN. ldap_explode_dn() returns an array
 * of all those components. with_attrib is used to request if the RDNs are
 * returned with only values or their attributes as well. To get RDNs with the
 * attributes (i.e. in attribute=value format) set with_attrib to 0 and to get
 * only values set it to 1.
 */
function array ldap_explode_dn(string dn, int with_attrib);
 
/**
 * Return first attribute
 * <p>
 * Returns the first attribute in the entry on success and false on error.
 * <p>
 * Similar to reading entries, attributes are also read one by one from a
 * particular entry. ldap_first_attribute() returns the first attribute in the
 * entry pointed by the entry identifier. Remaining attributes are retrieved
 * by calling {@link ldap_next_attribute()} successively. ber_identifier is the
 * identifier to internal memory location pointer. It is passed by reference.
 * The same ber_identifier is passed to the {@link ldap_next_attribute()} function,
 * which modifies that pointer.
 * 
 * @see ldap_get_attributes()
 */
function string ldap_first_attribute(int link_identifier, int result_entry_identifier, int ber_identifier);
 
/**
 * Return first result id
 * <p>
 * Returns the result entry identifier for the first entry on success and
 * false on error.
 * <p>
 * Entries in the LDAP result are read sequentially using the
 * ldap_first_entry() and {@link ldap_next_entry()} functions. {@link ldap_first_entry()}
 * returns the entry identifier for first entry in the result. This entry
 * identifier is then supplied to {@link lap_next_entry()} routine to get successive
 * entries from the result.
 * 
 * @see ldap_get_entries()
 */
function int ldap_first_entry(int link_identifier, int result_identifier);
 
/**
 * Free result memory
 * <p>
 * Returns true on success and false on error.
 * <p>
 * ldap_free_result() frees up the memory allocated internally to store the
 * result and pointed by the result_identifier. All result memory will be
 * automatically freed when the script terminates.
 * <p>
 * Typically all the memory allocated for the ldap result gets freed at the
 * end of the script. In case the script is making successive searches which
 * return large result sets, ldap_free_result() could be called to keep the
 * runtime memory usage by the script low.
 */
function int ldap_free_result(int result_identifier);
 
/**
 * Get attributes from a search result entry
 * <p>
 * Returns a complete entry information in a multi-dimensional array on
 * success and false on error.
 * <p>
 * ldap_get_attributes() function is used to simplify reading the attributes
 * and values from an entry in the search result. The return value is a
 * multi-dimensional array of attributes and values.
 * <p>
 * Having located a specific entry in the directory, you can find out what
 * information is held for that entry by using this call. You would use this
 * call for an application which "browses" directory entries and/or where you
 * do not know the structure of the directory entries. In many applications
 * you will be searching for a specific attribute such as an email address or
 * a surname, and won't care what other data is held.
 * <pre>
 *    return_value["count"] = number of attributes in the entry
 *    return_value[0] = first attribute
 *    return_value[n] = nth attribute
 *    return_value["attribute"]["count"] = number of values for attribute
 *    return_value["attribute"][0] = first value of the attribute
 *    return_value["attribute"][i] = ith value of the attribute
 * </pre>
 * <b>Example 1.</b> Show the list of attributes held for a particular directory
 * entry
 * <pre>
 *    // $ds is the link identifier for the directory
 *    // $sr is a valid search result from a prior call to
 *    // one of the ldap directory search calls
 *    $entry = ldap_first_entry($ds, $sr);
 *    $attrs = ldap_get_attributes($ds, $entry);
 *    echo $attrs["count"]." attributes held for this entry:&lt;p&gt;";
 *    for ($i=0; $i&lt;$attrs["count"]; $i++)
 *       echo $attrs[$i]."&lt;br&gt;";
 * </pre>
 *
 * @see ldap_first_attribute()
 * @see ldap_next_attribute()
 */
function array ldap_get_attributes(int link_identifier, int result_entry_identifier);
 
/**
 * Get the DN of a result entry
 * <p>
 * Returns the DN of the result entry and false on error.
 * <p>
 * ldap_get_dn() function is used to find out the DN of an entry in the
 * result.
 */
function string ldap_get_dn(int link_identifier, int result_entry_identifier);
 
/**
 * Get all result entries
 * <p>
 * Returns a complete result information in a multi-dimenasional array on
 * success and false on error.
 * <p>
 * ldap_get_entries() function is used to simplify reading multiple entries
 * from the result and then reading the attributes and multiple values. The
 * entire information is returned by one function call in a multi-dimensional
 * array. The structure of the array is as follows.
 * <p>
 * The attribute index is converted to lowercase. (Attributes are
 * case-insensitive for directory servers, but not when used as array indices)
 * <pre>
 *    return_value["count"] = number of entries in the result
 *    return_value[0] : refers to the details of first entry
 *    return_value[i]["dn"] =  DN of the ith entry in the result
 *    return_value[i]["count"] = number of attributes in ith entry
 *    return_value[i][j] = jth attribute in the ith entry in the result
 *    return_value[i]["attribute"]["count"] = number of values for
 *                                            attribute in ith entry
 *    return_value[i]["attribute"][j] = jth value of attribute in ith entry
 * </pre>
 *
 * @see ldap_first_entry()
 * @see ldap_next_entry()
 */
function array ldap_get_entries(int link_identifier, int result_identifier);
 
/**
 * Get all values from a result entry
 * <p>
 * Returns an array of values for the attribute on success and false on error.
 * <p>
 * ldap_get_values() function is used to read all the values of the attribute
 * in the entry in the result. entry is specified by the
 * result_entry_identifier. The number of values can be found by indexing
 * "count" in the resultant array. Individual values are accessed by integer
 * index in the array. The first index is 0.
 * <p>
 * This call needs a result_entry_identifier, so needs to be preceded by one
 * of the ldap search calls and one of the calls to get an individual entry.
 * <p>
 * You application will either be hard coded to look for certain attributes
 * (such as "surname" or "mail") or you will have to use the
 * ldap_get_attributes() call to work out what attributes exist for a given
 * entry.
 * <p>
 * LDAP allows more than one entry for an attribute, so it can, for example,
 * store a number of email addresses for one person's directory entry all
 * labeled with the attribute "mail"
 * <pre>
 *    return_value["count"] = number of values for attribute
 *    return_value[0] = first value of attribute
 *    return_value[i] = ith value of attribute
 * </pre>
 * <b>Example 1.</b> List all values of the "mail" attribute for a directory entry
 * <pre>
 *    // $ds is a valid link identifier for a directory server
 *    // $sr is a valid search result from a prior call to
 *    //     one of the ldap directory search calls
 *    // $entry is a valid entry identifier from a prior call to
 *    //        one of the calls that returns a directory entry
 *    $values = ldap_get_values($ds, $entry,"mail");
 *    echo $values["count"]." email addresses for this entry.&lt;p&gt;";
 *    for ($i=0; $i &lt; $values["count"]; $i++)
 *        echo $values[$i]."&lt;br&gt;";
 * </pre>
 */
function array ldap_get_values(int link_identifier, int result_entry_identifier, string attribute);
 
/**
 * Single-level search
 * <p>
 * Returns a search result identifier or false on error.
 * <p>
 * ldap_list() performs the search for a specified filter on the directory
 * with the scope LDAP_SCOPE_ONELEVEL.
 * <p>
 * LDAP_SCOPE_ONELEVEL means that the search should only return information
 * that is at the level immediately below the base dn given in the call.
 * (Equivalent to typing "ls" and getting a list of files and folders in the
 * current working directory.)
 * <p>
 * This call takes an optional fourth parameter which is an array of the
 * attributes required. See {@link ldap_search()} notes.
 * <p>
 * <b>Example 1.</b> Produce a list of all organizational units of an organization
 * <pre>
 *    // $ds is a valid link identifier for a directory server
 *    $basedn = "o=My Company, c=US";
 *    $justthese = array("ou");
 *    $sr=ldap_list($ds, $basedn, "ou=*", $justthese);
 *    $info = ldap_get_entries($ds, $sr);
 * 
 *    for ($i=0; $i&lt;$info["count"]; $i++)
 *        echo $info[$i]["ou"][0] ;
 * </pre>
 */
function int ldap_list(int link_identifier, string base_dn, string filter, array [attributes]);
 
/**
 * Modify an LDAP entry
 * <p>
 * Returns true on success and false on error.
 * <p>
 * ldap_modify() function is used to modify the existing entries in the LDAP
 * directory. The structure of the entry is same as in {@link ldap_add()}.
 */
function int ldap_modify(int link_identifier, string dn, array entry);
 
/**
 * Get the next attribute in result
 * <p>
 * Returns the next attribute in an entry on success and false on error.
 * <p>
 * ldap_next_attribute() is called to retrieve the attributes in an entry. The
 * internal state of the pointer is maintained by the ber_identifier. It is
 * passed by reference to the function. The first call to
 * ldap_next_attribute() is made with the result_entry_identifier returned
 * from {@link ldap_first_attribute()}.
 * 
 * @see ldap_get_attributes()
 */
function string ldap_next_attribute(int link_identifier, int result_entry_identifier, int ber_identifier);
 
/**
 * Get next result entry
 * <p>
 * Returns entry identifier for the next entry in the result whose entries are
 * being read starting with {@link ldap_first_entry()}. If there are no more entries
 * in the result then it returns false.
 * <p>
 * ldap_next_entry() function is used to retrieve the entries stored in the
 * result. Successive calls to the ldap_next_entry() return entries one by one
 * till there are no more entries. The first call to ldap_next_entry() is made
 * after the call to ldap_first_entry() with the result_identifier as returned
 * from the {@link ldap_first_entry()}.
 * 
 * @see ldap_get_entries()
 */
function int ldap_next_entry(int link_identifier, int result_entry_identifier);
 
/**
 * Read an entry
 * <p>
 * Returns a search result identifier or false on error.
 * <p>
 * ldap_read() performs the search for a specified filter on the directory
 * with the scope LDAP_SCOPE_BASE. So it is equivalent to reading an entry
 * from the directory.
 * <p>
 * An empty filter is not allowed. If you want to retrieve absolutely all
 * information for this entry, use a filter of "objectClass=*". If you know
 * which entry types are used on the directory server, you might use an
 * appropriate filter such as "objectClass=inetOrgPerson".
 * <p>
 * This call takes an optional fourth parameter which is an array of the
 * attributes required. See {@link ldap_search()} notes.
 */
function int ldap_read(int link_identifier, string base_dn, string filter, array [attributes]);
 
/**
 * Search LDAP tree
 * <p>
 * Returns a search result identifier or false on error.
 * <p>
 * ldap_search() performs the search for a specified filter on the directory
 * with the scope of LDAP_SCOPE_SUBTREE. This is equivalent to searching the
 * entire directory. base_dn specifies the base DN for the directory.
 * <p>
 * There is a optional fourth parameter, that can be added to restrict the
 * attributes and values returned by the server to just those required. This
 * is much more efficient than the default action (which is to return all
 * attributes and their associated values). The use of the fourth parameter
 * should therefore be considered good practice.
 * <p>
 * The fourth parameter is a standard PHP string array of the required
 * attributes, eg array("mail","sn","cn") Note that the "dn" is always
 * returned irrespective of which attributes types are requested.
 * <p>
 * Note too that some directory server hosts will be configured to return no
 * more than a preset number of entries. If this occurs, the server will
 * indicate that it has only returned a partial results set.
 * <p>
 * The search filter can be simple or advanced, using boolean operators in the
 * format described in the LDAP doumentation (see the Netscape Directory SDK
 * for full information on filters).
 * <p>
 * The example below retrieves the organizational unit, surname, given name
 * and email address for all people in "My Company" where the surname or given
 * name contains the substring $person. This example uses a boolean filter to
 * tell the server to look for information in more than one attribute.
 * <p>
 * <b>Example 1.</b> LDAP search
 * <pre>
 *    // $ds is a valid link identifier for a directory server
 *    // $person is all or part of a person's name, eg "Jo"
 *    $dn = "o=My Company, c=US";
 *    $filter="(|(sn=$person*)(givenname=$person*))";
 *    $justthese = array( "ou", "sn", "givenname", "mail");
 *    $sr=ldap_search($ds, $dn, $filter, $justthese);
 *    $info = ldap_get_entries($ds, $sr);
 *    print $info["count"]." entries returned&lt;p&gt;";
 * </pre>
 */
function int ldap_search(int link_identifier, string base_dn, string filter, array [attributes]);
 
/**
 * Unbind from LDAP directory
 * <p>
 * Returns true on success and false on error.
 * <p>
 * ldap_unbind() function unbinds from the LDAP directory.
 */
function int ldap_unbind(int link_identifier);


///////////////////////////////////////////////////////////////////////////
// Mail functions
//
 
/**
 * The mail() function allows you to send mail.
 * <p>
 * Mail() automatically mails the message specified in message to the receiver
 * specified in to. Multiple recipients can be specified by putting a comma
 * between each address in to.
 * <P>
 * <b>Example 1.</b> Sending mail.
 * <pre>
 *    mail("rasmus@lerdorf.on.ca", "My Subject", "Line 1\nLine 2\nLine 3");
 * </pre>
 * If a fourth string argument is passed, this string is inserted at the end
 * of the header. This is typically used to add extra headers. Multiple extra
 * headers are separated with a newline.
 * <b>Example 2.</b> Sending mail with extra headers.
 * <pre>
 *    mail("nobody@aol.com", "the subject", $message,
 *         "From: webmaster@$SERVER_NAME\nReply-To: webmaster@$SERVER_NAME\nX-Mailer: PHP/" . phpversion());
 * </pre>
 */
function bool mail(string to, string subject, string message, string [additional_headers]);


///////////////////////////////////////////////////////////////////////////
// Mathematical functions
// 
// These math functions will only handle values within the range of the long
// and double types on your computer. If you need to handle bigger numbers,
// take a look at the arbitrary precision math functions.
// 

/**
 * The value of the constant Pi.
 */
global int M_PI = 3.14159265358979323846;
 
/**
 * absolute value
 * <p>
 * Returns the absolute value of number. If the argument number is float,
 * return type is also float, otherwise it is int.
 */
function mixed abs(mixed number);
 
/**
 * arc cosine
 * <p>
 * Returns the arc cosine of arg in radians.
 * 
 * @see asin()
 * @see atan()
 */
function float acos(float arg);
 
/**
 * arc sine
 * <p>
 * Returns the arc sine of arg in radians.
 * 
 * @see acos()
 * @see atan()
 */
function float asin(float arg);
 
/**
 * arc tangent
 * <p>
 * Returns the arc tangent of arg in radians.
 * 
 * @see acos()
 * @see atan()
 */
function float atan(float arg);
 
/**
 * arc tangent of two variables
 * <p>
 * This function calculates the arc tangent of the two variables x and y. It
 * is similar to calculating the arc tangent of y / x, except that the signs
 * of both arguments are used to determine the quadrant of the result.
 * <p>
 * The function returns the result in radians, which is between -PI and PI
 * (inclusive).
 * 
 * @see acos()
 * @see atan()
 */
function float atan2(float y, float x);
 
/**
 * convert a number between arbitrary bases
 * <p>
 * Returns a string containing number represented in base tobase. The base in
 * which number is given is specified in frombase. Both frombase and tobase
 * have to be between 2 and 36, inclusive. Digits in numbers with a base
 * higher than 10 will be represented with the letters a-z, with a meaning 10,
 * b meaning 11 and z meaning 36.
 * <P>
 * <b>Example 1.</b> base_convert()
 * <pre>
 *    $binary = base_convert($hexadecimal, 16, 2);
 * </pre>
 */
function strin base_convert(string number, int frombase, int tobase);
 
/**
 * binary to decimal
 * <p>
 * Returns the decimal equivalent of the binary number represented by the
 * binary_string argument.
 * <p>
 * OctDec converts a binary number to a decimal number. The largest number
 * that can be converted is 31 bits of 1's or 2147483647 in decimal.
 * 
 * @see decbin()
 */
function int bindec(string binary_string);
 
/**
 * round fractions up
 * <p>
 * Returns the next highest integer value from number. Using ceil() on
 * integers is absolutely a waste of time.
 * <p>
 * <b>Note:</b>
 * PHP/FI 2's ceil() returned a float. Use: $new =
 * (double)ceil($number); to get the old behaviour.
 * 
 * @see floor()
 * @see round()
 */
function int ceil(float number);
 
/**
 * cosine
 * <p>
 * Returns the cosine of arg in radians.
 * 
 * @see sin()
 * @see tan()
 */
function float cos(float arg);
 
/**
 * decimal to binary
 * <p>
 * Returns a string containing a binary representation of the given number
 * argument. The largest number that can be converted is 2147483647 in decimal
 * resulting to a string of 31 1's.
 * 
 * @see bindec()
 */
function string decbin(int number);
 
/**
 * decimal to hexadecimal
 * <p>
 * Returns a string containing a hexadecimal representation of the given
 * number argument. The largest number that can be converted is 2147483647 in
 * decimal resulting to "7fffffff".
 * 
 * @see hexdec()
 */
function string dechex(int number);
 
/**
 * decimal to octal
 * <p>
 * Returns a string containing an octal representation of the given number
 * argument. The largest number that can be converted is 2147483647 in decimal
 * resulting to "17777777777". See also octdec().
 */
function string decoct(int number);
 
/**
 * e to the power of...
 * <p>
 * Returns e raised to the power of arg.
 * 
 * @see pow()
 */
function float exp(float arg);
 
/**
 * round fractions down
 * <p>
 * Returns the next lowest integer value from number. Using floor() on
 * integers is absolutely a waste of time.
 * <p>
 * <b>Note:</b>
 * PHP/FI 2's floor() returned a float. Use: $new =
 * (double)floor($number); to get the old behaviour.
 * 
 * @see ceil()
 * @see round()
 */
function int floor(float number);
 
/**
 * show largest possible random value
 * <p>
 * Returns the maximum value that can be returned by a call to rand().
 * 
 * @see rand()
 * @see srand()
 * @see mt_rand()
 * @see mt_srand()
 * @see mt_getrandmax()
 */
function int getrandmax(void );
 
/**
 * hexadecimal to decimal
 * <p>
 * Returns the decimal equivalent of the hexadecimal number represented by the
 * hex_string argument. HexDec converts a hexadecimal string to a decimal
 * number. The largest number that can be converted is 7fffffff or 2147483647
 * in decimal.
 * 
 * @see dechex()
 */
function int hexdec(string hex_string);
 
/**
 * natural logarithm
 * <p>
 * Returns the natural logarithm of arg.
 */
function float log(float arg);
 
/**
 * base-10 logarithm
 * <p>
 * Returns the base-10 logarithm of arg.
 */
function float log10(float arg);
 
/**
 * find highest value
 * <p>
 * max() returns the numerically highest of the parameter values.
 * <p>
 * If the first parameter is an array, max() returns the highest value in that
 * array. If the first parameter is an integer, string or double, you need at
 * least two parameters and max() returns the biggest of these values. You can
 * compare an unlimited number of values.
 * <p>
 * If one or more of the values is a double, all the values will be treated as
 * doubles, and a double is returned. If none of the values is a double, all
 * of them will be treated as integers, and an integer is returned.
 */
function mixed max(mixed arg1, mixed arg2, mixed argn);
 
/**
 * find lowest value
 * <p>
 * min() returns the numerically lowest of the parameter values.
 * <p>
 * If the first parameter is an array, min() returns the lowest value in that
 * array. If the first parameter is an integer, string or double, you need at
 * least two parameters and min() returns the lowest of these values. You can
 * compare an unlimited number of values.
 * <p>
 * If one or more of the values is a double, all the values will be treated as
 * doubles, and a double is returned. If none of the values is a double, all
 * of them will be treated as integers, and an integer is returned.
 */
function mixed min(mixed arg1, mixed arg2, mixed argn);
 
/**
 * generate a better random value
 * <p>
 * Many random number generators of older libcs have dubious or unknown
 * characteristics and are slow. By default, PHP uses the libc random number
 * generator with the rand() function. {@link mt_rand()} function is a drop-in
 * replacement for this. It uses a random number generator with known
 * characteristics, the Mersenne Twister, which will produce random numbers
 * that should be suitable for cryptographic purposes and is four times faster
 * than what the average libc provides. The Homepage of the Mersenne Twister
 * can be found at http://www.math.keio.ac.jp/~matumoto/emt.html, and an
 * optimized version of the MT source is available from
 * http://www.scp.syr.edu/~marc/hawk/twister.html.
 * <p>
 * If called without the optional min,max arguments mt_rand() returns a
 * pseudo-random value between 0 and RAND_MAX. If you want a random number
 * between 5 and 15 (inclusive), for example, use mt_rand(5,15).
 * <p>
 * Remember to seed the random number generator before use with mt_srand().
 * 
 * @see mt_srand()
 * @see mt_getrandmax()
 * @see srand()
 * @see rand() 
 * @see getrandmax()
 */
function int mt_rand([int min], [int max]);
 
/**
 * seed the better random number generator
 * <p>
 * Seeds the random number generator with seed.
 * <pre>
 *    // seed with microseconds since last "whole" second
 *    mt_srand((double)microtime()*1000000);
 *    $randval = mt_rand();
 * </pre>
 * 
 * @see mt_rand()
 * @see mt_getrandmax()
 * @see srand()
 * @see rand() 
 * @see getrandmax()
 */
function void mt_srand(int seed);
 
/**
 * show largest possible random value
 * <p>
 * Returns the maximum value that can be returned by a call to mt_rand().
 * 
 * @see mt_rand()
 * @see mt_srand()
 * @see rand()
 * @see srand()
 * @see getrandmax()
 */
function int mt_getrandmax(void );
 
/**
 * format a number with grouped thousands
 * <p>
 * number_format() returns a formatted version of number. This function
 * accepts either one, two or four parameters (not three):
 * <p>
 * If only one parameter is given, number will be formatted without decimals,
 * but with a comma (",") between every group of thousands.
 * <p>
 * If two parameters are given, number will be formatted with decimals
 * decimals with a dot (".") in front, and a comma (",") between every group
 * of thousands.
 * <p>
 * If all four parameters are given, number will be formatted with decimals
 * decimals, dec_point instead of a dot (".") before the decimals and
 * thousands_sep instead of a comma (",") between every group of thousands.
 */
function string number_format(float number, int decimals, string dec_point, string thousands_sep);
 
/**
 * octal to decimal
 * <p>
 * Returns the decimal equivalent of the octal number represented by the
 * octal_string argument. OctDec converts an octal string to a decimal number.
 * The largest number that can be converted is 17777777777 or 2147483647 in
 * decimal.
 * 
 * @see decoct()
 */
function int octdec(string octal_string);
 
/**
 * get value of pi
 * <p>
 * Returns an approximation of pi.
 */
function double pi(void );
 
/**
 * exponential expression
 * <p>
 * Returns base raised to the power of exp.
 * 
 * @see exp()
 */
function float pow(float base, float exp);
 
/**
 * generate a random value
 * <p>
 * If called without the optional min,max arguments rand() returns a
 * pseudo-random value between 0 and RAND_MAX. If you want a random number
 * between 5 and 15 (inclusive), for example, use rand(5,15).
 * <p>
 * Remember to seed the random number generator before use with {@link srand()}.
 * 
 * @see srand()
 * @see getrandmax()
 * @see mt_rand()
 * @see mt_srand() * @see mt_getrandmax()
 */
function int rand([int min], [int max]);
 
/**
 * Rounds a float.
 * <p>
 * Returns the rounded value of val.
 * <pre>
 *    $foo = round( 3.4 );   // $foo == 3.0
 *    $foo = round( 3.5 );   // $foo == 4.0
 *    $foo = round( 3.6 );   // $foo == 4.0
 * </pre>
 *
 * @see ceil()
 * @see floor()
 */
function double round(double val);
 
/**
 * sine
 * <p>
 * Returns the sine of arg in radians.
 * 
 * @see cos()
 * @see tan()
 */
function float sin(float arg);
 
/**
 * square root
 * <p>
 * Returns the square root of arg.
 */
function float sqrt(float arg);
 
/**
 * seed the random number generator
 * <p>
 * Seeds the random number generator with seed.
 * <pre>
 *    // seed with microseconds since last "whole" second
 *    srand((double)microtime()*1000000);
 *    $randval = rand();
 * </pre>
 *
 * @see rand()
 * @see getrandmax()
 * @see mt_rand()
 * @see mt_srand()
 * @see mt_getrandmax()
 */
function void srand(int seed);
 
/**
 * tangent
 * <p>
 * Returns the tangent of arg in radians.
 * 
 * @see sin()
 * @see cos()
 */
function float tan(float arg);

///////////////////////////////////////////////////////////////////////////
// Encryption functions
// 
// These functions work using mcrypt.
// 
// This is an interface to the mcrypt library, which supports a wide variety
// of block algorithms such as DES, TripleDES, Blowfish (default), 3-WAY,
// SAFER-SK64, SAFER-SK128, TWOFISH, TEA, RC2 and GOST in CBC, OFB, CFB and
// ECB cipher modes. Additionally, it supports RC6 and IDEA which are
// considered "non-free".
// 
// To use it, download libmcrypt-x.x.tar.gz from here and follow the included
// installation instructions. You need to compile PHP with the --with-mcrypt
// parameter to enable this extension.
// 
// mcrypt can be used to encrypt and decrypt using the above mentioned
// ciphers. The four important mcrypt commands (mcrypt_cfb(), mcrypt_cbc(),
// mcrypt_ecb(), and mcrypt_ofb()) can operate in both modes which are named
// MCRYPT_ENCRYPT and MCRYPT_DECRYPT, respectively.
// Example 1. Encrypt an input value with TripleDES in ECB mode
// 
// <?php
// $key = "this is a very secret key";
// $input = "Let us meet at 9 o'clock at the secret place.";
// 
// $encrypted_data = mcrypt_ecb(MCRYPT_TripleDES, $key, $input, MCRYPT_ENCRYPT);
// ?>
// 
// This example will give you the encrypted data as a string in
// $encrypted_data.
// 
// mcrypt can operate in four cipher modes (CBC, OFB, CFB, and ECB). We will
// outline the normal use for each of these modes. For a more complete
// reference and discussion see Applied Cryptography by Schneier (ISBN
// 0-471-11709-9).
// 
//    * ECB (electronic codebook) is suitable for random data, such as
//      encrypting other keys. Since data there is short and random, the
//      disadvantages of ECB have a favorable negative effect.
// 
//    * CBC (cipher block chaining) is especially suitable for encrypting
//      files where the security is increased over ECB significantly.
// 
//    * CFB (cipher feedback) is the best mode for encrypting byte streams
//      where single bytes must be encrypted.
// 
//    * OFB (output feedback) is comparable to CFB, but can be used in
//      applications where error propagation cannot be tolerated.
// 
// PHP does not support encrypting/decrypting bit streams currently. As of
// now, PHP only supports handling of strings.
// 
// For a complete list of supported ciphers, see the defines at the end of
// mcrypt.h. The general rule is that you can access the cipher from PHP with
// MCRYPT_ciphername.
//
// You must (in CFB and OFB mode) or can (in CBC mode) supply an
// initialization vector (IV) to the respective cipher function. The IV must
// be unique and must be the same when decrypting/encrypting. With data which
// is stored encrypted, you can take the output of a function of the index
// under which the data is stored (e.g. the MD5 key of the filename).
// Alternatively, you can transmit the IV together with the encrypted data
// (see chapter 9.3 of Applied Cryptography by Schneier (ISBN 0-471-11709-9)
// for a discussion of this topic).
// 
// Here is a short list of ciphers which are currently supported by the mcrypt
// extension. If a cipher is not listed here, but is listed by mcrypt as
// supported, you can safely assume that this documentation is outdated.

/**/
global int MCRYPT_BLOWFISH;
global int MCRYPT_DES;
global int MCRYPT_TripleDES;
global int MCRYPT_ThreeWAY;
global int MCRYPT_GOST;
global int MCRYPT_CRYPT;
global int MCRYPT_DES_COMPAT;
global int MCRYPT_SAFER64;
global int MCRYPT_SAFER128;
global int MCRYPT_CAST128;
global int MCRYPT_TEAN;
global int MCRYPT_RC2;
global int MCRYPT_TWOFISH;    // (for older mcrypt 2.x versions)
global int MCRYPT_TWOFISH128; // (TWOFISHxxx are available in newer 2.x versions)
global int MCRYPT_TWOFISH192;
global int MCRYPT_TWOFISH256;
global int MCRYPT_RC6;
global int MCRYPT_IDEA;

/**
 * Get the name of the specified cipher
 * <p>
 * mcrypt_get_cipher_name() is used to get the name of the specified cipher.
 * <p>
 * mcrypt_get_cipher_name() takes the cipher number as an argument and returns
 * the name of the cipher or false, if the cipher does not exist.
 * <p>
 * <b>Example 1.</b> mcrypt_get_cipher_name example
 * <pre>
 *    &lt;?php
 *    $cipher = MCRYPT_TripleDES;
 *    print mcrypt_get_cipher_name($cipher);
 *    ?&gt;
 * </pre>
 * The above example will produce:
 * <pre>
 *    TripleDES
 * </pre>
 */
function string mcrypt_get_cipher_name(int cipher);
 
/**
 * Get the block size of the specified cipher
 * <p>
 * mcrypt_get_block_size() is used to get the size of a block of the specified
 * cipher.
 * <p>
 * mcrypt_get_block_size() takes one argument, the cipher and returns the size
 * in bytes.
 * 
 * @see mcrypt_get_key_size()
 */
function int mcrypt_get_block_size(int cipher);
 
/**
 * Get the key size of the specified cipher
 * <p>
 * mcrypt_get_key_size() is used to get the size of a key of the specified
 * cipher.
 * <p>
 * mcrypt_get_key_size() takes one argument, the cipher and returns the size
 * in bytes.
 * 
 * @see mcrypt_get_block_size()
 */
function int mcrypt_get_key_size(int cipher);
 
/**
 * mcrypt_create_iv() is used to create an IV.
 * <p>
 * mcrypt_create_iv() takes two arguments, size determines the size of the IV,
 * source specifies the source of the IV.
 * <p>
 * The source can be MCRYPT_RAND (system random number generator),
 * MCRYPT_DEV_RANDOM (read data from /dev/random) and MCRYPT_DEV_URANDOM (read
 * data from /dev/urandom). If you use MCRYPT_RAND, make sure to call {@link srand()}
 * before to initialize the random number generator.
 * <p>
 * <b>Example 1.</b> mcrypt_create_iv example
 * <pre>
 *    &lt;?php
 *    $cipher = MCRYPT_TripleDES;
 *    $block_size = mcrypt_get_block_size($cipher);
 *    $iv = mcrypt_create_iv($block_size, MCRYPT_DEV_RANDOM);
 *    ?&gt;
 * </pre>
 */
function string mcrypt_create_iv(int size, int source);
 
/**
 * Encrypt/decrypt data in CBC mode
 * <p>
 * mcrypt_cbc() encrypts or decrypts (depending on mode) the data with cipher
 * and key in CBC cipher mode and returns the resulting string.
 * <p>
 * cipher is one of the MCRYPT_ciphername constants.
 * <p>
 * key is the key supplied to the algorithm. It must be kept secret.
 * <p>
 * data is the data which shall be encrypted/decrypted.
 * <p>
 * mode is MCRYPT_ENCRYPT or MCRYPT_DECRYPT.
 * <p>
 * iv is the optional initialization vector.
 * 
 * @see mcrypt_cfb()
 * @see mcrypt_ecb()
 * @see mcrypt_ofb()
 */
function int mcrypt_cbc(int cipher, string key, string data, int mode, string [iv]);
 
/**
 * Encrypt/decrypt data in CFB mode
 * <p>
 * mcrypt_cfb() encrypts or decrypts (depending on mode) the data with cipher
 * and key in CFB cipher mode and returns the resulting string.
 * <p>
 * cipher is one of the MCRYPT_ciphername constants.
 * <p>
 * key is the key supplied to the algorithm. It must be kept secret.
 * <p>
 * data is the data which shall be encrypted/decrypted.
 * <p>
 * mode is MCRYPT_ENCRYPT or MCRYPT_DECRYPT.
 * <p>
 * iv is the initialization vector.
 * 
 * @see mcrypt_cbc()
 * @see mcrypt_ecb()
 * @see mcrypt_ofb()
 */
function int mcrypt_cfb(int cipher, string key, string data, int mode, string iv);
 
/**
 * Encrypt/decrypt data in ECB mode
 * <p>
 * mcrypt_ecb() encrypts or decrypts (depending on mode) the data with cipher
 * and key in ECB cipher mode and returns the resulting string.
 * <p>
 * cipher is one of the MCRYPT_ciphername constants.
 * <p>
 * key is the key supplied to the algorithm. It must be kept secret.
 * <p>
 * data is the data which shall be encrypted/decrypted.
 * <p>
 * mode is MCRYPT_ENCRYPT or MCRYPT_DECRYPT.
 * 
 * @see mcrypt_cbc()
 * @see mcrypt_cfb()
 * @see mcrypt_ofb()
 */
function int mcrypt_ecb(int cipher, string key, string data, int mode);
 
/**
 * Encrypt/decrypt data in OFB mode
 * <p>
 * mcrypt_ofb() encrypts or decrypts (depending on mode) the data with cipher
 * and key in OFB cipher mode and returns the resulting string.
 * <p>
 * cipher is one of the MCRYPT_ciphername constants.
 * <p>
 * key is the key supplied to the algorithm. It must be kept secret.
 * <p>
 * data is the data which shall be encrypted/decrypted.
 * <p>
 * mode is MCRYPT_ENCRYPT or MCRYPT_DECRYPT.
 * <p>
 * iv is the initialization vector.
 * 
 * @see mcrypt_cbc()
 * @see mcrypt_cfb()
 * @see mcrypt_ecb()
 */
function int mcrypt_ofb(int cipher, string key, string data, int mode, string iv);


///////////////////////////////////////////////////////////////////////////
// Hash functions
// 
// These functions are intended to work with mhash.
// 
// This is an interface to the mhash library. mhash supports a wide variety of
// hash algorithms such as MD5, SHA1, GOST, and many others.
// 
// To use it, download the mhash distribution from its web site and follow the
// included installation instructions. You need to compile PHP with the
// --with-mhash parameter to enable this extension.
// 
// mhash can be used to create checksums, message digests, and more.
// 
// Example 1. Compute the SHA1 key and print it out as hex
// 
// <?php
// $input = "Let us meet at 9 o' clock at the secret place.";
// $hash = mhash(MHASH_SHA1, $input);
// print "The hash is ".bin2hex($hash)."\n";
// ?>
// 
// This will produce:
// 
// The hash is d3b85d710d8f6e4e5efd4d5e67d041f9cecedafe
// 
// For a complete list of supported hashes, refer to the documentation of
// mhash. The general rule is that you can access the hash algorithm from PHP
// with MHASH_HASHNAME. For example, to access HAVAL you use the PHP constant
// MHASH_HAVAL.
// 
// Here is a list of hashes which are currently supported by mhash. If a hash
// is not listed here, but is listed by mhash as supported, you can safely
// assume that this documentation is outdated.

/**/
global int MHASH_MD5;
global int MHASH_SHA1;
global int MHASH_HAVAL;
global int MHASH_RIPEMD160;
global int MHASH_RIPEMD128;
global int MHASH_SNEFRU;
global int MHASH_TIGER;
global int MHASH_GOST;
global int MHASH_CRC32;
global int MHASH_CRC32B;
 
/**
 * Get the name of the specified hash
 * <p>
 * mhash_get_hash_name() is used to get the name of the specified hash.
 * <p>
 * mhash_get_hash_name() takes the hash id as an argument and returns the name
 * of the hash or false, if the hash does not exist.
 * <p>
 * <b>Example 1.</b> mhash_get_hash_name example
 * <pre>
 *    &lt;?php
 *    $hash = MHASH_MD5;
 *    <p>
 *    print mhash_get_hash_name($hash);
 *    ?&gt;
 * </pre>
 * The above example will print out:
 * <pre>
 *    MD5
 * </pre>
 */
function string mhash_get_hash_name(int hash);
 
/**
 * Get the block size of the specified hash
 * <p>
 * mhash_get_block_size() is used to get the size of a block of the specified
 * hash.
 * <p>
 * mhash_get_block_size() takes one argument, the hash and returns the size in
 * bytes or false, if the hash does not exist.
 */
function int mhash_get_block_size(int hash);
 
/**
 * Get the highest available hash id
 * <p>
 * mhash_count() returns the highest available hash id. Hashes are numbered
 * from 0 to this hash id.
 * <p>
 * <b>Example 1.</b> Traversing all hashes
 * <pre>
 *    &lt;?php
 *    <p>
 *    $nr = mhash_count();
 *    <p>
 *    for($i = 0; $i &lt;= $nr; $i++) {
 *        echo sprintf("The blocksize of %s is %d\n",
 *                mhash_get_hash_name($i),
 *                mhash_get_block_size($i));
 *    }
 *    ?&gt;
 * </pre>
 */
function int mhash_count(void );
 
/**
 * Compute hash
 * <p>
 * mhash() applies a hash function specified by hash to the data and returns
 * the resulting hash (also called digest).
 */
function string mhash(int hash, string data);


///////////////////////////////////////////////////////////////////////////
// Miscellaneous functions
//
// These functions were placed here because none of the other categories
// seemed to fit.
 
/**
 * Return true if client disconnected
 * <p>
 * Returns true if client disconnected. See the Connection Handling
 * description in the Feature chapter for a complete explanation.
 */
function int connection_aborted(void );

/**
 * Returns connection status bitfield
 * <p>
 * Returns the connection status bitfield. See the Connection Handling
 * description in the Feature chapter for a complete explanation.
 */
function int connection_status(void );

/**
 * Return true if client disconnected
 * <p>
 * Returns true if script timed out. See the Connection Handling description
 * in the Feature chapter for a complete explanation.
 */
function int connection_timeout(void );
 
/**
 * Evaluate a string as PHP code
 * <p>
 * eval() evaluates the string given in code_str as PHP code. Among other
 * things, this can be useful for storing code in a database text field for
 * later execution.
 * <p>
 * There are some factors to keep in mind when using eval(). Remember that the
 * string passed must be valid PHP code, including things like terminating
 * statements with a semicolon so the parser doesn't die on the line after the
 * eval(), and properly escaping things in code_str.
 * <p>
 * Also remember that variables given values under eval() will retain these
 * values in the main script afterwards.
 * <p>
 * <b>Example 1.</b> eval() example - simple text merge
 * <pre>
 *    &lt;?php
 *    $string = 'cup';
 *    $name = 'coffee';
 *    $str = 'This is a $string with my $name in it.&lt;br&gt;';
 *    echo $str;
 *    eval( "\$str = \"$str\";" );
 *    echo $str;
 *    ?&gt;
 * </pre>
 * The above example will show:
 * <pre>
 *    This is a $string with my $name in it.
 *    This is a cup with my coffee in it.
 * </pre>
 */
function void eval(string code_str);
 
/**
 * Output a message and terminate the current script
 * <p>
 * This language construct outputs a message and terminates parsing of the
 * script. It does not return.
 * <p>
 * <b>Example 1.</b> die example
 * <pre>
 *    &lt;?php
 *    $filename = '/path/to/data-file';
 *    $file = fopen($filename, 'r')
 *      or die "unable to open file ($filename)";
 *    ?&gt;
 * </pre>
 */
function void die(string message);
 
/**
 * Terminate current script
 * <p>
 * This language construct terminates parsing of the script. It does not
 * return.
 */
function void exit(void);
 
/**
 * Return true if the given function has been defined
 * <p>
 * Checks the list of defined functions for function_name. Returns true if the
 * given function name was found, false otherwise.
 * 
 */
function int function_exists(string function_name);
 
/**
 * This function sets whether a client disconnect should cause a script to be
 * aborted. It will return the previous setting and can be called without an
 * argument to not change the current setting and only return the current
 * setting. See the Connection Handling section in the Features chapter for a
 * complete description of connection handling in PHP.
 */
function int ignore_user_abort(int [setting]);
 
/**
 * This function parses a binary IPTC block into its single tags. It returns
 * an array using the tagmarker as an index and the value as the value. It
 * returns false on error or if no IPTC data was found. See {@link GetImageSize()} for
 * a sample.
 */
function array iptcparse(string iptcblock);
 
/**
 * Leak memory
 * <p>
 * Leak() leaks the specified amount of memory.
 * <p>
 * This is useful when debugging the memory manager, which automatically
 * cleans up "leaked" memory when each request is completed.
 */
function void leak(int bytes);
 
/**
 * pack data into binary string
 * <p>
 * Pack given arguments into binary string according to format. Returns binary
 * string containing data.
 * <p>
 * The idea to this function was taken from Perl and all formatting codes work
 * the same as there. The format string consists of format codes followed by
 * an optional repeater argument. The repeater argument can be either an
 * integer value or * for repeating to the end of the input data. For a, A, h,
 * H the repeat count specifies how many characters of one data argument are
 * taken, for @ it is the absolute position where to put the next data, for
 * everything else the repeat count specifies how many data arguments are
 * consumed and packed into the resulting binary string. Currently implemented
 * are
 * <ul>
 * <li> a NUL-padded string
 * <li> A SPACE-padded string
 * <li> h Hex string, low nibble first
 * <li> H Hex string, high nibble first
 * <li> c signed char
 * <li> C unsigned char
 * <li> s signed short (always 16 bit, machine byte order)
 * <li> S unsigned short (always 16 bit, machine byte order)
 * <li> n unsigned short (always 16 bit, big endian byte order)
 * <li> v unsigned short (always 16 bit, little endian byte order)
 * <li> i signed integer (machine dependant size and byte order)
 * <li> I unsigned integer (machine dependant size and byte order)
 * <li> l signed long (always 32 bit, machine byte order)
 * <li> L unsigned long (always 32 bit, machine byte order)
 * <li> N unsigned long (always 32 bit, big endian byte order)
 * <li> V unsigned long (always 32 bit, little endian byte order)
 * <li> f float (machine dependent size and representation)
 * <li> d double (machine dependent size and representation)
 * <li> x NUL byte
 * <li> X Back up one byte
 * <li> @ NUL-fill to absolute position
 * </ul>
 * <b>Example 1.</b> pack format string
 * <pre>
 *    $binarydata = pack("nvc*", 0x1234, 0x5678, 65, 66);
 * </pre>
 * The resulting binary string will be 6 bytes long and contain the byte
 * sequence 0x12, 0x34, 0x78, 0x56, 0x41, 0x42.
 * <p>
 * Note that the distinction between signed and unsigned values only affects
 * the function {@link unpack()}, where as function pack() gives the same result for
 * signed and unsigned format codes.
 * <p>
 * Also note that PHP internally stores integral values as signed values of a
 * machine dependant size. If you give it an unsigned integral value too large
 * to be stored that way it is converted to a double which often yields an
 * undesired result.
 */
function string pack(string format, mixed [args]...);
 
/**
 * <p>
 * Registers the function named by func to be executed when script processing
 * is complete.
 * <p>
 * Common Pitfalls:
 * <p>
 * Since no output is allowed to the browser in this function, you will be
 * unable to debug it using statements such as print or echo.
 */
function int register_shutdown_function(string func);
 
/**
 * generates a storable representation of a value
 * <p>
 * serialize() returns a string containing a byte-stream representation of
 * value that can be stored anywhere.
 * <p>
 * This is useful for storing or passing PHP values around without losing
 * their type and structure.
 * <p>
 * To make the serialized string into a PHP value again, use {@link unserialize()}.
 * serialize() handles the types integer, double, string, array
 * (multidimensional) and object (object properties will be serialized, but
 * methods are lost).
 * <p>
 * <b>Example 1.</b> serialize example
 * <pre>
 *    // $session_data contains a multi-dimensional array with session
 *    // information for the current user.  We use serialize() to store
 *    // it in a database at the end of the request.
 *    $conn = odbc_connect("webdb", "php", "chicken");
 *    $stmt = odbc_prepare($conn,
 *                         "UPDATE sessions SET data = ? WHERE id = ?");
 *    $sqldata = array(serialize($session_data), $PHP_AUTH_USER);
 *    if (!odbc_execute($stmt, &$sqldata)) {
 *        $stmt = odbc_prepare($conn,
 *                             "INSERT INTO sessions (id, data) VALUES(?, ?)");
 *        if (!odbc_execute($stmt, &$sqldata)) {
 *            // Something went wrong.  Bitch, whine and moan. 
 *        }
 *    }
 * </pre>
 */
function string serialize(mixed value);
 
/**
 * Delay execution
 * <p>
 * The sleep function delays program execution for the given number of
 * seconds.
 * 
 * @see usleep()
 */
function void sleep(int seconds);
 
/**
 * unpack data from binary string
 * <p>
 * Unpack from binary string into array according to format. Returns array
 * containing unpacked elements of binary string.
 * <p>
 * Unpack works slightly different from Perl as the unpacked data is stored in
 * an associative array. To accomplish this you have to name the different
 * format codes and separate them by a slash /.
 * <p>
 * <b>Example 1.</b> unpack format string
 * <pre>
 *    $array = unpack("c2chars/nint", $binarydata);
 * </pre>
 * The resulting array will contain the entries "chars1", "chars2" and "int".
 * <p>
 * For an explanation of the format codes see also: {@link pack()}
 * <p>
 * Note that PHP internally stores integral values as signed. If you unpack a
 * large unsigned long and it is of the same size as PHP internally stored
 * values the result will be a negative number even though unsigned unpacking
 * was specified.
 */
function array unpack(string format, string data);
 
/**
 * creates a PHP value from a stored representation
 * <p>
 * unserialize() takes a single serialized variable (see {@link serialize()}) and
 * converts it back into a PHP value. The converted value is returned, and can
 * be an integer, double, string, array or object. If an object was
 * serialized, its methods are not preserved in the returned value.
 * <p>
 * <b>Example 1.</b> unserialize example
 * <pre>
 *    // Here, we use unserialize() to load session data from a database
 *    // into $session_data.  This example complements the one described
 *    // with {@link serialize()}.
 *    $conn = odbc_connect("webdb", "php", "chicken");
 *    $stmt = odbc_prepare($conn, "SELECT data FROM sessions WHERE id = ?");
 *    $sqldata = array($PHP_AUTH_USER);
 *    if (!odbc_execute($stmt, &$sqldata) || !odbc_fetch_into($stmt, &$tmp)) {
 *        // if the execute or fetch fails, initialize to empty array
 *        $session_data = array();
 *    } else {
 *        // we should now have the serialized data in $tmp[0].
 *        $session_data = unserialize($tmp[0]);
 *        if (!is_array($session_data)) {
 *            // something went wrong, initialize to empty array
 *            $session_data = array();
 *        }
 *    }
 * </pre>
 */
function mixed unserialize(string str);
 
/**
 * generate a unique id
 * <p>
 * uniqid() returns a prefixed unique identifier based on current time in
 * microseconds. The prefix can be useful for instance if you generate
 * identifiers simultaneously on several hosts that might happen to generate
 * the identifier at the same microsecond. The prefix can be up to 114
 * characters long.
 * <p>
 * If you need a unique identifier or token and you intend to give out that
 * token to the user via the network (i.e. session cookies), it is recommended
 * that you use something along the lines of
 * <pre>
 *    $token = md5(uniqid("")); // no random portion
 *    $better_token = md5(uniqid(rand())); // better, difficult to guess
 * </pre>
 * This will create a 32 character identifier (a 128 bit hex number) that is
 * extremely difficult to predict.
 */
function int uniqid(string prefix);
 
/**
 * Delay execution in microseconds
 * <p>
 * The sleep function delays program execution for the given number of
 * micro_seconds.
 * 
 * @see sleep()
 */
function void usleep(int micro_seconds);


///////////////////////////////////////////////////////////////////////////
// mSQL functions
//
 
/**
 * send mSQL query
 * <p>
 * Returns a positive mSQL query identifier to the query result, or false on
 * error.
 * <p>
 * msql() selects a database and executes a query on it. If the optional link
 * identifier isn't specified, the function will try to find an open link to
 * the mSQL server and if no such link is found it'll try to create one as if
 * {@link msql_connect()} was called with no arguments (see {@link msql_connect()}).
 */
function int msql(string database, string query, int link_identifier);
 
/**
 * returns number of affected rows
 * <p>
 * Returns number of affected ("touched") rows by a specific query (i.e. the
 * number of rows returned by a SELECT, the number of rows modified by an
 * update, or the number of rows removed by a delete).
 * 
 * @see msql_query()
 */
function int msql_affected_rows(int query_identifier);
 
/**
 * close mSQL connection
 * <p>
 * Returns true on success, false on error.
 * <p>
 * msql_close() closes the link to a mSQL database that's associated with the
 * specified link identifier. If the link identifier isn't specified, the last
 * opened link is assumed.
 * <p>
 * Note that this isn't usually necessary, as non-persistent open links are
 * automatically closed at the end of the script's execution.
 * <p>
 * msql_close() will not close persistent links generated by {@link msql_pconnect()}.
 * 
 * @see msql_connect()
 * @see msql_pconnect()
 */
function int msql_close(int link_identifier);
 
/**
 * open mSQL connection
 * <p>
 * Returns a positive mSQL link identifier on success, or false on error.
 * <p>
 * msql_connect() establishes a connection to a mSQL server. The hostname
 * argument is optional, and if it's missing, localhost is assumed.
 * <p>
 * In case a second call is made to msql_connect() with the same arguments, no
 * new link will be established, but instead, the link identifier of the
 * already opened link will be returned.
 * <p>
 * The link to the server will be closed as soon as the execution of the
 * script ends, unless it's closed earlier by explicitly calling {@link msql_close()}.
 * 
 * @see msql_pconnect()
 * @see msql_close()
 */
function int msql_connect(string hostname);
 
/**
 * create mSQL database
 * <p>
 * msql_create_db() attempts to create a new database on the server associated
 * with the specified link identifier.
 * 
 * @see msql_drop_db()
 */
function int msql_create_db(string database_name, int [link_identifier] );
 
/**
 * create mSQL database
 * <p>
 * Identical to msql_create_db().
 */
function int msql_createdb(string database name, int [link_identifier] );
 
/**
 * move internal row pointer
 * <p>
 * Returns true on success, false on failure.
 * <p>
 * msql_data_seek() moves the internal row pointer of the mSQL result
 * associated with the specified query identifier to pointer to the specifyed
 * row number. The next call to {@link msql_fetch_row()} would return that row.
 * 
 * @see msql_fetch_row()
 */
function int msql_data_seek(int query_identifier, int row_number);
 
/**
 * get current mSQL database name
 * <p>
 * msql_dbname() returns the database name stored in position i of the result
 * pointer returned from the {@link msql_listdbs()} function. The {@link msql_numrows()}
 * function can be used to determine how many database names are available.
 */
function string msql_dbname(int query_identifier, int i);
 
/**
 * drop (delete) mSQL database
 * <p>
 * Returns true on success, false on failure.
 * <p>
 * msql_drop_db() attempts to drop (remove) an entire database from the server
 * associated with the specified link identifier.
 * 
 * @see msql_create_db()
 */
function int msql_drop_db(string database_name, int link_identifier);
 
/**
 * drop (delete) mSQL database
 * <p>
 * Returns true on success, false on failure.
 * <p>
 * msql_drop_db() attempts to drop (remove) an entire database from the server
 * associated with the specified link identifier.
 * 
 * @see msql_drop_db()
 * @see msql_create_db()
 */
function int msql_dropdb(string database_name, int link_identifier);
 
/**
 * returns error message of last msql call
 * <p>
 * Errors coming back from the mSQL database backend no longer issue warnings.
 * Instead, use these functions to retrieve the error string.
 */
function string msql_error( );
 
/**
 * fetch row as array
 * <p>
 * Returns an array that corresponds to the fetched row, or false if there are
 * no more rows.
 * <p>
 * msql_fetch_array() is an extended version of {@link msql_fetch_row()}. In addition
 * to storing the data in the numeric indices of the result array, it also
 * stores the data in associative indices, using the field names as keys.
 * <p>
 * The second optional argument result_type in {@link msql_fetch_array()} is a
 * constant and can take the following values: MSQL_ASSOC, MSQL_NUM, and
 * MYSQL_BOTH.
 * <p>
 * Be careful if you are retrieving results from a query that may return a
 * record that contains only one field that has a value of 0 (or an empty
 * string, or NULL).
 * <p>
 * An important thing to note is that using {@link msql_fetch_array()} is NOT
 * significantly slower than using msql_fetch_row(), while it provides a
 * significant added value.
 * <p>
 * For further details, also see {@link msql_fetch_row()}
 */
function int msql_fetch_array(int query_identifier, int [result_type] );
 
/**
 * get field information
 * <p>
 * Returns an object containing field information
 * <p>
 * msql_fetch_field() can be used in order to obtain information about fields
 * in a certain query result. If the field offset isn't specified, the next
 * field that wasn't yet retreived by msql_fetch_field() is retreived.
 * <p>
 * The properties of the object are:
 * <ul>
 * <li> name - column name
 * <li> table - name of the table the column belongs to
 * <li> not_null - 1 if the column cannot be null
 * <li> primary_key - 1 if the column is a primary key
 * <li> unique - 1 if the column is a unique key
 * <li> type - the type of the column
 * </ul>
 *
 * @see msql_field_seek()
 */
function object msql_fetch_field(int query_identifier, int field_offset);
 
/**
 * fetch row as object
 * <p>
 * Returns an object with properties that correspond to the fetched row, or
 * false if there are no more rows.
 * <p>
 * msql_fetch_object() is similar to {@link msql_fetch_array()}, with one difference -
 * an object is returned, instead of an array. Indirectly, that means that you
 * can only access the data by the field names, and not by their offsets
 * (numbers are illegal property names).
 * <p>
 * The optional second argument result_type in {@link msql_fetch_array()} is a
 * constant and can take the following values: MSQL_ASSOC, MSQL_NUM, and
 * MSQL_BOTH.
 * <p>
 * Speed-wise, the function is identical to {@link msql_fetch_array()}, and almost as
 * quick as {@link msql_fetch_row()} (the difference is insignificant).
 * 
 * @see msql_fetch_array()
 * @see msql_fetch_row()
 */
function int msql_fetch_object(int query_identifier, int [result_type] );
 
/**
 * get row as enumerated array
 * <p>
 * Returns an array that corresponds to the fetched row, or false if there are
 * no more rows.
 * <p>
 * msql_fetch_row() fetches one row of data from the result associated with
 * the specified query identifier. The row is returned as an array. Each
 * result column is stored in an array offset, starting at offset 0.
 * <p>
 * Subsequent call to {@link msql_fetch_row()} would return the next row in the result
 * set, or false if there are no more rows.
 * 
 * @see msql_fetch_array()
 * @see msql_fetch_object()
 * @see msql_data_seek()
 * @see msql_result()
 */
function array msql_fetch_row(int query_identifier);
 
/**
 * get field name
 * <p>
 * msql_fieldname() returns the name of the specified field. query_identifier
 * is the query identifier, and field is the field index.
 * msql_fieldname($result, 2); will return the name of the second field in the
 * result associated with the result identifier.
 */
function string msql_fieldname(int query_identifier, int field);
 
/**
 * set field offset
 * <p>
 * Seeks to the specified field offset. If the next call to {@link msql_fetch_field()}
 * won't include a field offset, this field would be returned.
 * 
 * @see msql_fetch_field()
 */
function int msql_field_seek(int query_identifier, int field_offset);
 
/**
 * get table name for field
 * <p>
 * Returns the name of the table field was fetched from.
 */
function int msql_fieldtable(int query_identifier, int field);
 
/**
 * get field type
 * <p>
 * msql_fieldtype() is similar to the {@link msql_fieldname()} function. The arguments
 * are identical, but the field type is returned. This will be one of "int",
 * "string" or "real".
 */
function string msql_fieldtype(int query_identifier, int i);
 
/**
 * get field flags
 * <p>
 * msql_fieldflags() returns the field flags of the specified field. Currently
 * this is either, "not null", "primary key", a combination of the two or ""
 * (an empty string).
 */
function string msql_fieldflags(int query_identifier, int i);
 
/**
 * get field length
 * <p>
 * msql_fieldlen() returns the length of the specified field.
 */
function int msql_fieldlen(int query_identifier, int i);
 
/**
 * free result memory
 * <p>
 * msql_free_result() frees the memory associated with query_identifier. When
 * PHP completes a request, this memory is freed automatically, so you only
 * need to call this function when you want to make sure you don't use too
 * much memory while the script is running.
 */
function int msql_free_result(int query_identifier);
 
/**
 * free result memory
 * <p>
 * msql_free_result() frees the memory associated with query_identifier. When
 * PHP completes a request, this memory is freed automatically, so you only
 * need to call this function when you want to make sure you don't use too
 * much memory while the script is running.
 *
 * @see msql_free_result()
 */
function int msql_freeresult(int query_identifier);
 
/**
 * list result fields
 * <p>
 * msql_list_fields() retrieves information about the given tablename.
 * Arguments are the database name and the table name. A result pointer is
 * returned which can be used with {@link msql_fieldflags()}, {@link msql_fieldlen()},
 * {@link msql_fieldname()}, and {@link msql_fieldtype()}. A query identifier is a positive
 * integer. The function returns -1 if a error occurs. A string describing the
 * error will be placed in $phperrmsg, and unless the function was called as
 * @msql_list_fields() then this error string will also be printed out.
 * 
 * @see msql_error()
 */
function int msql_list_fields(string database, string tablename);
 
/**
 * list result fields
 * <p>
 * msql_list_fields() retrieves information about the given tablename.
 * Arguments are the database name and the table name. A result pointer is
 * returned which can be used with {@link msql_fieldflags()}, {@link msql_fieldlen()},
 * {@link msql_fieldname()}, and {@link msql_fieldtype()}. A query identifier is a positive
 * integer. The function returns -1 if a error occurs. A string describing the
 * error will be placed in $phperrmsg, and unless the function was called as
 * @msql_list_fields() then this error string will also be printed out.
 * 
 * @see msql_list_fields()
 * @see msql_error()
 */
function int msql_listfields(string database, string tablename);
 
/**
 * list mSQL databases on server
 * <p>
 * msql_list_dbs() will return a result pointer containing the databases
 * available from the current msql daemon. Use the {@link msql_dbname()} function to
 * traverse this result pointer.
 */
function int msql_list_dbs(void);
 
/**
 * list mSQL databases on server
 * <p>
 * msql_list_dbs() will return a result pointer containing the databases
 * available from the current msql daemon. Use the {@link msql_dbname()} function to
 * traverse this result pointer.
 *
 * @see msql_listdbs()
 */
function int msql_listdbs(void);
 
/**
 * list tables in an mSQL database
 * <p>
 * msql_list_tables() takes a database name and result pointer much like the
 * {@link msql()} function. The {@link msql_tablename()} function should be used to extract
 * the actual table names from the result pointer.
 */
function int msql_list_tables(string database);
 
/**
 * list tables in an mSQL database
 * <p>
 * msql_list_tables() takes a database name and result pointer much like the
 * {@link msql()} function. The {@link msql_tablename()} function should be used to extract
 * the actual table names from the result pointer.
 *
 * @see msql_list_tables()
 */
function int msql_listtables(string database);
 
/**
 * get number of fields in result
 * <p>
 * msql_num_fields() returns the number of fields in a result set.
 * 
 * @see msql()
 * @see msql_query()
 * @see msql_fetch_field()
 * @see msql_num_rows()
 */
function int msql_num_fields(int query_identifier);
 
/**
 * get number of rows in result
 * <p>
 * msql_num_rows() returns the number of rows in a result set.
 * 
 * @see msql()
 * @see msql_query()
 * @see msql_fetch_row()
 */
function int msql_num_rows(int query_identifier);
 
/**
 * get number of fields in result
 * <p>
 * Identical to msql_num_fields().
 */
function int msql_numfields(int query_identifier);
 
/**
 * get number of rows in result
 * <p>
 * Identical to msql_num_rows().
 */
function int msql_numrows(void);
 
/**
 * open persistent mSQL connection
 * <p>
 * Returns a positive mSQL persistent link identifier on success, or false on
 * error.
 * <p>
 * msql_pconnect() acts very much like {@link msql_connect()} with two major
 * differences.
 * <p>
 * First, when connecting, the function would first try to find a (persistent)
 * link that's already open with the same host. If one is found, an identifier
 * for it will be returned instead of opening a new connection.
 * <p>
 * Second, the connection to the SQL server will not be closed when the
 * execution of the script ends. Instead, the link will remain open for future
 * use (msql_close() will not close links established by msql_pconnect()).
 * <p>
 * This type of links is therefore called 'persistent'.
 */
function int msql_pconnect(string hostname);
 
/**
 * send mSQL query
 * <p>
 * msql_query() sends a query to the currently active database on the server
 * that's associated with the specified link identifier. If the link
 * identifier isn't specified, the last opened link is assumed. If no link is
 * open, the function tries to establish a link as if {@link msql_connect()} was
 * called, and use it.
 * <p>
 * Returns a positive mSQL query identifier on success, or false on error.
 * 
 * @see msql()
 * @see msql_select_db()
 * @see msql_connect()
 */
function int msql_query(string query, int link_identifier);
 
/**
 * make regular expression for case insensitive match
 * 
 * @see sql_regcase()
 */
function msql_regcase();
 
/**
 * get result data
 * <p>
 * Returns the contents of the cell at the row and offset in the specified
 * mSQL result set.
 * <p>
 * msql_result() returns the contents of one cell from a mSQL result set. The
 * field argument can be the field's offset, or the field's name, or the
 * field's table dot field's name (fieldname.tablename). If the column name
 * has been aliased ('select foo as bar from...'), use the alias instead of
 * the column name.
 * <p>
 * When working on large result sets, you should consider using one of the
 * functions that fetch an entire row (specified below). As these functions
 * return the contents of multiple cells in one function call, they're MUCH
 * quicker than msql_result(). Also, note that specifying a numeric offset for
 * the field argument is much quicker than specifying a fieldname or
 * tablename.fieldname argument.
 * <p>
 * Recommended high-performance alternatives: {@link msql_fetch_row()},
 * msql_fetch_array(), and {@link msql_fetch_object()}.
 */
function int msql_result(int query_identifier, int i, mixed field);
 
/**
 * select mSQL database
 * <p>
 * Returns true on success, false on error.
 * <p>
 * msql_select_db() sets the current active database on the server that's
 * associated with the specified link identifier. If no link identifier is
 * specified, the last opened link is assumed. If no link is open, the
 * function will try to establish a link as if {@link msql_connect()} was called, and
 * use it.
 * <p>
 * Every subsequent call to {@link msql_query()} will be made on the active database.
 * 
 * @see msql_connect()
 * @see msql_pconnect()
 * @see msql_query()
 */
function int msql_select_db(string database_name, int link_identifier);
 
/**
 * select mSQL database
 * <p>
 * Returns true on success, false on error.
 * <p>
 * msql_select_db() sets the current active database on the server that's
 * associated with the specified link identifier. If no link identifier is
 * specified, the last opened link is assumed. If no link is open, the
 * function will try to establish a link as if {@link msql_connect()} was called, and
 * use it.
 * <p>
 * Every subsequent call to {@link msql_query()} will be made on the active database.
 * 
 * @see msql_select_db()
 * @see msql_connect()
 * @see msql_pconnect()
 * @see msql_query()
 */
function int msql_selectdb(string database_name, int link_identifier);
 
/**
 * get table name of field
 * <p>
 * msql_tablename() takes a result pointer returned by the {@link msql_list_tables()}
 * function as well as an integer index and returns the name of a table. The
 * {@link msql_numrows()} function may be used to determine the number of tables in
 * the result pointer.
 * <p>
 * <b>Example 1.</b> msql_tablename() example
 * <pre>
 *    &lt;?php
 *    msql_connect ("localhost");
 *    $result = msql_list_tables("wisconsin");
 *    $i = 0;
 *    while ($i &lt; msql_numrows($result)) {
 *        $tb_names[$i] = msql_tablename($result, $i);
 *        echo $tb_names[$i] . "&lt;BR&gt;";
 *        $i++;
 *    }
 *    ?&gt;
 * </pre>
 */
function string msql_tablename(int query_identifier, int field);


///////////////////////////////////////////////////////////////////////////
// Microsoft SQL Server functions
// 
 
/**
 * close MS SQL Server connection
 * <p>
 * Returns: true on success, false on error
 * <p>
 * mssql_close() closes the link to a MS SQL Server database that's associated
 * with the specified link identifier. If the link identifier isn't specified,
 * the last opened link is assumed.
 * <p>
 * Note that this isn't usually necessary, as non-persistent open links are
 * automatically closed at the end of the script's execution.
 * <p>
 * mssql_close() will not close persistent links generated by
 * {@link mssql_pconnect()}.
 * 
 * @see mssql_connect()
 * @see mssql_pconnect()
 */
function int mssql_close(int link_identifier);
 
/**
 * open MS SQL server connection
 * <p>
 * Returns: A positive MS SQL link identifier on success, or false on error.
 * <p>
 * mssql_connect() establishes a connection to a MS SQL server. The servername
 * argument has to be a valid servername that is defined in the 'interfaces'
 * file.
 * <p>
 * In case a second call is made to mssql_connect() with the same arguments,
 * no new link will be established, but instead, the link identifier of the
 * already opened link will be returned.
 * <p>
 * The link to the server will be closed as soon as the execution of the
 * script ends, unless it's closed earlier by explicitly calling
 * {@link mssql_close()}.
 * 
 * @see mssql_pconnect()
 * @see mssql_close()
 */
function int mssql_connect(string servername, string username, string password);
 
/**
 * move internal row pointer
 * <p>
 * Returns: true on success, false on failure
 * <p>
 * mssql_data_seek() moves the internal row pointer of the MS SQL result
 * associated with the specified result identifier to pointer to the specifyed
 * row number. The next call to {@link mssql_fetch_row()} would return that row.
 * 
 * @see mssql_data_seek()
 */
function int mssql_data_seek(int result_identifier, int row_number);
 
/**
 * fetch row as array
 * <p>
 * Returns: An array that corresponds to the fetched row, or false if there
 * are no more rows.
 * <p>
 * mssql_fetch_array() is an extended version of {@link mssql_fetch_row()}. In
 * addition to storing the data in the numeric indices of the result array, it
 * also stores the data in associative indices, using the field names as keys.
 * <p>
 * An important thing to note is that using mssql_fetch_array() is NOT
 * significantly slower than using {@link mssql_fetch_row()}, while it provides a
 * significant added value.
 * <p>
 * For further details, also see mssql_fetch_row()
 */
function int mssql_fetch_array(int result);
 
/**
 * get field information
 * <p>
 * Returns an object containing field information.
 * <p>
 * mssql_fetch_field() can be used in order to obtain information about fields
 * in a certain query result. If the field offset isn't specified, the next
 * field that wasn't yet retreived by mssql_fetch_field() is retreived.
 * <p>
 * The properties of the object are:
 * <ul>
 * <li> name - column name. if the column is a result of a function, this
 *      property is set to computed#N, where #N is a serial number.
 * <li> column_source - the table from which the column was taken
 * <li> max_length - maximum length of the column
 * <li> numeric - 1 if the column is numeric
 * </ul>
 *
 * @see mssql_field_seek()
 */
function object mssql_fetch_field(int result, int field_offset);
 
/**
 * fetch row as object
 * <p>
 * Returns: An object with properties that correspond to the fetched row, or
 * false if there are no more rows.
 * <p>
 * mssql_fetch_object() is similar to {@link mssql_fetch_array()}, with one difference
 * - an object is returned, instead of an array. Indirectly, that means that
 * you can only access the data by the field names, and not by their offsets
 * (numbers are illegal property names).
 * <p>
 * Speed-wise, the function is identical to {@link mssql_fetch_array()}, and almost as
 * quick as {@link mssql_fetch_row()} (the difference is insignificant).
 * 
 * @see mssql_fetch_array()
 * @see mssql_fetch_row()
 */
function int mssql_fetch_object(int result);
 
/**
 * get row as enumerated array
 * <p>
 * Returns: An array that corresponds to the fetched row, or false if there
 * are no more rows.
 * <p>
 * mssql_fetch_row() fetches one row of data from the result associated with
 * the specified result identifier. The row is returned as an array. Each
 * result column is stored in an array offset, starting at offset 0.
 * <p>
 * Subsequent call to mssql_fetch_rows() would return the next row in the
 * result set, or false if there are no more rows.
 * 
 * @see mssql_fetch_array()
 * @see mssql_fetch_object()
 * @see mssql_data_seek()
 * @see mssql_fetch_lengths()
 * @see mssql_result()
 */
function array mssql_fetch_row(int result);
 
/**
 * set field offset
 * <p>
 * Seeks to the specified field offset. If the next call to
 * {@link mssql_fetch_field()} won't include a field offset, this field would be
 * returned.
 * 
 * @see mssql_fetch_field()
 */
function int mssql_field_seek(int result, int field_offset);
 
/**
 * free result memory
 * <p>
 * mssql_free_result() only needs to be called if you are worried about using
 * too much memory while your script is running. All result memory will
 * automatically be freed when the script, you may call mssql_free_result()
 * with the result identifier as an argument and the associated result memory
 * will be freed.
 */
function int mssql_free_result(int result);
 
/**
 * get number of fields in result
 * <p>
 * mssql_num_fields() returns the number of fields in a result set.
 * 
 * @see mssql_db_query()
 * @see mssql_query()
 * @see mssql_fetch_field()
 * @see mssql_num_rows()
 */
function int mssql_num_fields(int result);
 
/**
 * get number of rows in result
 * <p>
 * mssql_num_rows() returns the number of rows in a result set.
 * 
 * @see mssql_db_query()
 * @see mssql_query()
 * @see mssql_fetch_row()
 */
function int mssql_num_rows(string result);
 
/**
 * open persistent MS SQL connection
 * <p>
 * Returns: A positive MS SQL persistent link identifier on success, or false
 * on error
 * <p>
 * mssql_pconnect() acts very much like mssql_connect() with two major
 * differences.
 * <p>
 * First, when connecting, the function would first try to find a (persistent)
 * link that's already open with the same host, username and password. If one
 * is found, an identifier for it will be returned instead of opening a new
 * connection.
 * <p>
 * Second, the connection to the SQL server will not be closed when the
 * execution of the script ends. Instead, the link will remain open for future
 * use (mssql_close() will not close links established by mssql_pconnect()).
 * <p>
 * This type of links is therefore called 'persistent'.
 */
function int mssql_pconnect(string servername, string username, string password);
 
/**
 * send MS SQL query
 * <p>
 * Returns: A positive MS SQL result identifier on success, or false on error.
 * <p>
 * mssql_query() sends a query to the currently active database on the server
 * that's associated with the specified link identifier. If the link
 * identifier isn't specified, the last opened link is assumed. If no link is
 * open, the function tries to establish a link as if {@link mssql_connect()} was
 * called, and use it.
 * 
 * @see mssql_db_query()
 * @see mssql_select_db()
 * @see mssql_connect()
 */
function int mssql_query(string query, int link_identifier);
 
/**
 * get result data
 * <p>
 * Returns: The contents of the cell at the row and offset in the specified MS
 * SQL result set.
 * <p>
 * mssql_result() returns the contents of one cell from a MS SQL result set.
 * The field argument can be the field's offset, or the field's name, or the
 * field's table dot field's name (fieldname.tablename). If the column name
 * has been aliased ('select foo as bar from...'), use the alias instead of
 * the column name.
 * <p>
 * When working on large result sets, you should consider using one of the
 * functions that fetch an entire row (specified below). As these functions
 * return the contents of multiple cells in one function call, they're MUCH
 * quicker than mssql_result(). Also, note that specifying a numeric offset
 * for the field argument is much quicker than specifying a fieldname or
 * tablename.fieldname argument.
 * <p>
 * Recommended high-performance alternatives: {@link mssql_fetch_row()},
 * {@link mssql_fetch_array()}, and {@link mssql_fetch_object()}.
 */
function int mssql_result(int result, int i, mixed field);
 
/**
 * select MS SQL database
 * <p>
 * Returns: true on success, false on error
 * <p>
 * mssql_select_db() sets the current active database on the server that's
 * associated with the specified link identifier. If no link identifier is
 * specified, the last opened link is assumed. If no link is open, the
 * function will try to establish a link as if {@link mssql_connect()} was called, and
 * use it.
 * <p>
 * Every subsequent call to {@link mssql_query()} will be made on the active database.
 * 
 * @see mssql_connect()
 * @see mssql_pconnect()
 * @see mssql_query()
 */
function int mssql_select_db(string database_name, int link_identifier);


///////////////////////////////////////////////////////////////////////////
// MySQL functions
// 
// These functions allow you to access MySQL database servers.
// More information about MySQL can be found at http://www.mysql.com/.
//

/**
 * <p>
 * mysql_affected_rows() returns the number of rows affected by the last
 * INSERT, UPDATE or DELETE query on the server associated with the specified
 * link identifier. If the link identifier isn't specified, the last opened
 * link is assumed.
 * <p>
 * If the last query was a DELETE query with no WHERE clause, all of the
 * records will have been deleted from the table but this function will return
 * zero.
 * <p>
 * This command is not effective for SELECT statements, only on statements
 * which modify records. To retrieve the number of rows returned from a
 * SELECT, use mysql_num_rows().
 */
function int mysql_affected_rows(int [link_identifier] );
 
/**
 * close MySQL connection
 * <p>
 * Returns: true on success, false on error
 * <p>
 * mysql_close() closes the link to a MySQL database that's associated with
 * the specified link identifier. If the link identifier isn't specified, the
 * last opened link is assumed.
 * <p>
 * Note that this isn't usually necessary, as non-persistent open links are
 * automatically closed at the end of the script's execution.
 * <p>
 * mysql_close() will not close persistent links generated by
 * {@link mysql_pconnect()}.
 * 
 * @see mysql_connect()
 * @see mysql_pconnect()
 */
function int mysql_close(int [link_identifier] );
 
/**
 * Open a connection to a MySQL Server
 * <p>
 * Returns: A positive MySQL link identifier on success, or false on error.
 * <p>
 * mysql_connect() establishes a connection to a MySQL server. All of the
 * arguments are optional, and if they're missing, defaults are assumed
 * ('localhost', user name of the user that owns the server process, empty
 * password).
 * <p>
 * The hostname string can also include a port number. eg. "hostname:port" or
 * a path to a socket eg. ":/path/to/socket" for the localhost.
 * <p>
 * In case a second call is made to mysql_connect() with the same arguments,
 * no new link will be established, but instead, the link identifier of the
 * already opened link will be returned.
 * <p>
 * The link to the server will be closed as soon as the execution of the
 * script ends, unless it's closed earlier by explicitly calling
 * {@link mysql_close()}.
 * 
 * @since Support for the ":/path/to/socket" was added in 3.0.10.
 * Support for ":port" wass added in 3.0B4.
 * @see mysql_pconnect()
 * @see mysql_close()
 */
function int mysql_connect(string [hostname [:port] [:/path/to/socket] ] , string [username] , string [password] );
 
/**
 * Create a MySQL database
 * <p>
 * mysql_create_db() attempts to create a new database on the server
 * associated with the specified link identifier.
 * 
 * @see mysql_drop_db()
 * @see mysql_createdb()
 */
function int mysql_create_db(string database_name, int [link_identifier] );
 
/**
 * Move internal result pointer
 * <p>
 * Returns: true on success, false on failure
 * <p>
 * mysql_data_seek() moves the internal row pointer of the MySQL result
 * associated with the specified result identifier to point to the specified
 * row number. The next call to {@link mysql_fetch_row()} would return that row.
 */
function int mysql_data_seek(int result_identifier, int row_number);
 
/**
 * Send an MySQL query to MySQL
 * <p>
 * Returns: A positive MySQL result identifier to the query result, or false
 * on error.
 * <p>
 * mysql_db_query() selects a database and executes a query on it. If the
 * optional link identifier isn't specified, the function will try to find an
 * open link to the MySQL server and if no such link is found it'll try to
 * create one as if {@link mysql_connect()} was called with no arguments
 * 
 * @see mysql_connect()
 * @see mysql()
 */
function int mysql_db_query(string database, string query, int [link_identifier] );
 
/**
 * Drop (delete) a MySQL database
 * <p>
 * Returns: true on success, false on failure.
 * <p>
 * mysql_drop_db() attempts to drop (remove) an entire database from the
 * server associated with the specified link identifier.
 * 
 * @see mysql_create_db()
 * @see mysql_dropdb()
 */
function int mysql_drop_db(string database_name, int [link_identifier] );
 
/**
 * Errors coming back from the mySQL database backend no longer issue
 * warnings. Instead, use these functions to retrieve the error number.
 * <pre>
 *    &lt;?php
 *    mysql_connect("marliesle");
 *    echo mysql_errno().": ".mysql_error()."&lt;BR&gt;";
 *    mysql_select_db("nonexistentdb");
 *    echo mysql_errno().": ".mysql_error()."&lt;BR&gt;";
 *    $conn = mysql_query("SELECT * FROM nonexistenttable");
 *    echo mysql_errno().": ".mysql_error()."&lt;BR&gt;";
 *    ?&gt;
 * </pre>
 *
 * @see mysql_error()
 */
function int mysql_errno(int [link_identifier] );
 
/**
 * Errors coming back from the mySQL database backend no longer issue
 * warnings. Instead, use these functions to retrieve the error string.
 * <pre> 
 *    &lt;?php
 *    mysql_connect("marliesle");
 *    echo mysql_errno().": ".mysql_error()."&lt;BR&gt;";
 *    mysql_select_db("nonexistentdb");
 *    echo mysql_errno().": ".mysql_error()."&lt;BR&gt;";
 *    $conn = mysql_query("SELECT * FROM nonexistenttable");
 *    echo mysql_errno().": ".mysql_error()."&lt;BR&gt;";
 *    ?&gt;
 * </pre>
 *
 * @see mysql_errno()
 */
function string mysql_error(int [link_identifier] );
 
/**
 * Fetch a result row as an associative array
 * <p>
 * Returns an array that corresponds to the fetched row, or false if there are
 * no more rows.
 * <p>
 * mysql_fetch_array() is an extended version of mysql_fetch_row(). In
 * addition to storing the data in the numeric indices of the result array, it
 * also stores the data in associative indices, using the field names as keys.
 * <p>
 * If two or more columns of the result have the same field names, the last
 * column will take precedence. To access the other column(s) of the same
 * name, you must the numeric index of the column or make an alias for the
 * column.
 * <p>
 * select t1.f1 as foo t2.f1 as bar from t1, t2
 * <p>
 * An important thing to note is that using mysql_fetch_array() is NOT
 * significantly slower than using {@link mysql_fetch_row()}, while it provides a
 * significant added value.
 * <p>
 * The optional second argument result_type in mysql_fetch_array() is a
 * constant and can take the following values: MYSQL_ASSOC, MYSQL_NUM, and
 * MYSQL_BOTH.
 * <p>
 * For further details, also see {@link mysql_fetch_row()}
 * <p>
 * <b>Example 1.</b> mysql fetch array
 * <pre>
 *    &lt;?php
 *    mysql_connect($host,$user,$password);
 *    $result = mysql_db_query("database","select * from table");
 *    while($row = mysql_fetch_array($result)) {
 *       echo $row["user_id"];
 *       echo $row["fullname"];
 *    }
 *    mysql_free_result($result);
 *    ?&gt;
 * </pre>
 */
function array mysql_fetch_array(int result, int [result_type] );
 
/**
 * Returns an object containing field information.
 * <p>
 * mysql_fetch_field() can be used in order to obtain information about fields
 * in a certain query result. If the field offset isn't specified, the next
 * field that wasn't yet retrieved by {@link mysql_fetch_field()} is retrieved.
 * <p>
 * The properties of the object are:
 * <ul>
 * <li> name - column name
 * <li> table - name of the table the column belongs to
 * <li> max_length - maximum length of the column
 * <li> not_null - 1 if the column cannot be null
 * <li> primary_key - 1 if the column is a primary key
 * <li> unique_key - 1 if the column is a unique key
 * <li> multiple_key - 1 if the column is a non-unique key
 * <li> numeric - 1 if the column is numeric
 * <li> blob - 1 if the column is a BLOB
 * <li> type - the type of the column
 * <li> unsigned - 1 if the column is unsigned
 * <li> zerofill - 1 if the column is zero-filled
 * </ul>
 *
 * @see mysql_field_seek()
 */
function object mysql_fetch_field(int result, int [field_offset] );
 
/**
 * Get the length of each output in a result
 * <p>
 * Returns: An array that corresponds to the lengths of each field in the last
 * row fetched by {@link mysql_fetch_row()}, or false on error.
 * <p>
 * mysql_fetch_lengths() stores the lengths of each result column in the last
 * row returned by {@link mysql_fetch_row()}, {@link mysql_fetch_array()}, and
 * {@link mysql_fetch_object()} in an array, starting at offset 0.
 * 
 * @see mysql_fetch_row()
 */
function array mysql_fetch_lengths(int result);
 
/**
 * Fetch a result row as an object
 * <p>
 * Returns an object with properties that correspond to the fetched row, or
 * false if there are no more rows.
 * <p>
 * mysql_fetch_object() is similar to {@link mysql_fetch_array()}, with one difference
 * - an object is returned, instead of an array. Indirectly, that means that
 * you can only access the data by the field names, and not by their offsets
 * (numbers are illegal property names).
 * <p>
 * The optional argument result_typ is a constant and can take the following
 * values: MYSQL_ASSOC, MYSQL_NUM, and MYSQL_BOTH.
 * <p>
 * Speed-wise, the function is identical to {@link mysql_fetch_array()}, and almost as
 * quick as {@link mysql_fetch_row()} (the difference is insignificant).
 *
 * <b>Example 1.</b> mysql fetch object
 *    <pre>
 *    &lt;?php
 *    mysql_connect($host,$user,$password);
 *    $result = mysql_db_query("database","select * from table");
 *    while($row = mysql_fetch_object($result)) {
 *       echo $row-&gt;user_id;
 *       echo $row-&gt;fullname;
 *    }
 *    mysql_free_result($result);
 *    ?&gt;
 * </pre>
 *
 * @see mysql_fetch_array()
 * @see mysql_fetch_row()
 */
function object mysql_fetch_object(int result, int [result_typ]);
 
/**
 * Get a result row as an enumerated array
 * <p>
 * Returns: An array that corresponds to the fetched row, or false if there
 * are no more rows.
 * <p>
 * mysql_fetch_row() fetches one row of data from the result associated with
 * the specified result identifier. The row is returned as an array. Each
 * result column is stored in an array offset, starting at offset 0.
 * <p>
 * Subsequent call to mysql_fetch_row() would return the next row in the
 * result set, or false if there are no more rows.
 * 
 * @see mysql_fetch_array()
 * @see mysql_fetch_object()
 * @see mysql_data_seek()
 * @see mysql_fetch_lengths()
 * @see mysql_result()
 */
function array mysql_fetch_row(int result);
 
/**
 * Get the name of the specified field in a result
 * <p>
 * mysql_field_name() returns the name of the specified field. Arguments to
 * the function is the result identifier and the field index, ie.
 * mysql_field_name($result,2);
 * <p>
 * Will return the name of the second field in the result associated with the
 * result identifier.
 * <p>
 * For downwards compatibility mysql_fieldname() can also be used.
 */
function string mysql_field_name(int result, int field_index);
 
/**
 * Set result pointer to a specified field offset
 * <p>
 * Seeks to the specified field offset. If the next call to
 * {@link mysql_fetch_field()} won't include a field offset, this field would be
 * returned.
 * 
 * @see mysql_fetch_field()
 */
function int mysql_field_seek(int result, int field_offset);
 
/**
 * Get name of the table the specified field is in
 * <p>
 * Get the table name for field. For downward compatibility {@link mysql_fieldtable()}
 * can also be used.
 */
function string mysql_field_table(int result, int field_offset);
 
/**
 * Get the type of the specified field in a result
 * <p>
 * mysql_field_type() is similar to the {@link mysql_field_name()} function. The
 * arguments are identical, but the field type is returned. This will be one
 * of "int", "real", "string", "blob", or others as detailed in the MySQL
 * documentation.
 * <b>Example 1.</b> mysql field types
 * <pre>
 *    &lt;?php
 *    mysql_connect("localhost:3306");
 *    mysql_select_db("wisconsin");
 *    $result = mysql_query("SELECT * FROM onek");
 *    $fields = mysql_num_fields($result);
 *    $rows   = mysql_num_rows($result);
 *    $i = 0;
 *    $table = mysql_field_table($result, $i);
 *    echo "Your '".$table."' table has ".$fields." fields and ".$rows." records &lt;BR&gt;";
 *    echo "The table has the following fields &lt;BR&gt;";
 *    while ($i &lt; $fields) {
 *        $type  = mysql_field_type  ($result, $i);
 *        $name  = mysql_field_name  ($result, $i);
 *        $len   = mysql_field_len   ($result, $i);
 *        $flags = mysql_field_flags ($result, $i);
 *        echo $type." ".$name." ".$len." ".$flags."&lt;BR&gt;";
 *        $i++;
 *    }
 *    mysql_close();
 *    ?&gt;
 * </pre>
 * For downward compatibility {@link mysql_fieldtype()} can also be used.
 * 
 */
function string mysql_field_type(int result, int field_offset);
 
/**
 * <p>
 * mysql_field_flags() returns the field flags of the specified field. The
 * flags are reported as a single word per flag separated by a single space,
 * so that you can split the returned value using {@link explode()}.
 * <p>
 * The following flags are reported, if your version of MySQL is current
 * enough to support them: "not_null", "primary_key", "unique_key",
 * "multiple_key", "blob", "unsigned", "zerofill", "binary", "enum",
 * "auto_increment", "timestamp".
 * <p>
 * For downward compatibility {@link mysql_fieldflags()} can also be used.
 */
function string mysql_field_flags(int result, int field_offset);
 
/**
 * Returns the length of the specified field
 * <p>
 * mysql_field_len() returns the length of the specified field. For downward
 * compatibility {@link mysql_fieldlen()} can also be used.
 */
function int mysql_field_len(int result, int field_offset);
 
/**
 * Free result memory
 * <p>
 * mysql_free_result() only needs to be called if you are worried about using
 * too much memory while your script is running. All associated result memory
 * for the specified result identifier will automatically be freed.
 * <p>
 * For downward compatibility {@link mysql_freeresult()} can also be used.
 */
function int mysql_free_result(int result);
 
/**
 * Get the id generated from the previous INSERT operation
 * <p>
 * mysql_insert_id() returns the ID generated for an AUTO_INCREMENTED field.
 * This function takes no arguments. It will return the auto-generated ID
 * returned by the last INSERT query performed.
 */
function int mysql_insert_id(int [link_identifier] );
 
/**
 * List MySQL result fields
 * <p>
 * mysql_list_fields() retrieves information about the given tablename.
 * Arguments are the database name and the table name. A result pointer is
 * returned which can be used with {@link mysql_field_flags()}, {@link mysql_field_len()},
 * {@link mysql_field_name()}, and {@link mysql_field_type()}.
 * <p>
 * A result identifier is a positive integer. The function returns -1 if a
 * error occurs. A string describing the error will be placed in $phperrmsg,
 * and unless the function was called as @mysql() then this error string will
 * also be printed out.
 * <p>
 * For downward compatibility {@link mysql_listfields()} can also be used.
 */
function int mysql_list_fields(string database_name, string table_name, int [link_identifier] );
 
/**
 * List databases available on on MySQL server
 * <p>
 * mysql_list_dbs() will return a result pointer containing the databases
 * available from the current mysql daemon. Use the {@link mysql_tablename()} function
 * to traverse this result pointer.
 * <p>
 * For downward compatibility {@link mysql_listdbs()} can also be used.
 */
function int mysql_list_dbs(int [link_identifier] );
 
/**
 * List tables in a MySQL database
 * <p>
 * mysql_list_tables() takes a database name and returns a result pointer much
 * like the {@link mysql_db_query()} function. The {@link mysql_tablename()} function should
 * be used to extract the actual table names from the result pointer.
 * <p>
 * For downward compatibility {@link mysql_listtables()} can also be used.
 */
function int mysql_list_tables(string database, int [link_identifier] );
 
/**
 * Get number of fields in result
 * <p>
 * mysql_num_fields() returns the number of fields in a result set.
 * <p>
 * For downward compatibility {@link mysql_numfields()} can also be used.
 * 
 * @see mysql_db_query()
 * @see mysql_query()
 * @see mysql_fetch_field()
 * @see mysql_num_rows()
 */
function int mysql_num_fields(int result);
 
/**
 * Get number of rows in result
 * <p>
 * mysql_num_rows() returns the number of rows in a result set.
 * <p>
 * For downward compatibility {@link mysql_numrows()} can also be used.
 * 
 * @see mysql_db_query()
 * @see mysql_query()
 * @see mysql_fetch_row()
 */
function int mysql_num_rows(int result);
 
/**
 * Open a persistent connection to a MySQL Server
 * <p>
 * Returns: A positive MySQL persistent link identifier on success, or false
 * on error
 * <p>
 * mysql_pconnect() establishes a connection to a MySQL server. All of the
 * arguments are optional, and if they're missing, defaults are assumed
 * ('localhost', user name of the user that owns the server process, empty
 * password).
 * <p>
 * The hostname string can also include a port number. eg. "hostname:port" or
 * a path to a socket eg. ":/path/to/socket" for the localhost.
 * <p>
 * mysql_pconnect() acts very much like {@link mysql_connect()} with two major
 * differences.
 * <p>
 * First, when connecting, the function would first try to find a (persistent)
 * link that's already open with the same host, username and password. If one
 * is found, an identifier for it will be returned instead of opening a new
 * connection.
 * <p>
 * Second, the connection to the SQL server will not be closed when the
 * execution of the script ends. Instead, the link will remain open for future
 * use (mysql_close() will not close links established by mysql_pconnect()).
 * <p>
 * This type of links is therefore called 'persistent'.
 * 
 * @since Support for ":port" wass added in 3.0B4.
 * Support for the ":/path/to/socket" was added in 3.0.10.
 */
function int mysql_pconnect(string [hostname [:port] [:/path/to/socket] ] , string [username] , string [password] );
 
/**
 * Send an SQL query to MySQL
 * <p>
 * mysql_query() sends a query to the currently active database on the server
 * that's associated with the specified link identifier. If link_identifier
 * isn't specified, the last opened link is assumed. If no link is open, the
 * function tries to establish a link as if {@link mysql_connect()} was called with no
 * arguments, and use it.
 * <p>
 * The query string should not end with a semicolon.
 * <p>
 * mysql_query() returns TRUE (non-zero) or FALSE to indicate whether or not
 * the query succeeded. A return value of TRUE means that the query was legal
 * and could be executed by the server. It does not indicate anything about
 * the number of rows affected or returned. It is perfectly possible for a
 * query to succeed but affect no rows or return no rows.
 * <p>
 * The following query is syntactically invalid, so {@link mysql_query()} fails and
 * returns FALSE:
 * <p>
 * <b>Example 1.</b> mysql_query()
 * <pre>
 *    &lt;?php
 *    $result = mysql_query ("SELECT * WHERE 1=1")
 *        or die ("Invalid query");
 *    ?&gt;
 * </pre>
 * The following query is semantically invalid if my_col is not a column in
 * the table my_tbl, so mysql_query() fails and returns FALSE:
 * <P>
 * <b>Example 2.</b> mysql_query()
 * <pre>
 *    &lt;?php
 *    $result = mysql_query ("SELECT my_col FROM my_tbl")
 *        or die ("Invalid query");
 *    ?&gt;
 * </pre>
 * mysql_query() will also fail and return FALSE if you don't have permission
 * to access the table(s) referenced by the query.
 * <p>
 * Assuming the query succeeds, you can call {@link mysql_affected_rows()} to find out
 * how many rows were affected (for DELETE, INSERT, REPLACE, or UPDATE
 * statements). For SELECT statements, {@link mysql_query()} returns a new result
 * identifier that you can pass to {@link mysql_result()}. When you are done with the
 * result set, you can free the resources associated with it by calling
 * {@link mysql_free_result()}.
 * 
 * @see mysql_affected_rows()
 * @see mysql_db_query()
 * @see mysql_free_result()
 * @see mysql_result()
 * @see mysql_select_db()
 * @see mysql_connect()
 */
function int mysql_query(string query, int [link_identifier] );
 
/**
 * Get result data
 * <p>
 * mysql_result() returns the contents of one cell from a MySQL result set.
 * The field argument can be the field's offset, or the field's name, or the
 * field's table dot field's name (fieldname.tablename). If the column name
 * has been aliased ('select foo as bar from...'), use the alias instead of
 * the column name.
 * <p>
 * When working on large result sets, you should consider using one of the
 * functions that fetch an entire row (specified below). As these functions
 * return the contents of multiple cells in one function call, they're MUCH
 * quicker than mysql_result(). Also, note that specifying a numeric offset
 * for the field argument is much quicker than specifying a fieldname or
 * tablename.fieldname argument.
 * <p>
 * Calls mysql_result() should not be mixed with calls to other functions that
 * deal with the result set.
 * <p>
 * Recommended high-performance alternatives: {@link mysql_fetch_row()},
 * {@link mysql_fetch_array()}, and {@link mysql_fetch_object()}.
 */
function int mysql_result(int result, int row, mixed [field] );
 
/**
 * Select a MySQL database
 * <p>
 * Returns: true on success, false on error
 * <p>
 * mysql_select_db() sets the current active database on the server that's
 * associated with the specified link identifier. If no link identifier is
 * specified, the last opened link is assumed. If no link is open, the
 * function will try to establish a link as if {@link mysql_connect()} was called, and
 * use it.
 * <p>
 * Every subsequent call to {@link mysql_query()} will be made on the active database.
 * <p>
 * For downward compatibility {@link mysql_selectdb()} can also be used.
 * 
 * @see mysql_connect()
 * @see mysql_pconnect()
 * @see mysql_query()
 */
function int mysql_select_db(string database_name, int [link_identifier] );
 
/**
 * get table name of field
 * <p>
 * mysql_tablename() takes a result pointer returned by the
 * {@link mysql_list_tables()} function as well as an integer index and returns the
 * name of a table. The {@link mysql_num_rows()} function may be used to determine the
 * number of tables in the result pointer.
 * <p>
 * <b>Example 1.</b> mysql_tablename() example
 * <pre>
 *    &lt;?php
 *    mysql_connect ("localhost:3306");
 *    $result = mysql_listtables ("wisconsin");
 *    $i = 0;
 *    while ($i &lt; mysql_num_rows ($result)) {
 *        $tb_names[$i] = mysql_tablename ($result, $i);
 *        echo $tb_names[$i] . "&lt;BR&gt;";
 *        $i++;
 *    }
 *    ?&gt;
 * </pre>
 */ 
function string mysql_tablename(int result, int i);


///////////////////////////////////////////////////////////////////////////
// Sybase functions
// 
 
/**
 * get number of affected rows in last query
 * <p>
 * Returns: The number of affected rows by the last query.
 * <p>
 * sybase_affected_rows() returns the number of rows affected by the last
 * INSERT, UPDATE or DELETE query on the server associated with the specified
 * link identifier. If the link identifier isn't specified, the last opened
 * link is assumed.
 * <p>
 * This command is not effective for SELECT statements, only on statements
 * which modify records. To retrieve the number of rows returned from a
 * SELECT, use {@link sybase_num_rows()}.
 * <p>
 * <b>Note:</b>
 * This function is only available using the CT library
 *      interface to Sybase, and not the DB library.
 */
function int sybase_affected_rows(int [link_identifier] );
 
/**
 * close Sybase connection
 * <p>
 * Returns: true on success, false on error
 * <p>
 * sybase_close() closes the link to a Sybase database that's associated with
 * the specified link identifier. If the link identifier isn't specified, the
 * last opened link is assumed.
 * <p>
 * Note that this isn't usually necessary, as non-persistent open links are
 * automatically closed at the end of the script's execution.
 * <p>
 * sybase_close() will not close persistent links generated by
 * {@link sybase_pconnect()}.
 * 
 * @see sybase_connect()
 * @see sybase_pconnect()
 */
function int sybase_close(int link_identifier);
 
/**
 * open Sybase server connection
 * <p>
 * Returns: A positive Sybase link identifier on success, or false on error.
 * <p>
 * sybase_connect() establishes a connection to a Sybase server. The
 * servername argument has to be a valid servername that is defined in the
 * 'interfaces' file.
 * <p>
 * In case a second call is made to sybase_connect() with the same arguments,
 * no new link will be established, but instead, the link identifier of the
 * already opened link will be returned.
 * <p>
 * The link to the server will be closed as soon as the execution of the
 * script ends, unless it's closed earlier by explicitly calling
 * {@link sybase_close()}.
 * 
 * @see sybase_pconnect()
 * @see sybase_close()
 */
function int sybase_connect(string servername, string username, string password);
 
/**
 * move internal row pointer
 * <p>
 * Returns: true on success, false on failure
 * <p>
 * sybase_data_seek() moves the internal row pointer of the Sybase result
 * associated with the specified result identifier to pointer to the specifyed
 * row number. The next call to {@link sybase_fetch_row()} would return that row.
 * 
 * @see sybase_data_seek()
 */
function int sybase_data_seek(int result_identifier, int row_number);
 
/**
 * fetch row as array
 * <p>
 * Returns: An array that corresponds to the fetched row, or false if there
 * are no more rows.
 * <p>
 * sybase_fetch_array() is an extended version of {@link sybase_fetch_row()}. In
 * addition to storing the data in the numeric indices of the result array, it
 * also stores the data in associative indices, using the field names as keys.
 * <p>
 * An important thing to note is that using sybase_fetch_array() is NOT
 * significantly slower than using {@link sybase_fetch_row()}, while it provides a
 * significant added value.
 * <p>
 * For further details, also see sybase_fetch_row()
 */
function int sybase_fetch_array(int result);
 
/**
 * get field information
 * <p>
 * Returns an object containing field information.
 * <p>
 * sybase_fetch_field() can be used in order to obtain information about
 * fields in a certain query result. If the field offset isn't specified, the
 * next field that wasn't yet retreived by {@link sybase_fetch_field()} is retreived.
 * <p>
 * The properties of the object are:
 * <ul>
 * <li> name - column name. if the column is a result of a function, this
 *      property is set to computed#N, where #N is a serial number.
 * <li> column_source - the table from which the column was taken
 * <li> max_length - maximum length of the column
 * <li> numeric - 1 if the column is numeric
 * </ul>
 *
 * @see sybase_field_seek()
 */
function object sybase_fetch_field(int result, int field_offset);
 
/**
 * fetch row as object
 * <p>
 * Returns: An object with properties that correspond to the fetched row, or
 * false if there are no more rows.
 * <p>
 * sybase_fetch_object() is similar to {@link sybase_fetch_array()}, with one
 * difference - an object is returned, instead of an array. Indirectly, that
 * means that you can only access the data by the field names, and not by
 * their offsets (numbers are illegal property names).
 * <p>
 * Speed-wise, the function is identical to {@link sybase_fetch_array()}, and almost
 * as quick as {@link sybase_fetch_row()} (the difference is insignificant).
 * 
 * @see sybase_fetch_array()
 * @see sybase_fetch_row()
 */
function int sybase_fetch_object(int result);
 
/**
 * get row as enumerated array
 * <p>
 * Returns: An array that corresponds to the fetched row, or false if there
 * are no more rows.
 * <p>
 * sybase_fetch_row() fetches one row of data from the result associated with
 * the specified result identifier. The row is returned as an array. Each
 * result column is stored in an array offset, starting at offset 0.
 * <p>
 * Subsequent call to sybase_fetch_rows() would return the next row in the
 * result set, or false if there are no more rows.
 * 
 * @see sybase_fetch_array()
 * @see sybase_fetch_object()
 * @see sybase_data_seek()
 * @see sybase_fetch_lengths()
 * @see sybase_result()
 */
function array sybase_fetch_row(int result);
 
/**
 * set field offset
 * <p>
 * Seeks to the specified field offset. If the next call to
 * sybase_fetch_field() won't include a field offset, this field would be
 * returned.
 * 
 * @see sybase_fetch_field()
 */
function int sybase_field_seek(int result, int field_offset);
 
/**
 * free result memory
 * <p>
 * sybase_free_result() only needs to be called if you are worried about using
 * too much memory while your script is running. All result memory will
 * automatically be freed when the script, you may call sybase_free_result()
 * with the result identifier as an argument and the associated result memory
 * will be freed.
 */
function int sybase_free_result(int result);
 
/**
 * get number of fields in result
 * <p>
 * sybase_num_fields() returns the number of fields in a result set.
 * 
 * @see sybase_db_query()
 * @see sybase_query()
 * @see sybase_fetch_field()
 * @see sybase_num_rows()
 */
function int sybase_num_fields(int result);
 
/**
 * get number of rows in result
 * <p>
 * sybase_num_rows() returns the number of rows in a result set.
 * 
 * @see sybase_db_query()
 * @see sybase_query()
 * @see sybase_fetch_row()
 */
function int sybase_num_rows(string result);
 
/**
 * open persistent Sybase connection
 * <p>
 * Returns: A positive Sybase persistent link identifier on success, or false
 * on error
 * <p>
 * sybase_pconnect() acts very much like {@link sybase_connect()} with two major
 * differences.
 * <p>
 * First, when connecting, the function would first try to find a (persistent)
 * link that's already open with the same host, username and password. If one
 * is found, an identifier for it will be returned instead of opening a new
 * connection.
 * <p>
 * Second, the connection to the SQL server will not be closed when the
 * execution of the script ends. Instead, the link will remain open for future
 * use (sybase_close() will not close links established by sybase_pconnect()).
 * <p>
 * This type of links is therefore called 'persistent'.
 */
function int sybase_pconnect(string servername, string username, string password);
 
/**
 * send Sybase query
 * <p>
 * Returns: A positive Sybase result identifier on success, or false on error.
 * <p>
 * sybase_query() sends a query to the currently active database on the server
 * that's associated with the specified link identifier. If the link
 * identifier isn't specified, the last opened link is assumed. If no link is
 * open, the function tries to establish a link as if {@link sybase_connect()} was
 * called, and use it.
 * 
 * @see sybase_db_query()
 * @see sybase_select_db()
 * @see sybase_connect()
 */
function int sybase_query(string query, int link_identifier);
 
/**
 * get result data
 * <p>
 * Returns: The contents of the cell at the row and offset in the specified
 * Sybase result set.
 * <p>
 * sybase_result() returns the contents of one cell from a Sybase result set.
 * The field argument can be the field's offset, or the field's name, or the
 * field's table dot field's name (fieldname.tablename). If the column name
 * has been aliased ('select foo as bar from...'), use the alias instead of
 * the column name.
 * <p>
 * When working on large result sets, you should consider using one of the
 * functions that fetch an entire row (specified below). As these functions
 * return the contents of multiple cells in one function call, they're MUCH
 * quicker than sybase_result(). Also, note that specifying a numeric offset
 * for the field argument is much quicker than specifying a fieldname or
 * tablename.fieldname argument.
 * <p>
 * Recommended high-performance alternatives: {@link sybase_fetch_row()},
 * {@link sybase_fetch_array()}, and {@link sybase_fetch_object()}.
 */
function int sybase_result(int result, int i, mixed field);
 
/**
 * select Sybase database
 * <p>
 * Returns: true on success, false on error
 * <p>
 * sybase_select_db() sets the current active database on the server that's
 * associated with the specified link identifier. If no link identifier is
 * specified, the last opened link is assumed. If no link is open, the
 * function will try to establish a link as if {@link sybase_connect()} was called,
 * and use it.
 * <p>
 * Every subsequent call to {@link sybase_query()} will be made on the active
 * database.
 * 
 * @see sybase_connect()
 * @see sybase_pconnect()
 * @see sybase_query()
 */
function int sybase_select_db(string database_name, int link_identifier);


///////////////////////////////////////////////////////////////////////////
// Network functions
// 
 
/**
 * Open Internet or Unix domain socket connection.
 * <p>
 * Initiates a stream connection in the Internet (AF_INET) or Unix (AF_UNIX)
 * domain. For the Internet domain, it will open a TCP socket connection to
 * hostname on port port. For the Unix domain, hostname will be used as the
 * path to the socket, port must be set to 0 in this case. The optional
 * timeout can be used to set a timeout in seconds for the connect system
 * call.
 * <p>
 * fsockopen() returns a file pointer which may be used together with the
 * other file functions (such as {@link fgets()}, {@link fgetss()},
 * {@link fputs()}, {@link fclose()}, {@link feof()}).
 * <p>
 * If the call fails, it will return false and if the optional errno and
 * errstr arguments are present they will be set to indicate the actual system
 * level error that occurred on the system-level connect() call. If the
 * returned errno is 0 and the function returned false, it is an indication
 * that the error occurred before the connect() call. This is most likely due
 * to a problem initializing the socket. Note that the errno and errstr
 * arguments must be passed by reference.
 * <p>
 * Depending on the environment, the Unix domain or the optional connect
 * timeout may not be available.
 * <p>
 * The socket will by default be opened in blocking mode. You can switch it to
 * non-blocking mode by using {@link set_socket_blocking()}.
 *
 * <b>Example 1.</b> fsockopen example
 * <pre>
 *    $fp = fsockopen("www.php.net", 80, &$errno, &$errstr, 30);
 *    if(!$fp) {
 *            echo "$errstr ($errno)&lt;br&gt;\n";
 *    } else {
 *            fputs($fp,"GET / HTTP/1.0\n\n");
 *            while(!feof($fp)) {
 *                    echo fgets($fp,128);
 *            }
 *            fclose($fp);
 *    }
 * </pre>
 * 
 * @see pfsockopen()
 */
function int fsockopen(string hostname, int port, int [errno], string [errstr], double [timeout]);
 
/**
 * Open persistent Internet or Unix domain socket connection.
 * <p>
 * This function behaves exactly as fsockopen() with the difference that the
 * connection is not closed after the script finishes. It is the persistent
 * version of {@link fsockopen()}.
 */
function int pfsockopen(string hostname, int port, int [errno], string [errstr], int [timeout]);
 
/**
 * Set blocking/non-blocking mode on a socket
 * <p>
 * If mode is false, the given socket descriptor will be switched to
 * non-blocking mode, and if true, it will be switched to blocking mode. This
 * affects calls like {@link fgets()} that read from the socket. In non-blocking mode
 * an {@link fgets()} call will always return right away while in blocking mode it
 * will wait for data to become available on the socket.
 */
function int set_socket_blocking(int socket_descriptor, int mode);
 
/**
 * Returns the host name of the Internet host specified by ip_address. If an
 * error occurs, returns ip_address.
 * 
 * @see gethostbyname()
 */
function string gethostbyaddr(string ip_address);
 
/**
 * Returns the IP address of the Internet host specified by hostname.
 * 
 * @see gethostbyaddr()
 */
function string gethostbyname(string hostname);
 
/**
 * Returns a list of IP addresses to which the Internet host specified by
 * hostname resolves.
 * 
 * @see gethostbyname()
 * @see gethostbyaddr()
 * @see checkdnsrr()
 * @see getmxrr()
 */
function array gethostbynamel(string hostname);
 
/**
 * Searches DNS for records of type type corresponding to host. Returns true
 * if any records are found; returns false if no records were found or if an
 * error occurred.
 * <p>
 * type may be any one of: A, MX, NS, SOA, PTR, CNAME, or ANY. The default is MX.
 * <p>
 * host may either be the IP address in dotted-quad notation or the host name.
 * 
 * @see getmxrr()
 * @see gethostbyaddr()
 * @see gethostbyname()
 * @see gethostbynamel()
 */
function int checkdnsrr(string host, string [type]);
 
/**
 * Get MX records corresponding to a given Internet host name.
 * <p>
 * Searches DNS for MX records corresponding to hostname. Returns true if any
 * records are found; returns false if no records were found or if an error
 * occurred.
 * <p>
 * A list of the MX records found is placed into the array mxhosts. If the
 * weight array is given, it will be filled with the weight information
 * gathered.
 * 
 * @see checkdnsrr()
 * @see gethostbyname()
 * @see gethostbynamel()
 * @see gethostbyaddr()
 */
function int getmxrr(string hostname, array mxhosts, array [weight]);
 
/**
 * open connection to system logger
 * <p>
 * openlog() opens a connection to the system logger for a program. The string
 * ident is added to each message. Values for option and facility are given in
 * the next section. The use of openlog() is optional; It will automatically
 * be called by {@link syslog()} if necessary, in which case ident will default to
 * false. See also {@link syslog()} and {@link closelog()}.
 */
function int openlog(string ident, int option, int facility);
 
/**
 * generate a system log message
 * <p>
 * syslog() generates a log message that will be distributed by the system
 * logger. priority is a combination of the facility and the level, values for
 * which are given in the next section. The remaining argument is the message
 * to send, except that the two characters %m will be replaced by the error
 * message string (strerror) corresponding to the present value of errno.
 * <p>
 * More information on the syslog facilities can be found in the man pages for
 * syslog on Unix machines.
 * <p>
 * On Windows NT, the syslog service is emulated using the Event Log.
 */
function int syslog(int priority, string message);
 
/**
 * close connection to system logger
 * <p>
 * closelog() closes the descriptor being used to write to the system logger.
 * The use of closelog() is optional.
 */
function int closelog(void);
 
/**
 * enable internal PHP debugger
 * <p>
 * Enables the internal PHP debugger, connecting it to address. The debugger
 * is still under development.
 */
function int debugger_on(string address);
 
/**
 * disable internal PHP debugger
 * <p>
 * Disables the internal PHP debugger. The debugger is still under
 * development.
 */
function int debugger_off(void);


///////////////////////////////////////////////////////////////////////////
// NIS functions
// 
// NIS (formerly called Yellow Pages) allows network management of important
// administrative files (e.g. the password file). For more information refer
// to the NIS manpage and Introduction to YP/NIS. There is also a book called
// Managing NFS and NIS by Hal Stern.
// 
// To get these functions to work, you have to configure PHP with --with-yp.
 
/**
 * Fetches the machine's default NIS domain.
 * <p>
 * yp_get_default_domain() returns the default domain of the node or FALSE.
 * Can be used as the domain parameter for successive NIS calls.
 * <p>
 * A NIS domain can be described a group of NIS maps. Every host that needs to
 * look up information binds itself to a certain domain. Refer to the
 * documents mentioned at the beginning for more detailed information.
 * <p>
 * <b>Example 1.</b> Example for the default domain
 * <pre>
 *    &lt;?php
 *        $domain = yp_get_default_domain();
 *        if(!$domain) {
 *            echo yp_errno() . ": " . yp_err_string();
 *        }
 *        echo "Default NIS domain is: " . $domain;
 *    ?&gt;
 * </pre>
 *
 * @see yp_errno()
 * @see yp_err_string()
 */
function int yp_get_default_domain(void );
 
/**
 * Returns the order number for a map.
 * <p>
 * yp_order() returns the order number for a map or FALSE.
 * <p>
 * <b>Example 1.</b> Example for the NIS order
 * <pre>
 *    &lt;?php
 *        $number = yp_order($domain,$mapname);
 *        if(!$number) {
 *            echo yp_errno() . ": " . yp_err_string();
 *        }
 *        echo "Order number for this map is: " . $order;
 *    ?&gt;
 * </pre>
 *
 * @see yp_get_default_domain()
 * @see yp_errno()
 * @see yp_err_string()
 */
function int yp_order(string domain, string map);
 
/**
 * Returns the machine name of the master NIS server for a map.
 * <p>
 * yp_master() returns the machine name of the master NIS server for a map.
 * <p>
 * <b>Example 1.</b> Example for the NIS master
 * <pre>
 *    &lt;?php
 *        $number = yp_master($domain, $mapname);
 *        if(!$number) {
 *            echo yp_errno() . ": " . yp_err_string();
 *        }
 *        echo "Master for this map is: " . $master;
 *    ?&gt;
 * </pre>
 *
 * @see yp_get_default_domain()
 * @see yp_errno()
 * @see yp_err_string()
 */
function string yp_master(string domain, string map);
 
/**
 * Returns the matched line.
 * <p>
 * yp_match() returns the value associated with the passed key out of the
 * specified map or FALSE. This key must be exact.
 * <p>
 * <b>Example 1.</b> Example for NIS match
 * <pre>
 *    &lt;?php
 *        $entry = yp_match($domain, "passwd.byname", "joe");
 *        if(!$entry) {
 *            echo yp_errno() . ": " . yp_err_string();
 *        }
 *        echo "Matched entry is: " . $entry;
 *    ?&gt;
 * </pre>
 * In this case this could be:
 * <pre>
 *    joe:##joe:11111:100:Joe
 *    User:/home/j/joe:/usr/local/bin/bash
 * </pre>
 * 
 * @see yp_get_default_domain()
 * @see yp_errno()
 * @see yp_err_string()
 */
function string yp_match(string domain, string map, string key);
 
/**
 * Returns the first key-value pair from the named map.
 * <p>
 * yp_first() returns the first key-value pair from the named map in the named
 * domain, otherwise FALSE.
 * <p>
 * <b>Example 1.</b> Example for the NIS first
 * <pre>
 *    &lt;?php
 *        $entry = yp_first($domain, "passwd.byname");
 *        if(!$entry) {
 *            echo yp_errno() . ": " . yp_err_string();
 *        }
 *        $key = key($entry);
 *        echo "First entry in this map has key " . $key
 *              . " and value " . $entry[$key];
 *    ?&gt;
 * </pre>
 *
 * @see yp_get_default_domain()
 * @see yp_errno()
 * @see yp_err_string()
 */
function object yp_first(string domain, string map);
 
/**
 * Returns the next key-value pair in the named map.
 * <p>
 * yp_next() returns the next key-value pair in the named map after the
 * specified key or FALSE.
 * <p>
 * <b>Example 1.</b> Example for NIS next
 * <pre>
 *    &lt;?php
 *        $entry = yp_next($domain, "passwd.byname", "joe");
 *        if(!$entry) {
 *            echo yp_errno() . ": " . yp_err_string();
 *        }
 *        $key = key($entry);
 *        echo "The next entry after joe has key " . $key
 *              . " and value " . $entry[$key];
 *    ?&gt;
 * </pre>
 *
 * @see yp_get_default_domain()
 * @see yp_errno()
 * @see yp_err_string()
 */
function object yp_next(string domain, string map, string key);
 
/**
 * Returns the error code of the previous operation.
 * <p>
 * yp_errno() returns the error code of the previous operation.
 * <p>
 * Possible errors are:
 * <ul>
 * <li> 1 args to function are bad
 * <li> 2 RPC failure - domain has been unbound
 * <li> 3 can't bind to server on this domain
 * <li> 4 no such map in server's domain
 * <li> 5 no such key in map
 * <li> 6 internal yp server or client error
 * <li> 7 resource allocation failure
 * <li> 8 no more records in map database
 * <li> 9 can't communicate with portmapper
 * <li> 10 can't communicate with ypbind
 * <li> 11 can't communicate with ypserv
 * <li> 12 local domain name not set
 * <li> 13 yp database is bad
 * <li> 14 yp version mismatch
 * <li> 15 access violation
 * <li> 16 database busy
 * </ul>
 * 
 * @see yp_err_string()
 */
function int yp_errno();
 
/**
 * yp_err_string() returns the error message associated with the previous
 * operation. Useful to indicate what exactly went wrong.
 * <p>
 * <b>Example 1.</b> Example for NIS errors
 * <pre>
 *    &lt;?php
 *       echo "Error: " . yp_err_string();
 *   ?&gt;
 * </pre>
 *
 * @see yp_errno()
 */
function string yp_err_string(void );


///////////////////////////////////////////////////////////////////////////
// ODBC functions
// 
 
/**
 * Toggle autocommit behaviour
 * <p>
 * Without the OnOff parameter, this function returns auto-commit status for
 * connection_id. True is returned if auto-commit is on, false if it is off or
 * an error occurs.
 * <p>
 * If OnOff is true, auto-commit is enabled, if it is false auto-commit is
 * disabled. Returns true on success, false on failure.
 * <p>
 * By default, auto-commit is on for a connection. Disabling auto-commit is
 * equivalent with starting a transaction.
 * 
 * @see odbc_commit()
 * @see odbc_rollback()
 */
function int odbc_autocommit(int connection_id, int [OnOff]);
 
/**
 * handling of binary column data
 * <p>
 * (ODBC SQL types affected: BINARY, VARBINARY, LONGVARBINARY)
 * <ul>
 * <li> ODBC_BINMODE_PASSTHRU: Passthru BINARY data
 * <li> ODBC_BINMODE_RETURN: Return as is
 * <li> ODBC_BINMODE_CONVERT: Convert to char and return
 * </ul>
 * When binary SQL data is converted to character C data, each byte (8 bits)
 * of source data is represented as two ASCII characters. These characters are
 * the ASCII character representation of the number in its hexadecimal form.
 * For example, a binary 00000001 is converted to "01" and a binary 11111111
 * is converted to "FF".
 * <p>
 * Table 1. LONGVARBINARY handling
 * <pre>
 *  binmode                 longreadlen result
 *  ODBC_BINMODE_PASSTHRU   0           passthru
 *  ODBC_BINMODE_RETURN     0           passthru
 *  ODBC_BINMODE_CONVERT    0           passthru
 *  ODBC_BINMODE_PASSTHRU   0           passthru
 *  ODBC_BINMODE_PASSTHRU   &gt;0          passthru
 *  ODBC_BINMODE_RETURN     &gt;0          return as is
 *  ODBC_BINMODE_CONVERT    &gt;0          return as char
 * </pre>
 * If odbc_fetch_into() is used, passthru means that an empty string is
 * returned for these columns.
 * <p>
 * If result_id is 0, the settings apply as default for new results.
 * <p>
 * <b>Note:</b>
 * Default for longreadlen is 4096 and binmode defaults to
 * ODBC_BINMODE_RETURN. Handling of binary long columns is also
 * affected by {@link odbc_longreadlen()}
 */
function int odbc_binmode(int result_id, int mode);
 
/**
 * Close an ODBC connection
 * <p>
 * odbc_close() will close down the connection to the database server
 * associated with the given connection identifier.
 * <p>
 * <b>Note:</b>
 * This function will fail if there are open transactions on
 *      this connection. The connection will remain open in this case.
 */
function void odbc_close(int connection_id);
 
/**
 * Close all ODBC connections
 * <p>
 * odbc_close_all() will close down all connections to database server(s).
 * <p>
 * <b>Note:</b>
 * This function will fail if there are open transactions on a
 *      connection. This connection will remain open in this case.
 */
function void odbc_close_all(void);
 
/**
 * Commit an ODBC transaction
 * <p>
 * Returns: true on success, false on failure. All pending transactions on
 * connection_id are committed.
 */
function int odbc_commit(int connection_id);
 
/**
 * Connect to a datasource
 * <p>
 * Returns an ODBC connection id or 0 (false) on error.
 * <p>
 * The connection id returned by this functions is needed by other ODBC
 * functions. You can have multiple connections open at once. The optional
 * fourth parameter sets the type of cursor to be used for this connection.
 * This parameter is not normally needed, but can be useful for working around
 * problems with some ODBC drivers.
 * <p>
 * With some ODBC drivers, executing a complex stored procedure may fail with
 * an error similar to: "Cannot open a cursor on a stored procedure that has
 * anything other than a single select statement in it". Using
 * SQL_CUR_USE_ODBC may avoid that error. Also, some drivers don't support the
 * optional row_number parameter in {@link odbc_fetch_row()}. SQL_CUR_USE_ODBC might
 * help in that case, too.
 * <p>
 * The following constants are defined for cursortype:
 * <ul>
 * <li> SQL_CUR_USE_IF_NEEDED
 * <li> SQL_CUR_USE_ODBC
 * <li> SQL_CUR_USE_DRIVER
 * <li> SQL_CUR_DEFAULT
 * </ul>
 * For persistent connections see {@link odbc_pconnect()}.
 */
function int odbc_connect(string dsn, string user, string password, int [cursor_type]);
 
/**
 * Get cursorname
 * <p>
 * odbc_cursor will return a cursorname for the given result_id.
 */
function string odbc_cursor(int result_id);
 
/**
 * synonym for odbc_exec()
 * <p>
 * odbc_do will execute a query on the given connection
 */
function string odbc_do(int conn_id, string query);
 
/**
 * Prepare and execute a SQL statement
 * <p>
 * Returns false on error. Returns an ODBC result identifier if the SQL
 * command was executed successfully.
 * <p>
 * odbc_exec() will send an SQL statement to the database server specified by
 * connection_id. This parameter must be a valid identifier returned by
 * {@link odbc_connect()} or {@link odbc_pconnect()}.
 * 
 * @see odbc_prepare()
 * @see odbc_execute()
 */
function int odbc_exec(int connection_id, string query_string);
 
/**
 * execute a prepared statement
 * <p>
 * Executes a statement prepared with {@link odbc_prepare()}. Returns true on
 * successful execution, false otherwise. The array arameters_array only needs
 * to be given if you really have parameters in your statement.
 */
function int odbc_execute(int result_id, array [parameters_array]);
 
/**
 * Fetch one result row into array
 * <p>
 * Returns the number of columns in the result; false on error. result_array
 * must be passed by reference, but it can be of any type since it will be
 * converted to type array. The array will contain the column values starting
 * at array index 0.
 */
function int odbc_fetch_into(int result_id, int [rownumber], array result_array);
 
/**
 * Fetch a row
 * <p>
 * If odbc_fetch_row() was succesful (there was a row), true is returned. If
 * there are no more rows, false is returned.
 * <p>
 * odbc_fetch_row() fetches a row of the data that was returned by {@link odbc_do()} /
 * {@link odbc_exec()}. After odbc_fetch_row() is called, the fields of that row can
 * be accessed with {@link odbc_result()}.
 * <p>
 * If row_number is not specified, odbc_fetch_row() will try to fetch the next
 * row in the result set. Calls to odbc_fetch_row() with and without
 * row_number can be mixed.
 * <p>
 * To step through the result more than once, you can call odbc_fetch_row()
 * with row_number 1, and then continue doing odbc_fetch_row() without
 * row_number to review the result. If a driver doesn't support fetching rows
 * by number, the row_number parameter is ignored.
 */
function int odbc_fetch_row(int result_id, int [row_number]);
 
/**
 * Get the columnname
 * <p>
 * odbc_field_name() will return the name of the field occupying the given
 * column number in the given ODBC result identifier. Field numbering starts
 * at 1. false is returned on error.
 */
function string odbc_field_name(int result_id, int field_number);
 
/**
 * datatype of a field
 * <p>
 * odbc_field_type() will return the SQL type of the field referecend by
 * number in the given ODBC result identifier. Field numbering starts at 1.
 */
function string odbc_field_type(int result_id, int field_number);
 
/**
 * get the Length of a field
 * <p>
 * odbc_field_len() will return the length of the field referecend by number
 * in the given ODBC result identifier. Field numbering starts at 1.
 */
function int odbc_field_len(int result_id, int field_number);
 
/**
 * free resources associated with a result
 * <p>
 * Always returns true.
 * <p>
 * odbc_free_result() only needs to be called if you are worried about using
 * too much memory while your script is running. All result memory will
 * automatically be freed when the script is finished. But, if you are sure
 * you are not going to need the result data anymore in a script, you may call
 * odbc_free_result(), and the memory associated with result_id will be freed.
 * <p>
 * <b>Note:</b>
 * If auto-commit is disabled (see {@link odbc_autocommit()}) and you
 * call odbc_free_result() before commiting, all pending
 * transactions are rolled back.
 */
function int odbc_free_result(int result_id);
 
/**
 * handling of LONG columns
 * <p>
 * (ODBC SQL types affected: LONG, LONGVARBINARY) The number of bytes returned
 * to PHP is controled by the parameter length. If it is set to 0, Long column
 * data is passed thru to the client.
 * <p>
 * <b>Note:</b>
 * Handling of LONGVARBINARY columns is also affected by
 * {@link odbc_binmode()}
 */
function int odbc_longreadlen(int result_id, int length);
 
/**
 * number of columns in a result
 * <p>
 * odbc_num_fields() will return the number of fields (columns) in an ODBC
 * result. This function will return -1 on error. The argument is a valid
 * result identifier returned by {@link odbc_exec()}.
 */
function int odbc_num_fields(int result_id);
 
/**
 * Open a persistent database connection
 * <p>
 * Returns an ODBC connection id or 0 (false) on error. This function is much
 * like odbc_connect(), except that the connection is not really closed when
 * the script has finished. Future requests for a connection with the same
 * dsn, user, password combination (via {@link odbc_connect()} and {@link odbc_pconnect()})
 * can reuse the persistent connection.
 * <p>
 * <b>Note:</b>
 * Persistent connections have no effect if PHP is used as a
 * CGI program.
 * <p>
 * For information about the optional cursor_type parameter see the
 * {@link odbc_connect()} function. For more information on persistent connections,
 * refer to the PHP FAQ.
 */
function int odbc_pconnect(string dsn, string user, string password, int [cursor_type]);
 
/**
 * Prepares a statement for execution
 * <p>
 * Returns false on error.
 * <p>
 * Returns an ODBC result identifier if the SQL command was prepared
 * successfully. The result identifier can be used later to execute the
 * statement with {@link odbc_execute()}.
 */
function int odbc_prepare(int connection_id, string query_string);
 
/**
 * Number of rows in a result
 * <p>
 * odbc_num_rows() will return the number of rows in an ODBC result. This
 * function will return -1 on error. For INSERT, UPDATE and DELETE statements
 * odbc_num_rows() returns the number of rows affected. For a SELECT clause
 * this can be the number of rows available.
 * <p>
 * <b>Note:</b>
 * Using odbc_num_rows() to determine the number of rows available after
 * a SELECT will return -1 with many drivers.
 */
function int odbc_num_rows(int result_id);
 
/**
 * get result data
 * <p>
 * Returns the contents of the field.
 * <p>
 * field can either be an integer containing the column number of the field
 * you want; or it can be a string containing the name of the field. For
 * example:
 * <pre>
 *      $item_3 = odbc_result($Query_ID, 3 );
 *      $item_val = odbc_result($Query_ID, "val");
 * </pre>
 * The first call to odbc_result() returns the value of the third field in the
 * current record of the query result. The second function call to
 * odbc_result() returns the value of the field whose field name is "val" in
 * the current record of the query result. An error occurs if a column number
 * parameter for a field is less than one or exceeds the number of columns (or
 * fields) in the current record. Similarly, an error occurs if a field with a
 * name that is not one of the fieldnames of the table(s) that is(are) being
 * queried.
 * <p>
 * Field indices start from 1. Regarding the way binary or long column data is
 * returned refer to odbc_binmode () and {@link odbc_longreadlen()}.
 */
function string odbc_result(int result_id, mixed field);
 
/**
 * Print result as HTML table
 * <p>
 * Returns the number of rows in the result or false on error.
 * <p>
 * odbc_result_all() will print all rows from a result identifier produced by
 * {@link odbc_exec()}. The result is printed in HTML table format. With the optional
 * string argument format, additional overall table formatting can be done.
 */
function int odbc_result_all(int result_id, string [format]);
 
/**
 * Rollback a transaction
 * <p>
 * Rolls back all pending statements on connection_id. Returns true on
 * success, false on failure.
 */
function int odbc_rollback(int connection_id);
 
/**
 * e.
 * <p>
 * This function allows fiddling with the ODBC options for a particular
 * connection or query result. It was written to help find work arounds to
 * problems in quirky ODBC drivers. You should probably only use this function
 * if you are an ODBC programmer and understand the effects the various
 * options will have. You will certainly need a good ODBC reference to explain
 * all the different options and values that can be used. Different driver
 * versions support different options.
 * <p>
 * Because the effects may vary depending on the ODBC driver, use of this
 * function in scripts to be made publicly available is strongly discouraged.
 * Also, some ODBC options are not available to this function because they
 * must be set before the connection is established or the query is prepared.
 * However, if on a particular job it can make PHP work so your boss doesn't
 * tell you to use a commercial product, that's all that really matters.
 * <p>
 * Id is a connection id or result id on which to change the settings.For
 * SQLSetConnectOption(), this is a connection id. For SQLSetStmtOption(),
 * this is a result id.
 * <p>
 * function is the ODBC function to use. The value should be 1 for
 * SQLSetConnectOption() and 2 for SQLSetStmtOption().
 * <p>
 * Parmeter option is the option to set.
 * <p>
 * Parameter param is the value for the given option.
 * <b>Example 1.</b> ODBC Setoption Examples
 * <pre>
 *    // 1. Option 102 of SQLSetConnectOption() is SQL_AUTOCOMMIT.
 *    //    Value 1 of SQL_AUTOCOMMIT is SQL_AUTOCOMMIT_ON.
 *    //    This example has the same effect as
 *    //    odbc_autocommit($conn, true);
 *    odbc_setoption ($conn, 1, 102, 1);
 *    // 2. Option 0 of SQLSetStmtOption() is SQL_QUERY_TIMEOUT.
 *    //    This example sets the query to timeout after 30 seconds.
 *    $result = odbc_prepare ($conn, $sql);
 *    odbc_setoption ($result, 2, 0, 30);
 *    odbc_execute ($result);
 * </pre>
 */
function int odbc_setoption(int id, int function, int option, int param);


///////////////////////////////////////////////////////////////////////////
// Oracle 8 functions
// 
// These functions allow you to access Oracle8 and Oracle7 databases. It uses
// the Oracle8 Call-Interface (OCI8). You will need the Oracle8 client
// libraries to use this extension.
// 
// This extension is more flexible than the standard Oracle extension. It
// supports binding of global and local PHP variables to Oracle placeholders,
// has full LOB, FILE and ROWID support and allows you to use user-supplied
// define variables.
//  

/**
 * Use a PHP variable for the define-step during a SELECT
 * <p>
 * OCIDefineByName() uses fetches SQL-Columns into user-defined PHP-Variables.
 * Be careful that Oracle user ALL-UPPERCASE column-names, whereby in your
 * select you can also write lower-case. OCIDefineByName() expects the
 * Column-Name to be in uppercase. If you define a variable that doesn't
 * exists in you select statement, no error will be given!
 * <p>
 * If you need to define an abstract Datatype (LOB/ROWID/BFILE) you need to
 * allocate it first using {@link OCINewDescriptor()} function. See also the
 * {@link OCIBindByName()} function.
 * <p>
 * <b>Example 1.</b> OCIDefineByName
 * <pre>
 *    &lt;?php
 *    // OCIDefineByPos example thies@digicol.de (980219) 
 *    $conn = OCILogon("scott","tiger");
 *    $stmt = OCIParse($conn,"select empno, ename from emp");
 *    // the define MUST be done BEFORE ociexecute! 
 *    OCIDefineByName($stmt,"EMPNO",&$empno);
 *    OCIDefineByName($stmt,"ENAME",&$ename);
 *    OCIExecute($stmt);
 *    while (OCIFetch($stmt)) {
 *        echo "empno:".$empno."\n";
 *        echo "ename:".$ename."\n";
 *    }
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    ?&gt;
 * </pre>
 */
function int OCIDefineByName(int stmt, string Column_Name, mixed &variable, int [type]);
 
/**
 * Bind a PHP variable to an Oracle Placeholder
 * <p>
 * OCIBindByName() binds the PHP variable variable to the Oracle placeholder
 * ph_name. Whether it will be used for input or output will be determined
 * run-time, and the necessary storage space will be allocated. The length
 * paramter sets the maximum length for the bind. If you set length to -1
 * OCIBindByName() will use the current length of variable to set the maximum
 * length.
 * <p>
 * If you need to bind an abstract Datatype (LOB/ROWID/BFILE) you need to
 * allocate it first using {@link OCINewDescriptor()} function. The length is not used
 * for abstract Datatypes and should be set to -1. The type variable tells
 * oracle, what kind of descriptor we want to use. Possible values are:
 * OCI_B_FILE (Binary-File), OCI_B_CFILE (Character-File), OCI_B_CLOB
 * (Character-LOB), OCI_B_BLOB (Binary-LOB) and OCI_B_ROWID (ROWID).
 * <p>
 * <b>Example 1.</b> OCIDefineByName
 * <pre>
 *    &lt;?php
 *    // OCIBindByPos example thies@digicol.de (980221)
 *    //
 *    //  inserts 3 resords into emp, and uses the ROWID for updating the
 *    //  records just after the insert.
 *    <p>
 *    $conn = OCILogon("scott","tiger");
 *    <p>
 *    $stmt = OCIParse($conn,"insert into emp (empno, ename) ".
 *                                               "values (:empno,:ename) ".
 *                                               "returning ROWID into :rid");
 *    <p>
 *    $data = array(1111 =&gt; "Larry", 2222 =&gt; "Bill", 3333 =&gt; "Jim");
 *    $rowid = OCINewDescriptor($conn,OCI_D_ROWID);
 *
 *    OCIBindByName($stmt,":empno",&$empno,32);
 *    OCIBindByName($stmt,":ename",&$ename,32);
 *    OCIBindByName($stmt,":rid",&$rowid,-1,OCI_B_ROWID);
 * 
 *    $update = OCIParse($conn,"update emp set sal = :sal where ROWID = :rid");
 *    OCIBindByName($update,":rid",&$rowid,-1,OCI_B_ROWID);
 *    OCIBindByName($update,":sal",&$sal,32);
 *
 *    $sal = 10000;
 *    while (list($empno,$ename) = each($data)) {
 *            OCIExecute($stmt);
 *            OCIExecute($update);
 *    }
 * 
 *    $rowid-&gt;free();
 *    OCIFreeStatement($update);
 *    OCIFreeStatement($stmt);
 *
 *    $stmt = OCIParse($conn,"select * from emp where empno in (1111,2222,3333)");
 *    OCIExecute($stmt);
 *    while (OCIFetchInto($stmt,&$arr,OCI_ASSOC)) {
 *            var_dump($arr);
 *    }
 *    OCIFreeStatement($stmt);
 *
 *    // delete our "junk" from the emp table.... 
 *    $stmt = OCIParse($conn,"delete from emp where empno in (1111,2222,3333)");
 *    OCIExecute($stmt);
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    ?&gt;
 * </pre>
 */
function int OCIBindByName(int stmt, string ph_name, mixed &variable, intlength, int [type]);
 
/**
 * Establishes a connection to Oracle
 * <p>
 * OCILogon() returns an connection identified needed for most other OCI
 * calls. If the optional third parameter is not specified, PHP uses the
 * environment variable ORACLE_SID to determine which database to connect to.
 * Connections are shared at the page level when using OCILogon(). This means
 * that commits and rollbacks apply to all open transactions in the page, even
 * if you have created multiple connections.
 * <p>
 * This example demonstrates how the connections are shared.
 * <p>
 * <b>Example 1.</b> OCILogon
 * <pre> 
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;pre>";
 *    $db = "";
 * 
 *    $c1 = ocilogon("scott","tiger",$db);
 *    $c2 = ocilogon("scott","tiger",$db);
 * 
 *    function create_table($conn)
 *    { $stmt = ociparse($conn,"create table scott.hallo (test varchar2(32))");
 *      ociexecute($stmt);
 *      echo $conn." created table\n\n";
 *    }
 * 
 *    function drop_table($conn)
 *    { $stmt = ociparse($conn,"drop table scott.hallo");
 *      ociexecute($stmt);
 *      echo $conn." dropped table\n\n";
 *    }
 * 
 *    function insert_data($conn)
 *    { $stmt = ociparse($conn,"insert into scott.hallo values($conn || ' ' || to_char(sysdate,'DD-MON-YY HH24:MI:SS'))");
 *      ociexecute($stmt,OCI_DEFAULT);
 *      echo $conn." inserted hallo\n\n";
 *    }
 * 
 *    function delete_data($conn)
 *    { $stmt = ociparse($conn,"delete from scott.hallo");
 *      ociexecute($stmt,OCI_DEFAULT);
 *      echo $conn." deleted hallo\n\n";
 *    }
 * 
 *    function commit($conn)
 *    { ocicommit($conn);
 *      echo $conn." commited\n\n";
 *    }
 * 
 *    function rollback($conn)
 *    { ocirollback($conn);
 *      echo $conn." rollback\n\n";
 *    }
 * 
 *    function select_data($conn)
 *    { $stmt = ociparse($conn,"select * from scott.hallo");
 *      ociexecute($stmt,OCI_DEFAULT);
 *      echo $conn."----selecting\n\n";
 *      while (ocifetch($stmt))
 *        echo $conn." &lt;".ociresult($stmt,"TEST")."&gt;\n\n";
 *      echo $conn."----done\n\n";
 *    }
 * 
 *    create_table($c1);
 *    insert_data($c1);   // Insert a row using c1
 *    insert_data($c2);   // Insert a row using c2
 * 
 *    select_data($c1);   // Results of both inserts are returned
 *    select_data($c2);
 * 
 *    rollback($c1);      // Rollback using c1
 * 
 *    select_data($c1);   // Both inserts have been rolled back
 *    select_data($c2);
 * 
 *    insert_data($c2);   // Insert a row using c2
 *    commit($c2);        // commit using c2
 * 
 *    select_data($c1);   // result of c2 insert is returned
 * 
 *    delete_data($c1);   // delete all rows in table using c1
 *    select_data($c1);   // no rows returned
 *    select_data($c2);   // no rows returned
 *    commit($c1);        // commit using c1
 * 
 *    select_data($c1);   // no rows returned
 *    select_data($c2);   // no rows returned
 * 
 *    drop_table($c1);
 *    print "&lt;/PRE&gt;&lt;/HTML&gt;";
 *    ?&gt;
 * </pre>
 *
 * @see OCIPLogon()
 * @see OCINLogon()
 */
function int OCILogon(string username, string password, string [ORACLE_SID]);
 
/**
 * turns a new session.
 * <p>
 * OCIPLogon() Creates a persistent connection to an Oracle 8 database and
 * logs on. If the optional third parameter is not specified, PHP uses the
 * environment variable ORACLE_SID to determine which database to connect to.
 * 
 * @see OCILogon()
 * @see OCINLogon()
 */
function int OCIPLogon(int conn);
 
/**
 * turns a new session.
 * <p>
 * OCINLogon() Creates a new connection to an Oracle 8 database and logs on.
 * If the optional third parameter is not specified, PHP uses the environment
 * variable ORACLE_SID to determine which database to connect to. OCINLogon()
 * forces a new connection. This is should be used if you need to isolate a
 * set of transactions. By default, connections are shared at the page level
 * if using {@link OCILogon()} or at the web server process level if using
 * {@link OCIPLogon()}. If you have multiple connections open using {@link OCINLogon()}, all
 * commits and rollbacks apply to the specified connection only..
 * <p>
 * This example demonstrates how the connections are separated.
 * <P>
 * <b>Example 1.</b> OCINLogon
 * <pre>
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;PRE&gt;";
 *    $db = "";
 * 
 *    $c1 = ocilogon("scott","tiger",$db);
 *    $c2 = ocinlogon("scott","tiger",$db);
 * 
 *    function create_table($conn)
 *    { $stmt = ociparse($conn,"create table scott.hallo (test varchar2(32))");
 *      ociexecute($stmt);
 *      echo $conn." created table\n\n";
 *    }
 * 
 *    function drop_table($conn)
 *    { $stmt = ociparse($conn,"drop table scott.hallo");
 *      ociexecute($stmt);
 *      echo $conn." dropped table\n\n";
 *    }
 * 
 *    function insert_data($conn)
 *    { $stmt = ociparse($conn,"insert into scott.hallo values($conn || ' ' || to_char(sysdate,'DD-MON-YY HH24:MI:SS'))");
 *      ociexecute($stmt,OCI_DEFAULT);
 *      echo $conn." inserted hallo\n\n";
 *    }
 * 
 *    function delete_data($conn)
 *    { $stmt = ociparse($conn,"delete from scott.hallo");
 *      ociexecute($stmt,OCI_DEFAULT);
 *      echo $conn." deleted hallo\n\n";
 *    }
 * 
 *    function commit($conn)
 *    { ocicommit($conn);
 *      echo $conn." commited\n\n";
 *    }
 * 
 *    function rollback($conn)
 *    { ocirollback($conn);
 *      echo $conn." rollback\n\n";
 *    }
 * 
 *    function select_data($conn)
 *    { $stmt = ociparse($conn,"select * from scott.hallo");
 *      ociexecute($stmt,OCI_DEFAULT);
 *      echo $conn."----selecting\n\n";
 *      while (ocifetch($stmt))
 *        echo $conn." &lt;".ociresult($stmt,"TEST")."&gt;\n\n";
 *      echo $conn."----done\n\n";
 *    }
 * 
 *    create_table($c1);
 *    insert_data($c1);
 * 
 *    select_data($c1);
 * 
 *    select_data($c2);
 * 
 *    rollback($c1);
 * 
 *    select_data($c1);
 *    select_data($c2);
 * 
 *    insert_data($c2);
 *    commit($c2);
 * 
 *    select_data($c1);
 * 
 *    delete_data($c1);
 *    select_data($c1);
 *    select_data($c2);
 *    commit($c1);
 * 
 *    select_data($c1);
 *    select_data($c2);
 * 
 *    drop_table($c1);
 *    print "&lt;/PRE&gt;&lt;/HTML&gt;";
 *    ?&gt;
 * </pre>
 *
 * @see OCILogon()
 * @see OCIPLogon()
 */
function int OCINLogon(int conn);
 
/**
 * Disconnects from Oracle
 * <p>
 * OCILogOff() closes an Oracle connection.
 */
function int OCILogOff(int connection);
 
/**
 * Execute a statement
 * <p>
 * OCIExecute() executes a previously parsed statement. (see {@link OCIParse()}). The
 * optional mode allows you to specify the execution-mode (default is
 * OCI_COMMIT_ON_SUCCESS). If you don't want statements to be commited
 * automaticly specify OCI_DEFAULT as your mode.
 */
function int OCIExecute(int statement, int [mode]);
 
/**
 * Commits outstanding transactions
 * <p>
 * OCICommit() commits all outstanding statements for Oracle connection
 * connection.
 */
function int OCICommit(int connection);
 
/**
 * Rolls back outstanding transactions
 * <p>
 * OCIRollback() rolls back all outstanding statements for Oracle connection
 * connection.
 */
function int OCIRollback(int connection);
 
/**
 * <p>
 * OCINewDescriptor() Allocates storage to hold descriptors or LOB locators.
 * Valid values for the valid type are OCI_D_FILE, OCI_D_LOB, OCI_D_ROWID.
 * <p>
 * <b>Example 1.</b> OCINewDescriptor
 * <pre>
 *    &lt;?php
 *    // This script is designed to be called from a HTML form.
 *    // It expects $user, $password, $table, $where, and $commitsize
 *    // to be passed in from the form.  The script then deletes
 *    // the selected rows using the ROWID and commits after each
 *    // set of $commitsize rows. (Use with care, there is no rollback)
 *    //
 *    $conn = OCILogon($user, $password);
 *    $stmt = OCIParse($conn,"select rowid from $table $where");
 *    $rowid = OCINewDescriptor($conn,OCI_D_ROWID);
 *    OCIDefineByName($stmt,"ROWID",&$rowid);
 *    OCIExecute($stmt);
 *    while ( OCIFetch($stmt) ) {
 *       $nrows = OCIRowCount($stmt);
 *       $delete = OCIParse($conn,"delete from $table where ROWID = :rid");
 *       OCIBindByName($delete,":rid",&$rowid,-1,OCI_B_ROWID);
 *       OCIExecute($delete);
 *       print "$nrows\n";
 *       if ( ($nrows % $commitsize) == 0 ) {
 *           OCICommit($conn);
 *       }
 *    }
 *    $nrows = OCIRowCount($stmt);
 *    print "$nrows deleted...\n";
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    ?&gt;
 * </pre>
 */
function string OCINewDescriptor(int connection, int [type]);
 
/**
 * Gets the number of affected rows
 * <p>
 * OCIRowCounts() returns the number of rows affected for eg
 * update-statements. This funtions will not tell you the number of rows that
 * a select will return!
 * <p>
 * <b>Example 1.</b> OCIRowCount
 * <pre>
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;PRE&gt;";
 *    $conn = OCILogon("scott","tiger");
 *    $stmt = OCIParse($conn,"create table emp2 as select * from emp");
 *    OCIExecute($stmt);
 *    print OCIRowCount($stmt) . " rows inserted.&lt;BR&gt;";
 *    OCIFreeStatement($stmt);
 *    $stmt = OCIParse($conn,"delete from emp2");
 *    OCIExecute($stmt);
 *    print OCIRowCount($stmt) . " rows deleted.&lt;BR&gt;";
 *    OCICommit($conn);
 *    OCIFreeStatement($stmt);
 *    $stmt = OCIParse($conn,"drop table emp2");
 *    OCIExecute($stmt);
 *    OCIFreeStatement($stmt);
 *    OCILogOff($conn);
 *    print "&lt;/PRE&gt;&lt;/HTML&gt;";
 *    ?&gt;
 * </pre>
 */
function int OCIRowCount(int statement);
 
/**
 * Return the number of result columns in a statement
 * <p>
 * OCINumCols() returns the number of columns in a statement
 * <p>
 * <b>Example 1.</b> OCINumCols
 * <pre>
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;PRE&gt;\n";
 *    $conn = OCILogon("scott", "tiger");
 *    $stmt = OCIParse($conn,"select * from emp");
 *    OCIExecute($stmt);
 *    while ( OCIFetch($stmt) ) {
 *       print "\n";
 *       $ncols = OCINumCols($stmt);
 *       for ( $i = 1; $i &lt;= $ncols; $i++ ) {
 *          $column_name  = OCIColumnName($stmt,$i);
 *          $column_value = OCIResult($stmt,$i);
 *          print $column_name . ': ' . $column_value . "\n";
 *       }
 *       print "\n";
 *    }
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    print "&lt;/PRE&gt;";
 *    print "&lt;/HTML&gt;\n";
 *    ?&gt;
 * </pre>
 */
function int OCINumCols(int stmt);
 
/**
 * Returns coulumn value for fetched row
 * <p>
 * OCIResult() returns the data for column column in the current row (see
 * {@link OCIFetch()}).OCIResult() will return everything as strings except for
 * abstract types (ROWIDs, LOBs and FILEs).
 */
function int OCIResult(int statement, mixed column);
 
/**
 * Fetches the next row into result-buffer
 * <p>
 * OCIFetch() fetches the next row (for SELECT statements) into the internal
 * result-buffer.
 */
function int OCIFetch(int statement);
 
/**
 * Fetches the next row into result-array
 * <p>
 * OCIFetchInto() fetches the next row (for SELECT statements) into the result
 * array. OCIFetchInto() will overwrite the previous content of result. By
 * default result will contain a one-based array of all columns that are not
 * NULL.
 * <p>
 * The mode parameter allows you to change the default behaviour. You can
 * specify more than one flag by simply addig them up (eg
 * OCI_ASSOC+OCI_RETURN_NULLS). The known flags are:
 * <dl>
 * <dt>OCI_ASSOC<dd>Return an associative array.
 * <dt>OCI_NUM<dd>Return an numbered array starting with one. (DEFAULT)
 * <dt>OCI_RETURN_NULLS<dd>Return empty columns.
 * <dt>OCI_RETURN_LOBS<dd>Return the value of a LOB instead of the desxriptor.
 * </dl>
 */
function int OCIFetchInto(int stmt, array &result, int [mode]);
 
/**
 * Fetch all rows of result data into an array.
 * <p>
 * OCIFetchStatement() fetches all the rows from a result into a user-defined
 * array. OCIFetchStatement() returns the number of rows fetched.
 * <p>
 * <b>Example 1.</b> OCIFetchStatement
 * <pre>
 *    <?php
 *    // OCIFetchStatement example mbritton@verinet.com (990624) 
 *    $conn = OCILogon("scott","tiger");
 *    $stmt = OCIParse($conn,"select * from emp");
 *    OCIExecute($stmt);
 * 
 *    $nrows = OCIFetchStatement($stmt,$results);
 *    if ( $nrows &gt; 0 ) {
 *       print "&lt;TABLE BORDER=\"1\"&gt;\n";
 *       print "&lt;TR&gt;\n";
 *       while ( list( $key, $val ) = each( $results ) ) {
 *          print "&lt;TH&gt;$key&lt;/TH&gt;\n";
 *       }
 *       print "&lt;/TR&gt;\n";
 * 
 *       for ( $i = 0; $i &lt; $nrows; $i++ ) {
 *          reset($results);
 *          print "&lt;TR&gt;\n";
 *          while ( $column = each($results) ) {
 *             $data = $column['value'];
 *             print "&lt;TD&gt;$data[$i]&lt;/TD&gt;\n";
 *          }
 *          print "&lt;/TR&gt;\n";
 *       }
 *       print "&lt;/TABLE&gt;\n";
 *    } else {
 *       echo "No data found&lt;BR&gt;\n";
 *    }
 *    print "$nrows Records Selected&lt;BR&gt;\n";
 * 
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    ?&gt;
 * </pre>
 */
function int OCIFetchStatement(int stmt, array &variable);
 
/**
 * test whether a result column is NULL
 * <p>
 * OCIColumnIsNULL() returns true if the returned column col in the result
 * from the statement stmt is NULL. You can either use the column-number
 * (1-Based) or the column-name for the col parameter.
 */
function int OCIColumnIsNULL(int stmt, mixed column);
 
/**
 * return result column size
 * <p>
 * OCIColumnSize() returns the size of the column as given by Oracle. You can
 * either use the column-number (1-Based) or the column-name for the col
 * parameter.
 * <p>
 * <b>Example 1.</b> OCIColumnSize
 * <pre>
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;PRE&gt;\n";
 *    $conn = OCILogon("scott", "tiger");
 *    $stmt = OCIParse($conn,"select * from emp");
 *    OCIExecute($stmt);
 *    print "&lt;TABLE BORDER=\"1\"&gt;";
 *    print "&lt;TR&gt;";
 *    print "&lt;TH&gt;Name&lt;/TH&gt;";
 *    print "&lt;TH&gt;Type&lt;/TH&gt;";
 *    print "&lt;TH&gt;Length&lt;/TH&gt;";
 *    print "&lt;/TR&gt;";
 *    $ncols = OCINumCols($stmt);
 *    for ( $i = 1; $i &lt;= $ncols; $i++ ) {
 *       $column_name  = OCIColumnName($stmt,$i);
 *       $column_type  = OCIColumnType($stmt,$i);
 *       $column_size  = OCIColumnSize($stmt,$i);
 *       print "&lt;TR&gt;";
 *       print "&lt;TD&gt;$column_name&lt;/TD&gt;";
 *       print "&lt;TD&gt;$column_type&lt;/TD&gt;";
 *       print "&lt;TD&gt;$column_size&lt;/TD&gt;";
 *       print "&lt;/TR&gt;";
 *    }
 *    print "&lt;/TABLE&gt;";
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    print "&lt;/PRE&gt;";
 *    print "&lt;/HTML&gt;\n";
 *    ?&gt;
 * </pre>
 *
 * @see OCINumCols()
 * @see OCIColumnName()
 * @see OCIColumnSize()
 */
function int OCIColumnSize(int stmt, mixed column);
 
/**
 * Return a string containing server version information.
 * <p>
 * <b>Example 1.</b> OCIServerVersion
 * <pre>
 *    &lt;?php
 *    $conn = OCILogon("scott","tiger");
 *    print "Server Version: " . OCIServerVersion($conn);
 *    OCILogOff($conn);
 *    ?&gt;
 * </pre>
 */
function string OCIServerVersion(int conn);
 
/**
 * Return the type of an OCI statement.
 * <p>
 * OCIStatementType() returns on of the following values:
 * <ul>
 * <li> "SELECT"
 * <li> "UPDATE"
 * <li> "DELETE"
 * <li> "INSERT"
 * <li> "CREATE"
 * <li> "DROP"
 * <li> "ALTER"
 * <li> "BEGIN"
 * <li> "DECLARE"
 * <li> "UNKNOWN"
 * </ul>
 * <b>Example 1.</b> Code examples
 * <pre>
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;PRE&gt;";
 *    $conn = OCILogon("scott","tiger");
 *    $sql  = "delete from emp where deptno = 10";
 *    $stmt = OCIParse($conn,$sql);
 *    if ( OCIStatementType($stmt) == "DELETE" ) {
 *       die "You are not allowed to delete from this table&lt;BR&gt;";
 *    }
 *    OCILogoff($conn);
 *    print "&lt;/PRE&gt;&lt;/HTML&gt;";
 *    ?&gt;
 * </pre>
 */
function string OCIStatementType(int stmt);
 
/**
 * OCINewCursor() allocates a new statement handle on the specified
 * connection.
 * <p>
 * <b>Example 1.</b> Using a REF CURSOR from a stored procedure
 * <pre>
 *    &lt;?php
 *    // suppose your stored procedure info.output returns a ref cursor in :data
 *    $conn = OCILogon("scott","tiger");
 *    $curs = OCINewCursor($conn);
 *    $stmt = OCIParse($conn,"begin info.output(:data); end;");
 *    ocibindbyname($stmt,"data",&$curs,-1,OCI_B_CURSOR);
 *    ociexecute($stmt);
 *    ociexecute($curs);
 *    while (OCIFetchInto($curs,&$data)) {
 *        var_dump($data);
 *    }
 *    OCIFreeCursor($stmt);
 *    OCIFreeStatement($curs);
 *    OCILogoff($conn);
 *    ?&gt;
 * </pre>
 * <b>Example 2.</b> Using a REF CURSOR in a select statement
 * <pre>
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;BODY&gt;";
 *    $conn = OCILogon("scott","tiger");
 *    $count_cursor = "CURSOR(select count(empno) num_emps from emp " .
 *                    "where emp.deptno = dept.deptno) as EMPCNT from dept";
 *    $stmt = OCIParse($conn,"select deptno,dname,$count_cursor");
 * 
 *    ociexecute($stmt);
 *    print "&lt;TABLE BORDER=\"1\"&gt;";
 *    print "&lt;TR&gt;";
 *    print "&lt;TH&gt;DEPT NAME&lt;/TH&gt;";
 *    print "&lt;TH&gt;DEPT #&lt;/TH&gt;";
 *    print "&lt;TH&gt;# EMPLOYEES&lt;/TH&gt;";
 *    print "&lt;/TR&gt;";
 * 
 *    while (OCIFetchInto($stmt,&$data,OCI_ASSOC)) {
 *        print "&lt;TR&gt;";
 *        $dname  = $data["DNAME"];
 *        $deptno = $data["DEPTNO"];
 *        print "&lt;TD&gt;$dname&lt;/TD&gt;";
 *        print "&lt;TD&gt;$deptno&lt;/TD&gt;";
 *        ociexecute($data[ "EMPCNT" ]);
 *        while (OCIFetchInto($data[ "EMPCNT" ],&$subdata,OCI_ASSOC)) {
 *            $num_emps = $subdata["NUM_EMPS"];
 *            print  "&lt;TD&gt;$num_emps&lt;/TD&gt;";
 *        }
 *        print "&lt;/TR&gt;";
 *    }
 *    print "&lt;/TABLE&gt;";
 *    print "&lt;/BODY&gt;&lt;/HTML&gt;";
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    ?&gt;
 * </pre>
 */
function int OCINewCursor(int conn);
 
/**
 * Free all resources associated with a statement.
 * <p>
 * OCIFreeStatement() returns true if successful, or false if unsuccessful.
 */
function int OCIFreeStatement(int stmt);
 
/**
 * Free all resources associated with a cursor.
 * <p>
 * OCIFreeCursor() returns true if successful, or false if unsuccessful.
 */
function int OCIFreeCursor(int stmt);
 
/**
 * Returns the name of a column.
 * <p>
 * OCIColumnName() returns the name of the column corresponding to the column
 * number (1-based) that is passed in.
 * <p>
 * <b>Example 1.</b> OCIColumnName
 * <pre>
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;PRE&gt;\n";
 *    $conn = OCILogon("scott", "tiger");
 *    $stmt = OCIParse($conn,"select * from emp");
 *    OCIExecute($stmt);
 *    print "&lt;TABLE BORDER=\"1\"&gt;";
 *    print "&lt;TR&gt;";
 *    print "&lt;TH&gt;Name&lt;/TH&gt;";
 *    print "&lt;TH&gt;Type&lt;/TH&gt;";
 *    print "&lt;TH&gt;Length&lt;/TH&gt;";
 *    print "&lt;/TR&gt;";
 *    $ncols = OCINumCols($stmt);
 *    for ( $i = 1; $i &lt;= $ncols; $i++ ) {
 *       $column_name  = OCIColumnName($stmt,$i);
 *       $column_type  = OCIColumnType($stmt,$i);
 *       $column_size  = OCIColumnSize($stmt,$i);
 *       print "&lt;TR&gt;";
 *       print "&lt;TD&gt;$column_name&lt;/TD&gt;";
 *       print "&lt;TD&gt;$column_type&lt;/TD&gt;";
 *       print "&lt;TD&gt;$column_size&lt;/TD&gt;";
 *       print "&lt;/TR&gt;";
 *    }
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    print "&lt;/PRE&gt;";
 *    print "&lt;/HTML&gt;\n";
 * ?&gt;
 * </pre>
 *
 * @see OCINumCols()
 * @see OCIColumnType()
 * @see OCIColumnSize()
 */
function string OCIColumnName(int stmt, int col);
 
/**
 * Returns the data type of a column.
 * <p>
 * OCIColumnType() returns the data type of the column corresponding to the
 * column number (1-based) that is passed in.
 * <p>
 * <b>Example 1.</b> OCIColumnType
 * <pre>
 *    &lt;?php
 *    print "&lt;HTML&gt;&lt;PRE&gt;\n";
 *    $conn = OCILogon("scott", "tiger");
 *    $stmt = OCIParse($conn,"select * from emp");
 *    OCIExecute($stmt);
 *    print "&lt;TABLE BORDER=\"1\"&gt;";
 *    print "&lt;TR&gt;";
 *    print "&lt;TH&gt;Name&lt;/TH&gt;";
 *    print "&lt;TH&gt;Type&lt;/TH&gt;";
 *    print "&lt;TH&gt;Length&lt;/TH&gt;";
 *    print "&lt;/TR&gt;";
 *    $ncols = OCINumCols($stmt);
 *    for ( $i = 1; $i &lt;= $ncols; $i++ ) {
 *       $column_name  = OCIColumnName($stmt,$i);
 *       $column_type  = OCIColumnType($stmt,$i);
 *       $column_size  = OCIColumnSize($stmt,$i);
 *       print "&lt;TR&gt;";
 *       print "&lt;TD&gt;$column_name&lt;/TD&gt;";
 *       print "&lt;TD&gt;$column_type&lt;/TD&gt;";
 *       print "&lt;TD&gt;$column_size&lt;/TD&gt;";
 *       print "&lt;/TR&gt;";
 *    }
 *    OCIFreeStatement($stmt);
 *    OCILogoff($conn);
 *    print "&lt;/PRE&gt;";
 *    print "&lt;/HTML&gt;\n";
 *    ?&gt;
 * </pre>
 *
 * @see OCINumCols()
 * @see OCIColumnName()
 * @see OCIColumnSize()
 */
function mixed OCIColumnType(int stmt, int col);
 
/**
 * Parse a query and return a statement
 * <p>
 * OCIParse() parses the query using conn. It returns true if the query is
 * valid, false if not. The query can be any valid SQL statement.
 */
function int OCIParse(int conn, string query);
 
/**
 * se.
 * <p>
 * OCIError() returns the last error found. If the optional stmt|conn is not
 * provided, the last error encountered is returned. If no error is found,
 * OCIError() returns false.
 */
function int OCIError(int [stmt|conn]);
 
/**
 * disabled
 * <p>
 * OCIInternalDebug() enables internal debug output. Set onoff to 0 to turn
 * debug output off, 1 to turn it on.
 */
function void OCIInternalDebug(int onoff);


///////////////////////////////////////////////////////////////////////////
// Oracle functions
//
 
/**
 * bind a PHP variable to an Oracle parameter
 * <p>
 * Returns true if the bind succeeds, otherwise false. Details about the error
 * can be retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions.
 * <p>
 * This function binds the named PHP variable with a SQL parameter. The SQL
 * parameter must be in the form ":name". With the optional type parameter,
 * you can define whether the SQL parameter is an in/out (0, default), in (1)
 * or out (2) parameter. As of PHP 3.0.1, you can use the constants
 * ORA_BIND_INOUT, ORA_BIND_IN and ORA_BIND_OUT instead of the numbers.
 * <p>
 * ora_bind must be called after {@link ora_parse()} and before {@link ora_exec()}. Input
 * values can be given by assignment to the bound PHP variables, after calling
 * {@link ora_exec()} the bound PHP variables contain the output values if available.
 * <pre>
 *    &lt;?php
 *    ora_parse($curs, "declare tmp INTEGER; begin tmp := :in; :out := tmp; :x := 7.77; end;");
 *    ora_bind($curs, "result", ":x", $len, 2);
 *    ora_bind($curs, "input", ":in", 5, 1);
 *    ora_bind($curs, "output", ":out", 5, 2);
 *    $input = 765;
 *    ora_exec($curs);
 *    echo "Result: $result<BR&gt;Out: $output&lt;BR&gt;In: $input";
 *    ?&gt;
 * </pre>
 */
function int ora_bind(int cursor, string PHP_variable_name, string SQL_parameter_name, int length, int [type]);
 
/**
 * close an Oracle cursor
 * <p>
 * Returns true if the close succeeds, otherwise false. Details about the
 * error can be retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions.
 * <p>
 * This function closes a data cursor opened with {@link ora_open()}.
 */
function int ora_close(int cursor);
 
/**
 * get name of Oracle result column
 * <p>
 * Returns the name of the field/column column on the cursor cursor. The
 * returned name is in all uppercase letters.
 */
function string Ora_ColumnName(int cursor, int column);
 
/**
 * get type of Oracle result column
 * <p>
 * Returns the Oracle data type name of the field/column column on the cursor
 * cursor. The returned type will be one of the following:
 * <ul>
 * <li> "VARCHAR2"
 * <li> "VARCHAR"
 * <li> "CHAR"
 * <li> "NUMBER"
 * <li> "LONG"
 * <li> "LONG RAW"
 * <li> "ROWID"
 * <li> "DATE"
 * <li> "CURSOR"
 * </ul>
 */
function string Ora_ColumnType(int cursor, int column);
 
/**
 * commit an Oracle transaction
 * <p>
 * Returns true on success, false on error. Details about the error can be
 * retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions. This
 * function commits an Oracle transaction. A transaction is defined as all the
 * changes on a given connection since the last commit/rollback, autocommit
 * was turned off or when the connection was established.
 */
function int ora_commit(int conn);
 
/**
 * disable automatic commit
 * <p>
 * Returns true on success, false on error. Details about the error can be
 * retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions.
 * <p>
 * This function turns off automatic commit after each {@link ora_exec()}.
 */
function int ora_commitoff(int conn);
 
/**
 * enable automatic commit
 * <p>
 * This function turns on automatic commit after each {@link ora_exec()} on the given
 * connection.
 * <p>
 * Returns true on success, false on error. Details about the error can be
 * retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions.
 */
function int ora_commiton(int conn);
 
/**
 * get Oracle error message
 * <p>
 * Returns an error message of the form XXX-NNNNN where XXX is where the error
 * comes from and NNNNN identifies the error message.
 * <p>
 * <b>Note:</b>
 * Support for connection ids was added in 3.0.4.
 * <p>
 * On UNIX versions of Oracle, you can find details about an error message
 * like this: $ oerr ora 00001 00001, 00000, "unique constraint (%s.%s)
 * violated" // *Cause: An update or insert statement attempted to insert a
 * duplicate key // For Trusted ORACLE configured in DBMS MAC mode, you may
 * see // this message if a duplicate entry exists at a different level. //
 * *Action: Either remove the unique restriction or do not insert the key
 */
function string Ora_Error(int cursor_or_connection);
 
/**
 * get Oracle error code
 * <p>
 * Returns the numeric error code of the last executed statement on the
 * specified cursor or connection.
 * 
 * @since Support for connection ids was added in 3.0.4.
 */
function int Ora_ErrorCode(int cursor_or_connection);
 
/**
 * execute parsed statement on an Oracle cursor
 * <p>
 * Returns true on success, false on error. Details about the error can be
 * retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions.
 */
function int ora_exec(int cursor);
 
/**
 * fetch a row of data from a cursor
 * <p>
 * Returns true (a row was fetched) or false (no more rows, or an error
 * occured). If an error occured, details can be retrieved using the
 * {@link ora_error()} and {@link ora_errorcode()} functions. If there was no error,
 * {@link ora_errorcode()} will return 0. Retrieves a row of data from the specified
 * cursor.
 */
function int ora_fetch(int cursor);
 
/**
 * get data from a fetched row
 * <p>
 * Returns the column data. If an error occurs, False is returned and
 * {@link ora_errorcode()} will return a non-zero value. Note, however, that a test
 * for False on the results from this function may be true in cases where
 * there is not error as well (NULL result, empty string, the number 0, the
 * string "0"). Fetches the data for a column or function result.
 */
function mixed ora_getcolumn(int cursor, mixed column);
 
/**
 * close an Oracle connection
 * <p>
 * Returns true on success, False on error. Details about the error can be
 * retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions. Logs out the
 * user and disconnects from the server.
 */
function int ora_logoff(int connection);
 
/**
 * open an Oracle connection
 * <p>
 * Establishes a connection between PHP and an Oracle database with the given
 * username and password.
 * <p>
 * Connections can be made using SQL*Net by supplying the TNS name to user
 * like this:
 * <p>
 *    $conn = Ora_Logon("user@TNSNAME", "pass");
 * <p>
 * If you have character data with non-ASCII characters, you should make sure
 * that NLS_LANG is set in your environment. For server modules, you should
 * set it in the server's environment before starting the server.
 * <p>
 * Returns a connection index on success, or false on failure. Details about
 * the error can be retrieved using the {@link ora_error()} and {@link ora_errorcode()}
 * functions.
 */
function int ora_logon(string user, string password);
 
/**
 * open an Oracle cursor
 * <p>
 * Opens an Oracle cursor associated with connection.
 * <p>
 * Returns a cursor index or False on failure. Details about the error can be
 * retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions.
 */
function int ora_open(int connection);
 
/**
 * parse an SQL statement
 * <p>
 * This function parses an SQL statement or a PL/SQL block and associates it
 * with the given cursor. Returns 0 on success or -1 on error.
 */
function int ora_parse(int cursor_ind, string sql_statement, int defer);
 
/**
 * roll back transaction
 * <p>
 * This function undoes an Oracle transaction. (See {@link ora_commit()} for the
 * definition of a transaction.)
 * <p>
 * Returns true on success, false on error. Details about the error can be
 * retrieved using the {@link ora_error()} and {@link ora_errorcode()} functions.
 */
function int ora_rollback(int connection);


///////////////////////////////////////////////////////////////////////////
// Perl-compatible Regular Expression functions
// 
// The syntax for patterns used in these functions closely resembles Perl. The
// expression should be enclosed in the delimiters, a forward slash (/), for
// example. Any character can be used for delimiter as long as it's not
// alphanumeric or backslash (\). If the delimiter character has to be used in
// the expression itself, it needs to be escaped by backslash.
// 
// The ending delimiter may be followed by various modifiers that affect the
// matching. See Pattern Modifiers.
// 
// Example 1. Examples of valid patterns
// 
//    * /<\/\w+>/
// 
//    * |(\d{3})-\d+|Sm
// 
//    * /^(?i)php[34]/
// 
// Example 2. Examples of invalid patterns
// 
//    * /href='(.*)' - missing ending delimiter
// 
//    * /\w+\s*\w+/J - unknown modifier 'J'
// 
//    * 1-\d3-\d3-\d4| - missing starting delimiter
// 
 
/**
 * Perform a regular expression match
 * <p>
 * Searches subject for a match to the regular expression given in pattern.
 * <p>
 * If matches is provided, then it is filled with the results of search.
 * $matches[0] will contain the text that match the full pattern, $matches[1]
 * will have the text that matched the first captured parenthesized
 * subpattern, and so on.
 * <p>
 * Returns true if a match for pattern was found in the subject string, or
 * false if not match was found or an error occurred.
 * <p>
 * <b>Example 1.</b> Getting the page number out of a string
 * <pre>
 *    if (preg_match("/page\s+#(\d+)/i", "Go to page #9.", $parts))
 *       print "Next page is $parts[1]";
 *    else
 *       print "Page not found.";
 * </pre>
 *
 * @see preg_match_all()
 * @see preg_replace()
 * @see preg_split()
 */
function int preg_match(string pattern, string subject, array [matches]);
 
/**
 * Perform a global regular expression match
 * <p>
 * Searches subject for all matches to the regular expression given in pattern
 * and puts them in matches in the order specified by order.
 * <p>
 * After the first match is found, the subsequent searches are continued on
 * from end of the last match.
 * <p>
 * order can be one of two things:
 * <dl>
 * <dt>PREG_PATTERN_ORDER
 * <dd>
 * Orders results so that $matches[0] is an array of full pattern
 * matches, $matches[1] is an array of strings matched by the first
 * parenthesized subpattern, and so on.
 * <pre>
 *     preg_match_all("|&lt;[^&gt;]+&gt;(.*)&lt;/[^&gt;]+&gt;|U", "&lt;b&gt;example: &lt;/b&gt;&lt;div align=left&gt;a test&lt;/div&gt;", $out, PREG_PATTERN_ORDER);
 *     print $out[0][0].", ".$out[0][1]."\n";
 *     print $out[1][0].", ".$out[1][1]."\n"
 * </pre>
 * This example will produce:
 * <pre>
 *     &lt;b&gt;example: &lt;/b&gt;, &lt;div align=left&gt;this is a test&lt;/div&gt;
 *     example: , this is a test
 * </pre>
 * So, $out[0] contains array of strings that matched full pattern, and
 * $out[1] contains array of strings enclosed by tags.
 * <p>
 * <dt>PREG_SET_ORDER
 * <dd>
 * Orders results so that $matches[0] is an array of first set of
 * matches, $matches[1] is an array of second set of matches, and so on.
 * <pre>
 *     preg_match_all("|&lt;[^&gt;]+&gt;(.*)&lt;/[^&gt;]+&gt;|U", "&lt;b&gt;example: &lt;/b&gt;&lt;div align=left&gt;a test&lt;/div&gt;", $out, PREG_SET_ORDER);
 *     print $out[0][0].", ".$out[0][1]."\n";
 *     print $out[1][0].", ".$out[1][1]."\n"
 * </pre>
 * This example will produce:
 * <pre>
 *     &lt;b&gt;example: &lt;/b&gt;, example:
 *     &lt;div align=left&gt;this is a test&lt;/div&gt;, this is a test
 * </pre>
 * In this case, $matches[0] is the first set of matches, and
 * $matches[0][0] has text matched by full pattern, $matches[0][1] has
 * text matched by first subpattern and so on. Similarly, $matches[1] is
 * the second set of matches, etc.
 * </dl>
 * If order is not specified, it is assumed to be PREG_PATTERN_ORDER.
 * <p>
 * Returns the number of full pattern matches, or false if no match is found
 * or an error occurred.
 * <p>
 * <b>Example 1.</b> Getting all phone numbers out of some text.
 * <pre>
 *    preg_match_all("/\(?  (\d{3})?  \)?  (?(1)  [\-\s] ) \d{3}-\d{4}/x",
 *                   "Call 555-1212 or 1-800-555-1212", $phones);
 * </pre>
 *
 * @see preg_match()
 * @see preg_replace()
 * @see preg_split()
 */
function int preg_match_all(string pattern, string subject, array matches, int [order]);
 
/**
 * Perform a regular expression search and replace
 * <p>
 * Searches subject for matches to pattern and replaces them with replacement.
 * <p>
 * replacement may contain references of the form \\n. Every such reference
 * will be replaced by the text captured by the n'th parenthesized pattern. n
 * can be from 0 to 99, and \\0 refers to the text matched by the whole
 * pattern. Opening parentheses are counted from left to right (starting from
 * 1) to obtain the number of the capturing subpattern.
 * <p>
 * If no matches are found in subject, then it will be returned unchanged.
 * <p>
 * Every parameter to preg_replace() can be an array.
 * <p>
 * If subject is an array, then the search and replace is performed on every
 * entry of subject, and the return value is an array as well.
 * <p>
 * If pattern and replacement are arrays, then preg_replace() takes a value
 * from each array and uses them to do search and replace on subject. If
 * replacement has fewer values than pattern, then empty string is used for
 * the rest of replacement values. If pattern is an array and replacement is a
 * string; then this replacement string is used for every value of pattern.
 * The converse would not make sense, though.
 * <p>
 * /e modifier makes preg_replace() treat the replacement parameter as PHP
 * code after the appropriate references substitution is done. Tip: make sure
 * that replacement constitutes a valid PHP code string, otherwise PHP will
 * complain about a parse error at the line containing preg_replace().
 * <p>
 * <b>Note:</b>
 * This modifier was added in PHP 4.0.
 * <p>
 * <b>Example 1.</b> Replacing several values
 * <pre>
 *    $patterns = array("/(19|20\d{2})-(\d{1,2})-(\d{1,2})/", "/^\s*{(\w+)}\s*=/");
 *    $replace = array("\\3/\\4/\\1", "$\\1 =");
 *    print preg_replace($patterns, $replace, "{startDate} = 1999-5-27");
 * </pre>
 * This example will produce:
 * <pre>
 *    $startDate = 5/27/1999
 * </pre>
 * <b>Example 2.</b> Using /e modifier
 * <pre>
 *    preg_replace("/(&lt;\/?)(\w+)([^&gt;]*&gt;)/e", "'\\1'.strtoupper('\\2').'\\3'", $html_body);
 * </pre>
 * This would capitalize all HTML tags in the input text.
 * 
 * @see preg_match()
 * @see preg_match_all()
 * @see preg_split()
 */
function mixed preg_replace(mixed pattern, mixed replacement, mixed subject);
 
/**
 * Split string by a regular expression
 * <p>
 * Returns an array containing substrings of subject split along boundaries
 * matched by pattern.
 * <p>
 * If limit is specified, then only substrings up to limit are returned.
 * <p>
 * <b>Example 1.</b> Getting parts of search string
 * <pre>
 *    $keywords = preg_split("/[\s,]+/", "hypertext language, programming");
 * </pre>
 * 
 * @see preg_match()
 * @see preg_match_all()
 * @see preg_replace()
 */
function array preg_split(string pattern, string subject, int [limit]);
 
/**
 * Quote regular expression characters
 * <p>
 * preg_quote() takes str and puts a backslash in front of every character
 * that is part of the regular expression syntax. This is useful if you have a
 * run-time string that you need to match in some text and the string may
 * contain special regex characters.
 * <p>
 * The special regular expression characters are:
 * <pre>
 *    . \\ + * ? [ ^ ] $ ( ) { } = ! &lt; &gt; | :
 * </pre>
 *
 * @since This function was added in PHP 3.0.9.
 */
function string preg_quote(string str);
 
/**
 * Return array entries that match the pattern
 * <p>
 * preg_grep() returns the array consisting of the elements of the input array
 * that match the given pattern.
 * <p>
 * <b>Example 1.</b> preg_grep() example
 * <pre>
 *    preg_grep("/^(\d+)?\.\d+$/", $array); // find all floating point numbers in the array
 * </pre>
 * 
 * @since This function was added in PHP 4.0.
 */
function array preg_grep(string pattern, array input);
 
/**
 * describes possible modifiers in regex patterns
 * <p>
 * The current possible PCRE modifiers are listed below. The names in
 * parentheses refer to internal PCRE names for these modifiers.
 * <dl>
 * <dt> i (PCRE_CASELESS)
 * <dd>
 * If this modifier is set, letters in the pattern match both
 * upper and lower case letters.
 * <dt> m (PCRE_MULTILINE)
 * <dd>
 * By default, PCRE treats the subject string as consisting of
 * a single "line" of characters (even if it actually contains
 * several newlines). The "start of line" metacharacter (^)
 * matches only at the start of the string, while the "end of
 * line" metacharacter ($) matches only at the end of the
 * string, or before a terminating newline (unless E modifier
 * is set). This is the same as Perl.
 * <p>
 * When this modifier is set, the "start of line" and "end of
 * line" constructs match immediately following or immediately
 * before any newline in the subject string, respectively, as
 * well as at the very start and end. This is equivalent to
 * Perl's /m modifier. If there are no "\n" characters in a
 * subject string, or no occurrences of ^ or $ in a pattern,
 * setting this modifier has no effect.
 * <dt> s (PCRE_DOTALL)
 * <dd>
 * If this modifier is set, a dot metacharater in the pattern
 * matches all characters, including newlines. Without it,
 * newlines are excluded. This modifier is equivalent to Perl's
 * /s modifier. A negative class such as [^a] always matches a
 * newline character, independent of the setting of this
 * modifier.
 * <dt> x (PCRE_EXTENDED)
 * <dd>
 * If this modifier is set, whitespace data characters in the
 * pattern are totally ignored except when escaped or inside a
 * character class, and characters between an unescaped #
 * outside a character class and the next newline character,
 * inclusive, are also ignored. This is equivalent to Perl's /x
 * modifier, and makes it possible to include comments inside
 * complicated patterns. Note, however, that this applies only
 * to data characters. Whitespace characters may never appear
 * within special character sequences in a pattern, for example
 * within the sequence (?( which introduces a conditional
 * subpattern.
 * <dt> e
 * <dd>
 * If this modifier is set, preg_replace() does normal
 * substitution of \\ references in the replacement string,
 * evaluates it as PHP code, and uses the result for replacing
 * the search string.
 * </dl>
 * Only preg_replace() uses this modifier; it is ignored by
 * other PCRE functions.
 * <p>
 * <b>Note:</b>
 * This modifier was added in PHP 4.0.
 * <dl>
 * <dt> A (PCRE_ANCHORED)
 * <dd>
 * If this modifier is set, the pattern is forced to be
 * "anchored", that is, it is constrained to match only at the
 * start of the string which is being searched (the "subject
 * string"). This effect can also be achieved by appropriate
 * constructs in the pattern itself, which is the only way to
 * do it in Perl.
 * <dt> E (PCRE_DOLLAR_ENDONLY)
 * <dd>
 * If this modifier is set, a dollar metacharacter in the
 * pattern matches only at the end of the subject string.
 * Without this modifier, a dollar also matches immediately
 * before the final character if it is a newline (but not
 * before any other newlines). This modifier is ignored if m
 * modifier is set. There is no equivalent to this modifier in
 * Perl.
 * <dt> S
 * <dd>
 * When a pattern is going to be used several times, it is
 * worth spending more time analyzing it in order to speed up
 * the time taken for matching. If this modifier is set, then
 * this extra analysis is performed. At present, studying a
 * pattern is useful only for non-anchored patterns that do not
 * have a single fixed starting character.
 * <dt> U (PCRE_UNGREEDY)
 * <dd>
 * This modifier inverts the "greediness" of the quantifiers so
 * that they are not greedy by default, but become greedy if
 * followed by "?". It is not compatible with Perl. It can also
 * be set by a (?U) modifier setting within the pattern.
 * <dt> X (PCRE_EXTRA)
 * <dd>
 * This modifier turns on additional functionality of PCRE that
 * is incompatible with Perl. Any backslash in a pattern that
 * is followed by a letter that has no special meaning causes
 * an error, thus reserving these combinations for future
 * expansion. By default, as in Perl, a backslash followed by a
 * letter with no special meaning is treated as a literal.
 * There are at present no other features controlled by this
 * modifier.
 * </dl>
 */
function pcre_modifiers();
 
/**
 * describes PCRE regex syntax
 * <p>
 * The PCRE library is a set of functions that implement regular
 * expression pattern matching using the same syntax and semantics
 * as Perl 5, with just a few differences (see below).  The current
 * implementation corresponds to Perl 5.005.
 * <p>
 * Differences From Perl
 * <p>
 * The differences described here  are  with  respect  to  Perl
 * 5.005.
 * <ol>
 * <li> By default, a whitespace character is any character  that
 *      the  C  library  function {@link isspace()} recognizes, though it is
 *      possible to compile PCRE  with  alternative  character  type
 *      tables. Normally {@link isspace()} matches space, formfeed, newline,
 *      carriage return, horizontal tab, and vertical tab. Perl 5 no
 *      longer  includes vertical tab in its set of whitespace char-
 *      acters. The \v escape that was in the Perl documentation for
 *      a long time was never in fact recognized. However, the char-
 *      acter itself was treated as whitespace at least up to 5.002.
 *      In 5.004 and 5.005 it does not match \s.
 * 
 * <li> PCRE does  not  allow  repeat  quantifiers  on  lookahead
 *      assertions. Perl permits them, but they do not mean what you
 *      might think. For example, (?!a){3} does not assert that  the
 *      next  three characters are not "a". It just asserts that the
 *      next character is not "a" three times.
 * 
 * <li> Capturing subpatterns that occur inside  negative  looka-
 *      head  assertions  are  counted,  but  their  entries  in the
 *      offsets vector are never set. Perl sets its numerical  vari-
 *      ables  from  any  such  patterns that are matched before the
 *      assertion fails to match something (thereby succeeding), but
 *      only  if  the negative lookahead assertion contains just one
 *      branch.
 * 
 * <li> Though binary zero characters are supported in  the  sub-
 *      ject  string,  they  are  not  allowed  in  a pattern string
 *      because it is passed as a normal  C  string,  terminated  by
 *      zero. The escape sequence "\0" can be used in the pattern to
 *      represent a binary zero.
 * 
 * <li> The following Perl escape sequences  are  not  supported:
 *      \l,  \u,  \L,  \U,  \E, \Q. In fact these are implemented by
 *      Perl's general string-handling and are not part of its  pat-
 *      tern matching engine.
 * 
 * <li> The Perl \G assertion is  not  supported  as  it  is  not
 *      relevant to single pattern matches.
 * 
 * <li> Fairly obviously, PCRE does  not  support  the  (?{code})
 *      construction.
 * 
 * <li> There are at the time of writing some  oddities  in  Perl
 *      5.005_02  concerned  with  the  settings of captured strings
 *      when part of a pattern is repeated.  For  example,  matching
 *      "aba"  against the pattern /^(a(b)?)+$/ sets $2 to the value
 *      "b", but matching "aabbaa" against /^(aa(bb)?)+$/ leaves  $2
 *      unset.    However,    if   the   pattern   is   changed   to
 *      /^(aa(b(b))?)+$/ then $2 (and $3) get set.
 * <p>
 *      In Perl 5.004 $2 is set in both cases, and that is also true
 *      of PCRE. If in the future Perl changes to a consistent state
 *      that is different, PCRE may change to follow.
 * 
 * <li> Another as yet unresolved discrepancy  is  that  in  Perl
 *      5.005_02  the  pattern /^(a)?(?(1)a|b)+$/ matches the string
 *      "a", whereas in PCRE it does not.  However, in both Perl and
 *      PCRE /^(a)?a/ matched against "a" leaves $1 unset.
 * 
 * <li>PCRE  provides  some  extensions  to  the  Perl  regular
 *      expression facilities:
 * <ul>
 * <li> Although lookbehind assertions must match  fixed  length
 *      strings,  each  alternative branch of a lookbehind assertion
 *      can match a different length of string. Perl 5.005  requires
 *      them all to have the same length.
 * <li> If PCRE_DOLLAR_ENDONLY is set and PCRE_MULTILINE is  not
 *      set,  the  $ meta- character matches only at the very end of
 *      the string.
 * <li> If PCRE_EXTRA is set, a backslash followed by  a  letter
 *      with no special meaning is faulted.
 * <li> If PCRE_UNGREEDY is set, the greediness of  the  repeti-
 *      tion  quantifiers  is inverted, that is, by default they are
 *      not greedy, but if followed by a question mark they are.
 * </ul>
 * </ul>
 * Regular Expression Details
 * <p>
 *      The syntax and semantics of  the  regular  expressions  sup-
 *      ported  by PCRE are described below. Regular expressions are
 *      also described in the Perl documentation and in a number  of
 *      other  books,  some  of which have copious examples. Jeffrey
 *      Friedl's  "Mastering  Regular  Expressions",  published   by
 *      O'Reilly  (ISBN 1-56592-257-3), covers them in great detail.
 *      The description here is intended as reference documentation.
 * <p>
 *      A regular expression is a pattern that is matched against  a
 *      subject string from left to right. Most characters stand for
 *      themselves in a pattern, and match the corresponding charac-
 *      ters in the subject. As a trivial example, the pattern
 * <p>
 *      The quick brown fox
 * <p>
 *      matches a portion of a subject string that is  identical  to
 *      itself.  The  power  of  regular  expressions comes from the
 *      ability to include alternatives and repetitions in the  pat-
 *      tern.  These  are encoded in the pattern by the use of meta-
 *      characters, which do not stand for  themselves  but  instead
 *      are interpreted in some special way.
 * <p>
 *      There are two different sets of meta-characters: those  that
 *      are  recognized anywhere in the pattern except within square
 *      brackets, and those that are recognized in square  brackets.
 *      Outside square brackets, the meta-characters are as follows:
 * <pre>
 *        \      general escape character with several uses
 *        ^      assert start of  subject  (or  line,  in  multiline
 *      mode)
 *        $      assert end of subject (or line, in multiline mode)
 *        .      match any character except newline (by default)
 *        [      start character class definition
 *        |      start of alternative branch
 *        (      start subpattern
 *        )      end subpattern
 *        ?      extends the meaning of (
 *               also 0 or 1 quantifier
 *               also quantifier minimizer
 *        *      0 or more quantifier
 *        +      1 or more quantifier
 *        {      start min/max quantifier
 * </pre>
 *      Part of a pattern that is in square  brackets  is  called  a
 *      "character  class".  In  a  character  class  the only meta-
 *      characters are:
 * <pre>
 *        \      general escape character
 *        ^      negate the class, but only if the first character
 *        -      indicates character range
 *        ]      terminates the character class
 * </pre>
 * The following sections describe  the  use  of  each  of  the
 * meta-characters.
 * <dl>
 * <dt>BACKSLASH
 * <dd>
 *      The backslash character has several uses. Firstly, if it  is
 *      followed  by  a  non-alphameric character, it takes away any
 *      special  meaning  that  character  may  have.  This  use  of
 *      backslash  as  an  escape  character applies both inside and
 *      outside character classes.
 * <p>
 *      For example, if you want to match a "*" character, you write
 *      "\*" in the pattern. This applies whether or not the follow-
 *      ing character would otherwise  be  interpreted  as  a  meta-
 *      character,  so it is always safe to precede a non-alphameric
 *      with "\" to specify that it stands for itself.  In  particu-
 *      lar, if you want to match a backslash, you write "\\".
 * <p>
 *      If a pattern is compiled with the PCRE_EXTENDED option, whi-
 *      tespace in the pattern (other than in a character class) and
 *      characters between a "#" outside a character class  and  the
 *      next  newline  character  are ignored. An escaping backslash
 *      can be used to include a whitespace or "#" character as part
 *      of the pattern.
 * <p>
 *      A second use of backslash provides a way  of  encoding  non-
 *      printing  characters  in patterns in a visible manner. There
 *      is no restriction on the appearance of non-printing  charac-
 *      ters,  apart from the binary zero that terminates a pattern,
 *      but when a pattern is being prepared by text editing, it  is
 *      usually  easier to use one of the following escape sequences
 *      than the binary character it represents:
 * <pre>
 *        \a     alarm, that is, the BEL character (hex 07)
 *        \cx    "control-x", where x is any character
 *        \e     escape (hex 1B)
 *        \f     formfeed (hex 0C)
 *        \n     newline (hex 0A)
 *        \r     carriage return (hex 0D)
 *        \t     tab (hex 09)
 *        \xhh   character with hex code hh
 *        \ddd   character with octal code ddd, or backreference
 * </pre>
 *      The precise effect of "\cx" is as follows: if "x" is a lower
 *      case  letter,  it  is converted to upper case. Then bit 6 of
 *      the character (hex 40) is inverted.  Thus "\cz" becomes  hex
 *      1A, but "\c{" becomes hex 3B, while "\c;" becomes hex 7B.
 * <p>
 *      After "\x", up to two hexadecimal digits are  read  (letters
 *      can be in upper or lower case).
 * <p>
 *      After "\0" up to two further octal digits are read. In  both
 *      cases,  if  there are fewer than two digits, just those that
 *      are present are used. Thus the sequence "\0\x\07"  specifies
 *      two binary zeros followed by a BEL character.  Make sure you
 *      supply two digits after the initial zero  if  the  character
 *      that follows is itself an octal digit.
 * <p>
 *      The handling of a backslash followed by a digit other than 0
 *      is  complicated.   Outside  a character class, PCRE reads it
 *      and any following digits as a decimal number. If the  number
 *      is  less  than  10, or if there have been at least that many
 *      previous capturing left parentheses in the  expression,  the
 *      entire  sequence is taken as a back reference. A description
 *      of how this works is given later, following  the  discussion
 *      of parenthesized subpatterns.
 * <p>
 *      Inside a character  class,  or  if  the  decimal  number  is
 *      greater  than  9 and there have not been that many capturing
 *      subpatterns, PCRE re-reads up to three octal digits  follow-
 *      ing  the  backslash,  and  generates  a single byte from the
 *      least significant 8 bits of the value. Any subsequent digits
 *      stand for themselves.  For example:
 * <pre>
 *        \040   is another way of writing a space
 *        \40    is the same, provided there are fewer than 40
 *                  previous capturing subpatterns
 *        \7     is always a back reference
 *        \11    might be a back reference, or another way of
 *                  writing a tab
 *        \011   is always a tab
 *        \0113  is a tab followed by the character "3"
 *        \113   is the character with octal code 113 (since there
 *                  can be no more than 99 back references)
 *        \377   is a byte consisting entirely of 1 bits
 *        \81    is either a back reference, or a binary zero
 *                  followed by the two characters "8" and "1"
 * </pre>
 *      Note that octal values of 100 or greater must not be  intro-
 *      duced  by  a  leading zero, because no more than three octal
 *      digits are ever read.
 * <p>
 *      All the sequences that define a single  byte  value  can  be
 *      used both inside and outside character classes. In addition,
 *      inside a character class, the sequence "\b"  is  interpreted
 *      as  the  backspace  character  (hex 08). Outside a character
 *      class it has a different meaning (see below).
 * <p>
 *      The third use of backslash is for specifying generic charac-
 *      ter types:
 * <pre>
 *        \d     any decimal digit
 *        \D     any character that is not a decimal digit
 *        \s     any whitespace character
 *        \S     any character that is not a whitespace character
 *        \w     any "word" character
 *        \W     any "non-word" character
 * </pre>
 *      Each pair of escape sequences partitions the complete set of
 *      characters  into  two  disjoint  sets.  Any  given character
 *      matches one, and only one, of each pair.
 * <p>
 *      A "word" character is any letter or digit or the  underscore
 *      character,  that  is,  any  character which can be part of a
 *      Perl "word". The definition of letters and  digits  is  con-
 *      trolled  by PCRE's character tables, and may vary if locale-
 *      specific matching is  taking  place  (see  "Locale  support"
 *      above). For example, in the "fr" (French) locale, some char-
 *      acter codes greater than 128 are used for accented  letters,
 *      and these are matched by \w.
 * <p>
 *      These character type sequences can appear  both  inside  and
 *      outside  character classes. They each match one character of
 *      the appropriate type. If the current matching  point  is  at
 *      the end of the subject string, all of them fail, since there
 *      is no character to match.
 * <p>
 *      The fourth use of backslash is  for  certain  simple  asser-
 *      tions. An assertion specifies a condition that has to be met
 *      at a particular point in  a  match,  without  consuming  any
 *      characters  from  the subject string. The use of subpatterns
 *      for more complicated  assertions  is  described  below.  The
 *      backslashed assertions are
 * <pre>
 *        \b     word boundary
 *        \B     not a word boundary
 *        \A     start of subject (independent of multiline mode)
 *        \Z     end of subject or newline at  end  (independent  of
 *               multiline mode)
 *        \z     end of subject (independent of multiline mode)
 * </pre>
 *      These assertions may not appear in  character  classes  (but
 *      note that "\b" has a different meaning, namely the backspace
 *      character, inside a character class).
 * <p>
 *      A word boundary is a position in the  subject  string  where
 *      the current character and the previous character do not both
 *      match \w or \W (i.e. one matches \w and  the  other  matches
 *      \W),  or the start or end of the string if the first or last
 *      character matches \w, respectively.
 * <p>
 *      The \A, \Z, and \z assertions differ  from  the  traditional
 *      circumflex  and  dollar  (described below) in that they only
 *      ever match at the very start and end of the subject  string,
 *      whatever  options  are  set.  They  are  not affected by the
 *      PCRE_NOTBOL or PCRE_NOTEOL options. The  difference  between
 *      \Z  and  \z  is that \Z matches before a newline that is the
 *      last character of the string as well as at the  end  of  the
 *      string, whereas \z matches only at the end.
 * 
 * <dt> CIRCUMFLEX AND DOLLAR
 * <dd>
 *      Outside a character class, in the default matching mode, the
 *      circumflex  character  is an assertion which is true only if
 *      the current matching point is at the start  of  the  subject
 *      string. Inside a character class, circumflex has an entirely
 *      different meaning (see below).
 * <p>
 *      Circumflex need not be the first character of the pattern if
 *      a  number of alternatives are involved, but it should be the
 *      first thing in each alternative in which it appears  if  the
 *      pattern is ever to match that branch. If all possible alter-
 *      natives start with a circumflex, that is, if the pattern  is
 *      constrained to match only at the start of the subject, it is
 *      said to be an "anchored" pattern. (There are also other con-
 *      structs that can cause a pattern to be anchored.)
 * <p>
 *      A dollar character is an assertion which is true only if the
 *      current  matching point is at the end of the subject string,
 *      or immediately before a newline character that is  the  last
 *      character in the string (by default). Dollar need not be the
 *      last character of the pattern if a  number  of  alternatives
 *      are  involved,  but it should be the last item in any branch
 *      in which it appears.  Dollar has no  special  meaning  in  a
 *      character class.
 * <p>
 *      The meaning of dollar can be changed so that it matches only
 *      at   the   very   end   of   the   string,  by  setting  the
 *      PCRE_DOLLAR_ENDONLY option at compile or matching time. This
 *      does not affect the \Z assertion.
 * <p>
 *      The meanings of the circumflex  and  dollar  characters  are
 *      changed  if  the  PCRE_MULTILINE option is set. When this is
 *      the case,  they  match  immediately  after  and  immediately
 *      before an internal "\n" character, respectively, in addition
 *      to matching at the start and end of the subject string.  For
 *      example,  the  pattern  /^abc$/  matches  the subject string
 *      "def\nabc" in multiline  mode,  but  not  otherwise.  Conse-
 *      quently,  patterns  that  are  anchored  in single line mode
 *      because all branches start with "^" are not anchored in mul-
 *      tiline  mode.  The  PCRE_DOLLAR_ENDONLY option is ignored if
 *      PCRE_MULTILINE is set.
 * <p>
 *      Note that the sequences \A, \Z, and \z can be used to  match
 *      the  start  and end of the subject in both modes, and if all
 *      branches of a pattern start with \A is it  always  anchored,
 *      whether PCRE_MULTILINE is set or not.
 * 
 * <dt> FULL STOP (PERIOD, DOT)
 * <dd>
 *      Outside a character class, a dot in the pattern matches  any
 *      one  character  in  the  subject,  including  a non-printing
 *      character, but not (by default) newline.  If the PCRE_DOTALL
 *      option  is  set,  then dots match newlines as well. The han-
 *      dling of dot is entirely independent of the handling of cir-
 *      cumflex  and  dollar,  the only relationship being that they
 *      both involve newline characters.  Dot has no special meaning
 *      in a character class.
 *
 * <dt> SQUARE BRACKETS
 * <dd>
 *      An opening square bracket introduces a character class, ter-
 *      minated  by  a  closing  square  bracket.  A  closing square
 *      bracket on its own is  not  special.  If  a  closing  square
 *      bracket  is  required as a member of the class, it should be
 *      the first data character in the class (after an initial cir-
 *      cumflex, if present) or escaped with a backslash.
 * <p>
 *      A character class matches a single character in the subject;
 *      the  character  must  be in the set of characters defined by
 *      the class, unless the first character in the class is a cir-
 *      cumflex,  in which case the subject character must not be in
 *      the set defined by the class. If a  circumflex  is  actually
 *      required  as  a  member  of  the class, ensure it is not the
 *      first character, or escape it with a backslash.
 * <p>
 *      For example, the character class [aeiou] matches  any  lower
 *      case vowel, while [^aeiou] matches any character that is not
 *      a lower case vowel. Note that a circumflex is  just  a  con-
 *      venient  notation for specifying the characters which are in
 *      the class by enumerating those that are not. It  is  not  an
 *      assertion:  it  still  consumes a character from the subject
 *      string, and fails if the current pointer is at  the  end  of
 *      the string.
 * <p>
 *      When caseless matching  is  set,  any  letters  in  a  class
 *      represent  both their upper case and lower case versions, so
 *      for example, a caseless [aeiou] matches "A" as well as  "a",
 *      and  a caseless [^aeiou] does not match "A", whereas a case-
 *      ful version would.
 * <p>
 *      The newline character is never treated in any special way in
 *      character  classes,  whatever the setting of the PCRE_DOTALL
 *      or PCRE_MULTILINE options is. A  class  such  as  [^a]  will
 *      always match a newline.
 * <p>
 *      The minus (hyphen) character can be used to specify a  range
 *      of  characters  in  a  character  class.  For example, [d-m]
 *      matches any letter between d and m, inclusive.  If  a  minus
 *      character  is required in a class, it must be escaped with a
 *      backslash or appear in a position where it cannot be  inter-
 *      preted as indicating a range, typically as the first or last
 *      character in the class.
 *      It is not possible to have the literal character "]" as  the
 *      end  character  of  a  range.  A  pattern such as [W-]46] is
 *      interpreted as a class of two characters ("W" and "-")  fol-
 *      lowed by a literal string "46]", so it would match "W46]" or
 *      "-46]". However, if the "]" is escaped with a  backslash  it
 *      is  interpreted  as  the end of range, so [W-\]46] is inter-
 *      preted as a single class containing a range followed by  two
 *      separate characters. The octal or hexadecimal representation
 *      of "]" can also be used to end a range.
 * <p>
 *      Ranges operate in ASCII collating sequence. They can also be
 *      used  for  characters  specified  numerically,  for  example
 *      [\000-\037]. If a range that includes letters is  used  when
 *      caseless  matching  is set, it matches the letters in either
 *      case. For example, [W-c] is equivalent  to  [][\^_`wxyzabc],
 *      matched  caselessly,  and  if  character tables for the "fr"
 *      locale are in use, [\xc8-\xcb] matches accented E characters
 *      in both cases.
 * <p>
 *      The character types \d, \D, \s, \S,  \w,  and  \W  may  also
 *      appear  in  a  character  class, and add the characters that
 *      they match to the class. For example, [\dABCDEF] matches any
 *      hexadecimal  digit.  A  circumflex  can conveniently be used
 *      with the upper case character types to specify a  more  res-
 *      tricted set of characters than the matching lower case type.
 *      For example, the class [^\W_] matches any letter  or  digit,
 *      but not underscore.
 * <p>
 *      All non-alphameric characters other than \,  -,  ^  (at  the
 *      start)  and  the  terminating ] are non-special in character
 *      classes, but it does no harm if they are escaped.
 * 
 * <dt> VERTICAL BAR
 * <dd>
 *      Vertical bar characters are  used  to  separate  alternative
 *      patterns. For example, the pattern
 * <pre>
 *        gilbert|sullivan
 * </pre>
 *      matches either "gilbert" or "sullivan". Any number of alter-
 *      natives  may  appear,  and an empty alternative is permitted
 *      (matching the empty string).   The  matching  process  tries
 *      each  alternative in turn, from left to right, and the first
 *      one that succeeds is used. If the alternatives are within  a
 *      subpattern  (defined  below),  "succeeds" means matching the
 *      rest of the main pattern as well as the alternative  in  the
 *      subpattern.
 * 
 * <dt> INTERNAL OPTION SETTING
 * <dd>
 *      The settings of PCRE_CASELESS, PCRE_MULTILINE,  PCRE_DOTALL,
 *      and  PCRE_EXTENDED can be changed from within the pattern by
 *      a sequence of Perl option letters enclosed between "(?"  and
 *      ")". The option letters are
 * <pre>
 *        i  for PCRE_CASELESS
 *        m  for PCRE_MULTILINE
 *        s  for PCRE_DOTALL
 *        x  for PCRE_EXTENDED
 * </pre>
 *      For example, (?im) sets caseless, multiline matching. It  is
 *      also possible to unset these options by preceding the letter
 *      with a hyphen, and a combined setting and unsetting such  as
 *      (?im-sx),  which sets PCRE_CASELESS and PCRE_MULTILINE while
 *      unsetting PCRE_DOTALL and PCRE_EXTENDED, is also  permitted.
 *      If  a  letter  appears both before and after the hyphen, the
 *      option is unset.
 * <p>
 *      The scope of these option changes depends on  where  in  the
 *      pattern  the  setting  occurs. For settings that are outside
 *      any subpattern (defined below), the effect is the same as if
 *      the  options were set or unset at the start of matching. The
 *      following patterns all behave in exactly the same way:
 * <pre>
 *        (?i)abc
 *        a(?i)bc
 *        ab(?i)c
 *        abc(?i)
 * </pre>
 *      which in turn is the same as compiling the pattern abc  with
 *      PCRE_CASELESS  set.   In  other words, such "top level" set-
 *      tings apply to the whole pattern  (unless  there  are  other
 *      changes  inside subpatterns). If there is more than one set-
 *      ting of the same option at top level, the rightmost  setting
 *      is used.
 * <p>
 *      If an option change occurs inside a subpattern,  the  effect
 *      is  different.  This is a change of behaviour in Perl 5.005.
 *      An option change inside a subpattern affects only that  part
 *      of the subpattern that follows it, so
 * <pre>
 *        (a(?i)b)c
 * </pre>
 *      matches  abc  and  aBc  and  no  other   strings   (assuming
 *      PCRE_CASELESS  is  not used).  By this means, options can be
 *      made to have different settings in different  parts  of  the
 *      pattern.  Any  changes  made  in one alternative do carry on
 *      into subsequent branches within  the  same  subpattern.  For
 *      example,
 * <pre>
 *        (a(?i)b|c)
 * </pre>
 *      matches "ab", "aB", "c", and "C", even though when  matching
 *      "C" the first branch is abandoned before the option setting.
 *      This is because the effects of  option  settings  happen  at
 *      compile  time. There would be some very weird behaviour oth-
 *      erwise.
 * <p>
 *      The PCRE-specific options PCRE_UNGREEDY and  PCRE_EXTRA  can
 *      be changed in the same way as the Perl-compatible options by
 *      using the characters U and X  respectively.  The  (?X)  flag
 *      setting  is  special in that it must always occur earlier in
 *      the pattern than any of the additional features it turns on,
 *      even when it is at top level. It is best put at the start.
 *
 * <dt> SUBPATTERNS
 * <dd>
 *      Subpatterns are delimited by parentheses  (round  brackets),
 *      which can be nested.  Marking part of a pattern as a subpat-
 *      tern does two things:
 * <ol>
 * <li> It localizes a set of alternatives. For example, the pat-
 *      tern
 * <pre>
 *        cat(aract|erpillar|)
 * </pre>
 *      matches one of the words "cat",  "cataract",  or  "caterpil-
 *      lar".  Without  the  parentheses, it would match "cataract",
 *      "erpillar" or the empty string.
 * 
 * <li> It sets up the subpattern as a capturing  subpattern  (as
 *      defined  above).   When the whole pattern matches, that por-
 *      tion of the subject string that matched  the  subpattern  is
 *      passed  back  to  the  caller  via  the  ovector argument of
 *      {@link pcre_exec()}. Opening parentheses are counted  from  left  to
 *      right (starting from 1) to obtain the numbers of the captur-
 *      ing subpatterns.
 * <p>
 *      For example, if the string "the red king" is matched against
 *      the pattern
 * <pre>
 *        the ((red|white) (king|queen))
 * </pre>
 *      the captured substrings are "red king", "red",  and  "king",
 *      and are numbered 1, 2, and 3.
 * </ol>
 * <p>
 *      The fact that plain parentheses fulfil two functions is  not
 *      always  helpful.  There are often times when a grouping sub-
 *      pattern is required without a capturing requirement.  If  an
 *      opening parenthesis is followed by "?:", the subpattern does
 *      not do any capturing, and is not counted when computing  the
 *      number of any subsequent capturing subpatterns. For example,
 *      if the string "the  white  queen"  is  matched  against  the
 *      pattern
 * <pre>
 *        the ((?:red|white) (king|queen))
 * </pre>
 *      the captured substrings are "white queen" and  "queen",  and
 *      are  numbered  1  and 2. The maximum number of captured sub-
 *      strings is 99, and the maximum number  of  all  subpatterns,
 *      both capturing and non-capturing, is 200.
 * <p>
 *      As a  convenient  shorthand,  if  any  option  settings  are
 *      required  at  the  start  of a non-capturing subpattern, the
 *      option letters may appear between the "?" and the ":".  Thus
 *      the two patterns
 * <pre>
 *        (?i:saturday|sunday)
 *        (?:(?i)saturday|sunday)
 * </pre>
 *      match exactly the same set of strings.  Because  alternative
 *      branches  are  tried from left to right, and options are not
 *      reset until the end of the subpattern is reached, an  option
 *      setting  in  one  branch does affect subsequent branches, so
 *      the above patterns match "SUNDAY" as well as "Saturday".
 * 
 * <dt> REPETITION
 * <dd>
 *      Repetition is specified by quantifiers, which can follow any
 *      of the following items:
 * <ul>
 * <li> a single character, possibly escaped
 * <li> the . metacharacter
 * <li> a character class
 * <li> a back reference (see next section)
 * <li> a parenthesized subpattern (unless it is  an  assertion  - see below)
 * </ul>
 * <p>
 *      The general repetition quantifier specifies  a  minimum  and
 *      maximum  number  of  permitted  matches,  by  giving the two
 *      numbers in curly brackets (braces), separated  by  a  comma.
 *      The  numbers  must be less than 65536, and the first must be
 *      less than or equal to the second. For example:
 * <pre>
 *        z{2,4}
 * </pre>
 *      matches "zz", "zzz", or "zzzz". A closing brace on  its  own
 *      is not a special character. If the second number is omitted,
 *      but the comma is present, there is no upper  limit;  if  the
 *      second number and the comma are both omitted, the quantifier
 *      specifies an exact number of required matches. Thus
 * <pre>
 *        [aeiou]{3,}
 * </pre>
 *      matches at least 3 successive vowels,  but  may  match  many
 *      more, while
 * <pre>
 *        \d{8}
 * </pre>
 *      matches exactly 8 digits.  An  opening  curly  bracket  that
 *      appears  in a position where a quantifier is not allowed, or
 *      one that does not match the syntax of a quantifier, is taken
 *      as  a literal character. For example, {,6} is not a quantif-
 *      ier, but a literal string of four characters.
 * <p>
 *      The quantifier {0} is permitted, causing the  expression  to
 *      behave  as  if the previous item and the quantifier were not
 *      present.
 * <p>
 *      For convenience (and  historical  compatibility)  the  three
 *      most common quantifiers have single-character abbreviations:
 * <pre>
 *        *    is equivalent to {0,}
 *        +    is equivalent to {1,}
 *        ?    is equivalent to {0,1}
 * </pre>
 *      It is possible to construct infinite loops  by  following  a
 *      subpattern  that  can  match no characters with a quantifier
 *      that has no upper limit, for example:
 * <pre>
 *        (a?)*
 * </pre>
 *      Earlier versions of Perl and PCRE used to give an  error  at
 *      compile  time  for such patterns. However, because there are
 *      cases where this  can  be  useful,  such  patterns  are  now
 *      accepted,  but  if  any repetition of the subpattern does in
 *      fact match no characters, the loop is forcibly broken.
 * <p>
 *      By default, the quantifiers  are  "greedy",  that  is,  they
 *      match  as much as possible (up to the maximum number of per-
 *      mitted times), without causing the rest of  the  pattern  to
 *      fail. The classic example of where this gives problems is in
 *      trying to match comments in C programs. These appear between
 *      the  sequences // and  and within the sequence, individual
 *      * and / characters may appear. An attempt to  match  C  com-
 *      ments by applying the pattern
 * <pre>
 *        /\*.*\* /
 * </pre>
 *      to the string
 * <pre>
 *        // first command * /  not comment  / * second comment 
 * </pre>
 *      fails, because it matches  the  entire  string  due  to  the
 *      greediness of the .*  item.
 * <p>
 *      However, if a quantifier is followed  by  a  question  mark,
 *      then it ceases to be greedy, and instead matches the minimum
 *      number of times possible, so the pattern
 * <pre>
 *        /\*.*?\* /
 * </pre>
 *      does the right thing with the C comments. The meaning of the
 *      various  quantifiers is not otherwise changed, just the pre-
 *      ferred number of matches.  Do not confuse this use of  ques-
 *      tion  mark  with  its  use as a quantifier in its own right.
 *      Because it has two uses, it can sometimes appear doubled, as
 *      in
 * <pre>
 *        \d??\d
 * </pre>
 *      which matches one digit by preference, but can match two  if
 *      that is the only way the rest of the pattern matches.
 * <p>
 *      If the PCRE_UNGREEDY option is set (an option which  is  not
 *      available  in  Perl)  then the quantifiers are not greedy by
 *      default, but individual ones can be made greedy by following
 *      them  with  a  question mark. In other words, it inverts the
 *      default behaviour.
 * <p>
 *      When a parenthesized subpattern is quantified with a minimum
 *      repeat  count  that is greater than 1 or with a limited max-
 *      imum, more store is required for the  compiled  pattern,  in
 *      proportion to the size of the minimum or maximum.
 * <p>
 *      If a pattern starts with .* or  .{0,}  and  the  PCRE_DOTALL
 *      option (equivalent to Perl's /s) is set, thus allowing the .
 *      to match newlines, then the pattern is implicitly  anchored,
 *      because whatever follows will be tried against every charac-
 *      ter position in the subject string, so there is no point  in
 *      retrying  the overall match at any position after the first.
 *      PCRE treats such a pattern as though it were preceded by \A.
 *      In  cases where it is known that the subject string contains
 *      no newlines, it is worth setting PCRE_DOTALL when  the  pat-
 *      tern begins with .* in order to obtain this optimization, or
 *      alternatively using ^ to indicate anchoring explicitly.
 * <p>
 *      When a capturing subpattern is repeated, the value  captured
 *      is the substring that matched the final iteration. For exam-
 *      ple, after
 * <pre>
 *        (tweedle[dume]{3}\s*)+
 * </pre>
 *      has matched "tweedledum tweedledee" the value  of  the  cap-
 *      tured  substring  is  "tweedledee".  However,  if  there are
 *      nested capturing  subpatterns,  the  corresponding  captured
 *      values  may  have been set in previous iterations. For exam-
 *      ple, after
 *        /(a|(b))+/
 * <p>
 *      matches "aba" the value of the second captured substring  is "b".
 * 
 * <dt> BACK REFERENCES
 * <dd>
 *      Outside a character class, a backslash followed by  a  digit
 *      greater  than  0  (and  possibly  further  digits) is a back
 *      reference to a capturing subpattern  earlier  (i.e.  to  its
 *      left)  in  the  pattern,  provided there have been that many
 *      previous capturing left parentheses.
 * <p>
 *      However, if the decimal number following  the  backslash  is
 *      less  than  10,  it is always taken as a back reference, and
 *      causes an error only if there are not  that  many  capturing
 *      left  parentheses in the entire pattern. In other words, the
 *      parentheses that are referenced need not be to the  left  of
 *      the  reference  for  numbers  less  than 10. See the section
 *      entitled "Backslash" above for further details of  the  han-
 *      dling of digits following a backslash.
 * <p>
 *      A back reference matches whatever actually matched the  cap-
 *      turing subpattern in the current subject string, rather than
 *      anything matching the subpattern itself. So the pattern
 * <pre>
 *        (sens|respons)e and \1ibility
 * </pre>
 *      matches "sense and sensibility" and "response and  responsi-
 *      bility",  but  not  "sense  and  responsibility". If caseful
 *      matching is in force at the time of the back reference, then
 *      the case of letters is relevant. For example,
 * <pre>
 *        ((?i)rah)\s+\1
 * </pre>
 *      matches "rah rah" and "RAH RAH", but  not  "RAH  rah",  even
 *      though  the  original  capturing subpattern is matched case-
 *      lessly.
 * <p>
 *      There may be more than one back reference to the  same  sub-
 *      pattern.  If  a  subpattern  has not actually been used in a
 *      particular match, then any  back  references  to  it  always
 *      fail. For example, the pattern
 * <pre>
 *        (a|(bc))\2
 * </pre>
 *      always fails if it starts to match  "a"  rather  than  "bc".
 *      Because  there  may  be up to 99 back references, all digits
 *      following the backslash are taken as  part  of  a  potential
 *      back reference number. If the pattern continues with a digit
 *      character, then some delimiter must be used to terminate the
 *      back reference. If the PCRE_EXTENDED option is set, this can
 *      be whitespace.  Otherwise an empty comment can be used.
 * <p>
 *      A back reference that occurs inside the parentheses to which
 *      it  refers  fails when the subpattern is first used, so, for
 *      example, (a\1) never matches.  However, such references  can
 *      be useful inside repeated subpatterns. For example, the pat-
 *      tern
 * <pre>
 *        (a|b\1)+
 * </pre>
 *      matches any number of "a"s and also "aba", "ababaa" etc.  At
 *      each iteration of the subpattern, the back reference matches
 *      the character string corresponding to  the  previous  itera-
 *      tion.  In  order  for this to work, the pattern must be such
 *      that the first iteration does not need  to  match  the  back
 *      reference.  This  can  be  done using alternation, as in the
 *      example above, or by a quantifier with a minimum of zero.
 *
 * <dt> ASSERTIONS
 * <dd>
 *      An assertion is  a  test  on  the  characters  following  or
 *      preceding  the current matching point that does not actually
 *      consume any characters. The simple assertions coded  as  \b,
 *      \B,  \A,  \Z,  \z, ^ and $ are described above. More compli-
 *      cated assertions are coded as  subpatterns.  There  are  two
 *      kinds:  those that look ahead of the current position in the
 *      subject string, and those that look behind it.
 * <p>
 *      An assertion subpattern is matched in the normal way, except
 *      that  it  does not cause the current matching position to be
 *      changed. Lookahead assertions start with  (?=  for  positive
 *      assertions and (?! for negative assertions. For example,
 * <pre>
 *        \w+(?=;)
 * </pre>
 *      matches a word followed by a semicolon, but does not include
 *      the semicolon in the match, and
 * <pre>
 *        foo(?!bar)
 * </pre>
 *      matches any occurrence of "foo"  that  is  not  followed  by
 *      "bar". Note that the apparently similar pattern
 * <pre>
 *        (?!foo)bar
 * </pre>
 *      does not find an occurrence of "bar"  that  is  preceded  by
 *      something other than "foo"; it finds any occurrence of "bar"
 *      whatsoever, because the assertion  (?!foo)  is  always  true
 *      when  the  next  three  characters  are  "bar". A lookbehind
 *      assertion is needed to achieve this effect.
 *      Lookbehind assertions start with (?<=  for  positive  asser-
 *      tions and (?<! for negative assertions. For example,
 * <pre>
 *        (?<!foo)bar
 * </pre>
 *      does find an occurrence of "bar" that  is  not  preceded  by
 *      "foo". The contents of a lookbehind assertion are restricted
 *      such that all the strings  it  matches  must  have  a  fixed
 *      length.  However, if there are several alternatives, they do
 *      not all have to have the same fixed length. Thus
 * <pre>
 *        (?<=bullock|donkey)
 * </pre>
 *      is permitted, but
 * <pre>
 *        (?<!dogs?|cats?)
 * </pre>
 *      causes an error at compile time. Branches  that  match  dif-
 *      ferent length strings are permitted only at the top level of
 *      a lookbehind assertion. This is an extension  compared  with
 *      Perl  5.005,  which  requires all branches to match the same
 *      length of string. An assertion such as
 * <pre>
 *        (?<=ab(c|de))
 * </pre>
 *      is not permitted, because its single  top-level  branch  can
 *      match two different lengths, but it is acceptable if rewrit-
 *      ten to use two top-level branches:
 * <pre>
 *        (?<=abc|abde)
 * </pre>
 *      The implementation of lookbehind  assertions  is,  for  each
 *      alternative,  to  temporarily move the current position back
 *      by the fixed width and then  try  to  match.  If  there  are
 *      insufficient  characters  before  the  current position, the
 *      match is deemed to fail.  Lookbehinds  in  conjunction  with
 *      once-only  subpatterns can be particularly useful for match-
 *      ing at the ends of strings; an example is given at  the  end
 *      of the section on once-only subpatterns.
 * <p>
 *      Several assertions (of any sort) may  occur  in  succession.
 *      For example,
 * <pre>
 *        (?<=\d{3})(?<!999)foo
 * </pre>
 *      matches "foo" preceded by three digits that are  not  "999".
 *      Furthermore,  assertions  can  be nested in any combination.
 *      For example,
 * <pre>
 *        (?<=(?<!foo)bar)baz
 * </pre>
 *      matches an occurrence of "baz" that  is  preceded  by  "bar"
 *      which in turn is not preceded by "foo".
 * <p>
 *      Assertion subpatterns are not capturing subpatterns, and may
 *      not  be  repeated,  because  it makes no sense to assert the
 *      same thing several times. If an assertion contains capturing
 *      subpatterns within it, these are always counted for the pur-
 *      poses of numbering the capturing subpatterns  in  the  whole
 *      pattern.   Substring  capturing  is carried out for positive
 *      assertions, but it does not make sense for  negative  asser-
 *      tions.
 * <p>
 *      Assertions count towards the maximum  of  200  parenthesized
 *      subpatterns.
 * 
 * <dt> ONCE-ONLY SUBPATTERNS
 * <dd>
 *      With both maximizing and minimizing repetition,  failure  of
 *      what  follows  normally  causes  the repeated item to be re-
 *      evaluated to see if a different number of repeats allows the
 *      rest  of  the  pattern  to  match. Sometimes it is useful to
 *      prevent this, either to change the nature of the  match,  or
 *      to  cause  it fail earlier than it otherwise might, when the
 *      author of the pattern knows there is no  point  in  carrying
 *      on.
 * <p>
 *      Consider, for example, the pattern \d+foo  when  applied  to
 *      the subject line
 * <pre>
 *        123456bar
 * </pre>
 *      After matching all 6 digits and then failing to match "foo",
 *      the normal action of the matcher is to try again with only 5
 *      digits matching the \d+ item, and then with 4,  and  so  on,
 *      before ultimately failing. Once-only subpatterns provide the
 *      means for specifying that once a portion of the pattern  has
 *      matched,  it  is  not to be re-evaluated in this way, so the
 *      matcher would give up immediately on failing to match  "foo"
 *      the  first  time.  The  notation  is another kind of special
 *      parenthesis, starting with (?&gt; as in this example:
 * <pre>
 *        (?&gt;\d+)bar
 * </pre>
 *      This kind of parenthesis "locks up" the  part of the pattern
 *      it  contains once it has matched, and a failure further into
 *      the pattern is prevented from backtracking  into  it.  Back-
 *      tracking  past  it to previous items, however, works as nor-
 *      mal.
 * <p>
 *      An alternative description is that a subpattern of this type
 *      matches  the  string  of  characters that an identical stan-
 *      dalone pattern would match, if anchored at the current point
 *      in the subject string.
 * <p>
 *      Once-only subpatterns are not capturing subpatterns.  Simple
 *      cases  such as the above example can be thought of as a max-
 *      imizing repeat that must  swallow  everything  it  can.  So,
 *      while both \d+ and \d+? are prepared to adjust the number of
 *      digits they match in order to make the rest of  the  pattern
 *      match, (?&gt;\d+) can only match an entire sequence of digits.
 * <p>
 *      This construction can of course contain arbitrarily  compli-
 *      cated subpatterns, and it can be nested.
 * <p>
 *      Once-only subpatterns can be used in conjunction with  look-
 *      behind  assertions  to specify efficient matching at the end
 *      of the subject string. Consider a simple pattern such as
 * <pre>
 *        abcd$
 * </pre>
 *      when applied to a long  string  which  does  not  match  it.
 *      Because matching proceeds from left to right, PCRE will look
 *      for each "a" in the subject and then  see  if  what  follows
 *      matches the rest of the pattern. If the pattern is specified
 *      as
 * <pre>
 *        ^.*abcd$
 * </pre>
 *      then the initial .* matches the entire string at first,  but
 *      when  this  fails,  it  backtracks to match all but the last
 *      character, then all but the last two characters, and so  on.
 *      Once again the search for "a" covers the entire string, from
 *      right to left, so we are no better off. However, if the pat-
 *      tern is written as
 * <pre>
 *        ^(?&gt;.*)(?<=abcd)
 * </pre>
 *      then there can be no backtracking for the .*  item;  it  can
 *      match  only  the  entire  string.  The subsequent lookbehind
 *      assertion does a single test on the last four characters. If
 *      it  fails,  the  match  fails immediately. For long strings,
 *      this approach makes a significant difference to the process-
 *      ing time.
 * 
 * <dt> CONDITIONAL SUBPATTERNS
 * <dd>
 *      It is possible to cause the matching process to obey a  sub-
 *      pattern  conditionally  or to choose between two alternative
 *      subpatterns, depending on the result  of  an  assertion,  or
 *      whether  a previous capturing subpattern matched or not. The
 *      two possible forms of conditional subpattern are
 * <pre>
 *        (?(condition)yes-pattern)
 *        (?(condition)yes-pattern|no-pattern)
 * </pre>
 *      If the condition is satisfied, the yes-pattern is used; oth-
 *      erwise  the  no-pattern  (if  present) is used. If there are
 *      more than two alternatives in the subpattern, a compile-time
 *      error occurs.
 * <p>
 *      There are two kinds of condition. If the  text  between  the
 *      parentheses  consists of a sequence of digits, then the con-
 *      dition is satisfied if  the  capturing  subpattern  of  that
 *      number  has  previously matched. Consider the following pat-
 *      tern, which contains non-significant white space to make  it
 *      more  readable  (assume  the  PCRE_EXTENDED  option)  and to
 *      divide it into three parts for ease of discussion:
 * <pre>
 *        ( \( )?    [^()]+    (?(1) \) )
 * </pre>
 *      The first part matches an optional opening parenthesis,  and
 *      if  that character is present, sets it as the first captured
 *      substring. The second part matches one  or  more  characters
 *      that  are  not  parentheses. The third part is a conditional
 *      subpattern that tests whether the first set  of  parentheses
 *      matched  or  not.  If  they did, that is, if subject started
 *      with an opening parenthesis, the condition is true,  and  so
 *      the  yes-pattern  is  executed  and a closing parenthesis is
 *      required. Otherwise, since no-pattern is  not  present,  the
 *      subpattern  matches  nothing.  In  other words, this pattern
 *      matches a sequence of non-parentheses,  optionally  enclosed
 *      in parentheses.
 * <p>
 *      If the condition is not a sequence of digits, it must be  an
 *      assertion.  This  may be a positive or negative lookahead or
 *      lookbehind assertion. Consider this pattern, again  contain-
 *      ing  non-significant  white space, and with the two alterna-
 *      tives on the second line:
 * <pre>
 *        (?(?=[^a-z]*[a-z])
 *        \d{2}[a-z]{3}-\d{2}  |  \d{2}-\d{2}-\d{2} )
 * </pre>
 *      The condition is a positive lookahead assertion that matches
 *      an optional sequence of non-letters followed by a letter. In
 *      other words, it tests for  the  presence  of  at  least  one
 *      letter  in the subject. If a letter is found, the subject is
 *      matched against  the  first  alternative;  otherwise  it  is
 *      matched  against the second. This pattern matches strings in
 *      one of the two forms dd-aaa-dd or dd-dd-dd,  where  aaa  are
 *      letters and dd are digits.
 * 
 * <dt> COMMENTS
 * <dd>
 *      The  sequence  (?#  marks  the  start  of  a  comment  which
 *      continues   up  to  the  next  closing  parenthesis.  Nested
 *      parentheses are not permitted. The characters that make up a
 *      comment play no part in the pattern matching at all.
 * <p>
 *      If the PCRE_EXTENDED option is set, an unescaped # character
 *      outside  a character class introduces a comment that contin-
 *      ues up to the next newline character in the pattern.
 * 
 * <dt> PERFORMANCE
 * <dd>
 *      Certain items that may appear in patterns are more efficient
 *      than  others.  It is more efficient to use a character class
 *      like [aeiou] than a set of alternatives such as (a|e|i|o|u).
 *      In  general,  the  simplest  construction  that provides the
 *      required behaviour is usually the  most  efficient.  Jeffrey
 *      Friedl's  book contains a lot of discussion about optimizing
 *      regular expressions for efficient performance.
 * <p>
 *      When a pattern begins with .* and the PCRE_DOTALL option  is
 *      set,  the  pattern  is implicitly anchored by PCRE, since it
 *      can match only at the start of a subject string. However, if
 *      PCRE_DOTALL  is not set, PCRE cannot make this optimization,
 *      because the . metacharacter does not then match  a  newline,
 *      and if the subject string contains newlines, the pattern may
 *      match from the character immediately following one  of  them
 *      instead of from the very start. For example, the pattern
 * <pre>
 *         (.*) second
 * </pre>
 *      matches the subject "first\nand second" (where \n stands for
 *      a newline character) with the first captured substring being
 *      "and". In order to do this, PCRE  has  to  retry  the  match
 *      starting after every newline in the subject.
 * <p>
 *      If you are using such a pattern with subject strings that do
 *      not  contain  newlines,  the best performance is obtained by
 *      setting PCRE_DOTALL, or starting the  pattern  with  ^.*  to
 *      indicate  explicit anchoring. That saves PCRE from having to
 *      scan along the subject looking for a newline to restart at.
 */
function pcre_syntax();


///////////////////////////////////////////////////////////////////////////
// PDF functions
// 
// You can use the PDF functions in PHP to create PDF files if you have the
// PDF library by Thomas Merz (available at http://www.ifconnection.de/~tm/).
// Please consult the excelent documentation for pdflib shipped with the
// source distribution of pdflib or available at
// http://www.ifconnection.de/~tm/software/pdflib/PDFlib-0.6.pdf. It provides
// a very good overview of what pdflib capable of doing. Most of the functions
// in pdflib and the PHP module have the same name. The parameters are also
// identical. You should also understand some of the concepts of PDF or
// Postscript to efficiently use this module. All lengths and coordinates are
// measured in Postscript points. There are generally 72 PostScript points to
// an inch, but this depends on the output resolution.
// 
// There is another PHP module for pdf document creation based on FastIO's
// ClibPDF. It has a slightly different API. Check the ClibPDF functions
// section for details.
// 
// Currently two versions of pdflib are supported: 0.6 and 2.0. It is
// recommended that you use the newer version since it has more features and
// fixes some problems which required a patch for the old version.
// Unfortunately, the changes of the pdflib API in 2.0 have been so severe
// that even some PHP functions had to be altered. Here is a list of changes:
// 
//    * The Info structure does not exist anymore. Therefore the function
//      pdf_get_info() is obsolete and the functions pdf_set_info_creator(),
//      pdf_set_info_title(), pdf_set_info_author(), pdf_set_info_subject()
//      and pdf_set_info_keywords() do not take the info structure as the
//      first parameter but the pdf document. This also means that the pdf
//      document must be opened before these functions can be called.
// 
//    * The way a new document is opened has changed. The function pdf_open()
//      takes only one parameter which is the file handle of a file opened
//      with fopen().
// 
// The pdf module introduces two new types of variables (if pdflib 2.0 is used
// it is only one new type). They are called pdfdoc and pdfinfo (pdfinfo is
// not existent if pdflib 2.0 is used. pdfdoc is a pointer to a pdf document
// and almost all functions need it as its first parameter. pdfinfo contains
// meta data about the PDF document. It has to be set before pdf_open() is
// called.
// 
// In order to output text into a PDF document you will need to provide the
// afm file for each font. Afm files contain font metrics for a Postscript
// font. By default these afm files are searched for in a directory named
// 'fonts' relative to the directory where the PHP script is located. (Again,
// this was true for pdflib 0.6, newer versions do not not neccessarily need
// the afm files.)
// 
// Most of the functions are fairly easy to use. The most difficult part is
// probably to create a very simple pdf document at all. The following example
// should help to get started. It uses the PHP functions for pdflib 0.6. It
// creates the file test.pdf with one page. The page contains the text
// "Times-Roman" in an outlined 30pt font. The text is also underlined.
// 
// Example 1. Creating a PDF document with pdflib 0.6
// 
// <?php
// $fp = fopen("test.pdf", "w");
// $info = PDF_get_info();
// pdf_set_info_author($info, "Uwe Steinmann");
// PDF_set_info_title($info, "Test for PHP wrapper of PDFlib 0.6");
// PDF_set_info_author($info, "Name of Author");
// pdf_set_info_creator($info, "See Author");
// pdf_set_info_subject($info, "Testing");
// $pdf = PDF_open($fp, $info);
// PDF_begin_page($pdf, 595, 842);
// PDF_add_outline($pdf, "Page 1");
// pdf_set_font($pdf, "Times-Roman", 30, 4);
// pdf_set_text_rendering($pdf, 1);
// PDF_show_xy($pdf, "Times Roman outlined", 50, 750);
// pdf_moveto($pdf, 50, 740);
// pdf_lineto($pdf, 330, 740);
// pdf_stroke($pdf);
// PDF_end_page($pdf);
// PDF_close($pdf);
// fclose($fp);
// echo "<A HREF=getpdf.php3>finished</A>";
// ?>
// 
// 
// The PHP script getpdf.php3 just outputs the pdf document.
// 
// <?php
// $fp = fopen("test.pdf", "r");
// header("Content-type: application/pdf");
// fpassthru($fp);
// fclose($fp);
// ?>
// 
// 
// Doing the same with pdflib 2.0 looks like the following:
// Example 2. Creating a PDF document with pdflib 2.0
// 
// <?php
// $fp = fopen("test.pdf", "w");
// $pdf = PDF_open($fp);
// pdf_set_info_author($pdf, "Uwe Steinmann");
// PDF_set_info_title($pdf, "Test for PHP wrapper of PDFlib 2.0");
// PDF_set_info_author($pdf, "Name of Author");
// pdf_set_info_creator($pdf, "See Author");
// pdf_set_info_subject($pdf, "Testing");
// PDF_begin_page($pdf, 595, 842);
// PDF_add_outline($pdf, "Page 1");
// pdf_set_font($pdf, "Times-Roman", 30, 4);
// pdf_set_text_rendering($pdf, 1);
// PDF_show_xy($pdf, "Times Roman outlined", 50, 750);
// pdf_moveto($pdf, 50, 740);
// pdf_lineto($pdf, 330, 740);
// pdf_stroke($pdf);
// PDF_end_page($pdf);
// PDF_close($pdf);
// fclose($fp);
// echo "<A HREF=getpdf.php3>finished</A>";
// ?>
// 
// 
// The PHP script getpdf.php3 is the same as above.
// The pdflib distribution contains a more complex example which creates a
// serious of pages with an analog clock. This example converted into PHP
// using pdflib 2.0 looks as the following (you can see the same example in
// the documentation for the clibpdf module):
// Example 3. pdfclock example from pdflib 2.0 distribution
// 
// <?php
// $pdffilename = "clock.pdf";
// $radius = 200;
// $margin = 20;
// $pagecount = 40;
// 
// $fp = fopen($pdffilename, "w");
// $pdf = pdf_open($fp);
// pdf_set_info_creator($pdf, "pdf_clock.php3");
// pdf_set_info_author($pdf, "Uwe Steinmann");
// pdf_set_info_title($pdf, "Analog Clock");
// 
// while($pagecount-- > 0) {
//     pdf_begin_page($pdf, 2 * ($radius + $margin), 2 * ($radius + $margin));
// 
//     pdf_set_transition($pdf, 4);  /* wipe */
//     pdf_set_duration($pdf, 0.5);
// 
//     pdf_translate($pdf, $radius + $margin, $radius + $margin);
//     pdf_save($pdf);
//     pdf_setrgbcolor($pdf, 0.0, 0.0, 1.0);
// 
//     /* minute strokes */
//     pdf_setlinewidth($pdf, 2.0);
//     for ($alpha = 0; $alpha < 360; $alpha += 6) {
//         pdf_rotate($pdf, 6.0);
//         pdf_moveto($pdf, $radius, 0.0);
//         pdf_lineto($pdf, $radius-$margin/3, 0.0);
//         pdf_stroke($pdf);
//     }
// 
//     pdf_restore($pdf);
//     pdf_save($pdf);
// 
//     /* 5 minute strokes */
//     pdf_setlinewidth($pdf, 3.0);
//     for ($alpha = 0; $alpha < 360; $alpha += 30) {
//         pdf_rotate($pdf, 30.0);
//         pdf_moveto($pdf, $radius, 0.0);
//         pdf_lineto($pdf, $radius-$margin, 0.0);
//         pdf_stroke($pdf);
//     }
// 
//     $ltime = getdate();
// 
//     /* draw hour hand */
//     pdf_save($pdf);
//     pdf_rotate($pdf,-(($ltime['minutes']/60.0)+$ltime['hours']-3.0)*30.0);
//     pdf_moveto($pdf, -$radius/10, -$radius/20);
//     pdf_lineto($pdf, $radius/2, 0.0);
//     pdf_lineto($pdf, -$radius/10, $radius/20);
//     pdf_closepath($pdf);
//     pdf_fill($pdf);
//     pdf_restore($pdf);
// 
//     /* draw minute hand */
//     pdf_save($pdf);
//     pdf_rotate($pdf,-(($ltime['seconds']/60.0)+$ltime['minutes']-15.0)*6.0);
//     pdf_moveto($pdf, -$radius/10, -$radius/20);
//     pdf_lineto($pdf, $radius * 0.8, 0.0);
//     pdf_lineto($pdf, -$radius/10, $radius/20);
//     pdf_closepath($pdf);
//     pdf_fill($pdf);
//     pdf_restore($pdf);
// 
//     /* draw second hand */
//     pdf_setrgbcolor($pdf, 1.0, 0.0, 0.0);
//     pdf_setlinewidth($pdf, 2);
//     pdf_save($pdf);
//     pdf_rotate($pdf, -(($ltime['seconds'] - 15.0) * 6.0));
//     pdf_moveto($pdf, -$radius/5, 0.0);
//     pdf_lineto($pdf, $radius, 0.0);
//     pdf_stroke($pdf);
//     pdf_restore($pdf);
// 
//     /* draw little circle at center */
//     pdf_circle($pdf, 0, 0, $radius/30);
//     pdf_fill($pdf);
// 
//     pdf_restore($pdf);
// 
//     pdf_end_page($pdf);
// }
// 
// $pdf = pdf_close($pdf);
// fclose($fp);
// echo "<A HREF=getpdf.php3?filename=".$pdffilename.">finished</A>";
// ?>
// 
// 
// The PHP script getpdf.php3 just outputs the pdf document.
// 
// <?php
// $fp = fopen($filename, "r");
// header("Content-type: application/pdf");
// fpassthru($fp);
// fclose($fp);
// ?>
// 
 
/**
 * Returns a default info structure for a pdf document
 * <p>
 * The PDF_get_info() function returns a default info structure for the pdf
 * document. It should be filled with appropriate information like the author,
 * subject etc. of the document.
 *
 * @see PDF_set_info_creator()
 * @see PDF_set_info_author()
 * @see PDF_set_info_keywords()
 * @see PDF_set_info_title()
 * @see PDF_set_info_subject()
 * @since This functions is not available if pdflib 2.0 support is activated.
 */
function info pdf_get_info(string filename);
 
/**
 * Fills the creator field of the info structure
 * <p>
 * The PDF_set_info_creator() function sets the creator of a pdf document. It
 * has to be called after PDF_get_info() and before {@link PDF_open()}. Calling it
 * after {@link PDF_open()} will have no effect on the document.
 * <p>
 * <b>Note:</b>
 * This function is not part of the pdf library.
 * <p>
 * <b>Note:</b>
 * This function takes a different first parameter if pdflib
 * 2.0 support is activated. The first parameter has to be the
 * identifier of the pdf document as returned by {@link pdf_open()}.
 * Consequently, {@link pdf_open()} has to be called before this function.
 * 
 * @see PDF_get_info()
 * @see PDF_set_info_keywords()
 * @see PDF_set_info_title()
 * @see PDF_set_info_subject()
 */
function void pdf_set_info_creator(info info, string creator);
 
/**
 * Fills the title field of the info structure
 * <p>
 * The PDF_set_info_title() function sets the title of a pdf document. It has
 * to be called after {@link PDF_get_info()} and before {@link PDF_open()}. Calling it after
 * {@link PDF_open()} will have no effect on the document.
 * <p>
 * <b>Note:</b>
 * This function is not part of the pdf library.
 * <p>
 * <b>Note:</b>
 * This function takes a different first parameter if pdflib
 * 2.0 support is activated. The first parameter has to be the
 * identifier of the pdf document as returned by {@link pdf_open()}.
 * Consequently, {@link pdf_open()} has to be called before this function.
 * 
 * @see PDF_get_info()
 * @see PDF_set_info_creator()
 * @see PDF_set_info_author()
 * @see PDF_set_info_keywords()
 * @see PDF_set_info_subject()
 */
function void pdf_set_info_title(info info, string title);
 
/**
 * Fills the subject field of the info structure
 * <p>
 * The PDF_set_info_subject() function sets the subject of a pdf document. It
 * has to be called after {@link PDF_get_info()} and before {@link PDF_open()}. Calling it
 * after {@link PDF_open()} will have no effect on the document.
 * <p>
 * <b>Note:</b>
 * This function is not part of the pdf library.
 * <p>
 * <b>Note:</b>
 * This function takes a different first parameter if pdflib
 * 2.0 support is activated. The first parameter has to be the
 * identifier of the pdf document as returned by {@link pdf_open()}.
 * Consequently, {@link pdf_open()} has to be called before this function.
 * 
 * @see PDF_get_info()
 * @see PDF_set_info_creator()
 * @see PDF_set_info_author()
 * @see PDF_set_info_title()
 * @see PDF_set_info_keywords()
 */
function void pdf_set_info_subject(info info, string subject);
 
/**
 * Fills the keywords field of the info structure
 * <p>
 * The PDF_set_info_keywords() function sets the keywords of a pdf document.
 * It has to be called after {@link PDF_get_info()} and before {@link PDF_open()}. Calling it
 * after {@link PDF_open()} will have no effect on the document.
 * <p>
 * <b>Note:</b>
 * This function is not part of the pdf library.
 * <p>
 * <b>Note:</b>
 * This function takes a different first parameter if pdflib
 * 2.0 support is activated. The first parameter has to be the
 * identifier of the pdf document as returned by {@link pdf_open()}.
 * Consequently, {@link pdf_open()} has to be called before this function.
 * 
 * @see PDF_get_info()
 * @see PDF_set_info_creator()
 * @see PDF_set_info_author()
 * @see PDF_set_info_title()
 * @see PDF_set_info_subject()
 */
function void pdf_set_info_keywords(info info, string keywords);
 
/**
 * Fills the author field of the info structure
 * <p>
 * The PDF_set_info_author() function sets the author of a pdf document. It
 * has to be called after {@link PDF_get_info()} and before {@link PDF_open()}. Calling it
 * after {@link PDF_open()} will have no effect on the document.
 * <p>
 * <b>Note:</b>
 * This function is not part of the pdf library.
 * <p>
 * <b>Note:</b>
 * This function takes a different first parameter if pdflib
 * 2.0 support is activated. The first parameter has to be the
 * identifier of the pdf document as returned by {@link pdf_open()}.
 * Consequently, {@link pdf_open()} has to be called before this function.
 * 
 * @see PDF_get_info()
 * @see PDF_set_info_creator()
 * @see PDF_set_info_keywords()
 * @see PDF_set_info_title()
 * @see PDF_set_info_subject()
 */
function void pdf_set_info_author(info info, string author);
 
/**
 * Opens a new pdf document
 * <p>
 * The PDF_open() function opens a new pdf document. The corresponding file
 * has to be opened with {@link fopen()} and the file descriptor passed as argument
 * file. info is the info structure that has to be created with
 * {@link pdf_get_info()}. The info structure will be deleted within this function.
 * <p>
 * <b>Note:</b>
 * The return value is needed as the first parameter in all
 * other functions writing to the pdf document.
 * <p>
 * <b>Note:</b>
 * This function does not allow the second parameter if pdflib
 * 2.0 support is activated.
 * 
 * @see fopen()
 * @see PDF_get_info()
 * @see PDF_close()
 */
function int pdf_open(int file, int info);
 
/**
 * Closes a pdf document
 * <p>
 * The PDF_close() function closes the pdf document.
 * <p>
 * <b>Note:</b>
 * Due to an unclean implementation of the pdflib 0.6 the
 * internal closing of the document also closes the file. This
 * should not be done because pdflib did not open the file, but
 * expects an already open file when {@link PDF_open()} is called.
 * Consequently it shouldn't close the file. In order to fix this
 * just take out line 190 of the file p_basic.c in the pdflib 0.6
 * source distribution until the next release of pdflib will fix
 * this.
 * <p>
 * <b>Note:</b>
 * This function works properly without any patches to pdflib
 * if pdflib 2.0 support is activated.
 * 
 * @see PDF_open()
 * @see fclose()
 */
function void pdf_close(int pdf_document);
 
/**
 * Starts new page
 * <p>
 * The PDF_begin_page() function starts a new page with height height and
 * width width.
 * 
 * @see PDF_end_page()
 */
function void pdf_begin_page(int pdf_document, double height, double width);
 
/**
 * Ends a page
 * <p>
 * The PDF_end_page() function ends a page. Once a page is ended it cannot be
 * modified anymore.
 * 
 * @see PDF_begin_page()
 */
function void pdf_end_page(int pdf_document);
 
/**
 * Output text at current position
 * <p>
 * The PDF_show() function outputs the string text at the current position
 * using the current font.
 * 
 * @see PDF_show_xy()
 * @see PDF_set_text_pos()
 * @see PDF_set_font()
 */
function void pdf_show(int pdf_document, string text);
 
/**
 * Output text at given position
 * <p>
 * The PDF_show_xy() function outputs the string text at position (x-koor,
 * y-koor).
 * 
 * @see PDF_show()
 */
function void pdf_show_xy(int pdf_document, string text, double x_koor, double y_koor);
 
/**
 * Selects a font face and size
 * <p>
 * The PDF_set_font() function sets the current font face, font size and
 * encoding. You will need to provide the Adobe Font Metrics (afm-files) for
 * the font in the font path (default is ./fonts). The last parameter encoding
 * can take the following values: 0 = builtin, 1 = pdfdoc, 2 = macroman, 3 =
 * macexpert, 4 = winansi. An encoding greater than 4 and less than 0 will
 * default to winansi. winansi is often a good choice.
 * <p>
 * <b>Note:</b>
 * This function does not need the afm files for winansi
 * encoding if pdflib 2.0 support is activated.
 */
function void pdf_set_font(int pdf_document, string font_name, double size, int encoding);
 
/**
 * Sets distance between text lines
 * <p>
 * The PDF_set_leading() function sets the distance between text lines. This
 * will be used if text is output by {@link PDF_continue_text()}.
 * 
 * @see PDF_continue_text()
 */
function void pdf_set_leading(int pdf_document, double distance);
 
/**
 * Determines how text is rendered
 * <p>
 * The PDF_set_text_rendering() function determines how text is rendered. The
 * possible values for mode are 0=fill text, 1=stroke text, 2=fill and stroke
 * text, 3=invisible, 4=fill text and add it to cliping path, 5=stroke text
 * and add it to clipping path, 6=fill and stroke text and add it to cliping
 * path, 7=add it to clipping path.
 */
function void pdf_set_text_rendering(int pdf_document, int mode);
 
/**
 * Sets horizontal scaling of text
 * <p>
 * The PDF_set_horiz_scaling() function sets the horizontal scaling to scale
 * percent.
 */
function void pdf_set_horiz_scaling(int pdf_document, double scale);
 
/**
 * Sets the text rise
 * <p>
 * The PDF_set_text_rise() function sets the text rising to value points.
 */
function void pdf_set_text_rise(int pdf_document, double value);
 
/**
 * Sets the text matrix
 * <p>
 * The PDF_set_text_matrix() function sets a matrix which describes a
 * transformation applied on the current text font. The matrix has to passed
 * as an array with six elements.
 */
function void pdf_set_text_matrix(int pdf_document, array matrix);
 
/**
 * Sets text position
 * <p>
 * The PDF_set_text_pos() function sets the position of text for the next
 * pdf_show() function call.
 * 
 * @see PDF_show()
 * @see PDF_show_xy()
 */
function void pdf_set_text_pos(int pdf_document, double x_koor, double y_koor);
 
/**
 * Sets character spacing
 * <p>
 * The PDF_set_char_spacing() function sets the spacing between characters.
 * 
 * @see PDF_set_word_spacing()
 * @see PDF_set_leading()
 */
function void pdf_set_char_spacing(int pdf_document, double space);
 
/**
 * Sets spacing between words
 * <p>
 * The PDF_set_word_spacing() function sets the spacing between words.
 * 
 * @see PDF_set_char_spacing()
 * @see PDF_set_leading()
 */
function void pdf_set_word_spacing(int pdf_document, double space);
 
/**
 * Outputs text in next line
 * <p>
 * The PDF_continue_text() function outputs the string in text in the next
 * line. The distance between the lines can be set with {@link PDF_set_leading()}.
 * 
 * @see PDF_show_xy()
 * @see PDF_set_leading()
 * @see PDF_set_text_pos()
 */
function void pdf_continue_text(int pdf_document, string text);
 
/**
 * Returns width of text using current font
 * <p>
 * The PDF_stringwidth() function returns the width of the string in text. It
 * requires a font to be set before.
 * 
 * @see PDF_set_font()
 */
function double pdf_stringwidth(int pdf_document, string text);
 
/**
 * Saves the current environment
 * <p>
 * The PDF_save() function saves the current environment. It works like the
 * postscript command gsave. Very useful if you want to translate or rotate an
 * object without effecting other objects. {@link PDF_save()} should always be
 * followed by {@link PDF_restore()}.
 * 
 * @see PDF_restore()
 */
function void pdf_save(int pdf_document);
 
/**
 * Restores formerly saved environment
 * <p>
 * The PDF_restore() function restores the environment saved with {@link PDF_save()}.
 * It works like the postscript command grestore. Very useful if you want to
 * translate or rotate an object without effecting other objects.
 * <P>
 * <b>Example 1.</b> Save and Restore
 * <pre>
 * &lt;?php PDF_save($pdf);
 * // do all kinds of rotations, transformations, ...
 * PDF_restore($pdf) ?&gt;
 * </pre>
 *
 * @see PDF_save()
 */
function void pdf_restore(int pdf_document);
 
/**
 * Sets origin of coordinate system
 * <p>
 * The PDF_translate() function set the origin of coordinate system to the
 * point (x-koor, y-koor). The following example draws a line from (0, 0) to
 * (200, 200) relative to the initial coordinate system. You have to set the
 * current point after PDF_translate() and before you start drawing more
 * objects.
 * <P>
 * <b>Example 1.</b> Translation
 * <pre>
 *    &lt;?php PDF_moveto($pdf, 0, 0);
 *    PDF_lineto($pdf, 100, 100);
 *    PDF_stroke($pdf);
 *    PDF_translate($pdf, 100, 100);
 *    PDF_moveto($pdf, 0, 0);
 *    PDF_lineto($pdf, 100, 100);
 *    PDF_stroke($pdf);
 *    ?&gt;
 * </pre>
 */
function void pdf_translate(int pdf_document, double x_koor, double y_koor);
 
/**
 * Sets scaling
 * <p>
 * The PDF_scale() function set the scaling factor in both directions. The
 * following example scales x and y direction by 72. The following line will
 * therefore be drawn one inch in both directions.
 * <P>
 * <b>Example 1.</b> Scaling
 * <pre>
 *    &lt;?php PDF_scale($pdf, 72.0, 72.0);
 *    PDF_lineto($pdf, 1, 1);
 *    PDF_stroke($pdf);
 *    ?&gt;
 * </pre>
 */
function void pdf_scale(int pdf_document, double x_scale, double y_scale);
 
/**
 * Sets rotation
 * <p>
 * The PDF_rotate() function set the rotation in degress to angle.
 */
function void pdf_rotate(int pdf_document, double angle);
 
/**
 * Sets flatness
 * <p>
 * The PDF_setflat() function set the flatness to a value between 0 and 100.
 */
function void pdf_setflat(int pdf_document, double value);
 
/**
 * Sets linejoin parameter
 * <p>
 * The PDF_setlinejoin() function set the linejoin parameter between a value
 * of 0 and 2.
 */
function void pdf_setlinejoin(int pdf_document, long value);
 
/**
 * Sets linecap parameter
 * <p>
 * The PDF_setlinecap() function set the linecap parameter between a value of
 * 0 and 2.
 */
function void pdf_setlinecap(int pdf_document, int value);
 
/**
 * Sets miter limit
 * <p>
 * The PDF_setmiterlimit() function set the miter limit to a value greater of
 * equal than 1.
 */
function void pdf_setmiterlimit(int pdf_document, double value);
 
/**
 * Sets line width
 * <p>
 * The PDF_setlinewidth() function set the line width to width.
 */
function void pdf_setlinewidth(int pdf_document, double width);
 
/**
 * Sets dash pattern
 * <p>
 * The PDF_setdash() function set the dash pattern white white points and
 * black black points. If both are 0 a solid line is set.
 */
function void pdf_setdash(int pdf_document, double white, double black);
 
/**
 * Sets current point
 * <p>
 * The PDF_moveto() function set the current point to the coordinates x-koor
 * and y-koor.
 */
function void pdf_moveto(int pdf_document, double x_koor, double y_koor);
 
/**
 * Draws a curve
 * <p>
 * The PDF_curveto() function draws a Bezier curve from the current point to
 * the point (x3, y3) using (x1, y1) and (x2, y2) as control points.
 * 
 * @see PDF_moveto()
 * @see PDF_lineto()
 * @see PDF_stroke()
 */
function void pdf_curveto(int pdf_document, double x1, double y1, double x2, double y2, double x3, double y3);
 
/**
 * Draws a line
 * <p>
 * The PDF_lineto() function draws a line from the current point to the point
 * with coordinates (x-koor, y-koor).
 * 
 * @see PDF_moveto()
 * @see PDF_curveto()
 * @see PDF_stroke()
 */
function void pdf_lineto(int pdf_document, double x_koor, double y_koor);
 
/**
 * Draws a circle
 * <p>
 * The PDF_circle() function draws a circle with center at point (x-koor,
 * y-koor) and radius radius.
 * 
 * @see PDF_arc()
 * @see PDF_stroke()
 */
function void pdf_circle(int pdf_document, double x_koor, double y_koor, double radius);
 
/**
 * Draws an arc
 * <p>
 * The PDF_arc() function draws an arc with center at point (x-koor, y-koor)
 * and radius radius, starting at angle start and ending at angle end.
 * 
 * @see PDF_circle()
 * @see PDF_stroke()
 */
function void pdf_arc(int pdf_document, double x_koor, double y_koor, double radius, double start, double end);
 
/**
 * Draws a rectangle
 * <p>
 * The PDF_rect() function draws a rectangle with its lower left corner at
 * point (x-koor, y-koor). This width is set to widgth. This height is set to
 * height.
 * 
 * @see PDF_stroke()
 */
function void pdf_rect(int pdf_document, double x_koor, double y_koor, double width, double height);
 
/**
 * Closes path
 * <p>
 * The PDF_closepath() function closes the current path. This means, it draws
 * a line from current point to the point where the first line was started.
 * Many functions like {@link PDF_moveto()}, {@link PDF_circle()} and {@link PDF_rect()} start a new
 * path.
 */
function void pdf_closepath(int pdf_document);
 
/**
 * Draws line along path
 * <p>
 * The PDF_stroke() function draws a line along current path. The current path
 * is the sum of all line drawing. Without this function the line would not be
 * drawn.
 * 
 * @see PDF_closepath()
 * @see PDF_closepath_stroke()
 */
function void pdf_stroke(int pdf_document);
 
/**
 * Closes path and draws line along path
 * <p>
 * The PDF_closepath_stroke() function is a combination of {@link PDF_closepath()} and
 * {@link PDF_stroke()}. Than clears the path.
 * 
 * @see PDF_closepath()
 * @see PDF_stroke()
 */
function void pdf_closepath_stroke(int pdf_document);
 
/**
 * Fills current path
 * <p>
 * The PDF_fill() function fills the interior of the current path with the
 * current fill color.
 * 
 * @see PDF_closepath()
 * @see PDF_stroke()
 * @see PDF_setgray_fill()
 * @see PDF_setgray()
 * @see PDF_setrgbcolor_fill()
 * @see PDF_setrgbcolor()
 */
function void pdf_fill(int pdf_document);
 
/**
 * Fills and strokes current path
 * <p>
 * The PDF_fill_stroke() function fills the interior of the current path with
 * the current fill color and draws current path.
 * 
 * @see PDF_closepath()
 * @see PDF_stroke()
 * @see PDF_fill()
 * @see PDF_setgray_fill()
 * @see PDF_setgray()
 * @see PDF_setrgbcolor_fill()
 * @see PDF_setrgbcolor()
 */
function void pdf_fill_stroke(int pdf_document);
 
/**
 * Closes, fills and strokes current path
 * <p>
 * The PDF_closepath_fill_stroke() function closes, fills the interior of the
 * current path with the current fill color and draws current path.
 * 
 * @see PDF_closepath()
 * @see PDF_stroke()
 * @see PDF_fill()
 * @see PDF_setgray_fill()
 * @see PDF_setgray()
 * @see PDF_setrgbcolor_fill()
 * @see PDF_setrgbcolor()
 */
function void pdf_closepath_fill_stroke(int pdf_document);
 
/**
 * Ends current path
 * <p>
 * The PDF_endpath() function ends the current path but does not close it.
 * 
 * @see PDF_closepath()
 */
function void pdf_endpath(int pdf_document);
 
/**
 * Clips to current path
 * <p>
 * The PDF_clip() function clips all drawing to the current path.
 */
function void pdf_clip(int pdf_document);
 
/**
 * Sets filling color to gray value
 * <p>
 * The PDF_setgray_fill() function sets the current gray value to fill a path.
 * 
 * @see PDF_setrgbcolor_fill()
 */
function void pdf_setgray_fill(int pdf_document, double value);
 
/**
 * Sets drawing color to gray value
 * <p>
 * The PDF_setgray_stroke() function sets the current drawing color to the
 * given gray value.
 * 
 * @see PDF_setrgbcolor_stroke()
 */
function void pdf_setgray_stroke(int pdf_document, double gray_value);
 
/**
 * Sets drawing and filling color to gray value
 * <p>
 * The PDF_setgray_stroke() function sets the current drawing and filling
 * color to the given gray value.
 * 
 * @see PDF_setrgbcolor_stroke()
 * @see PDF_setrgbcolor_fill()
 */
function void pdf_setgray(int pdf_document, double gray_value);
 
/**
 * Sets filling color to rgb color value
 * <p>
 * The PDF_setrgbcolor_fill() function sets the current rgb color value to
 * fill a path.
 * 
 * @see PDF_setrgbcolor_fill()
 */
function void pdf_setrgbcolor_fill(int pdf_document, double red_value, double green_value, double blue_value);
 
/**
 * Sets drawing color to rgb color value
 * <p>
 * The PDF_setrgbcolor_stroke() function sets the current drawing color to the
 * given rgb color value.
 * 
 * @see PDF_setrgbcolor_stroke()
 */
function void pdf_setrgbcolor_stroke(int pdf_document, double red_value, double green_value, double blue_value);
 
/**
 * Sets drawing and filling color to rgb color value
 * <p>
 * The PDF_setrgbcolor_stroke() function sets the current drawing and filling
 * color to the given rgb color value.
 * 
 * @see PDF_setrgbcolor_stroke()
 * @see PDF_setrgbcolor_fill()
 */
function void pdf_setrgbcolor(int pdf_document, double red_value, double green_value, double blue_value);
 
/**
 * Adds bookmark for current page
 * <p>
 * The PDF_add_outline() function adds a bookmark with text text that points
 * to the current page.
 * <p>
 * Unfortunately pdflib does not make a copy of the string, which forces PHP
 * to allocate the memory. Currently this piece of memory is not been freed by
 * any PDF function but it will be taken care of by the PHP memory manager.
 */
function void pdf_add_outline(int pdf_document, string text);
 
/**
 * Sets transition between pages
 * <p>
 * The PDF_set_transition() function set the transition between following
 * pages. The value of transition can be
 * <ul>
 * <li> 0 - for none,
 * <li> 1 - for two lines sweeping across the screen reveal the page,
 * <li> 2 - for multiple lines sweeping across the screen reveal the page,
 * <li> 3 - for a box reveals the page,
 * <li> 4 - for a single line sweeping across the screen reveals the page,
 * <li> 5 - for the old page dissolves to reveal the page,
 * <li> 6 - for the dissolve effect moves from one screen edge to another,
 * <li> 7 - for the old page is simply replaced by the new page (default)
 * </ul>
 *
 * @see PDF_set_duration()
 */
function void pdf_set_transition(int pdf_document, int transition);
 
/**
 * Sets duration between pages
 * <p>
 * The PDF_set_duration() function set the duration between following pages in
 * seconds.
 * 
 * @see PDF_set_transition()
 */
function void pdf_set_duration(int pdf_document, double duration);
 
/**
 * Opens a GIF image
 * <p>
 * The PDF_open_gif() function opens an image stored in the file with the name
 * filename. The format of the image has to be gif. The function returns a pdf
 * image identifier.
 * <p>
 * <b>Example 1.</b> Including a gif image
 * <pre>
 *    &lt;?php
 *    $im = PDF_open_gif($pdf, "test.gif");
 *    pdf_place_image($pdf, $im, 100, 100, 1);
 *    pdf_close_image($pdf, $im);
 *    ?&gt;
 * </pre>
 *
 * @see PDF_close_image()
 * @see PDF_open_jpeg()
 * @see PDF_open_memory_image()
 * @see PDF_execute_image()
 * @see PDF_place_image()
 * @see PDF_put_image()
 */
function int pdf_open_gif(int pdf_document, string filename);
 
/**
 * Opens an image created with PHP's image functions
 * <p>
 * The PDF_open_memory_image() function takes an image created with the PHP's
 * image functions and makes it available for the pdf document. The function
 * returns a pdf image identifier.
 * <p>
 * <b>Example 1.</b> Including a memory image
 * <pre>
 *    &lt;?php
 *    $im = ImageCreate(100, 100);
 *    $col = ImageColorAllocate($im, 80, 45, 190);
 *    ImageFill($im, 10, 10, $col);
 *    $pim = PDF_open_memory_image($pdf, $im);
 *    ImageDestroy($im);
 *    pdf_place_image($pdf, $pim, 100, 100, 1);
 *    pdf_close_image($pdf, $pim);
 *    ?&gt;
 * </pre>
 *
 * @see PDF_close_image()
 * @see PDF_open_jpeg()
 * @see PDF_open_gif()
 * @see PDF_execute_image()
 * @see PDF_place_image()
 * @see PDF_put_image()
 */
function int pdf_open_memory_image(int pdf_document, string int image);
 
/**
 * Opens a JPEG image
 * <p>
 * The PDF_open_jpeg() function opens an image stored in the file with the
 * name filename. The format of the image has to be jpeg. The function returns
 * a pdf image identifier.
 * 
 * @see PDF_close_image()
 * @see PDF_open_gif()
 * @see PDF_open_memory_image()
 * @see PDF_execute_image()
 * @see PDF_place_image()
 * @see PDF_put_image()
 */
function int pdf_open_jpeg(int pdf_document, string filename);
 
/**
 * Closes an image
 * <p>
 * The PDF_close_image() function closes an image which has been opened with
 * any of the PDF_open_xxx() functions.
 * 
 * @see PDF_open_jpeg()
 * @see PDF_open_gif()
 * @see PDF_open_memory_image()
 */
function void pdf_close_image(int image);
 
/**
 * Places an image on the page
 * <p>
 * The PDF_place_image() function places an image on the page at postion
 * (x-koor, x-koor). The image can be scaled at the same time.
 * 
 * @see PDF_put_image()
 */
function void pdf_place_image(int pdf_document, int image, double x_koor, double y_koor, double scale);
 
/**
 * Stores an image in the PDF for later use
 * <p>
 * The PDF_put_image function places an image in the PDF file without showing
 * it. The stored image can be displayed with the {@link PDF_execute_image()} function
 * as many times as needed. This is useful when using the same image multiple
 * times in order to keep the file size small. Using PDF_put_image() and
 * {@link PDF_execute_image()} is highly recommended for larger images (several kb) if
 * they show up more than once in the document.
 * 
 * @see PDF_put_image()
 * @see PDF_place_image()
 * @see PDF_execute_image()
 */
function void pdf_put_image(int pdf_document, int image);
 
/**
 * Places a stored image on the page
 * <p>
 * The PDF_execute_image function displays an image that has been put in the
 * PDF file with the PDF_put_image() function on the current page at the given
 * coordinates.
 * <p>
 * The image can be scaled while displaying it. A scale of 1.0 will show the
 * image in the original size.
 * <p>
 * <b>Example 1.</b> Multiple show of an image
 * <pre>
 *    &lt;?php
 *    $im = ImageCreate(100, 100);
 *    $col1 = ImageColorAllocate($im, 80, 45, 190);
 *    ImageFill($im, 10, 10, $col1);
 *    $pim = PDF_open_memory_image($pdf, $im);
 *    pdf_put_image($pdf, $pim);
 *    pdf_execute_image($pdf, $pim, 100, 100, 1);
 *    pdf_execute_image($pdf, $pim, 200, 200, 2);
 *    pdf_close_image($pdf, $pim);
 *    ?&gt;
 * </pre>
 */
function void pdf_execute_image(int pdf_document, int image, double x_coor, double y_coor, double scale);
 
/**
 * Adds annotation
 * <p>
 * The pdf_add_annotation() adds a note with the lower left corner at
 * (llx,lly) and the upper right corner at (urx, ury).
 */ 
function void pdf_add_annotation(int pdf_document, double llx, double lly, double urx, double ury, string title, string content);


///////////////////////////////////////////////////////////////////////////
// XLIII. PostgreSQL functions
// 
// Postgres, developed originally in the UC Berkeley Computer Science
// Department, pioneered many of the object-relational concepts now becoming
// available in some commercial databases. It provides SQL92/SQL3 language
// support, transaction integrity, and type extensibility. PostgreSQL is a
// public-domain, open source descendant of this original Berkeley code.
// 
// PostgreSQL is available without cost. The current version is available at
// www.PostgreSQL.org.
// 
// Since version 6.3 (03/02/1998) PostgreSQL use unix domain sockets, a table
// is given to this new possibilities. This socket will be found in
// /tmp/.s.PGSQL.5432. This option can be enabled with the '-i' flag to
// postmaster and it's meaning is: "listen on TCP/IP sockets as well as Unix
// domain socket".
// 
// Table 1. Postmaster and PHP
// 
//  Postmaster   PHP                            Status
//  postmaster & pg_connect("", "", "", "",     OK
//               "dbname");
//  postmaster   pg_connect("", "", "", "",     OK
//  -i &         "dbname");
//  postmaster & pg_connect("localhost", "",    Unable to connect to
//               "", "", "dbname");             PostgreSQL server:
//                                              connectDB() failed: Is the
//                                              postmaster running and
//                                              accepting TCP/IP (with -i)
//                                              connection at 'localhost' on
//                                              port '5432'? in
//                                              /path/to/file.php3 on line
//                                              20.
//  postmaster   pg_connect("localhost", "",    OK
//  -i &         "", "", "dbname");
// 
// One can also establish a connection with the following command: $conn =
// pg_Connect("host=localhost port=5432 dbname=chris");
// 
// To use the large object (lo) interface, it is necessary to enclose it
// within a transaction block. A transaction block starts with a begin and if
// the transaction was valid ends with commit and end. If the transaction
// fails the transaction should be closed with abort and rollback.
// Example 1. Using Large Objects
// 
// <?php
// $database = pg_Connect ("", "", "", "", "jacarta");
// pg_exec ($database, "begin");
//     $oid = pg_locreate ($database);
//     echo ("$oid\n");
//     $handle = pg_loopen ($database, $oid, "w");
//     echo ("$handle\n");
//     pg_lowrite ($handle, "gaga");
//     pg_loclose ($handle);
// pg_exec ($database, "commit")
// pg_exec ($database, "end")
// ?>
// 
 
/**
 * closes a PostgreSQL connection
 * <p>
 * Returns false if connection is not a valid connection index, true
 * otherwise. Closes down the connection to a PostgreSQL database associated
 * with the given connection index.
 */
function bool pg_close(int connection);
 
/**
 * returns number of affected tuples
 * <p>
 * pg_cmdTuples() returns the number of tuples (instances) affected by INSERT,
 * UPDATE, and DELETE queries. If no tuple is affected the function will
 * return 0.
 * <p>
 * <b>Example 1.</b> pg_cmdtuples
 * <pre>
 *    &lt;?php
 *    $result = pg_exec($conn, "INSERT INTO verlag VALUES ('Autor')");
 *    $cmdtuples = pg_cmdtuples($result);
 *    echo $cmdtuples . " &lt;- cmdtuples affected.";
 *    ?&gt;
 * </pre>
 */
function int pg_cmdtuples(int result_id);
 
/**
 * opens a connection
 * <p>
 * Returns a connection index on success, or false if the connection could not
 * be made. Opens a connection to a PostgreSQL database. Each of the arguments
 * should be a quoted string, including the port number. The options and tty
 * arguments are optional and can be left out. This function returns a
 * connection index that is needed by other PostgreSQL functions. You can have
 * multiple connections open at once.
 * <p>
 * A connection can also established with the following command: $conn =
 * pg_connect("dbname=marliese port=5432"); Other parameters besides dbname
 * and port are host, tty and options.
 * 
 * @see pg_pConnect()
 */
function int pg_connect(string host, string port, string options, string tty, string dbname);
 
/**
 * database name
 * <p>
 * Returns the name of the database that the given PostgreSQL connection index
 * is connected to, or false if connection is not a valid connection index.
 */
function string pg_dbname(int connection);
 
/**
 * error message
 * <p>
 * Returns a string containing the error message, false on failure. Details
 * about the error probably cannot be retrieved using the pg_errormessage()
 * function if an error occured on the last database action for which a valid
 * connection exists, this function will return a string containing the error
 * message generated by the backend server.
 */
function string pg_errormessage(int connection);
 
/**
 * execute a query
 * <p>
 * Returns a result index if query could be executed, false on failure or if
 * connection is not a valid connection index. Details about the error can be
 * retrieved using the pg_ErrorMessage() function if connection is valid.
 * Sends an SQL statement to the PostgreSQL database specified by the
 * connection index. The connection must be a valid index that was returned by
 * {@link pg_Connect()}. The return value of this function is an index to be used to
 * access the results from other PostgreSQL functions.
 * <p>
 * <b>Note:</b>
 * PHP/FI returned 1 if the query was not expected to return
 * data (inserts or updates, for example) and greater than 1 even on
 * selects that did not return anything. No such assumption can be
 * made in PHP.
 */
function int pg_exec(int connection, string query);
 
/**
 * fetch row as array
 * <p>
 * Returns: An array that corresponds to the fetched row, or false if there
 * are no more rows.
 * <p>
 * pg_fetch_array() is an extended version of {@link pg_fetch_row()}. In addition to
 * storing the data in the numeric indices of the result array, it also stores
 * the data in associative indices, using the field names as keys.
 * <p>
 * The third optional argument result_type in pg_fetch_array() is a constant
 * and can take the following values: PGSQL_ASSOC, PGSQL_NUM, and PGSQL_BOTH.
 * <p>
 * An important thing to note is that using pg_fetch_array() is NOT
 * significantly slower than using {@link pg_fetch_row()}, while it provides a
 * significant added value.
 * <p>
 * For further details, also see pg_fetch_row()
 * <p>
 * <b>Example 1.</b> PostgreSQL fetch array
 * <pre>
 *    &lt;?php
 *    $conn = pg_pconnect("","","","","publisher");
 *    if (!$conn) {
 *        echo "An error occured.\n";
 *        exit;
 *    }
 *    $result = pg_Exec ($conn, "SELECT * FROM authors");
 *    if (!$result) {
 *        echo "An error occured.\n";
 *        exit;
 *    }
 *    $arr = pg_fetch_array ($result, 0);
 *    echo $arr[0] . " &lt;- array\n";
 *    $arr = pg_fetch_array ($result, 1);
 *    echo $arr["author"] . " &lt;- array\n";
 *    ?&gt;
 * </pre>
 * 
 * @since Result_type was added in PHP 4.0.
 */
function array pg_fetch_array(int result, int row, int [result_type] );
 
/**
 * fetch row as object
 * <p>
 * Returns: An object with properties that correspond to the fetched row, or
 * false if there are no more rows.
 * <p>
 * pg_fetch_object() is similar to pg_fetch_array(), with one difference - an
 * object is returned, instead of an array. Indirectly, that means that you
 * can only access the data by the field names, and not by their offsets
 * (numbers are illegal property names).
 * <p>
 * The third optional argument result_type in pg_fetch_object() is a constant
 * and can take the following values: PGSQL_ASSOC, PGSQL_NUM, and PGSQL_BOTH.
 * <p>
 * Speed-wise, the function is identical to pg_fetch_array(), and almost as
 * quick as {@link pg_fetch_row()} (the difference is insignificant).
 * <p>
 * <b>Example 1.</b> Postgres fetch object
 * <pre>
 *    &lt;?php
 *    $database = "verlag";
 *    $db_conn = pg_connect ("localhost", "5432", "", "", $database);
 *    if (!$db_conn): ?&gt;
 *        &lt;H1&gt;Failed connecting to postgres database &lt;? echo $database ?&gt;&lt;/H1&gt; &lt;?
 *        exit;
 *    endif;
 * 
 *    $qu = pg_exec ($db_conn, "SELECT * FROM verlag ORDER BY autor");
 *    $row = 0; // postgres needs a row counter other dbs might not
 * 
 *    while ($data = pg_fetch_object ($qu, $row)):
 *        echo $data-&gt;autor." (";
 *        echo $data-&gt;jahr ."): ";
 *        echo $data-&gt;titel."&lt;BR&gt;";
 *        $row++;
 *    endwhile; ?&gt;
 * 
 *    &lt;PRE&gt;&lt;?php
 *    $fields[] = Array ("autor", "Author");
 *    $fields[] = Array ("jahr",  "  Year");
 *    $fields[] = Array ("titel", " Title");
 * 
 *    $row= 0; // postgres needs a row counter other dbs might not
 *    while ($data = pg_fetch_object ($qu, $row)):
 *        echo "----------\n";
 *        reset ($fields);
 *        while (list (,$item) = each ($fields)):
 *            echo $item[1].": ".$data-&gt;$item[0]."\n";
 *        endwhile;
 *        $row++;
 *    endwhile;
 *    echo "----------\n"; ?&gt;
 *    &lt;/PRE&gt; &lt;?php
 *    pg_freeResult ($qu);
 *    pg_close ($db_conn);
 *    ?&gt;
 * </pre>
 *
 * @see pg_fetch_array()
 * @see pg_fetch_row()
 * @since Result_type was added in PHP 4.0.
 */
function object pg_fetch_object(int result, int row, int [result_type] );
 
/**
 * get row as enumerated array
 * <p>
 * Returns: An array that corresponds to the fetched row, or false if there
 * are no more rows.
 * <p>
 * pg_fetch_row() fetches one row of data from the result associated with the
 * specified result identifier. The row is returned as an array. Each result
 * column is stored in an array offset, starting at offset 0.
 * <p>
 * Subsequent call to pg_fetch_row() would return the next row in the result
 * set, or false if there are no more rows.
 * <p>
 * <b>Example 1.</b> Postgres fetch row
 * <pre>
 *    &lt;?php
 *    $conn = pg_pconnect("","","","","publisher");
 *    if (!$conn) {
 *        echo "An error occured.\n";
 *        exit;
 *    }
 * 
 *    $result = pg_Exec ($conn, "SELECT * FROM authors");
 *    if (!$result) {
 *        echo "An error occured.\n";
 *        exit;
 *    }
 * 
 *    $row = pg_fetch_row ($result, 0);
 *    echo $row[0] . " &lt;- row\n";
 * 
 *    $row = pg_fetch_row ($result, 1);
 *    echo $row[0] . " &lt;- row\n";
 * 
 *    $row = pg_fetch_row ($result, 2);
 *    echo $row[1] . " &lt;- row\n";
 *    ?&gt;
 * </pre>
 * 
 * @see pg_fetch_array()
 * @see pg_fetch_object()
 * @see pg_result()
 */
function array pg_fetch_row(int result, int row);
 
/**
 * Test if a field is NULL
 * <p>
 * Test if a field is NULL or not. Returns 0 if the field in the given row is
 * not NULL. Returns 1 if the field in the given row is NULL. Field can be
 * specified as number or fieldname. Row numbering starts at 0.
 */
function int pg_fieldisnull(int result_id, int row, mixed field);
 
/**
 * Returns the name of a field
 * <p>
 * pg_FieldName() will return the name of the field occupying the given column
 * number in the given PostgreSQL result identifier. Field numbering starts
 * from 0.
 */
function string pg_fieldname(int result_id, int field_number);
 
/**
 * Returns the number of a column
 * <p>
 * pg_FieldNum() will return the number of the column slot that corresponds to
 * the named field in the given PosgreSQL result identifier. Field numbering
 * starts at 0. This function will return -1 on error.
 */
function int pg_fieldnum(int result_id, string field_name);
 
/**
 * Returns the printed length
 * <p>
 * pg_FieldPrtLen() will return the actual printed length (number of
 * characters) of a specific value in a PostgreSQL result. Row numbering
 * starts at 0. This function will return -1 on an error.
 */
function int pg_fieldprtlen(int result_id, int row_number, string field_name);
 
/**
 * Returns the internal storage size of the named field
 * <p>
 * pg_FieldSize() will return the internal storage size (in bytes) of the
 * field number in the given PostgreSQL result. Field numbering starts at 0. A
 * field size of -1 indicates a variable length field. This function will
 * return false on error.
 */
function int pg_fieldsize(int result_id, int field_number);
 
/**
 * Returns the type name for the corresponding field number
 * <p>
 * pg_FieldType() will return a string containing the type name of the given
 * field in the given PostgreSQL result identifier. Field numbering starts at
 * 0.
 */
function int pg_fieldtype(int result_id, int field_number);
 
/**
 * Frees up memory
 * <p>
 * pg_FreeResult() only needs to be called if you are worried about using too
 * much memory while your script is running. All result memory will
 * automatically be freed when the script is finished. But, if you are sure
 * you are not going to need the result data anymore in a script, you may call
 * pg_FreeResult() with the result identifier as an argument and the
 * associated result memory will be freed.
 */
function int pg_freeresult(int result_id);
 
/**
 * Returns the last object identifier
 * <p>
 * pg_GetLastOid() can be used to retrieve the Oid assigned to an inserted
 * tuple if the result identifier is used from the last command sent via
 * pg_Exec() and was an SQL INSERT. This function will return a positive
 * integer if there was a valid Oid. It will return -1 if an error occured or
 * the last command sent via {@link pg_Exec()} was not an INSERT.
 */
function int pg_getlastoid(int result_id);
 
/**
 * Returns the host name
 * <p>
 * pg_Host() will return the host name of the given PostgreSQL connection
 * identifier is connected to.
 */
function string pg_host(int connection_id);
 
/**
 * close a large object
 * <p>
 * pg_loclose() closes an Inversion Large Object. fd is a file descriptor for
 * the large object from {@link pg_loopen()}.
 */
function void pg_loclose(int fd);
 
/**
 * create a large object
 * <p>
 * pg_locreate() creates an Inversion Large Object and returns the oid of the
 * large object. conn specifies a valid database connection. PostgreSQL access
 * modes INV_READ, INV_WRITE, and INV_ARCHIVE are not supported, the object is
 * created always with both read and write access. INV_ARCHIVE has been
 * removed from PostgreSQL itself (version 6.3 and above).
 */
function int pg_locreate(int conn);
 
/**
 * open a large object
 * <p>
 * pg_loopen() open an Inversion Large Object and returns file descriptor of
 * the large object. The file descriptor encapsulates information about the
 * connection. Do not close the connection before closing the large object
 * file descriptor. objoid specifies a valid large object oid and mode can be
 * either "r", "w", or "rw".
 */
function int pg_loopen(int conn, int objoid, string mode);
 
/**
 * read a large object
 * <p>
 * pg_loread() reads at most len bytes from a large object and returns it as a
 * string. fd specifies a valid large object file descriptor andlen specifies
 * the maximum allowable size of the large object segment.
 */
function string pg_loread(int fd, int len);
 
/**
 * read a entire large object
 * <p>
 * pg_loreadall() reads a large object and passes it straight through to the
 * browser after sending all pending headers. Mainly intended for sending
 * binary data like images or sound.
 */
function void pg_loreadall(int fd);
 
/**
 * delete a large object
 * <p>
 * pg_lounlink() deletes a large object with the lobjid identifier for that
 * large object.
 */
function void pg_lounlink(int conn, int lobjid);
 
/**
 * write a large object
 * <p>
 * pg_lowrite() writes at most to a large object from a variable buf and
 * returns the number of bytes actually written, or false in the case of an
 * error. fd is a file descriptor for the large object from {@link pg_loopen()}.
 */
function int pg_lowrite(int fd, string buf);
 
/**
 * Returns the number of fields
 * <p>
 * pg_NumFields() will return the number of fields (columns) in a PostgreSQL
 * result. The argument is a valid result identifier returned by {@link pg_Exec()}.
 * This function will return -1 on error.
 */
function int pg_numfields(int result_id);
 
/**
 * Returns the number of rows
 * <p>
 * pg_NumRows() will return the number of rows in a PostgreSQL result. The
 * argument is a valid result identifier returned by {@link pg_Exec()}. This function
 * will return -1 on error.
 */
function int pg_numrows(int result_id);
 
/**
 * Returns options
 * <p>
 * pg_Options() will return a string containing the options specified on the
 * given PostgreSQL connection identifier.
 */
function string pg_options(int connection_id);
 
/**
 * make a persistent database connection
 * <p>
 * Returns a connection index on success, or false if the connection could not
 * be made. Opens a persistent connection to a PostgreSQL database. Each of
 * the arguments should be a quoted string, including the port number. The
 * options and tty arguments are optional and can be left out. This function
 * returns a connection index that is needed by other PostgreSQL functions.
 * You can have multiple persistent connections open at once. See also
 * {@link pg_Connect()}.
 * <p>
 * A connection can also established with the following command: $conn =
 * pg_pconnect("dbname=marliese port=5432"); Other parameters besides dbname
 * and port are host, tty and options.
 */
function int pg_pconnect(string host, string port, string options, string tty, string dbname);
 
/**
 * Returns the port number
 * <p>
 * pg_Port() will return the port number that the given PostgreSQL connection
 * identifier is connected to.
 */
function int pg_port(int connection_id);
 
/**
 * Returns values from a result identifier
 * <p>
 * pg_Result() will return values from a result identifier produced by
 * {@link pg_Exec()}. The row_number and fieldname sepcify what cell in the table of
 * results to return. Row numbering starts from 0. Instead of naming the
 * field, you may use the field index as an unquoted number. Field indices
 * start from 0.
 * <p>
 * PostgreSQL has many built in types and only the basic ones are directly
 * supported here. All forms of integer, boolean and oid types are returned as
 * integer values. All forms of float, and real types are returned as double
 * values. All other types, including arrays are returned as strings formatted
 * in the same default PostgreSQL manner that you would see in the psql
 * program.
 */
function mixed pg_result(int result_id, int row_number, mixed fieldname);
 
/**
 * Returns the tty name
 * <p>
 * pg_tty() will return the tty name that server side debugging output is sent
 * to on the given PostgreSQL connection identifier.
 */ 
function string pg_tty(int connection_id);


///////////////////////////////////////////////////////////////////////////
// Regular expression functions
// 
// Regular expressions are used for complex string manipulation in PHP. The
// functions that support regular expressions are:
// 
//    * ereg()
//    * ereg_replace()
//    * eregi()
//    * eregi_replace()
//    * split()
// 
// These functions all take a regular expression string as their first
// argument. PHP uses the POSIX extended regular expressions as defined by
// POSIX 1003.2. For a full description of POSIX regular expressions see the
// regex man pages included in the regex directory in the PHP distribution.
// 
// Example 1. Regular expression examples
// 
// ereg("abc",$string);
// /* Returns true if "abc"
//    is found anywhere in $string. */
// 
// ereg("^abc",$string);
// /* Returns true if "abc"
//    is found at the beginning of $string. */
// 
// ereg("abc$",$string);
// /* Returns true if "abc"
//    is found at the end of $string. */
// 
// eregi("(ozilla.[23]|MSIE.3)",$HTTP_USER_AGENT);
// /* Returns true if client browser
//    is Netscape 2, 3 or MSIE 3. */
// 
// ereg("([[:alnum:]]+) ([[:alnum:]]+) ([[:alnum:]]+)",
//      $string,$regs);
// /* Places three space separated words
//    into $regs[1], $regs[2] and $regs[3]. */
// 
// $string = ereg_replace("^","<BR>",$string);
// /* Put a <BR> tag at the beginning of $string. */
// 
// $string = ereg_replace("$","<BR>",$string);
// /* Put a <BR> tag at the end of $string. */
// 
// $string = ereg_replace("\n","",$string);
// /* Get rid of any carriage return
//    characters in $string. */
// 
 
/**
 * regular expression match
 * <p>
 * Searchs string for matches to the regular expression given in pattern.
 * <p>
 * If matches are found for parenthesized substrings of pattern and the
 * function is called with the third argument regs, the matches will be stored
 * in the elements of regs. $regs[1] will contain the substring which starts
 * at the first left parenthesis; $regs[2] will contain the substring starting
 * at the second, and so on. $regs[0] will contain a copy of string.
 * <p>
 * Searching is case sensitive.
 * <p>
 * Returns true if a match for pattern was found in string, or false if no
 * matches were found or an error occurred.
 * <p>
 * The following code snippet takes a date in ISO format (YYYY-MM-DD) and
 * prints it in DD.MM.YYYY format:
 * <p>
 * <b>Example 1.</b> ereg() example
 * <pre>
 *    if ( ereg( "([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $date, $regs ) ) {
 *        echo "$regs[3].$regs[2].$regs[1]";
 *    } else {
 *        echo "Invalid date format: $date";
 *    }
 * </pre>
 *
 * @see eregi()
 * @see ereg_replace()
 * @see eregi_replace()
 */
function int ereg(string pattern, string string, array [regs]);
 
/**
 * replace regular expression
 * <p>
 * This function scans string for matches to pattern, then replaces the
 * matched text with replacement.
 * <p>
 * The modified string is returned. (Which may mean that the original string
 * is returned if there are no matches to be replaced.)
 * <p>
 * If pattern contains parenthesized substrings, replacement may contain
 * substrings of the form \\digit, which will be replaced by the text matching
 * the digit'th parenthesized substring; \\0 will produce the entire contents
 * of string. Up to nine substrings may be used. Parentheses may be nested, in
 * which case they are counted by the opening parenthesis.
 * <p>
 * If no matches are found in string, then string will be returned unchanged.
 * <p>
 * For example, the following code snippet prints "This was a test" three
 * times:
 * <P>
 * <b>Example 1.</b> ereg_replace() example
 * <pre>
 *    $string = "This is a test";
 *    echo ereg_replace( " is", " was", $string );
 *    echo ereg_replace( "( )is", "\\1was", $string );
 *    echo ereg_replace( "(( )is)", "\\2was", $string );
 * </pre>
 *
 * @see ereg()
 * @see eregi()
 * @see eregi_replace()
 */
function string ereg_replace(string pattern, string replacement, string string);
 
/**
 * case insensitive regular expression match
 * <p>
 * This function is identical to {@link ereg()} save that this ignores case
 * distinction when matching alphabetic characters.
 * 
 * @see ereg()
 * @see ereg_replace()
 * @see eregi_replace()
 */
function int eregi(string pattern, string string, array [regs]);
 
/**
 * replace regular expression case insensitive
 * <p>
 * This function is identical to ereg_replace() save that this ignores case
 * distinction when matching alphabetic characters.
 * 
 * @see ereg()
 * @see eregi()
 * @see ereg_replace()
 */
function string eregi_replace(string pattern, string replacement, string string);
 
/**
 * split string into array by regular expression
 * <p>
 * Returns an array of strings, each of which is a substring of string formed
 * by splitting it on boundaries formed by pattern. If an error occurs,
 * returns false.
 * <p>
 * To get the first five fields from a line from /etc/passwd:
 * <p>
 * <b>Example 1.</b> split() example
 * <pre>
 *    $passwd_list = split( ":", $passwd_line, 5 );
 * </pre>
 * Note that pattern is case-sensitive.
 * 
 * @see explode()
 * @see implode()
 */
function array split(string pattern, string string, int [limit]);
 
/**
 * make regular expression for case insensitive match
 * <p>
 * Returns a valid regular expression which will match string, ignoring case.
 * This expression is string with each character converted to a bracket
 * expression; this bracket expression contains that character's uppercase and
 * lowercase form if applicable, otherwise it contains the original character
 * twice.
 *
 * <b>Example 1.</b> sql_regcase() example
 * <pre>
 *    echo sql_regcase( "Foo bar" );
 * </pre>
 * prints
 * <pre>
 *    [Ff][Oo][Oo][  ][Bb][Aa][Rr]
 * </pre>
 * This can be used to achieve case insensitive pattern matching in products
 * which support only case sensitive regular expressions.
 */
function string sql_regcase(string string);


///////////////////////////////////////////////////////////////////////////
// Semaphore and shared memory functions
// 
// This module provides semaphore functions using System V semaphores.
// Semaphores may be used to provide exclusive access to resources on the
// current machine, or to limit the number of processes that may
// simultaneously use a resource.
// 
// This module provides also shared memory functions using System V shared
// memory. Shared memory may be used to provide access to global variables.
// Different httpd-daemons and even other programs (such as Perl, C, ...) are
// able to access this data to provide a global data-exchange. Remember, that
// shared memory is NOT safe against simultaneous access. Use semaphores for
// synchronization.
// 
// Table 1. Limits of shared memory by the Unix OS
// 
//  SHMMAXmax size of shared memory, normally 131072 bytes
//  SHMMINminimum size of shared memory, normally 1 byte
//  SHMMNImax amount of shared memory segments, normally 100
//  SHMSEGmax amount of shared memory per process, normally 6
// 
 
/**
 * get a semaphore id
 * <p>
 * Returns: A positive semaphore identifier on success, or false on error.
 * <p>
 * sem_get() returns an id that can be used to access the System V semaphore
 * with the given key. The semaphore is created if necessary using the
 * permission bits specified in perm (defaults to 0666). The number of
 * processes that can acquire the semaphore simultaneously is set to
 * max_acquire (defaults to 1). Actually this value is set only if the process
 * finds it is the only process currently attached to the semaphore.
 * <p>
 * A second call to sem_get() for the same key will return a different
 * semaphore identifier, but both identifiers access the same underlying
 * semaphore.
 * 
 * @see sem_acquire()
 * @see sem_release()
 */
function int sem_get(int key, int [max_acquire] , int [perm] );
 
/**
 * acquire a semaphore
 * <p>
 * Returns: true on success, false on error
 * <p>
 * sem_acquire() blocks (if necessary) until the semaphore can be acquired. A
 * process attempting to acquire a semaphore which it has already acquired
 * will block forever if acquiring the semaphore would cause its max_acquire
 * value to be exceeded.
 * <p>
 * After processing a request, any semaphores acquired by the process but not
 * explicitly released will be released automatically and a warning will be
 * generated.
 * 
 * @see sem_get()
 * @see sem_release()
 */
function int sem_acquire(int sem_identifier);
 
/**
 * release a semaphore
 * <p>
 * Returns: true on success, false on error
 * <p>
 * sem_release() releases the semaphore if it is currently acquired by the
 * calling process, otherwise a warning is generated.
 * <p>
 * After releasing the semaphore, {@link sem_acquire()} may be called to re-acquire
 * it.
 * 
 * @see sem_get()
 * @see sem_acquire()
 */
function int sem_release(int sem_identifier);
 
/**
 * Creates or open a shared memory segment
 * <p>
 * shm_attach() returns an id that that can be used to access the System V
 * shared memory with the given key, the first call creates the shared memory
 * segment with mem_size (default: sysvshm.init_mem in the configuration file,
 * otherwise 10000 bytes) and the optional perm-bits (default: 0666).
 * <p>
 * A second call to shm_attach() for the same key will return a different
 * shared memory identifier, but both identifiers access the same underlying
 * shared memory. memsize and perm will be ignored.
 */
function int shm_attach(int key, int [memsize], int [perm]);
 
/**
 * Disconnects from shared memory segment
 * <p>
 * shm_detach() disconnects from the shared memory given by the shm_identifier
 * created by {@link shm_attach()}. Remember, that shared memory still exist in the
 * Unix system and the data is still present.
 */
function int shm_detach(int shm_identifier);
 
/**
 * Removes shared memory from Unix systems
 * <p>
 * Removes shared memory from Unix systems. All data will be destroyed.
 */
function int shm_remove(int shm_identifier);
 
/**
 * Inserts or updates a variable in shared memory
 * <p>
 * Inserts or updates a variable with a given variable_key. All variable-types
 * (double, int, string, array) are supported.
 */
function int shm_put_var(int shm_identifier, int variable_key, mixed variable);
 
/**
 * Returns a variable from shared memory
 * <p>
 * shm_get_var() returns the variable with a given variable_key. The variable
 * is still present in the shared memory.
 */
function mixed shm_get_var(int id, int variable_key);
 
/**
 * Removes a variable from shared memory
 * <p>
 * Removes a variable with a given variable_key and frees the occupied memory.
 */ 
function int shm_remove_var(int id, int variable_key);


///////////////////////////////////////////////////////////////////////////
// Session handling functions
// 
// Session support in PHP consists of a way to preserve certain data across
// subsequent accesses. This enables you to build more customized applications
// and increase the appeal of your web site.
// 
// A visitor accessing your web site is assigned an unique id, the so called
// session id. This is either stored in a cookie on the user side or is
// propagated in the URL.
// 
// The session support allows you register arbitrary numbers of variables to
// be preserved across requests. When a visitor accesses your site, PHP will
// check automatically (if session.auto_start is set to 1) or on your request
// (explicitly through session_start() or implicitly through
// session_register()) whether a specific session id has been sent with the
// request. If this is the case, the prior saved environment is recreated.
// 
// All registered variables are serialized after the request finishes.
// Registered variables which are undefined are marked as being not defined.
// On subsequent accesses, these are not defined by the session module unless
// the user defines them later.
// 
// Currently, objects cannot be used as session variables.
// 
// The constant SID is defined, if the session module does not know exactly
// whether the user has accepted the cookie. You can use <?=SID?> to print out
// the constant (this will evaluate to an empty string, if SID is not
// defined). SID is of the form session_name=session_id.
// 
// The following example demonstrates how to register a variable, and how to
// link correctly to another page (propagation of session id).
// Example 1. counting the number of hits of a single user
// 
// <?php
// session_register("count");
// $count++;
// ?>
// 
// Hello visitor, you have seen this page <? echo $count; ?> times.<p>
// 
// # the <?=SID?> is necessary to preserve the session id
// # in the case that the user has disabled cookies
// 
// To continue, <A HREF="nextpage.php?<?=SID?>">click here</A>
// 
// The session management system supports a number of configuration options
// which you can place in your php.ini file. We will give a short overview.
// 
//    * session.save_handler defines the name of the handler which is used for
//      storing and retrieving data associated with a session. Defaults to
//      files.
// 
//    * session.save_path defines the argument which is passed to the save
//      handler. If you choose the default files handler, this is the path
//      where the files are created. Defaults to /tmp.
// 
//    * session.name specifies the name of the session which is used as cookie
//      name. It should only contain alphanumeric characters. Defaults to
//      PHPSESSID.
// 
//    * session.auto_start specifies whether the session module start a
//      session automatically on request startup. Defaults to 0 (off).
// 
//    * session.lifetime specifies the lifetime of the cookie in seconds which
//      is sent to the browser. The value 0 means "until the browser is
//      closed." Defaults to 0.
// 
//    * session.serialize_handler defines the name of the handler which is
//      used to serialize/deserialize data. Currently, only "php" is
//      supported. Defaults to php.
// 
//    * session.gc_probability specifies the probability that the gc (garbage
//      collection) routine is started on each request in percent. Defaults to
//      1.
// 
//    * session.gc_maxlifetime specifies the number of seconds after which
//      data will be seen as 'garbage' and cleaned up.
// 
//      Note: Session handling was added in PHP 4.0.
// 
 
/**
 * Initialize session data
 * <p>
 * session_start() creates a session (or resumes the current one based on the
 * session id being passed via a GET variable or a cookie).
 * <p>
 * This function always returns true.
 * 
 * @since This function was added in PHP 4.0.
 */
function bool session_start(void);
 
/**
 * Destroys all data registered to a session
 * <p>
 * session_destroy() destroys all of the data associated with the current
 * session.
 * <p>
 * This function always returns true.
 * 
 * @since This function was added in PHP 4.0.
 */
function bool session_destroy(void);
 
/**
 * Get and/or set the current session name
 * <p>
 * session_name() returns the name of the current session. If name is
 * specified, the name of the current session is changed to its value.
 * <p>
 * <b>Example 1.</b> session_name() examples
 * <pre>
 *    $username="foo";
 *    if(isset($username)) {
 *        session_name($username);
 *    }
 *    echo "Your username is " . session_name();
 * </pre>
 *
 * @since This function was added in PHP 4.0.
 */
function string session_name(string [name]);
 
/**
 * Get and/or set the current session module
 * <p>
 * session_module_name() returns the name of the current session module. If
 * module is specified, that module will be used instead.
 * 
 * @since This function was added in PHP 4.0.
 */
function string session_module_name(string [module]);
 
/**
 * Get and/or set the current session save path
 * <p>
 * session_save_path() returns the path of the current directory used to save
 * session data. If path is specified, the path to which data is saved will be
 * changed.
 * <p>
 * <b>Note:</b>
 * On some operating systems, you may want to specify a path
 * on a filesystem that handles lots of small files efficiently. For
 * example, on Linux, reiserfs may provide better performance than
 * ext2fs.
 * 
 * @since This function was added in PHP 4.0.
 */
function string session_save_path(string [path]);
 
/**
 * Get and/or set the current session id
 * <p>
 * session_id() returns the session id for the current session. If id is
 * specified, it will replace the current session id.
 * <p>
 * directory used to save session data. If path is specified, the path to
 * which data is saved will be changed.
 * <p>
 * The constant SID can also be used to retrieve the current name and session
 * id as a string suitable for adding to URLs.
 * 
 * @since This function was added in PHP 4.0.
 */
function string session_id(string [id]);
 
/**
 * Register a variable with the current session
 * <p>
 * session_register() registers the global variable named name with the
 * current session.
 * <p>
 * This function returns true when the variable is successfully registered
 * with the session.
 * 
 * @since This function was added in PHP 4.0.
 */
function bool session_register(string name);
 
/**
 * Unregister a variable from the current session
 * <p>
 * session_unregister() unregisters (forgets) the global variable named name
 * from the current session.
 * <p>
 * This function returns true when the variable is successfully unregistered
 * from the session.
 * 
 * @since This function was added in PHP 4.0.
 */
function bool session_unregister(string name);
 
/**
 * Find out if a variable is registered in a session
 * <p>
 * session_is_registered() returns true if there is a variable with the name
 * name registered in the current session.
 * 
 * @since This function was added in PHP 4.0.
 */
function bool session_is_registered(string name);
 
/**
 * Decodes session data from a string
 * <p>
 * session_decode() decodes the session data in data, setting variables stored
 * in the session.
 * 
 * @since This function was added in PHP 4.0.
 */
function bool session_decode(string data);
 
/**
 * Encodes the current session data as a string
 * <p>
 * session_encode() returns a string with the contents of the current session
 * encoded within.
 * 
 * @since This function was added in PHP 4.0.
 */
function bool session_encode(void);


///////////////////////////////////////////////////////////////////////////
// Solid functions
// 
// The Solid functions are deprecated, you probably want to use the Unified
// ODBC functions instead.
//  

/**
 * close a Solid connection
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_close()
 */
function solid_close();
 
 
/**
 * connect to a Solid data source
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_connect()
 */
function solid_connect();
 
 
/**
 * execute a Solid query
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_exec()
 */
function solid_exec();

/**
 * fetch row of data from Solid query
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_fetch_row()
 */
function solid_fetchrow();
 
 
/**
 * get name of column from Solid query
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_field_name()
 */
function solid_fieldname();
 
 
/**
 * get index of column from Solid query
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_field_num()
 */
function solid_fieldnum();
 
/**
 * free result memory from Solid query
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_free_result()
 */
function solid_freeresult();
 
/**
 * get number of fields in Solid result
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_num_fields()
 */
function solid_numfields();
 
/**
 * get number of rows in Solid result
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_num_rows()
 */
function solid_numrows();
 
/**
 * get data from Solid results
 * 
 * @deprecated use the Unified ODBC functions instead.
 * @see odbc_result()
 */
function solid_result();


///////////////////////////////////////////////////////////////////////////
// SNMP functions
//
// In order to use the SNMP functions on Unix you need to install the UCD SNMP
// package. On Windows these functions are only available on NT and not on
// Win95/98.
// 
// Important: In order to use the UCD SNMP package, you need to define
// NO_ZEROLENGTH_COMMUNITY to 1 before compiling it. After configuring UCD
// SNMP, edit config.h and search for NO_ZEROLENGTH_COMMUNITY. Uncomment the
// #define line. It should look like this afterwards:
// 
// #define NO_ZEROLENGTH_COMMUNITY 1
// 
// If you see strange segmentation faults in combination with SNMP commands,
// you did not follow the above instructions. If you do not want to recompile
// UCD SNMP, you can compile PHP with the --enable-ucd-snmp-hack switch which
// will work around the misfeature.
// 

/**
 * Fetch an SNMP object
 * <p>
 * Returns SNMP object value on success and false on error.
 * <p>
 * The snmpget() function is used to read the value of an SNMP object
 * specified by the object_id. SNMP agent is specified by the hostname and the
 * read community is specified by the community parameter.
 * <pre>
 *    $syscontact = snmpget("127.0.0.1", "public", "system.SysContact.0")
 * </pre>
 */
function string snmpget(string hostname, string community, string object_id, int [timeout], int [retries]);
 
/**
 * Set an SNMP object
 * <p>
 * Sets the specified SNMP object value, returning true on success and false
 * on error.
 * <p>
 * The snmpset() function is used to set the value of an SNMP object specified
 * by the object_id. SNMP agent is specified by the hostname and the read
 * community is specified by the community parameter.
 */
function string snmpset(string hostname, string community, string object_id, string type, mixed value, int [timeout], int [retries]);
 
/**
 * Fetch all the SNMP objects from an agent
 * <p>
 * Returns an array of SNMP object values starting from the {@link object_id()} as
 * root and false on error.
 * <p>
 * snmpwalk() function is used to read all the values from an SNMP agent
 * specified by the hostname. Community specifies the read community for that
 * agent. A null object_id is taken as the root of the SNMP objects tree and
 * all objects under that tree are returned as an array. If object_id is
 * specified, all the SNMP objects below that object_id are returned.
 * <p>
 * $a = snmpwalk("127.0.0.1", "public", "");
 * <p>
 * Above function call would return all the SNMP objects from the SNMP agent
 * running on localhost. One can step through the values with a loop
 * <pre>
 *    for ($i=0; $i&lt;count($a); $i++) {
 *       echo $a[$i];
 *    }
 * </pre>
 */
function array snmpwalk(string hostname, string community, string object_id, int [timeout] , int [retries] );
 
/**
 * Query for a tree of information about a network entity
 * <p>
 * Returns an associative array with object ids and their respective object
 * value starting from the object_id as root and false on error.
 * <p>
 * snmpwalkoid() function is used to read all object ids and their respective
 * values from an SNMP agent specified by the hostname. Community specifies
 * the read community for that agent. A null object_id is taken as the root of
 * the SNMP objects tree and all objects under that tree are returned as an
 * array. If object_id is specified, all the SNMP objects below that object_id
 * are returned.
 * <p>
 * The existence of snmpwalkoid() and {@link snmpwalk()} has historical reasons. Both
 * functions are provided for backward compatibility.
 * <p>
 * $a = snmpwalkoid("127.0.0.1", "public", "");
 * <p>
 * Above function call would return all the SNMP objects from the SNMP agent
 * running on localhost. One can step through the values with a loop
 * <pre>
 *    for (reset($a); $i = key($a); next($a)) {
 *       echo "$i: $a[$i]&lt;br&gt;\n";
 *    }
 * </pre>
 */
function array snmpwalkoid(string hostname, string community, string object_id, int [timeout] , int [retries] );
 
/**
 * ting
 * <p>
 * Returns the current value stored in the UCD Library for quick_print.
 * quick_print is off by default.
 * <pre>
 *    $quickprint = snmp_get_quick_print();
 * </pre>
 * Above function call would return false if quick_print is on, and true if
 * quick_print is on.
 * <p>
 * snmp_get_quick_print() is only available when using the UCD SNMP library.
 * This function is not available when using the Windows SNMP library.
 * 
 * @see snmp_set_quick_print()
 */
function bool snmp_get_quick_print(void );
 
/**
 * Sets the value of quick_print within the UCD SNMP library. When this is set
 * (1), the SNMP library will return 'quick printed' values. This means that
 * just the value will be printed. When quick_print is not enabled (default)
 * the UCD SNMP library prints extra information including the type of the
 * value (i.e. IpAddress or OID). Additionally, if quick_print is not enabled,
 * the library prints additional hex values for all strings of three
 * characters or less.
 * <p>
 * Setting quick_print is often used when using the information returned
 * rather then displaying it.
 * <pre>
 *    snmp_set_quick_print(0);
 *    $a = snmpget("127.0.0.1", "public", ".1.3.6.1.2.1.2.2.1.9.1");
 *    echo "$a&lt;BR&gt;\n";
 *    snmp_set_quick_print(1);
 *    $a = snmpget("127.0.0.1", "public", ".1.3.6.1.2.1.2.2.1.9.1");
 *    echo "$a&lt;BR&gt;\n";
 * </pre>
 * The first value printed might be: 'Timeticks: (0) 0:00:00.00', whereas with
 * quick_print enabled, just '0:00:00.00' would be printed.
 * <p>
 * By default the UCD SNMP library returns verbose values, quick_print is used
 * to return only the value.
 * <p>
 * Currently strings are still returned with extra quotes, this will be
 * corrected in a later release.
 * <p>
 * snmp_set_quick_print() is only available when using the UCD SNMP library.
 * This function is not available when using the Windows SNMP library.
 */
function void snmp_set_quick_print(bool quick_print);


///////////////////////////////////////////////////////////////////////////
// String functions
// 
// These functions all manipulate strings in various ways. Some more
// specialized sections can be found in the regular expression and URL
// handling sections.
// 
 
/**
 * quote string with slashes
 * <p>
 * Returns a string with backslashes before characters that need to be quoted
 * in database queries etc. These characters are single quote ('), double
 * quote ("), backslash (\) and NUL (the null byte).
 * 
 * @see stripslashes()
 * @see htmlspecialchars()
 * @see quotemeta()
 */
function string addslashes(string str);
 
/**
 * convert binary data into hexadecimal representation
 * <p>
 * Returns an ASCII string containing the hexadecimal representation of str.
 * The conversion is done byte-wise with the high-nibble first.
 */
function string bin2hex(string str);
 
/**
 * remove trailing whitespace
 * <p>
 * Returns the argument string without trailing whitespace.
 * <p>
 * <b>Example 1.</b> chop() example
 * <pre>
 *    $trimmed = Chop($line);
 * </pre>
 *
 * @see trim()
 */
function string chop(string str);
 
/**
 * return a specific character
 * <p>
 * Returns a one-character string containing the character specified by ascii.
 * <P>
 * <b>Example 1.</b> chr() example
 * <pre>
 *    $str .= chr(27); // add an escape character at the end of $str 
 *    // Often this is more useful 
 *    $str = sprintf("The string ends in escape: %c", 27);
 * </pre>
 * This function complements ord(). See also {@link sprintf()} with a format string of
 * %c.
 */
function string chr(int ascii);
 
/**
 * Split a string into smaller chunks
 * <p>
 * Can be used to split a string into smaller chunks which is useful for e.g.
 * converting base64_encode output to match RFC 2045 semantics. It inserts
 * every chunklen (defaults to 76) chars the string end (defaults to "\r\n").
 * It returns the new string leaving the original string untouched.
 * <p>
 * <b>Example 1.</b> chunk_split() example
 * <pre>
 *    # format $data using RFC 2045 semantics
 *    $new_string = chunk_split(base64_encode($data));
 * </pre>
 * This function is significantly faster than {@link ereg_replace()}.
 * 
 * @since This function was added in 3.0.6.
 */
function string chunk_split(string string, int [chunklen] , string [end] );
 
/**
 * Convert from one Cyrillic character set to another
 * <p>
 * This function converts the given string from one Cyrillic character set to
 * another. The from and to arguments are single characters that represent the
 * source and target Cyrillic character sets. The supported types are:
 * <ul>
 * <li> k - koi8-r
 * <li> w - windows-1251
 * <li> i - iso8859-5
 * <li> a - x-cp866
 * <li> d - x-cp866
 * <li> m - x-mac-cyrillic
 * </ul>
 */
function string convert_cyr_string(string str, string from, string to);
 
/**
 * DES-encrypt a string
 * <p>
 * crypt() will encrypt a string using the standard Unix DES encryption
 * method. Arguments are a string to be encrypted and an optional
 * two-character salt string to base the encryption on. See the Unix man page
 * for your crypt function for more information.
 * <p>
 * If the salt argument is not provided, it will be randomly generated by PHP.
 * <p>
 * Some operating systems support more than one type of encryption. In fact,
 * sometimes the standard DES encryption is replaced by an MD5 based
 * encryption algorithm. The encryption type is triggered by the salt
 * argument. At install time, PHP determines the capabilities of the crypt
 * function and will accept salts for other encryption types. If no salt is
 * provided, PHP will auto-generate a standard 2-character DES salt by default
 * unless the default encryption type on the system is MD5 in which case a
 * random MD5-compatible salt is generated. PHP sets a constant named
 * CRYPT_SALT_LENGTH which tells you whether a regular 2-character salt
 * applies to your system or the longer 12-char MD5 salt is applicable.
 * <p>
 * The standard DES encryption crypt() contains the salt as the first two
 * characters of the output.
 * <p>
 * On systems where the crypt() function supports multiple encryption types,
 * the following constants are set to 0 or 1 depending on whether the given
 * type is available:
 * <ul>
 * <li> CRYPT_STD_DES - Standard DES encryption with a 2-char SALT
 * <li> CRYPT_EXT_DES - Extended DES encryption with a 9-char SALT
 * <li> CRYPT_MD5 - MD5 encryption with a 12-char SALT starting with $1$
 * <li> CRYPT_BLOWFISH - Extended DES encryption with a 16-char SALT starting
 *      with $2$
 * </ul>
 * There is no decrypt function, since crypt() uses a one-way algorithm.
 */
function string crypt(string str, string [salt]);
 
/**
 * output one or more strings
 * <p>
 * Outputs all parameters.
 * <p>
 * echo() is not actually a function (it is a language construct) so you are
 * not required to use parantheses with it.
 * <p>
 * <b>Example 1.</b> echo example
 * <pre>
 *    echo "Hello World";
 * </pre>
 * <b>Note:</b>
 * In fact, if you want to pass more than one parameter to
 * echo, you must not enclose the parameters within parentheses.
 * 
 * @see print()
 * @see printf()
 * @see flush()
 */
function echo(string arg1, string [argn]...);
 
/**
 * split a string by string
 * <p>
 * Returns an array of strings containing the elements separated by separator.
 * <p>
 * <b>Example 1.</b> explode() example
 * <pre>
 *    $pizza = "piece1 piece2 piece3 piece4 piece5 piece6";
 *    $pieces = explode(" ", $pizza);
 * </pre>
 *
 * @see split()
 * @see implode()
 */
function array explode(string separator, string string);
 
/**
 * flush the output buffer
 * <p>
 * Flushes the output buffers of PHP and whatever backend PHP is using (CGI, a
 * web server, etc.) This effectively tries to push all the output so far to
 * the user's browser.
 * 
 */
function void flush(void);
 
/**
 * array
 * <p>
 * Opens filename and parses it line by line for &lt;meta&gt; tags of the form
 * <P>
 * <b>Example 1.</b> Meta Tags Example
 * <pre>
 *    &lt;meta name="author" content="name"&gt;
 *    &lt;meta name="tags" content="php3 documentation"&gt;
 *    &lt;/head&gt; &lt;!-- parsing stops here --&gt;
 * </pre>
 * (pay attention to line endings - PHP uses a native function to parse the
 * input, so a Mac file won't work on Unix).
 * <p>
 * The value of the name property becomes the key, the value of the content
 * property becomes the value of the returned array, so you can easily use
 * standard array functions to traverse it or access single values. Special
 * characters in the value of the name property are substituted with '_', the
 * rest is converted to lower case.
 * <p>
 * Setting use_include_path to 1 will result in PHP trying to open the file
 * along the standard include path.
 */
function array get_meta_tags(string filename, int [use_include_path]);
 
/**
 * Convert special characters to HTML entities.
 * <p>
 * Certain characters have special significance in HTML, and should be
 * represented by HTML entities if they are to preserve their meanings. This
 * function returns a string with these conversions made.
 * <p>
 * This function is useful in preventing user-supplied text from containing
 * HTML markup, such as in a message board or guest book application.
 * <p>
 * At present, the translations that are done are:
 * <ul>
 * <li> '&' (ampersand) becomes '&amp;'
 * <li> '"' (double quote) becomes '&quot;'
 * <li> '&lt;' (less than) becomes '&lt;'
 * <li> '&gt;' (greater than) becomes '&gt;'
 * </ul>
 * Note that this functions does not translate anything beyond what is listed
 * above. For full entity translation, see {@link htmlentities()}.
 * 
 * @see htmlentities()
 * @see nl2br()
 */
function string htmlspecialchars(string string);
 
/**
 * Convert all applicable characters to HTML entities.
 * <p>
 * This function is identical to {@link htmlspecialchars()} in all ways, except that
 * all characters which have HTML entity equivalents are translated into these
 * entities.
 * <p>
 * At present, the ISO-8859-1 character set is used.
 * 
 * @see htmlspecialchars()
 * @see nl2br()
 */
function string htmlentities(string string);
 
/**
 * join array elements with a string
 * <p>
 * Returns a string containing a string representation of all the array
 * elements in the same order, with the glue string between each element.
 * <p>
 * <b>Example 1.</b> implode() example
 * <pre>
 *    $colon_separated = implode(":", $array);
 * </pre>
 *
 * @see explode()
 * @see join()
 * @see split()
 */
function string implode(string glue, array pieces);
 
/**
 * join array elements with a string
 * <p>
 * join() is an alias to implode(), and is identical in every way.
 */
function string join(string glue, array pieces);
 
/**
 * Strip whitespace from the beginning of a string.
 * <p>
 * This function strips whitespace from the start of a string and returns the
 * stripped string.
 * 
 * @see chop()
 * @see trim()
 */
function string ltrim(string str);
 
/**
 * calculate the md5 hash of a string
 * <p>
 * Calculates the MD5 hash of str using the RSA Data Security, Inc. MD5
 * Message-Digest Algorithm.
 */
function string md5(string str);
 
/**
 * Converts newlines to HTML line breaks.
 * <p>
 * Returns string with '&lt;BR&gt;' inserted before all newlines.
 * 
 * @see htmlspecialchars()
 * @see htmlentities()
 */
function string nl2br(string string);
 
/**
 * return ASCII value of character
 * <p>
 * Returns the ASCII value of the first character of string. This function
 * complements {@link chr()}.
 * <p>
 * <b>Example 1.</b> ord() example
 * <pre>
 *    if (ord($str) == 10) {
 *       echo("The first character of \$str is a line feed.\n");
 *    }
 * </pre>
 *
 * @see chr()
 */
function int ord(string string);
 
/**
 * parses the string into variables
 * <p>
 * Parses str as if it were the query string passed via an URL and sets
 * variables in the current scope.
 * <p>
 * <b>Example 1.</b> Using parse_str()
 * <pre>
 * $str = "first=value&second[]=this+works&second[]=another";
 * parse_str($str);
 * echo $first; // prints "value" 
 * echo $second[0]; // prints "this works" 
 * echo $second[1]; // prints "another" 
 * </pre>
 */
function void parse_str(string str);
 
/**
 * output a string
 * <p>
 * Outputs arg.
 * 
 * @see echo()
 * @see printf()
 * @see flush()
 */
function print(string arg);
 
/**
 * output a formatted string
 * <p>
 * Produces output according to format, which is described in the
 * documentation for sprintf().
 * 
 * @see print()
 * @see sprintf()
 * @see flush()
 */
function int printf(string format, mixed [args]...);
 
/**
 * This function returns an 8-bit binary string corresponding to the decoded
 * quoted printable string. This function is similar to {@link imap_qprint()}, except
 * this one does not require the IMAP module to work.
 */
function string quoted_printable_decode(string str);
 
/**
 * quote meta characters
 * <p>
 * Returns a version of str with a backslash character (\) before every
 * character that is among these:
 * <pre>
 *    . \\ + * ? [ ^ ] ( $ )
 * </pre>
 *
 * @see addslashes()
 * @see htmlentities()
 * @see htmlspecialchars()
 * @see nl2br()
 * @see stripslashes()
 */
function string quotemeta(string str);
 
/**
 * decode URL-encoded strings
 * <p>
 * Returns a string in which the sequences with percent (%) signs followed by
 * two hex digits have been replaced with literal characters. For example, the
 * string
 * <pre>
 *    foo%20bar%40baz
 * </pre>
 * decodes into
 * <pre>
 *    foo bar@baz
 * </pre>
 *
 * @see rawurlencode()
 */
function string rawurldecode(string str);
 
/**
 * URL-encode according to RFC1738
 * <p>
 * Returns a string in which all non-alphanumeric characters except
 * <pre>
 *    -_.
 * </pre>
 * have been replaced with a percent (%) sign followed by two hex digits. This
 * is the encoding described in RFC1738 for protecting literal characters from
 * being interpreted as special URL delimiters, and for protecting URL's from
 * being mangled by transmission media with character conversions (like some
 * email systems). For example, if you want to include a password in an ftp
 * url:
 * <P>
 * <b>Example 1.</b> rawurlencode() example 1
 * <pre>
 *    echo '&lt;A HREF="ftp://user:', rawurlencode ('foo @+%/'),
 *         '@ftp.my.com/x.txt"&gt;';
 * </pre>
 * Or, if you pass information in a path info component of the url:
 * <p>
 * <b>Example 2.</b> rawurlencode() example 2
 * <pre>
 *    echo '&lt;A HREF="http://x.com/department_list_script/',
 *         rawurlencode ('sales and marketing/Miami'), '"&gt;';
 * </pre>
 *
 * @see rawurldecode()
 */
function string rawurlencode(string str);
 
/**
 * set locale information
 * <p>
 * category is a string specifying the category of the functions affected by
 * the locale setting:
 * <ul>
 * <li> LC_ALL for all of the below
 * <li> LC_COLLATE for string comparison - not currently implemented in PHP
 * <li> LC_CTYPE for character classification and conversion, for example
 * <li>*    * LC_MONETARY for {@link localeconv()} - not currently implemented in PHP
 * <li> LC_NUMERIC for decimal separator
 * <li> LC_TIME for date and time formatting with {@link strftime()}
 * </ul>
 * If locale is the empty string "", the locale names will be set from the
 * values of environment variables with the same names as the above
 * categories, or from "LANG".
 * <p>
 * If locale is zero or "0", the locale setting is not affected, only the
 * current setting is returned.
 * <p>
 * Setlocale returns the new current locale, or false if the locale
 * functionality is not implemented in the plattform, the specified locale
 * does not exist or the category name is invalid. An invalid category name
 * also causes a warning message.
 */
function string setlocale(string category, string locale);
 
/**
 * calculate the similarity between two strings
 * <p>
 * This calculates the similarity between two strings as described in Oliver
 * [1993]. Note that this implementation does not use a stack as in Oliver's
 * pseudo code, but recursive calls which may or may not speed up the whole
 * process. Note also that the complexity of this algorithm is O(N**3) where N
 * is the length of the longest string.
 * <p>
 * By passing a reference as third argument, similar_text() will calculate the
 * similarity in percent for you. It returns the number of matching chars in
 * both strings.
 */
function int similar_text(string first, string second, double [percent]);
 
/**
 * calculate the soundex key of a string
 * <p>
 * Calculates the soundex key of str.
 * <p>
 * Soundex keys have the property that words pronounced similarly produce the
 * same soundex key, and can thus be used to simplify searches in databases
 * where you know the pronunciation but not the spelling. This soundex
 * function returns a string 4 characters long, starting with a letter.
 * <p>
 * This particular soundex function is one described by Donald Knuth in "The
 * Art Of Computer Programming, vol. 3: Sorting And Searching", Addison-Wesley
 * (1973), pp. 391-392.
 * <p>
 * <b>Example 1.</b> Soundex Examples
 * <pre>
 *    soundex("Euler") == soundex("Ellery") == 'E460';
 *    soundex("Gauss") == soundex("Ghosh") == 'G200';
 *    soundex("Knuth") == soundex("Kant") == 'H416';
 *    soundex("Lloyd") == soundex("Ladd") == 'L300';
 *    soundex("Lukasiewicz") == soundex("Lissajous") == 'L222';
 * </pre>
 */
function string soundex(string str);
 
/**
 * return a formatted string
 * <p>
 * Returns a string produced according to the formatting string format.
 * <p>
 * The format string is composed by zero or more directives: ordinary
 * characters (excluding %) that are copied directly to the result, and
 * conversion specifications, each of which results in fetching its own
 * parameter. This applies to both {@link sprintf()} and {@link printf()}
 * <p>
 * Each conversion specification consists of these elements, in order:
 * <ol>
 * <li> An optional padding specifier that says what character will be used
 *      for padding the results to the right string size. This may be a space
 *      character or a 0 (zero character). The default is to pad with spaces.
 *      An alternate padding character can be specified by prefixing it with a
 *      single quote ('). See the examples below.
 * 
 * <li> An optional alignment specifier that says if the result should be
 *      left-justified or right-justified. The default is right-justified; a -
 *      character here will make it left-justified.
 * 
 * <li> An optional number, a width specifier that says how many characters
 *      (minimum) this conversion should result in.
 * 
 * <li> An optional precision specifier that says how many decimal digits
 *      should be displayed for floating-point numbers. This option has no
 *      effect for other types than double. (Another function useful for
 *      formatting numbers is {@link number_format()}.)
 * 
 * <li> A type specifier that says what type the argument data should be
 *      treated as. Possible types:
 * <ul>
 * <li> % - a literal percent character. No argument is required.
 * <li> b - the argument is treated as an integer, and presented as a binary
 *      number.
 * <li> c - the argument is treated as an integer, and presented as the
 *      character with that ASCII value.
 * <li> d - the argument is treated as an integer, and presented as a decimal
 *      number.
 * <li> f - the argument is treated as a double, and presented as a
 *      floating-point number.
 * <li> o - the argument is treated as an integer, and presented as an octal
 *      number.
 * <li> s - the argument is treated as and presented as a string.
 * <li> x - the argument is treated as an integer and presented as a
 *      hexadecimal number (with lowercase letters).
 * <li> X - the argument is treated as an integer and presented as a
 *      hexadecimal number (with uppercase letters).
 * </ul>
 * </ol>
 * <b>Example 1.</b> sprintf: zero-padded integers
 * <pre>
 *    $isodate = sprintf("%04d-%02d-%02d", $year, $month, $day);
 * </pre>
 * <b>Example 2.</b> sprintf: formatting currency
 * <pre>
 *    $money1 = 68.75;
 *    $money2 = 54.35;
 *    $money = $money1 + $money2;
 *    // echo $money will output "123.1";
 *    $formatted = sprintf ("%01.2f", $money);
 *    // echo $formatted will output "123.10"
 * </pre>
 *
 * @see printf()
 * @see number_format()
 */
function sprintf(string format, mixed [args]...);
 
/**
 * Find the first occurrence of a character.
 * <p>
 * This function is an alias for {@link strstr()}, and is identical in every way.
 */
function string strchr(string haystack, string needle);
 
/**
 * binary safe string comparison
 * <p>
 * Returns &lt; 0 if str1 is less than str2; &gt; 0 if str1 is greater than str2,
 * and 0 if they are equal.
 * <p>
 * Note that this comparison is case sensitive.
 * 
 * @see ereg()
 * @see substr()
 * @see strstr()
 */
function int strcmp(string str1, string str2);
 
/**
 * find length of initial segment not matching mask
 * <p>
 * Returns the length of the initial segment of str1 which does not contain
 * any of the characters in str2.
 * 
 * @see strspn()
 */
function int strcspn(string str1, string str2);
 
/**
 * Strip HTML and PHP tags from a string
 * <p>
 * This function tries to strip all HTML and PHP tags from the given string.
 * It errors on the side of caution in case of incomplete or bogus tags. It
 * uses the same tag stripping state machine as the {@link fgetss()} function.
 */
function string strip_tags(string str);
 
/**
 * un-quote string quoted with addslashes
 * <p>
 * Returns a string with backslashes stripped off. (\' becomes ' and so on.)
 * Double backslashes are made into a single backslash.
 * 
 * @see addslashes()
 */
function string stripslashes(string str);
 
/**
 * get string length
 * <p>
 * Returns the length of string.
 */
function int strlen(string str);
 
/**
 * Find position of last occurrence of a char in a string.
 * <p>
 * Returns the numeric position of the last occurrence of needle in the
 * haystack string. Note that the needle in this case can only be a single
 * character. If a string is passed as the needle, then only the first
 * character of that string will be used.
 * <p>
 * If needle is not found, returns false.
 * <p>
 * If needle is not a string, it is converted to an integer and applied as the
 * ordinal value of a character.
 * 
 * @see strpos()
 * @see strrchr()
 * @see substr()
 * @see strstr()
 */
function int strrpos(string haystack, char needle);
 
/**
 * Find position of first occurrence of a string.
 * <p>
 * Returns the numeric position of the first occurrence of needle in the
 * haystack string. Unlike the {@link strrpos()}, this function can take a full string
 * as the needle parameter and the entire string will be used.
 * <p>
 * If needle is not found, returns false.
 * <p>
 * If needle is not a string, it is converted to an integer and applied as the
 * ordinal value of a character.
 * <p>
 * The optional offset parameter allows you to specify which character in
 * haystack to start searching. The position returned is still relative to the
 * the beginning of haystack.
 * 
 * @see strrpos()
 * @see strrchr()
 * @see substr()
 * @see strstr()
 */
function int strpos(string haystack, string needle, int [offset]);
 
/**
 * Find the last occurrence of a character in a string.
 * <p>
 * This function returns the portion of haystack which starts at the last
 * occurrence of needle and goes until the end of haystack.
 * <p>
 * Returns false if needle is not found.
 * <p>
 * If needle contains more than one character, the first is used.
 * <p>
 * If needle is not a string, it is converted to an integer and applied as the
 * ordinal value of a character.
 * <P>
 * <b>Example 1.</b> strrchr() example
 * <pre>
 *    // get last directory in $PATH
 *    $dir = substr( strrchr( $PATH, ":" ), 1 );
 *    // get everything after last newline
 *    $text = "Line 1\nLine 2\nLine 3";
 *    $last = substr( strrchr( $text, 10 ), 1 );
 * </pre>
 *
 * @see substr()
 * @see strstr()
 */
function string strrchr(string haystack, string needle);
 
/**
 * Reverse a string.
 * <p>
 * Returns string, reversed.
 */
function string strrev(string string);
 
/**
 * find length of initial segment matching mask
 * <p>
 * Returns the length of the initial segment of str1 which consists entirely
 * of characters in str2.
 * 
 * @see strcspn()
 */
function int strspn(string str1, string str2);
 
/**
 * Find first occurrence of a string.
 * <p>
 * Returns all of haystack from the first occurrence of needle to the end.
 * <p>
 * If needle is not found, returns false.
 * <p>
 * If needle is not a string, it is converted to an integer and applied as the
 * ordinal value of a character.
 * 
 * @see strrchr()
 * @see substr()
 * @see ereg()
 */
function string strstr(string haystack, string needle);
 
/**
 * tokenize string
 * <p>
 * strtok() is used to tokenize a string. That is, if you have a string like
 * "This is an example string" you could tokenize this string into its
 * individual words by using the space character as the token.
 * <b>Example 1.</b> {@link strtok()} example
 * <pre>
 *     $string = "This is an example string";
 *     $tok = strtok($string," ");
 *     while($tok) {
 *         echo "Word=$tok&lt;br&gt;";
 *         $tok = strtok(" ");
 *     }
 * </pre>
 * Note that only the first call to strtok uses the string argument. Every
 * subsequent call to strtok only needs the token to use, as it keeps track of
 * where it is in the current string. To start over, or to tokenize a new
 * string you simply call strtok with the string argument again to initialize
 * it. Note that you may put multiple tokens in the token parameter. The
 * string will be tokenized when any one of the characters in the argument are
 * found.
 * <p>
 * Also be careful that your tokens may be equal to "0". This evaluates to
 * false in conditional expressions.
 * 
 * @see split()
 * @see explode()
 */
function string strtok(string arg1, string arg2);
 
/**
 * Make a string lowercase.
 * <p>
 * Returns string with all alphabetic characters converted to lowercase.
 * <p>
 * Note that 'alphabetic' is determined by the current locale. This means that
 * in i.e. the default "C" locale, characters such as umlaut-A (�) will not be
 * converted.
 * 
 * @see strtoupper()
 * @see ucfirst()
 */
function string strtolower(string str);
 
/**
 * Make a string uppercase.
 * <p>
 * Returns string with all alphabetic characters converted to uppercase.
 * <p>
 * Note that 'alphabetic' is determined by the current locale. For instance,
 * in the default "C" locale characters such as umlaut-a (�) will not be
 * converted.
 * 
 * @see strtolower()
 * @see ucfirst()
 */
function string strtoupper(string string);
 
/**
 * Replace all occurrences of needle in haystack with str
 * <p>
 * This function replaces all occurences of needle in haystack with the given
 * str. If you don't need fancy replacing rules, you should always use this
 * function instead of {@link ereg_replace()}.
 * <p>
 * <b>Example 1.</b> str_replace() example
 * <pre>
 *    $bodytag = str_replace("%body%", "black", "&lt;body text=%body%&gt;");
 * </pre>
 * This function is binary safe.
 * 
 * @see ereg_replace()
 */
function string str_replace(string needle, string str, string haystack);
 
/**
 * Translate certain characters.
 * <p>
 * This function operates on str, translating all occurrences of each
 * character in from to the corresponding character in to and returning the
 * result.
 * <p>
 * If from and to are different lengths, the extra characters in the longer of
 * the two are ignored.
 * <b>Example 1.</b> strtr() example
 * <pre>
 *    $addr = strtr($addr, "���", "aao");
 * </pre>
 *
 * @see ereg_replace()
 */
function string strtr(string str, string from, string to);
 
/**
 * Return part of a string.
 * <p>
 * Substr returns the portion of string specified by the start and length
 * parameters.
 * <p>
 * If start is positive, the returned string will start at the start'th
 * character of string. Examples:
 * <pre>
 *    $rest = substr("abcdef", 1); // returns "bcdef"
 *    $rest = substr("abcdef", 1, 3); // returns "bcd"
 * </pre>
 * If start is negative, the returned string will start at the start'th
 * character from the end of string. Examples:
 * <pre>
 *    $rest = substr("abcdef", -1); // returns "f"
 *    $rest = substr("abcdef", -2); // returns "ef"
 *    $rest = substr("abcdef", -3, 1); // returns "d"
 * </pre>
 * If length is given and is positive, the string returned will end length
 * characters from start. If this would result in a string with negative
 * length (because the start is past the end of the string), then the returned
 * string will contain the single character at start.
 * <p>
 * If length is given and is negative, the string returned will end length
 * characters from the end of string. If this would result in a string with
 * negative length, then the returned string will contain the single character
 * at start. Examples:
 * <pre>
 *    $rest = substr("abcdef", 1, -1); // returns "bcde"
 * </pre>
 *
 * @see strrchr()
 * @see ereg()
 */
function string substr(string string, int start, int [length]);
 
/**
 * Strip whitespace from the beginning and end of a string.
 * <p>
 * This function strips whitespace from the start and the end of a string and
 * returns the stripped string.
 * 
 * @see chop()
 * @see ltrim()
 */
function string trim(string str);
 
/**
 * Make a string's first character uppercase
 * <p>
 * Capitalizes the first character of str if that character is alphabetic.
 * <p>
 * Note that 'alphabetic' is determined by the current locale. For instance,
 * in the default "C" locale characters such as umlaut-a (�) will not be
 * converted.
 * 
 * @see strtoupper()
 * @see strtolower()
 */
function string ucfirst(string str);
 
/**
 * Uppercase the first character of each word in a string
 * <p>
 * Capitalizes the first character of each word in str if that character is
 * alphabetic.
 * 
 * @see strtoupper()
 * @see strtolower()
 * @see ucfirst()
 */
function string ucwords(string str);


///////////////////////////////////////////////////////////////////////////
// URL functions
// 
 
/**
 * parse a URL and return its components
 * <p>
 * This function returns an associative array returning any of the various
 * components of the URL that are present. This includes the "scheme", "host",
 * "port", "user", "pass", "path", "query", and "fragment".
 */
function array parse_url(string url);
 
/**
 * decodes URL-encoded string
 * <p>
 * Decodes any %## encoding in the given string. The decoded string is
 * returned.
 * <b>Example 1.</b> urldecode() example
 * <pre>
 *    $a = split ('&', $querystring);
 *    $i = 0;
 *    while ($i &lt; count ($a)) {
 *      $b = split ('=', $a [$i]);
 *      echo 'Value for parameter ', htmlspecialchars (urldecode ($b [0])),
 *           ' is ', htmlspecialchars (urldecode ($b [1])), "&lt;BR&gt;";
 *      $i++;
 *    }
 * </pre>
 *
 * @see urlencode()
 */
function string urldecode(string str);
 
/**
 * URL-encodes string
 * <p>
 * Returns a string in which all non-alphanumeric characters except -_. have
 * been replaced with a percent (%) sign followed by two hex digits and spaces
 * encoded as plus (+) signs. It is encoded the same way that the posted data
 * from a WWW form is encoded, that is the same way as in
 * application/x-www-form-urlencoded media type. This differs from the RFC1738
 * encoding (see {@link rawurlencode()} ) in that for historical reasons, spaces are
 * encoded as plus (+ ) signs. This function is convenient when encoding a
 * string to be used in a query part of an URL, as a convinient way to pass
 * variables to the next page:
 * <b>Example 1.</b> urlencode() example
 * <pre>
 *    echo '&lt;A HREF="mycgi?foo=', urlencode ($userinput), '"&gt;';
 * </pre>
 *
 * @see urldecode()
 */
function string urlencode(string str);
 
/**
 * encodes data with MIME base64
 * <p>
 * base64_encode() returns data encoded with base64. This encoding is designed
 * to make binary data survive transport through transport layers that are not
 * 8-bit clean, such as mail bodies.
 * <p>
 * Base64-encoded data takes about 33% more space than the original data.
 * See RFC-2045 section 6.8.
 * 
 * @see base64_decode()
 * @see chunk_split()
 */
function string base64_encode(string data);
 
/**
 * decodes data encoded with MIME base64
 * <p>
 * base64_decode() decodes encoded_data and returns the original data. The
 * returned data may be binary.
 * See RFC-2045 section 6.8.
 * 
 * @see base64_encode()
 */
function string base64_decode(string encoded_data);


///////////////////////////////////////////////////////////////////////////
// Variable functions
// 
 
/**
 * Get the type of a variable.
 * <p>
 * Returns the type of the PHP variable var.
 * <p>
 * Possibles values for the returned string are:
 * <ul>
 * <li> "integer"
 * <li> "double"
 * <li> "string"
 * <li> "array"
 * <li> "object"
 * <li> "unknown type"
 * </ul>
 *
 * @see settype()
 */
function string gettype(mixed var);
 
/**
 * Get integer value of a variable.
 * <p>
 * Returns the integer value of var, using the specified base for the
 * conversion (the default is base 10).
 * <p>
 * var may be any scalar type. You cannot use intval() on arrays or objects.
 * 
 * @see doubleval()
 * @see strval()
 * @see settype()
 */
function int intval(mixed var, int [base]);
 
/**
 * Get double value of a variable.
 * <p>
 * Returns the double (floating point) value of var.
 * <p>
 * var may be any scalar type. You cannot use doubleval() on arrays or
 * objects.
 * 
 * @see intval()
 * @see strval()
 * @see settype()
 */
function double doubleval(mixed var);
 
/**
 * determine whether a variable is set
 * <p>
 * Returns false if var is set and has a non-empty or non-zero value; true
 * otherwise.
 * 
 * @see isset()
 * @see unset()
 */
function int empty(mixed var);
 
/**
 * Finds whether a variable is an array.
 * <p>
 * Returns true if var is an array, false otherwise.
 * 
 * @see is_double()
 * @see is_float()
 * @see is_int()
 * @see is_integer()
 * @see is_real()
 * @see is_string()
 * @see is_long()
 * @see is_object()
 */
function int is_array(mixed var);
 
/**
 * Finds whether a variable is a double.
 * <p>
 * Returns true if var is a double, false otherwise.
 * 
 * @see is_array()
 * @see is_float()
 * @see is_int()
 * @see is_integer()
 * @see is_real()
 * @see is_string()
 * @see is_long()
 * @see is_object()
 */
function int is_double(mixed var);
 
/**
 * Finds whether a variable is a float.
 * <p>
 * This function is an alias for is_double().
 * 
 * @see is_double()
 * @see is_real()
 * @see is_int()
 * @see is_integer()
 * @see is_string()
 * @see is_object()
 * @see is_array()
 * @see is_long()
 */
function int is_float(mixed var);
 
/**
 * Find whether a variable is an integer.
 * <p>
 * This function is an alias for is_long().
 * 
 * @see is_double()
 * @see is_float()
 * @see is_integer()
 * @see is_string()
 * @see is_real()
 * @see is_object()
 * @see is_array()
 * @see is_long()
 */
function int is_int(mixed var);
 
/**
 * Find whether a variable is an integer.
 * <p>
 * This function is an alias for is_long().
 * 
 * @see is_double()
 * @see is_float()
 * @see is_int()
 * @see is_string()
 * @see is_real()
 * @see is_object()
 * @see is_array()
 * @see is_long()
 */
function int is_integer(mixed var);
 
/**
 * Finds whether a variable is an integer.
 * <p>
 * Returns true if var is an integer (long), false otherwise.
 * 
 * @see is_double()
 * @see is_float()
 * @see is_int()
 * @see is_real()
 * @see is_string()
 * @see is_object()
 * @see is_array()
 * @see is_integer()
 */
function int is_long(mixed var);
 
/**
 * Finds whether a variable is an object.
 * <p>
 * Returns true if var is an object, false otherwise.
 * 
 * @see is_long()
 * @see is_int()
 * @see is_integer()
 * @see is_float()
 * @see is_double()
 * @see is_real()
 * @see is_string()
 * @see is_array()
 */
function int is_object(mixed var);
 
/**
 * Finds whether a variable is a real.
 * <p>
 * This function is an alias for is_double().
 * 
 * @see is_long()
 * @see is_int()
 * @see is_integer()
 * @see is_float()
 * @see is_double()
 * @see is_object()
 * @see is_string()
 * @see is_array()
 */
function int is_real(mixed var);
 
/**
 * Finds whether a variable is a string.
 * <p>
 * Returns true if var is a string, false otherwise.
 * 
 * @see is_long()
 * @see is_int()
 * @see is_integer()
 * @see is_float()
 * @see is_double()
 * @see is_real()
 * @see is_object()
 * @see is_array()
 */
function int is_string(mixed var);
 
/**
 * determine whether a variable is set
 * <p>
 * Returns true if var exists; false otherwise.
 * <p>
 * If a variable has been unset with {@link unset()}, it will no longer be isset().
 * <pre>
 *    $a = "test";
 *    echo isset($a); // true
 *    unset($a);
 *    echo isset($a); // false
 * </pre>
 * 
 * @see empty()
 * @see unset()
 */
function int isset(mixed var);
 
/**
 * Set the type of a variable.
 * <p>
 * Set the type of variable var to type.
 * <p>
 * Possibles values of type are:
 * <ul>
 * <li> "integer"
 * <li> "double"
 * <li> "string"
 * <li> "array"
 * <li> "object"
 * </ul>
 * @return true if successful; otherwise returns false.
 * 
 * @see gettype()
 */
function int settype(string var, string type);
 
/**
 * Get string value of a variable.
 * <p>
 * Returns the string value of var.
 * <p>
 * var may be any scalar type. You cannot use strval() on arrays or objects.
 * 
 * @see doubleval()
 * @see intval()
 * @see settype()
 */
function string strval(mixed var);
 
/**
 * Unset a given variable
 * <p>
 * unset() destroys the specified variable and returns true.
 * <p>
 * <b>Example 1.</b> unset() example
 * <pre>
 *    unset( $foo );
 *    unset( $bar['quux'] );
 * </pre>
 *
 * @see isset()
 * @see empty()
 */
function int unset(mixed var);


///////////////////////////////////////////////////////////////////////////
// Vmailmgr functions
// 
// These functions require qmail and the vmailmgr package by Bruce Guenter.
// 
// For all functions, the following two variables are defined as: string
// vdomain the domain name of your virtual domain (vdomain.com) string basepwd
// the password of the 'real' user that holds the virtual users
// 
// Only up to 8 characters are recognized in passwords for virtual users
// 
// Return status for all functions matches response in response.h
// 
// O ok
// 1 bad
// 2 error
// 3 error connecting
// 
// Known problems: vm_deluser() does not delete the user directory as it
// should. vm_addalias() currently does not work correctly.
// 
// <?php
// dl("php3_vmailmgr.so"); //load the shared library
// $vdomain="vdomain.com";
// $basepwd="password";
// ?>
//  

/**
 * Add a new virtual user with a password
 * <p>
 * Add a new virtual user with a password. newusername is the email login name
 * and newuserpassword the password for this user.
 */
function int vm_adduser(string vdomain, string basepwd, string newusername, string newuserpassword);
 
/**
 * Add an alias to a virtual user
 * <p>
 * Add an alias to a virtual user. username is the email login name and alias
 * is an alias for this vuser.
 */
function int vm_addalias(string vdomain, string basepwd, string username, string alias);
 
/**
 * Changes a virtual users password
 * <p>
 * Changes a virtual users password. username is the email login name,
 * password the old password for the vuser, and newpassword the new password.
 */
function int vm_passwd(string vdomain, string username, string password, string newpassword);
 
/**
 * Removes an alias
 * <p>
 * Removes an alias.
 */
function int vm_delalias(string vdomain, string basepwd, string alias);
 
/**
 * Removes a virtual user.
 */
function int vm_deluser(string vdomain, string username);


///////////////////////////////////////////////////////////////////////////
// WDDX functions
//
// These functions are intended for work with WDDX.
// 
// Note that all the functions that serialize variables use the first element
// of an array to determine whether the array is to be serialized into an
// array or structure. If the first element has string key, then it is
// serialized into a structure, otherwise, into an array.
// Example 1. Serializing a single value
// 
// <?php
// print wddx_serialize_value("PHP to WDDX packet example", "PHP packet");
// ?>
// 
// 
// This example will produce:
// 
// <wddxPacket version='0.9'><header comment='PHP packet'/><data>
// <string>PHP to WDDX packet example</string></data></wddxPacket>
// 
// 
// Example 2. Using incremental packets
// 
// <?php
// $pi = 3.1415926;
// $packet_id = wddx_packet_start("PHP");
// wddx_add_vars($packet_id, "pi");
// 
// /* Suppose $cities came from database */
// $cities = array("Austin", "Novato", "Seattle");
// wddx_add_vars($packet_id, "cities");
// 
// $packet = wddx_packet_end($packet_id);
// print $packet;
// ?>
// 
// 
// This example will produce:
// 
// <wddxPacket version='0.9'><header comment='PHP'/><data><struct>
// <var name='pi'><number>3.1415926</number></var><var name='cities'>
// <array length='3'><string>Austin</string><string>Novato</string>
// <string>Seattle</string></array></var></struct></data></wddxPacket>
// 

/**
 * Serialize a single value into a WDDX packet
 * <p>
 * wddx_serialize_value() is used to create a WDDX packet from a single given
 * value. It takes the value contained in var, and an optional comment string
 * that appears in the packet header, and returns the WDDX packet.
 */
function string wddx_serialize_value(mixed var, string [comment]);
 
/**
 * Serialize variables into a WDDX packet
 * <p>
 * wddx_serialize_vars() is used to create a WDDX packet with a structure that
 * contains the serialized representation of the passed variables.
 * <p>
 * wddx_serialize_vars() takes a variable number of arguments, each of which
 * can be either a string naming a variable or an array containing strings
 * naming the variables or another array, etc.
 * <p>
 * <b>Example 1.</b> wddx_serialize_vars example
 * <pre>
 *    &lt;?php
 *    $a = 1;
 *    $b = 5.5;
 *    $c = array("blue", "orange", "violet");
 *    $d = "colors";
 *    <p>
 *    $clvars = array("c", "d");
 *    print wddx_serialize_vars("a", "b", $clvars);
 *    ?&gt;
 *    &lt;PRE&gt;
 *    The above example will produce:
 *    &lt;PRE&gt;
 *    &lt;wddxPacket version='0.9'&gt;&lt;header/&gt;&lt;data&gt;&lt;struct&gt;&lt;var name='a'&gt;&lt;number&gt;1&lt;/number&gt;&lt;/var&gt;
 *    &lt;var name='b'&gt;&lt;number&gt;5.5&lt;/number&gt;&lt;/var&gt;&lt;var name='c'&gt;&lt;array length='3'&gt;
 *    &lt;string&gt;blue&lt;/string&gt;&lt;string&gt;orange&lt;/string&gt;&lt;string&gt;violet&lt;/string&gt;&lt;/array&gt;&lt;/var&gt;
 *    &lt;var name='d'&gt;&lt;string&gt;colors&lt;/string&gt;&lt;/var&gt;&lt;/struct&gt;&lt;/data&gt;&lt;/wddxPacket&gt;
 * </pre>
 */
function string wddx_serialize_vars(string var_name | array var_names [, ... ] );
 
/**
 * Starts a new WDDX packet with structure inside it
 * <p>
 * Use wddx_packet_start() to start a new WDDX packet for incremental addition
 * of variables. It takes an optional comment string and returns a packet ID
 * for use in later functions. It automatically creates a structure definition
 * inside the packet to contain the variables.
 */
function int wddx_packet_start(string [comment]);
 
/**
 * Ends a WDDX packet with the specified ID
 * <p>
 * wddx_packet_end() ends the WDDX packet specified by the packet_id and
 * returns the string with the packet.
 */
function int wddx_packet_end(int packet_id);
 
/**
 * Ends a WDDX packet with the specified ID
 * <p>
 * wddx_add_vars() is used to serialize passed variables and add the result to
 * the packet specified by the packet_id. The variables to be serialized are
 * specified in exactly the same way as wddx_serialize_vars().
 */
function wddx_add_vars(int packet_id, ...);
 
/**
 * Deserializes a WDDX packet
 * <p>
 * wddx_deserialized() takes a packet string and deserializes it. It returns
 * the result which can be string, number, or array. Note that structures are
 * deserialized into associative arrays.
 */
function mixed wddx_deserialize(string packet);


///////////////////////////////////////////////////////////////////////////
// Compression functions
// 
// This module uses the functions of zlib
// (http://www.cdrom.com/pub/infozip/zlib/) by Jean-loup Gailly and Mark Adler
// to transparently read and write gzip (.gz) compressed files.
// 
 
/**
 * close an open gz-file pointer
 * <p>
 * The gz-file pointed to by zp is closed.
 * <p>
 * Returns true on success and false on failure.
 * <p>
 * The gz-file pointer must be valid, and must point to a file successfully
 * opened by {@link gzopen()}.
 */
function int gzclose(int zp);
 
/**
 * test for end-of-file on a gz-file pointer
 * <p>
 * Returns true if the gz-file pointer is at EOF or an error occurs; otherwise
 * returns false.
 * <p>
 * The gz-file pointer must be valid, and must point to a file successfully
 * opened by {@link gzopen()}.
 */
function int gzeof(int zp);
 
/**
 * read entire gz-file into an array
 * <p>
 * Identical to {@link readgzfile()}, except that gzfile() returns the file in an
 * array.
 * 
 * @see readgzfile()
 * @see gzopen()
 */
function array gzfile(string filename);
 
/**
 * get character from gz-file pointer
 * <p>
 * Returns a string containing a single (uncompressed) character read from the
 * file pointed to by zp. Returns FALSE on EOF (as does {@link gzeof()}).
 * <p>
 * The gz-file pointer must be valid, and must point to a file successfully
 * opened by {@link gzopen()}.
 * 
 * @see gzopen()
 * @see gzgets()
 */
function string gzgetc(int zp);
 
/**
 * get line from file pointer
 * <p>
 * Returns a (uncompressed) string of up to length - 1 bytes read from the
 * file pointed to by fp. Reading ends when length - 1 bytes have been read,
 * on a newline, or on EOF (whichever comes first).
 * <p>
 * If an error occurs, returns false.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by gzopen().
 * 
 * @see gzopen()
 * @see gzgetc()
 */
function string gzgets(int zp, int length);
 
/**
 * get line from gz-file pointer and strip HTML tags
 * <p>
 * Identical to {@link gzgets()}, except that gzgetss attempts to strip any HTML and
 * PHP tags from the text it reads.
 * 
 * @see gzgets()
 * @see gzopen()
 */
function string gzgetss(int zp, int length);
 
/**
 * open gz-file
 * <p>
 * Opens a gzip (.gz) file for reading or writing. The mode parameter is as in
 * {@link fopen()} ("rb" or "wb") but can also include a compression level ("wb9") or
 * a strategy: 'f' for filtered data as in "wb6f", 'h' for Huffman only
 * compression as in "wb1h". (See the description of deflateInit2 in zlib.h
 * for more information about the strategy parameter.)
 * <p>
 * Gzopen can be used to read a file which is not in gzip format; in this case
 * {@link gzread()} will directly read from the file without decompression.
 * <p>
 * Gzopen returns a file pointer to the file opened, after that, everything
 * you read from this file descriptor will be transparently decompressed and
 * what you write gets compressed.
 * <p>
 * If the open fails, the function returns false.
 * <p>
 * <b>Example 1.</b> gzopen() example
 * <pre>
 *    $fp = gzopen("/tmp/file.gz", "r");
 * </pre>
 *
 * @see gzclose()
 */
function int gzopen(string filename, string mode);
 
/**
 * output all remaining data on a gz-file pointer
 * <p>
 * Reads to EOF on the given gz-file pointer and writes the (uncompressed)
 * results to standard output.
 * <p>
 * If an error occurs, returns false.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link gzopen()}.
 * <p>
 * The gz-file is closed when gzpassthru() is done reading it (leaving zp
 * useless).
 */
function int gzpassthru(int zp);
 
/**
 * write to a gz-file pointer
 * <p>
 * gzputs() is an alias to {@link gzwrite()}, and is identical in every way.
 */
function int gzputs(int zp, string str, int [length]);
 
/**
 * Binary-safe gz-file read
 * <p>
 * gzread() reads up to length bytes from the gz-file pointer referenced by
 * zp. Reading stops when length (uncompressed) bytes have been read or EOF is
 * reached, whichever comes first.
 * <pre>
 *    // get contents of a gz-file into a string
 *    $filename = "/usr/local/something.txt.gz";
 *    $zd = gzopen( $filename, "r" );
 *    $contents = gzread( $zd, 10000 );
 *    gzclose( $zd );
 * </pre>
 * 
 * @see gzwrite()
 * @see gzopen()
 * @see gzgets()
 * @see gzgetss()
 * @see gzfile()
 * @see gzpassthru()
 */
function string gzread(int zp, int length);
 
/**
 * rewind the position of a gz-file pointer
 * <p>
 * Sets the file position indicator for zp to the beginning of the file
 * stream.
 * <p>
 * If an error occurs, returns 0.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link gzopen()}.
 * 
 * @see gzseek()
 * @see gztell()
 */
function int gzrewind(int zp);
 
/**
 * seek on a gz-file pointer
 * <p>
 * Sets the file position indicator for the file referenced by zp to offset
 * bytes into the file stream. Equivalent to calling (in C) gzseek( zp,
 * offset, SEEK_SET ).
 * <p>
 * If the file is opened for reading, this function is emulated but can be
 * extremely slow. If the file is opened for writing, only forward seeks are
 * supported; gzseek then compresses a sequence of zeroes up to the new
 * starting position.
 * <p>
 * Upon success, returns 0; otherwise, returns -1. Note that seeking past EOF
 * is not considered an error.
 * 
 * @see gztell()
 * @see gzrewind()
 */
function int gzseek(int zp, int offset);
 
/**
 * tell gz-file pointer read/write position
 * <p>
 * Returns the position of the file pointer referenced by zp; i.e., its offset
 * into the file stream.
 * <p>
 * If an error occurs, returns false.
 * <p>
 * The file pointer must be valid, and must point to a file successfully
 * opened by {@link gzopen()}.
 * 
 * @see gzopen()
 * @see gzseek()
 * @see gzrewind()
 */
function int gztell(int zp);
 
/**
 * output a gz-file
 * <p>
 * Reads a file, decompresses it and writes it to standard output.
 * <p>
 * Readgzfile() can be used to read a file which is not in gzip format; in
 * this case readgzfile() will directly read from the file without
 * decompression.
 * <p>
 * Returns the number of (uncompressed) bytes read from the file. If an error
 * occurs, false is returned and unless the function was called as
 * @readgzfile, an error message is printed.
 * <p>
 * The file filename will be opened from the filesystem and its contents
 * written to standard output.
 * 
 * @see gzpassthru()
 * @see gzfile()
 * @see gzopen()
 */
function int readgzfile(string filename);
 
/**
 * Binary-safe gz-file write
 * <p>
 * gzwrite() writes the contents of string to the gz-file stream pointed to by
 * zp. If the length argument is given, writing will stop after length
 * (uncompressed) bytes have been written or the end of string is reached,
 * whichever comes first.
 * <p>
 * Note that if the length argument is given, then the magic_quotes_runtime
 * configuration option will be ignored and no slashes will be stripped from
 * string.
 * 
 * @see gzread()
 * @see gzopen()
 * @see gzputs()
 */
function int gzwrite(int zp, string string, int [length]);


///////////////////////////////////////////////////////////////////////////
// XML parser functions
// 
// XML (eXtensible Markup Language) is a data format for structured document
// interchange on the Web. It is a standard defined by The World Wide Web
// consortium (W3C). Information about XML and related technologies can be
// found at http://www.w3.org/XML/.
// 
// ------------------------------------------------------------------------
// Installation
// 
// This extension uses expat, which can be found at
// http://www.jclark.com/xml/. The Makefile that comes with expat does not
// build a library by default, you can use this make rule for that:
// 
// libexpat.a: $(OBJS)
//         ar -rc $@ $(OBJS)
//         ranlib $@
// 
// A source RPM package of expat can be found at
// http://www.guardian.no/~ssb/phpxml.html.
// 
// Note that if you are using Apache-1.3.7 or later, you already have the
// required expat library. Simply configure PHP using --with-xml (without any
// additional path) and it will automatically use the expat library built into
// Apache.
// 
// On UNIX, run configure with the --with-xml option. The expat library should
// be installed somewhere your compiler can find it. You may need to set
// CPPFLAGS and LDFLAGS in your environment before running configure if you
// have installed expat somewhere exotic.
// 
// Build PHP. Tada! That should be it.
// 
// ------------------------------------------------------------------------
// About This Extension
// 
// This PHP extension implements support for James Clark's expat in PHP. This
// toolkit lets you parse, but not validate, XML documents. It supports three
// source character encodings also provided by PHP: US-ASCII, ISO-8859-1 and
// UTF-8. UTF-16 is not supported.
// 
// This extension lets you create XML parsers and then define handlers for
// different XML events. Each XML parser also has a few parameters you can
// adjust.
// 
// ------------------------------------------------------------------------
// Case Folding
// 
// The element handler functions may get their element names case-folded.
// Case-folding is defined by the XML standard as "a process applied to a
// sequence of characters, in which those identified as non-uppercase are
// replaced by their uppercase equivalents". In other words, when it comes to
// XML, case-folding simply means uppercasing.
// 
// By default, all the element names that are passed to the handler functions
// are case-folded. This behaviour can be queried and controlled per XML
// parser with the xml_parser_get_option() and xml_parser_set_option()
// functions, respectively.
// 
// ------------------------------------------------------------------------
// Error Codes
// 
// The following constants are defined for XML error codes (as returned by
// xml_parse()):
//
// ------------------------------------------------------------------------
// Character Encoding
// 
// PHP's XML extension supports the Unicode character set through different
// character encodings. There are two types of character encodings, source
// encoding and target encoding. PHP's internal representation of the document
// is always encoded with UTF-8.
// 
// Source encoding is done when an XML document is parsed. Upon creating an
// XML parser, a source encoding can be specified (this encoding can not be
// changed later in the XML parser's lifetime). The supported source encodings
// are ISO-8859-1, US-ASCII and UTF-8. The former two are single-byte
// encodings, which means that each character is represented by a single byte.
// UTF-8 can encode characters composed by a variable number of bits (up to
// 21) in one to four bytes. The default source encoding used by PHP is
// ISO-8859-1.
// 
// Target encoding is done when PHP passes data to XML handler functions. When
// an XML parser is created, the target encoding is set to the same as the
// source encoding, but this may be changed at any point. The target encoding
// will affect character data as well as tag names and processing instruction
// targets.
// 
// If the XML parser encounters characters outside the range that its source
// encoding is capable of representing, it will return an error.
// 
// If PHP encounters characters in the parsed XML document that can not be
// represented in the chosen target encoding, the problem characters will be
// "demoted". Currently, this means that such characters are replaced by a
// question mark.
// 
// ------------------------------------------------------------------------
// Some Examples
// 
// Here are some example PHP scripts parsing XML documents.
// 
// ------------------------------------------------------------------------
// XML Element Structure Example
// 
// This first example displays the stucture of the start elements in a
// document with indentation.
// Example 1. Show XML Element Structure
// 
// $file = "data.xml";
// $depth = array();
// 
// function startElement($parser, $name, $attrs)
// {
//     global $depth;
//     for ($i = 0; $i < $depth[$parser]; $i++) {
//         print "  ";
//     }
//     print "$name\n";
//     $depth[$parser]++;
// }
// 
// function endElement($parser, $name)
// {
//     global $depth;
//     $depth[$parser]--;
// }
// 
// $xml_parser = xml_parser_create();
// xml_set_element_handler($xml_parser, "startElement", "endElement");
// if (!($fp = fopen($file, "r"))) {
//     die("could not open XML input");
// }
// while ($data = fread($fp, 4096)) {
//     if (!xml_parse($xml_parser, $data, feof($fp))) {
//         die(sprintf("XML error: %s at line %d",
//                     xml_error_string(xml_get_error_code($xml_parser)),
//                     xml_get_current_line_number($xml_parser)));
//     }
// }
// xml_parser_free($xml_parser);
// 
// ------------------------------------------------------------------------
// XML Tag Mapping Example
// 
// Example 2. Map XML to HTML
// 
// This example maps tags in an XML document directly to HTML tags. Elements
// not found in the "map array" are ignored. Of course, this example will only
// work with a specific XML document type.
// 
// $file = "data.xml";
// $map_array = array(
//     "BOLD"     => "B",
//     "EMPHASIS" => "I",
//     "LITERAL"  => "TT"
// );
// 
// function startElement($parser, $name, $attrs)
// {
//     global $map_array;
//     if ($htmltag = $map_array[$name]) {
//         print "<$htmltag>";
//     }
// }
// 
// function endElement($parser, $name)
// {
//     global $map_array;
//     if ($htmltag = $map_array[$name]) {
//         print "</$htmltag>";
//     }
// }
// 
// function characterData($parser, $data)
// {
//     print $data;
// }
// 
// $xml_parser = xml_parser_create();
// // use case-folding so we are sure to find the tag in $map_array
// xml_parser_set_option($xml_parser, XML_OPTION_CASE_FOLDING, true);
// xml_set_element_handler($xml_parser, "startElement", "endElement");
// xml_set_character_data_handler($xml_parser, "characterData");
// if (!($fp = fopen($file, "r"))) {
//     die("could not open XML input");
// }
// while ($data = fread($fp, 4096)) {
//     if (!xml_parse($xml_parser, $data, feof($fp))) {
//         die(sprintf("XML error: %s at line %d",
//                     xml_error_string(xml_get_error_code($xml_parser)),
//                     xml_get_current_line_number($xml_parser)));
//     }
// }
// xml_parser_free($xml_parser);
// 
// ------------------------------------------------------------------------
// XML External Entity Example
// 
// This example highlights XML code. It illustrates how to use an external
// entity reference handler to include and parse other documents, as well as
// how PIs can be processed, and a way of determining "trust" for PIs
// containing code.
// 
// XML documents that can be used for this example are found below the example
// (xmltest.xml and xmltest2.xml.)
// 
// Example 3. External Entity Example
// 
// $file = "xmltest.xml";
// 
// function trustedFile($file)
// {
//     // only trust local files owned by ourselves
//     if (!eregi("^([a-z]+)://", $file) && fileowner($file) == getmyuid()) {
//         return true;
//     }
//     return false;
// }
// 
// function startElement($parser, $name, $attribs)
// {
//     print "&lt;<font color=\"#0000cc\">$name</font>";
//     if (sizeof($attribs)) {
//         while (list($k, $v) = each($attribs)) {
//             print " <font color=\"#009900\">$k</font>=\"<font color=\"#990000\">$v</font>\"";
//         }
//     }
//     print "&gt;";
// }
// 
// function endElement($parser, $name)
// {
//     print "&lt;/<font color=\"#0000cc\">$name</font>&gt;";
// }
// 
// function characterData($parser, $data)
// {
//     print "<b>$data</b>";
// }
// 
// function PIHandler($parser, $target, $data)
// {
//     switch (strtolower($target)) {
//         case "php":
//             global $parser_file;
//             // If the parsed document is "trusted", we say it is safe
//             // to execute PHP code inside it.  If not, display the code
//             // instead.
//             if (trustedFile($parser_file[$parser])) {
//                 eval($data);
//             } else {
//                 printf("Untrusted PHP code: <i>%s</i>", htmlspecialchars($data));
//             }
//             break;
//     }
// }
// 
// function defaultHandler($parser, $data)
// {
//     if (substr($data, 0, 1) == "&" && substr($data, -1, 1) == ";") {
//         printf('<font color="#aa00aa">%s</font>', htmlspecialchars($data));
//     } else {
//         printf('<font size="-1">%s</font>', htmlspecialchars($data));
//     }
// }
// 
// function externalEntityRefHandler($parser, $openEntityNames, $base, $systemId,
//                                   $publicId)
// {
//     if ($systemId) {
//         if (!list($parser, $fp) = new_xml_parser($systemId)) {
//             printf("Could not open entity %s at %s\n", $openEntityNames,
//                    $systemId);
//             return false;
//         }
//         while ($data = fread($fp, 4096)) {
//             if (!xml_parse($parser, $data, feof($fp))) {
//                 printf("XML error: %s at line %d while parsing entity %s\n",
//                        xml_error_string(xml_get_error_code($parser)),
//                        xml_get_current_line_number($parser), $openEntityNames);
//                 xml_parser_free($parser);
//                 return false;
//             }
//         }
//         xml_parser_free($parser);
//         return true;
//     }
//     return false;
// }
// 
// function new_xml_parser($file) {
//     global $parser_file;
// 
//     $xml_parser = xml_parser_create();
//     xml_parser_set_option($xml_parser, XML_OPTION_CASE_FOLDING, 1);
//     xml_set_element_handler($xml_parser, "startElement", "endElement");
//     xml_set_character_data_handler($xml_parser, "characterData");
//     xml_set_processing_instruction_handler($xml_parser, "PIHandler");
//     xml_set_default_handler($xml_parser, "defaultHandler");
//     xml_set_external_entity_ref_handler($xml_parser, "externalEntityRefHandler");
// 
//     if (!($fp = @fopen($file, "r"))) {
//         return false;
//     }
//     if (!is_array($parser_file)) {
//         settype($parser_file, "array");
//     }
//     $parser_file[$xml_parser] = $file;
//     return array($xml_parser, $fp);
// }
// 
// if (!(list($xml_parser, $fp) = new_xml_parser($file))) {
//     die("could not open XML input");
// }
// 
// print "<pre>";
// while ($data = fread($fp, 4096)) {
//     if (!xml_parse($xml_parser, $data, feof($fp))) {
//         die(sprintf("XML error: %s at line %d\n",
//                     xml_error_string(xml_get_error_code($xml_parser)),
//                     xml_get_current_line_number($xml_parser)));
//     }
// }
// print "</pre>";
// print "parse complete\n";
// xml_parser_free($xml_parser);
// 
// ?>
// 
// Example 4. xmltest.xml
// 
// <?xml version='1.0'?>
// <!DOCTYPE chapter SYSTEM "/just/a/test.dtd" [
// <!ENTITY plainEntity "FOO entity">
// <!ENTITY systemEntity SYSTEM "xmltest2.xml">
// ]>
// <chapter>
//  <TITLE>Title &plainEntity;</TITLE>
//  <para>
//   <informaltable>
//    <tgroup cols="3">
//     <tbody>
//      <row><entry>a1</entry><entry morerows="1">b1</entry><entry>c1</entry></row>
//      <row><entry>a2</entry><entry>c2</entry></row>
//      <row><entry>a3</entry><entry>b3</entry><entry>c3</entry></row>
//     </tbody>
//    </tgroup>
//   </informaltable>
//  </para>
//  &systemEntity;
//  <sect1 id="about">
//   <title>About this Document</title>
//   <para>
//    <!-- this is a comment -->
//    <?php print 'Hi!  This is PHP version '.phpversion(); ?>
//   </para>
//  </sect1>
// </chapter>
// 
// This file is included from xmltest.xml:
// Example 5. xmltest2.xml
// 
// <?xml version="1.0"?>
// <!DOCTYPE foo [
// <!ENTITY testEnt "test entity">
// ]>
// <foo>
//  <element attrib="value"/>
//  &testEnt;
//  <?php print "This is some more PHP code being executed."; ?>
// </foo>
// 

/**/
global int XML_ERROR_NONE;
global int XML_ERROR_NO_MEMORY;
global int XML_ERROR_SYNTAX;
global int XML_ERROR_NO_ELEMENTS;
global int XML_ERROR_INVALID_TOKEN;
global int XML_ERROR_UNCLOSED_TOKEN;
global int XML_ERROR_PARTIAL_CHAR;
global int XML_ERROR_TAG_MISMATCH;
global int XML_ERROR_DUPLICATE_ATTRIBUTE;
global int XML_ERROR_JUNK_AFTER_DOC_ELEMENT;
global int XML_ERROR_PARAM_ENTITY_REF;
global int XML_ERROR_UNDEFINED_ENTITY;
global int XML_ERROR_RECURSIVE_ENTITY_REF;
global int XML_ERROR_ASYNC_ENTITY;
global int XML_ERROR_BAD_CHAR_REF;
global int XML_ERROR_BINARY_ENTITY_REF;
global int XML_ERROR_ATTRIBUTE_EXTERNAL_ENTITY_REF;
global int XML_ERROR_MISPLACED_XML_PI;
global int XML_ERROR_UNKNOWN_ENCODING;
global int XML_ERROR_INCORRECT_ENCODING;
global int XML_ERROR_UNCLOSED_CDATA_SECTION;
global int XML_ERROR_EXTERNAL_ENTITY_HANDLING;

/**
 * create an XML parser
 * <p>
 * This function creates an XML parser and returns a handle for use by other
 * XML functions. 
 * 
 * @param encoding 
 *      Which character encoding the parser should use. The following
 *      character encodings are supported:
 * <ul>
 * <li> ISO-8859-1 (default)
 * <li> US-ASCII
 * <li> UTF-8
 * </ul>
 *
 * @return false on failure.
 */
function int xml_parser_create(string [encoding]);
 
/**
 * set up start and end element handlers
 * <p>
 * Sets the element handler functions for the XML parser parser.
 * startElementHandler and endElementHandler are strings containing the names
 * of functions that must exist when xml_parse() is called for parser.
 * <p>
 * If a handler function is set to an empty string, or false, the handler in
 * question is disabled.
 * <p>
 * There is currently no support for object/method handlers.
 *
 * @param parser
 *        XML parser instance
 *
 * @param startElementHandler
 *        The function named by startElementHandler must accept three parameters:
 *        <pre>startElementHandler(int parser, string name, string attribs)</pre>
 *        <ul>
 *        <dt> parser
 *        <dd>
 *        The first parameter, parser, is a reference to the XML parser calling
 *        the handler.
 *        <dt> name
 *        <dd>
 *        The second parameter, name, contains the name of the element for which
 *        this handler is called. If case-folding is in effect for this parser,
 *        the element name will be in uppercase letters.
 *        <dt> attribs
 *        <dd>
 *        The third parameter, attribs, contains an associative array with the
 *        element's attributes (if any). The keys of this array are the
 *        attribute names, the values are the attribute values. Attribute names
 *        are case-folded on the same criteria as element names. Attribute
 *        values are not case-folded.
 *        <p>
 *        The original order of the attributes can be retrieved by walking
 *        through attribs the normal way, using each(). The first key in the
 *        array was the first attribute, and so on.
 *        </dl>
 *
 * @param endElementHandler
 *        The function named by endElementHandler must accept two parameters:
 *        <pre>endElementHandler<tt>(int parser, string name)</pre>
 *        <ul>
 *        <dt> parser
 *        <dd>The first parameter, parser, is a reference to the
 *        XML parser calling the handler.
 *        <dt> name
 *        <dd>The second parameter, name, contains the name of the element for which
 *        this handler is called. If case-folding is in effect for this parser,
 *        the element name will be in uppercase letters.
 *        </dl>
 *
 * @return True is returned if the handlers are set up,
 *         false if parser is not a parser.
 */
function int xml_set_element_handler(int parser, string startElementHandler, string endElementHandler);
 
/**
 * set up character data handler
 * <p>
 * Sets the character data handler function for the XML parser parser. handler
 * is a string containing the name of a function that must exist when
 * xml_parse() is called for parser.
 * <p>
 * If a handler function is set to an empty string, or false, the handler in
 * question is disabled.
 * <p>
 * There is currently no support for object/method handlers.
 *
 * @param handler
 *        The function named by handler must accept two parameters:
 *        <pre>handler(int parser, string data)</pre>
 *        <ul>
 *        <dt>parser
 *        <dd>
 *        The first parameter, parser, is a reference to the XML parser calling
 *        the handler.
 *        <dt>data
 *        <dd>
 *        The second parameter, data, contains the character data as a string.
 *        </dl>
 * 
 * @return True is returned if the handler is set up,
 *         false if parser is not a parser.
 */
function int xml_set_character_data_handler(int parser, string handler);
 
/**
 * Sets the processing instruction (PI) handler function for the XML parser
 * parser. handler is a string containing the name of a function that must
 * exist when xml_parse() is called for parser.
 * <p>
 * A processing instruction has the following format:
 * <pre>
 *    &lt;?target data?&gt;
 * </pre>
 * You can put PHP code into such a tag, but be aware of one limitation: in an
 * XML PI, the PI end tag (?&gt;) can not be quoted, so this character sequence
 * should not appear in the PHP code you embed with PIs in XML documents. If
 * it does, the rest of the PHP code, as well as the "real" PI end tag, will
 * be treated as character data.
 * <p>
 * If a handler function is set to an empty string, or false, the handler in
 * question is disabled.
 * <p>
 * There is currently no support for object/method handlers.
 * 
 * @param handler
 *        The function named by handler must accept three parameters:
 *        <pre>handler(int parser, string target, string data)</pre>
 *        <ul>
 *        <dt>parser
 *        <dd>The first parameter, parser, is a reference to the
 *        XML parser calling the handler.
 *        <dt>target
 *        <dd>The second parameter, target, contains the PI target.
 *        <dt>data
 *        <dd>The third parameter, data, contains the PI data.
 *        </dl>
 * 
 * @return True is returned if the handler is set up,
 *         false if parser is not a parser.
 */
function int xml_set_processing_instruction_handler(int parser, string handler);
 
/**
 * set up default handler
 * <p>
 * Sets the default handler function for the XML parser parser. handler is a
 * string containing the name of a function that must exist when xml_parse()
 * is called for parser.
 * <p>
 * If a handler function is set to an empty string, or false, the handler in
 * question is disabled.
 * <p>
 * There is currently no support for object/method handlers.
 * 
 * @param handler
 *        The function named by handler must accept two parameters:
 *        <pre>handler(int parser, string data)</pre>
 *        <ul>
 *        <dt>parser
 *        <dd>
 *        The first parameter, parser, is a reference to the XML parser calling
 *        the handler.
 *        <dt>data
 *        <dd>
 *        The second parameter, data, contains the character data. This may be
 *        the XML declaration, document type declaration, entities or other data
 *        for which no other handler exists.
 *        </dl>
 *
 * @return True is returned if the handler is set up,
 *         false if parser is not a parser.
 */
function int xml_set_default_handler(int parser, string handler);
 
/**
 * Sets the unparsed entity declaration handler.
 * <p>
 * Sets the unparsed entity declaration handler function for the XML parser
 * parser. handler is a string containing the name of a function that must
 * exist when xml_parse() is called for parser.
 * <p>
 * This handler will be called if the XML parser encounters an external entity
 * declaration with an NDATA declaration, like the following:
 * <pre>
 *    &lt;!ENTITY name {publicId | systemId} NDATA notationName&gt;
 * </pre>
 * See section 4.2.2 of the XML 1.0 spec for the definition of notation
 * declared external entities.
 * <p>
 * If a handler function is set to an empty string, or false, the handler in
 * question is disabled.
 * <p>
 * There is currently no support for object/method handlers.
 *
 * @param handler
 *        The function named by handler must accept six parameters:
 *        <pre>handler(int parser, string entityName, string base,
                       string systemId, string publicId, string notationName)</pre>
 *        <ul>
 *        <dt> parser
 *        <dd>
 *        The first parameter, parser, is a reference to the XML parser calling
 *        the handler.
 *        <dt> entityName
 *        <dd>
 *        The name of the entity that is about to be defined.
 *        <dt> base
 *        <dd>
 *        This is the base for resolving the system identifier (systemId) of the
 *        external entity. Currently this parameter will always be set to an
 *        empty string.
 *        <dt> systemId
 *        <dd>
 *        System identifier for the external entity.
 *        <dt> publicId
 *        <dd>
 *        Public identifier for the external entity.
 *        <dt> notationName
 *        <dd>
 *        Name of the notation of this entity (see
 *        xml_set_notation_decl_handler()).
 *        </ul>
 *
 * @return True is returned if the handler is set up,
 *         false if parser is not a parser.
 */
function int xml_set_unparsed_entity_decl_handler(int parser, string handler);
 
/**
 * set up notation declaration handler
 * <p>
 * Sets the notation declaration handler function for the XML parser parser.
 * handler is a string containing the name of a function that must exist when
 * xml_parse() is called for parser.
 * <p>
 * A notation declaration is part of the document's DTD and has the following
 * format:
 * <pre>
 *    &lt;!NOTATION name {systemId | publicId}&gt;
 * </pre>
 * See section 4.7 of the XML 1.0 spec for the definition of notation
 * declarations.
 * <p>
 * If a handler function is set to an empty string, or false, the handler in
 * question is disabled.
 * <p>
 * There is currently no support for object/method handlers.
 * 
 * @param handler
 *        The function named by handler must accept five parameters:
 *        <pre>handler(int parser, string notationName, string base,
 *                     string systemId, string publicId)</pre>
 *        <ul>
 *        <dt>parser
 *        <dd>The first parameter, parser, is a reference to the XML parser
 *        calling the handler.
 *        <dt>notationName
 *        <dd>
 *        This is the notation's name, as per the notation format described
 *        above.
 *        <dt>base
 *        <dd>
 *        This is the base for resolving the system identifier (systemId) of the
 *        notation declaration. Currently this parameter will always be set to
 *        an empty string.
 *        <dt>systemId
 *        <dd>
 *        System identifier of the external notation declaration.
 *        <dt>publicId
 *        <dd>
 *        Public identifier of the external notation declaration.
 *
 * @return True is returned if the handler is set up,
 *         false if parser is not a parser.
 */
function int xml_set_notation_decl_handler(int parser, string handler);
 
/**
 * Sets the notation declaration handler.
 * <p>
 * Sets the notation declaration handler function for the XML parser parser.
 * handler is a string containing the name of a function that must exist when
 * xml_parse() is called for parser.
 * <p>
 * If a handler function is set to an empty string, or false, the handler in
 * question is disabled.
 * <p>
 * There is currently no support for object/method handlers.
 *
 * @param handler
 *        The function named by handler must accept five parameters, and should
 *        return an integer value. If the value returned from the handler is false
 *        (which it will be if no value is returned), the XML parser will stop
 *        parsing and xml_get_error_code() will return
 *        XML_ERROR_EXTERNAL_ENTITY_HANDLING.
 *        <pre>int handler(int parser, string openEntityNames, string base,
 *                         string systemId, string publicId)</pre>
 *        <ul>
 *        <dt> parser
 *        <dd>
 *        The first parameter, parser, is a reference to the XML parser calling
 *        the handler.
 *        <dt> openEntityNames
 *        <dd>
 *        The second parameter, openEntityNames, is a space-separated list of
 *        the names of the entities that are open for the parse of this entity
 *        (including the name of the referenced entity).
 *        <dt> base
 *        <dd>
 *        This is the base for resolving the system identifier (systemid) of the
 *        external entity. Currently this parameter will always be set to an
 *        empty string.
 *        <dt> systemId
 *        <dd>
 *        The fourth parameter, systemId, is the system identifier as specified
 *        in the entity declaration.
 *        <dt> publicId
 *        <dd>
 *        The fifth parameter, publicId, is the public identifier as specified
 *        in the entity declaration, or an empty string if none was specified;
 *        the whitespace in the public identifier will have been normalized as
 *        required by the XML spec.
 *        </dl>
 *
 * @return True is returned if the handler is set up,
 *         false if parser is not a parser.
 */
function int xml_set_external_entity_ref_handler(int parser, string handler);
 
/**
 * start parsing an XML document
 * <p>
 * When the XML document is parsed, the handlers for the configured events are
 * called as many times as necessary, after which this function returns true
 * or false.
 *
 * @param parser
 *        A reference to the XML parser to use.
 * @param data
 *        Chunk of data to parse. A document may be parsed piece-wise by calling
 *        xml_parse() several times with new data, as long as the isFinal
 *        parameter is set and true when the last data is parsed.
 * @param isFinal (optional)
 *        If set and true, data is the last piece of data sent in this parse.
 *
 * @return
 * True is returned if the parse was successful, false if it was not
 * successful, or if parser does not refer to a valid parser. For unsuccessful
 * parses, error information can be retrieved with xml_get_error_code(),
 * {@link xml_error_string()}, {@link xml_get_current_line_number()},
 * {@link xml_get_current_column_number()} and {@link xml_get_current_byte_index()}.
 */
function int xml_parse(int parser, string data, int [isFinal]);
 
/**
 * get XML parser error code
 *
 * @param parser
 *        A reference to the XML parser to get error code from.
 *
 * @return
 * This function returns false if parser does not refer to a valid parser, or
 * else it returns one of the error codes listed in the error codes section.
 */
function int xml_get_error_code(int parser);
 
/**
 * get XML parser error string
 *
 * @param code
 *        An error code from {@link xml_get_error_code()}.
 * 
 * @return
 * Returns a string with a textual description of the error code code, or
 * false if no description was found.
 */
function string xml_error_string(int code);
 
/**
 * get current line number for an XML parser
 * 
 * @param parser
 *        A reference to the XML parser to get line number from.
 * 
 * @return
 * This function returns false if parser does not refer to a valid parser, or
 * else it returns which line the parser is currently at in its data buffer.
 * 
 */
function int xml_get_current_line_number(int parser);
 
/**
 * get current column on the current line
 * 
 * @param parser
 *        A reference to the XML parser to get column number from.
 * 
 * @return
 * This function returns false if parser does not refer to a valid parser, or
 * else it returns which column on the current line (as given by
 * {@link xml_get_current_line_number()}) the parser is currently at.
 */
function int xml_get_current_column_number(int parser);
 
/**
 * get current byte index for an XML parser
 * 
 * @param parser
 *        A reference to the XML parser to get byte index from.
 * 
 * @return
 * This function returns false if parser does not refer to a valid parser, or
 * else it returns which byte index the parser is currently at in its data
 * buffer (starting at 0).
 */
function int xml_get_current_byte_index(int parser);
 
/**
 * free an XML parser
 * 
 * @param parser
 *      A reference to the XML parser to free.
 * 
 * @return
 * This function returns false if parser does not refer to a valid parser,
 * or else it frees the parser and returns true.
 */
function string xml_parser_free(int parser);
 
/**
 * set options in an XML parser
 * 
 * @param parser
 *        A reference to the XML parser to set an option in.
 * @param option
 *        Which option to set. See below.
 * <pre>
 *  Option constant            Data type Description
 *  XML_OPTION_CASE_FOLDING    integer   Controls whether case-folding is
 *                                       enabled for this XML parser. Enabled
 *                                       by default.
 *  XML_OPTION_TARGET_ENCODING string    Sets which target encoding to use in
 *                                       this XML parser. By default, it is
 *                                       set to the same as the source
 *                                       encoding used by {@link xml_parser_create()}.
 *                                       Supported target encodings are
 *                                       ISO-8859-1, US-ASCII and UTF-8.
 * </pre>
 * @parma value
 *        The option's new value.
 * 
 * @return
 * This function returns false if parser does not refer to a valid parser, or
 * if the option could not be set. Else the option is set and true is
 * returned.
 * The following options are available:
 */
function int xml_parser_set_option(int parser, int option, mixed value);
 
/**
 * get options from an XML parser
 * 
 * @param parser
 *        A reference to the XML parser to get an option from.
 * @param option
 *        Which option to fetch. See {@link xml_parser_set_option()} for a list of
 *        options.
 * 
 * @return
 * This function returns false if parser does not refer to a valid parser, or
 * if the option could not be set. Else the option's value is returned.
 * 
 * @see xml_parser_set_option()
 */
function mixed xml_parser_get_option(int parser, int option);
 

///////////////////////////////////////////////////////////////////////////
// UTF-8 string functions
// 

/**
 * converts a UTF-8 encoded string to ISO-8859-1
 * <p>
 * This function decodes data, assumed to be UTF-8 encoded, to ISO-8859-1.
 * 
 * @see utf8_encode()
 */
function string utf8_decode(string data);
 
/**
 * encodes an ISO-8859-1 string to UTF-8
 * <p>
 * This function encodes the string data to UTF-8, and returns the encoded
 * version. UTF-8 is a standard mechanism used by Unicodefor encoding wide
 * character values into a byte stream. UTF-8 is transparent to plain ASCII
 * characters, is self-synchronized (meaning it is possible for a program to
 * figure out where in the bytestream characters start) and can be used with
 * normal string comparison functions for sorting and such. PHP encodes UTF-8
 * characters in up to four bytes, like this:
 * <p>
 * Table 1. UTF-8 encoding
 * <pre>
 *    bytesbits representation
 *    1    7    0bbbbbbb
 *    2    11   110bbbbb 10bbbbbb
 *    3    16   1110bbbb 10bbbbbb 10bbbbbb
 *    4    21   11110bbb 10bbbbbb 10bbbbbb 10bbbbbb
 * </pre>
 * Each b represents a bit that can be used to store character data.
 */
function string utf8_encode(string data);


///////////////////////////////////////////////////////////////////////////
// Calling User Functions
// 

/**
 * Call a user functions from an internal function.
 * <p>
 * All internal functions that call user functions must be reentrant. Among
 * other things, this means they must not use globals or static variables.
 *
 * @param function_table
 *        This is the hash table in which the function is to be looked up.
 * @param object
 *        This is a pointer to an object on which the function is invoked. This
 *        should be NULL if a global function is called. If it's not NULL (i.e. it
 *        points to an object), the function_table argument is ignored, and instead
 *        taken from the object's hash. The object *may* be modified by the function
 *        that is invoked on it (that function will have access to it via $this). If
 *        for some reason you don't want that to happen, send a copy of the object
 *        instead.
 * @param function_name
 *        The name of the function to call. Must be a pval of type IS_STRING with
 *        function_name.str.val and function_name.str.len set to the appropriate
 *        values. The function_name is modified by call_user_function() - it's
 *        converted to lowercase. If you need to preserve the case, send a copy of
 *        the function name instead.
 * @param retval
 *        A pointer to a pval structure, into which the return value of the invoked
 *        function is saved. The structure must be previously allocated -
 *        call_user_function() does NOT allocate it by itself.
 * @param param_count
 *        The number of parameters being passed to the function.
 * @param params
 *        An array of pointers to values that will be passed as arguments to the
 *        function, the first argument being in offset 0, the second in offset 1,
 *        etc. The array is an array of pointers to pval's; The pointers are sent
 *        as-is to the function, which means if the function modifies its arguments,
 *        the original values are changed (passing by reference). If you don't want
 *        that behavior, pass a copy instead.
 *
 * @return call_user_function() returns SUCCESS on success,
 * and FAILURE in case the function cannot be found.
 * You should check that return value! If it returns SUCCESS,
 * you are responsible for destroying the retval pval yourself
 * (or return it as the return value of your function). If it returns
 * FAILURE, the value of retval is undefined, and you mustn't touch it.
 */
function int call_user_function(HashTable *function_table, pval *object,
                                pval *function_name, pval *retval,
                                int param_count, pval *params[]);

