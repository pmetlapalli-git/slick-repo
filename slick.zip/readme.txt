
            Welcome to Visual SlickEdit


VISUAL SLICKEDIT SUPPORT

* Download the latest patches from our web site at

    http://www.slickedit.com/support/
  
* Technical support can be reached:

    by email at support@slickedit.com

    or by phone at +1 919.303.7400
  
    or by fax at +1 919.303.8400


-----------------------------------------------------------------------


ENHANCEMENTS FOR VERSION 5.0B

  See slickc.doc for information on Slick-C enhancements.
  
    * Context Tagging(TM) Enhancements
       -  Added Context Tagging for HTML, COBOL, 
          OO COBOL, Ada, Delphi, PHP.
       -  Auto function help now displays function comments.
       -  Javadoc comments displayed in built-in HTML browser, so your
          comments look really good.
       -  Hypertext link support for javadoc comments.
       -  Auto list members supports viewing comments for 
          symbols with the same name.
       -  Improved stripping comment characters and retrieval of 
          all comments.
       -  C style preprocessing for Java (for Visual J++ support).
          
    * Java package support now includes creating Jar files and generating
      javadoc.
    
    * HTML Beautifier
    
    * Print Preview
    
    * References and symbol uses support for Java, C/C++,
      COBOL, Slick-C, Ada, Delphi, PHP, and InstallScript.
      
    * Javadoc Editor.  Supports Java, C, C++, and Slick-C.
    
    * ISPF emulation
    
    * Printing Schemes
    
    * Seamlessly open a Visual C++ workspace
    
    * Emulation for Visual C++
    
    * Relative workspace and project files.  This allows you
      to relocate your workspace, project, and source files.

    * Go to definition dialog now supports non-prefix matching.
      In addition, when prefix matching is off, your search string
      may be a regular expression.
        
    * Multi-file diff now supports excluding directories.

    * Multi-file difference dialog supports selecting and
      operating on multiple files.
      
    * Smarter differencing.  The most notable improvement is smarter
      handling of braces which makes merging changes much easier
      for languages with braces.
    
    * Large toolbars including the Project, Output, and FTP Client
      toolbars, now have a Close button.
    
    * Auto reload now has an option to diff the files.
    
    * Enhanced project management
         -  Workspaces with multiple projects may be defined.
            Workspaces allow for projects to be shared between
            other workspaces.  In addition, dependencies may
            be defined between projects in a single workspace 
            allowing a more sophisticated build process.
            
    * Enhanced FTP Support
         - Recursive FTP directory operations: Upload, download, delete
         - More hosts supported:  OS/400, VM, VOS, Windows NT, OS/2,
           MVS, VMS, Netware, MacOS.
           
    * Support for projects with multiple language files types. For 
      example, Context Tagging works when you can have C/C++ and 
      assembly source files in the same workspace.
      
    * Associate File Types dialog now displays current
      associations and supports unassociating file types.
      
    * New HTML Toolbar
    
    * New Tagging toolbar
    
    * Procs Tab enhanced to show hierarchy/scope of symbols.
    
    * Language support for the mainframe languages PL/I, JCL, 
      and OS/390 Assembler.
    
    * Language support for IDL including tagging and color coding.
    
    * Tag files now support more than 65000 files.  Now the Windows NT
      development team (that uses Visual SlickEdit) can build one tag
      file for all of Windows NT instead of building multiple tag files.

    * Tag files are 10% smaller in size and build slightly faster.


-----------------------------------------------------------------------

  Other Enhancements Since 1.0


    * Context Tagging (TM) for C++, Java, COBOL, JavaScript, 
      Perl, InstallScript, PV-WAVE, and Slick-C. Auto List 
      Members, Auto Function Help, and context tag navigation.
      
      See on-line help under Context Tagging(TM) for detailed
      information.

    * DIFFzilla(TM).  The ultimate in multi-file differencing:
    
         - View differences between source trees.
         - Dynamic Difference Editing (TM) - intra-line differences color
           coded even as you type.
         - Generate file lists.
         - Automatic directory mapping.
         - Save/restore multi-file results.
         - Dialog box history (wildcards, paths, file specs).
         
    * Windows: Support for Rational Rose.  Run our new "roseinst.exe"
      executable located in the vslick\win directory.  This
      utility program registers Visual SlickEdit as the editor
      to be used by Rational Rose.
         
    * Complete FTP support.  Our FTP support includes a complete 
      FTP client and the ability to easily open and edit FTP files.

    * Source reference browsing for Java and Microsoft VC++.

    * User definable preprocessing for C++ symbol tagging.

      For example, the following can easily be corrected
      by defining global preprocessing and retagging
      your files.

        COMMON unsigned char gapp_has_focus INIT_TO(1);

      Just add

         #define COMMON
         #define INIT_TO(e) =e

      to your global preprocessing.

      The following can be corrected too:

         #define proto(x,y) x y

         void proto(myproc,(int arg1,int arg2));

    * New javamake command for compiling all java files in a project
      which checks all dependencies.

    * More support for PL/SQL including SmartPaste(TM), 
      syntax expansion, syntax indenting, auto keyword casing,
      procedure tagging, selective display of functions, 
      and improved color coding.
    
    * More support for Transact SQL (SQL Server) including
      syntax expansion, syntax indenting, auto keyword casing,
      procedure tagging, selective display of functions, 
      and improved color coding.
    
    * Support for PV-WAVE language including Context Tagging(TM), 
      SmartPaste(TM), syntax expansion, syntax indenting, 
      auto keyword casing, procedure tagging, selective display
      of functions, and improved color coding.
      
      NOTE: Press Alt+Dot when inside PV-WAVE procedure or
      function to get a list of the keywords.
      
    * Additional support for Tornado.  New tornado package, 
      quick access to Tornado API help, and icon for Visual
      SlickEdit which appears on the Tornado toolbar.
      
    * GNU EMACS emulation.
    
    * Support for InstallScript (InstallShield's macro language) 
      including Context Tagging(TM), SmartPaste(TM), 
      syntax expansion, syntax indenting, procedure tagging, 
      selective display of functions, and color coding.
      
    * New "Preserve case" option when performing a search and replace.

    * Smart editing for embedded languages.  Context Tagging (TM),
      SmartPaste(TM), syntax expansion, syntax indenting, 
      and all our other goodies now work for embedded languages.

    * More support for JavaScript including Context Tagging (TM) and 
      SmartPaste(TM).

    * New flat button toolbar look.

    * Version control enhanced.  Support for SCC.  New Auto
      check-out on edit option.

    * Hexadecimal printing.

    * Printing of selective display.

    * The Procs Tab now supports listing all symbol types.  You
      can choose which symbol types you want to display.

    * OLE Drag & Drop text between windows or applications.

    * Class Browser Tag Properties dialog is now a sizable dockable
      toolbar.

    * The Class Browser inheritance tree is now sizable.

    * Dynamic tagging.  Automatically updates project tag files and
      global tag files.  Tracks current function, functions/methods in
      current file, and tag symbols for word at cursor.

    * Class Browser.  Displays class members, optionally shows inherited
      accessible members, views inheritance, searches for members, and 
      more.  Supports non-object oriented languages.

    * C/C++/Java code beautifier.

    * Diff Editor.  Compares two files, color coding differences,
      and lets you edit without exiting diff mode.

    * Customizable dockable toolbars.  Project toolbar with tabs for
      Class Browser, tags in file, file open, and project files.  Output
      toolbar with tabs for tag symbol tracking, multi-file search output,
      and compilation output.

    * 3-Way Merge Editing.  Automatically merges two revision
      files with a base file.  Collisions are color coded and
      you can interactively add changes to the output file
      without exiting 3-Way Merge mode.

    * Hex editing

    * Associate Makefile support for VC++ 4.x, 5.0, and 6.0.  Once a 
      makefile is associated to a Visual SlickEdit project, you only
      need to update the files in your VC++ makefile to update your 
      Visual SlickEdit project files.                               

    * Much improved SmartPaste for character selections.

    * Embedded Language Color Coding.  Embedded JavaScript and VBScript in
      HTML are color coded.  In addition, "here documents" in UNIX
      Shell/Perl scripts are color coded.  To color code embedded source in
      a UNIX Shell/Perl script, just prefix your here document terminator
      with our color coding lexer name.

      Example of a "here document" in Perl, where 'HTMLEOF' is the
      terminator:

        print <<HTMLEOF;
        <HTML><HEAD><TITLE>...</TITLE></HEAD>
        <BODY>
        ...
        </BODY>
        </HTML>
        HTMLEOF


      Cool huh?!  Unknown languages are color coded in string color.
      Embedded language colors are user-definable.

    * Tagging now handles 10,000 files and more.  Tagging has been tested
      on 4 gigabytes of source code.  Tag an entire OS of source code.

    * Smart HTML Color Coding.  Color codes attributes on a per-tag basis
      in a user-definable attribute color.

    * You can now dynamically add tools to the Project menu by using the
      Project Properties dialog.  For example, if you want to add "Resource
      Editor" to the Project menu, just Press the "New Tool..." button on
      the Tools tab of the Project Properties dialog box ("Project",
      "Properties...") and enter the command line.

    * Bold/italic color coding.

    * Bold/italic printing.

    * Nested selective display.

    * Save/restore selective display and/or line modify.

    * Select Code Block now supports HTML <TAG> ... </TAG> pairs.

    * Smart HTML spell checking. Ignores tags and attributes
      which don't need checking. Spell checks comments and strings
      for embedded languages like JavaScript and VBScript.

    * Multi-file spell checking.

    * Much improved multi-file searching.

    * Improved List All Occurrences searching. Consistent
      with multi-file find, modeless, and next/prev commands.

    * Small configurable left margin when not in selective display mode.

    * Optional Brief syntax regular expressions.

    * Special character display.

    * Windows only: Microsoft IntelliMouse(TM) support. (32-bit only).

    * Windows only: Context menu key support.

    * Less space for command line and improved status line.

    * Configuration dialog simplified by configuration menu
      and tabbed dialogs.

    * API Apprentice

    * Word completion

    * Long line support.

    * Help Indexer supports Windows help 4.0 files and
      Visual C++ .mvb files.

    * Lots of Java support.  SmartPaste, code beautifying,
      code block operations, Tagging, syntax expansion/indenting,
      and color coding.

    * Mouse support for copy and move to cursor Ctrl+Shift+RButton
      and Ctrl+Rbutton respectively.  Even between files.

    * Search and replace across line boundaries.

    * Selective display.  Superb preprocessing for C++.
      Display function headings, lines with/without search
      string, collapse the current code block, or collapse all
      comments.

    * Rexx, perl, awk support.  Rexx support recognizes when
      you type /* on first line of .cmd file.

    * Color Coding Editor

    * Color schemes.  Change all your colors by selecting a
      scheme.  Define your own color schemes.

    * Extension specific aliases support completion and
      are invoked on space bar.  Extension specific aliases
      can be defined which override macro driven syntax
      expansion.

    * Powerful select code block command.  Invoke multiple
      times to select larger code blocks.

    * Right button mouse menu has a current-function command
      which tells you what function you are editing.

    * next-proc and prev-proc commands allow quickly cursor
      to your next and previous function definitions.

    * Color Printing

    * Project files search and replace.

    * Optional UNIX syntax Regular expression.

    * Regular expressions now support back references and
      ranges of occurrences.

    * Multi-file/buffer printing.

    * New commands on "Edit" menu for converting
      tabs to spaces and spaces to tabs.

    * Seek dialog supports a mathematical expression.

    * Macro language enhanced to support dynamically growing
      arrays and hash tables, structures, unions, pointers,
      pointers to functions, and simple types, in C++ syntax.

    * No limit on number of tab stops.

    * History editor.  Delete menu items from file menu and
      project menu.

    * Drag Drop within a single edit window.

    * SmartPaste for C++, Slick-C, Delphi, Java, AWK, Perl,
      Pascal.

    * Auto-restore for multiple desktops.

    * (Windows only) help index file creation.  Allows you to build
      an index for multiple help files.

    * Color Coding

    * VI emulation

    * Version Control support for PVCS, TLIB, Source Safe, and Delta.

    * AutoSave

    * Project Management supports auto-restore and specifying files for
      project.

    * Menu Editor

    * Automatic rebinding of menu bar key binding display.

    * Optional auto-restore of concurrent process buffer.

    * Smarter syntax expansion and brace matching.  Visual SlickEdit now
      understands the difference between comments, strings, and normal text.

    * Spell Check can be limited to comments and strings.

    * Find File on Open dialog box supports list files containing a particular
      string.

    * Link Window dialog box supports open files from disk and starting
      concurrent process buffer.

    * Compare macro automatically sets up your windows for comparing files.

    * Multi-File Find displays modeless dialog box which list occurrences
      as well as files.

    * File menu displays recently opened files.

