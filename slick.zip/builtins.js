/*
   Copyright 1998 by MicroEdge Inc.
   All rights reserved.
  
   This software is the confidential and proprietary information
   of MicroEdge Inc. You shall not disclose this information and 
   shall use it only with Visual SlickEdit.
   
   You may modify this file to add new built-ins
   for Visual SlickEdit's Context Tagging(TM).  Let us know about 
   new built-ins.  This way our installation/update will install the 
   most up-to-date version and you won't need to maintain a
   backup.
*/
 
// global functions and properties
Navigator navigator;
String escape(String s);
String unescape(String s);
String eval(String code);
JavaClass getClass(JavaObject javaobj);
boolean isNaN(value);
float parseFloat(String s);
int parseInt(String s);
Object taint(value);
Object untaint(value);

// built-in classes and their method, properties
class Anchor extends Link {
}
class Area extends Link {
}
class Array {
   public Array();
   public Array(int size);
   public Array(value0,value1,...);
   public Array(...);
   public int length;
   public String join(String separator="") const;
   public void reverse();
   public void sort();
   public void sort(orderFunc);
   public Object operator [](int i);
}
class Boolean {
   public Boolean(value);
   public String toString() const;
   public boolean valueOf() const;
}
class Button /*extends Element*/ {
   public const Form form;
   public const String name;
   public const String type;
   public const String value;
   public void blur();
   public void click();
   public void focus();
   public void onblur();
   public void onclick();
   public void onfocus();
}
class Checkbox /*extends Element*/ {
   public boolean checked;
   public const boolean defaultChecked;
   public const Form form;
   public const String name;
   public const String type;
   public String value;
   public void blur();
   public void click();
   public void focus();
   public void onblur();
   public void onclick();
   public void onfocus();
}
class Date {
   public Date();
   public Date(int milliseconds);
   public Date(String datestring);
   public Date(int year, int month, int day);
   public Date(int year, int month, int day, int hours, int minutes, int seconds);
   public int getDate() const;
   public int getDay() const;
   public int getHours() const;
   public int getMinutes() const;
   public int getSeconds() const;
   public int getTime() const;
   public int getTimezoneOffset() const;
   public int getYear() const;
   public static int parse(String datestring);
   public void setDate(int date);
   public void setHours(int hours);
   public void setMinutes(int minutes);
   public void setMonth(int month);
   public void setSeconds(int seconds);
   public void setTime(int milliseconds);
   public void setYear(int year);
   public String toGMTString() const;
   public String toLocaleString() const;
   public static int UTC(int year,int month,int day,int hours=0,int minutes=0,int seconds=0);
   public String prototype;
}
class Document {
   public String alinkColor;
   public Anchor[] anchors;
   public JavaObject[] applets;
   public String bgColor;
   public String cookie;
   public String domain;
   public JavaObject[] embeds;
   public String fgColor;
   public Form forms;
   public Image[] images;
   public const String lastModified;
   public String linkColor;
   public Link[] links;
   public Location location;
   public Plugin[] plugins;
   public const String referrer;
   public const String title;
   public const String URL;
   public String vlinkColor;
   public void clear();
   public void close();
   public void open();
   public void write(value,...);
   public void writeln(value,...);
   public void onload();
   public void onunload();
}
class Element {
   public boolean checked;
   public const boolean defaultChecked;
   public const String defaultValue;
   public const Form form;
   public int length;
   public const String name;
   public Option[] options;
   public int selectedIndex;
   public const String type;
   public String value;
   public void blur();
   public void click();
   public void focus();
   public void select();
   public void onblur();
   public void onclick();
   public void onfocus();
   public void onchange();
}
class FileUpload {
   public const Form form;
   public const String name;
   public const String type;
   public const String value;
   public void blur();
   public void focus();
   public void select();
   public void onblur();
   public void onfocus();
   public void onchange();
}
class Form {
   public String action;
   public Element[] elements;
   public String encoding;
   public String method;
   public String target;
   public void reset();
   public void submit();
   public void onreset();
   public void onsubmit();
} 
class Frame extends Window {
}
class Function {
   public Function(String argname, ..., String body);
   public String[] arguments;
   public Function caller;
   public Object prototype;
   public String toString() const;

}
class Hidden /*extends Element*/ {
   public const Form form;
   public const String name;
   public const String type;
   public const String value;
}
class History {
   public String current;
   public int length;
   public String next;
   public String previous;
   public void back();
   public void forward();
   public void go(int relative);
   public String toString() const;
}
class Image {
   public Image(int width=0, int height=0);
   public const int border;
   public const boolean complete;
   public const int height;
   public const int hspace;
   public String lowsrc;
   public const String name;
   public String src;
   public const int vspace;
   public const int width;
   public void onabort();
   public void onerror();
   public void onload();

}
class JavaArray {
   public int length;
   public JavaObject operator [](int i);
}
class JavaClass {
   // don't know what to do here, could be anything
   // example)  java.lang.Exception
}
class JavaMethod {
   // this could be any java class method
   // example)  java.lang.System.getProperty()
}
class JavaObject {
   // this could be any instance of a java class
   // example) var s = new java.lang.String()
}
class JavaPackage {
   // this could be any java package
   // example)  java.io   or   Packages.omg.corba
}
class Link {
   public String hash;
   public String host;
   public String hostname;
   public String href;
   public String pathname;
   public String port;
   public String protocol;
   public String search;
   public String target;
   public void onclick();
   public void onmouseout();
   public void onmouseover();
}
class Location {
   public String hash;
   public String host;
   public String hostname;
   public String href;
   public String pathname;
   public String port;
   public String protocol;
   public String search;
   public void reload(boolean force=false);
   public void replace(String url);
}
class Math {
   public final float E;
   public final float LN10;
   public final float LN2;
   public final float LN10E;
   public final float LN2E;
   public final float PI;
   public final float SQRT1_2;
   public final float SQRT2;
   public static float abs(float x);
   public static float acos(float x);
   public static float asin(float x);
   public static float atan(float x);
   public static float atan2(float x);
   public static int ceil(float x);
   public static float cos(float x);
   public static float exp(float x);
   public static int floor(float x);
   public static float log(float x);
   public static float max(float x, float y);
   public static float min(float x, float y);
   public static float random();
   public static int round(float x);
   public static float sin(float x);
   public static float sqrt(float x);
   public static float tan(float x);
}
class MimeType {
   public const String description;
   public JavaObject enabledPlugin;
   public const String suffixes;
   public const String type;
}
class Navigator {
   public String appCodename;
   public String appName;
   public String appVersion;
   public MimeType[] mimeTypes;
   public Plugin[] plugins;
   public String userAgent;
   public boolean javaEnabled();
   public boolean taintEnabled();
}
class Number {
   public Number(value);
   public final float MAX_VALUE;
   public final float MIN_VALUE;
   public final float NaN;
   public final float NEGATIVE_INFINITY;
   public final float POSITIVE_INFINITY;
   public String toString() const;
   public float valueOf() const;
   public String prototype;
}
class Object {
   public Object();
   public Object(value);
   public Function constructor;
   public void assign(value);
   public String eval(String code);
   public String toString() const;
   public Object valueOf() const;
}
class Option {
   public Option(String text, Object value=null, boolean defaultSelected=false, boolean selected=false);
   public const boolean defaultSelected;
   public const Form form;
   public const int index;
   public boolean selected;
   public String text;
   public String value;
}
class Packages {
   public JavaPackage java;
   public JavaPackage netscape;
   public JavaPackage sun;
}
class Password /*extends Element*/ {
   public const String defaultValue;
   public const Form form;
   public const String name;
   public const String type;
   public void blur();
   public void focus();
   public void select();
   public void onblur();
   public void onfocus();
   public void onchange();
}
class Plugin {
   public const String descriptoin;
   public const String filename;
   public const int length;
   public const String name;
}
class Radio /*extends Element*/ {
   public boolean checked;
   public const boolean defaultChecked;
   public const Form form;
   public const String name;
   public const String type;
   public String value;
   public void blur();
   public void focus();
   public void click();
   public void onblur();
   public void onfocus();
   public void onchange();
}
class Reset /*extends Element*/ {
   public const Form form;
   public const String name;
   public const String type;
   public String value;
   public void blur();
   public void focus();
   public void click();
   public void onblur();
   public void onfocus();
   public void onchange();
}
class Select {
   public const Form form;
   public int length;
   public const String name;
   public Option[] options;
   public int selectedIndex;
   public const String type;
   public void blur();
   public void focus();
   public void click();
   public void onblur();
   public void onfocus();
   public void onchange();
}
class String {
   public String(value);
   public int length;
   public String prototype;
   public String anchor(String name) const;
   public String big() const;
   public String blink() const;
   public String bold() const;
   public char charAt(int n) const;
   public String fixed() const;
   public String fontcolor(String color) const;
   public String fontsize(int size) const;
   public int indexOf(String substring, int start=0) const;
   public String italics() const;
   public String lastIndexof(String substring, int start=length) const;
   public String link(String href) const;
   public String small() const;
   public String[] split(String delimeter="") const;
   public String strike() const;
   public String sub() const;
   public String substring(int from, int to=length) const;
   public String sup() const;
   public String toLowerCase() const;
   public String toUpperCase() const;
}
class Submit /*extends Element*/ {
   public const Form form;
   public const String name;
   public const String type;
   public const String value;
   public void blur();
   public void focus();
   public void click();
   public void onblur();
   public void onfocus();
   public void onchange();
}
class Text /*extends Element*/ {
   public const String defaultValue;
   public const Form form;
   public const String name;
   public const String type;
   public String value;
   public void blur();
   public void focus();
   public void select();
   public void onblur();
   public void onfocus();
   public void onchange();
}
class Textarea /*extends Element*/ {
   public const String defaultValue;
   public const Form form;
   public const String name;
   public const String type;
   public const String value;
   public void blur();
   public void focus();
   public void select();
   public void onblur();
   public void onfocus();
   public void onchange();
}
class URL {
   public String hash;
   public String host;
   public String hostname;
   public String href;
   public String pathname;
   public String port;
   public String protocol;
   public String search;
}
class Window {
   public const boolean closed;
   public String defaultStatus;
   public Document document;
   public Frame[] frames;
   public History history;
   public int length;
   public Location location;
   public String name;
   public Navigator navigator;
   public void navigate();
   public Window opener;
   public Window parent;
   public Window self;
   public String status;
   public Window top;
   public Window window;
   public static void alert(String message);
   public void blur();
   public static void clearTimeout(timeoutId);
   public void close();
   public void confirm(String question);
   public void focus();
   public void navigate(String url);
   public void open(String url, String name, String features="", boolean replace=false);
   public void prompt(String message, String answer="");
   public void scroll();
   public void setTimeout();
   public void onblur();
   public void onerror();
   public void onfocus();
   public void onload();
   public void onunload();
}
