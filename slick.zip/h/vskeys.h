/*
    We are a little inconstant here with our naming 
    convertions in this file.  We use 
    KEY, KEYTAB, and K everywhere when we should probably use
    EVENT, EVENTTAB, and E.
    
    The event table has entries for all keys, mouse events, and some
    other Visual SlickEdit events (ON_??? events).
*/
#ifndef VSKEYS_H
#define VSKEYS_H

#define VS_NUMKEYS (VS_KEYTAB_MAXASCII+VS_KEYTAB_MAXEXT)

#define VS_NULL_KEY  0xffff

#define VS_NSPECIAL_KEYS   19 /* Number of special keys. */
#define VS_SK_ENTER        0
#define VS_SK_TAB          1
#define VS_SK_ESC          2
#define VS_SK_BACKSPACE    3   /* BA_SK_KSPACE+1 is the max for A-C-Special_Key */
#define VS_SK_PAD_STAR     4
#define VS_SK_PAD_PLUS     5
#define VS_SK_PAD_MINUS    6
#define VS_SK_HOME         7
#define VS_SK_END          8
#define VS_SK_LEFT         9
#define VS_SK_RIGHT        10
#define VS_SK_UP           11
#define VS_SK_DOWN         12
#define VS_SK_PAD_5        13
#define VS_SK_PGUP         14
#define VS_SK_PGDN         15
#define VS_SK_DEL          16
#define VS_SK_INS          17
#define VS_SK_PAD_SLASH    18

#define VS_K_S_SPACE       0x10000
#define VS_K_CTRL          VS_K_C_CTRL
#define VS_K_SHIFT         VS_K_A_ALT
#define VS_K_C_CTRL        (VS_K_S_SPACE+1)
#define VS_K_A_ALT         (VS_K_S_SPACE+2)
#define VS_K_C_DOT         (VS_K_S_SPACE+3)
#define VS_K_C_COMMA       (VS_K_S_SPACE+4)
#define VS_K_C_EQUAL       (VS_K_S_SPACE+5)
#define VS_K_C_SLASH       (VS_K_S_SPACE+6)
#define VS_K_C_S_COMMA     (VS_K_S_SPACE+7)
#define VS_K_C_S_DOT       (VS_K_S_SPACE+8)
#define VS_K_C_S_SPACE     (VS_K_S_SPACE+9)
#define VS_K_CONTEXT       (VS_K_S_SPACE+10)
#define VS_K_C_S_BACKSLASH (VS_K_S_SPACE+11)
#define VS_K_C_BREAK       (VS_K_S_SPACE+12)
//#define VS_K_C_BREAK       (VS_K_S_SPACE+13)
//#define VS_K_C_BREAK       (VS_K_S_SPACE+14)
//#define VS_K_C_BREAK       (VS_K_S_SPACE+15)
//#define VS_K_C_BREAK       (VS_K_S_SPACE+16)
#define VS_KEYTAB_MAXASCII 129
#define VS_KEYTAB_MAXEXT      (VS_K_ON_LAST-VS_K_S_SPACE+1)
/*
    VS_OFFSET_ALT_KEYS+ 0..127  (ASCII alt keys like Alt+'A' and Alt+'=')
*/
#define VS_OFFSET_ALT_KEYS (VS_K_S_SPACE+17)

/*
    VS_OFFSET_SPECIAL_KEYS+ 0..VS_NSPECIAL_KEYS-1
    
    Add VS_SK_??? to VS_OFFSET_SPECIAL_KEYS to get special key.
*/
#define VS_OFFSET_SPECIAL_KEYS   (VS_OFFSET_ALT_KEYS+128)

/*
    VS_OFFSET_A_SPECIAL_KEYS+ 0..VS_NSPECIAL_KEYS-1
    
    Add VS_SK_??? to VS_OFFSET_A_SPECIAL_KEYS to get Alt+special key.
*/
#define VS_OFFSET_A_SPECIAL_KEYS (VS_OFFSET_SPECIAL_KEYS+VS_NSPECIAL_KEYS)

/*
    VS_OFFSET_C_SPECIAL_KEYS+ 0..VS_NSPECIAL_KEYS-1
    
    Add VS_SK_??? to VS_OFFSET_C_SPECIAL_KEYS to get Ctrl+special key.
*/
#define VS_OFFSET_C_SPECIAL_KEYS (VS_OFFSET_A_SPECIAL_KEYS+VS_NSPECIAL_KEYS)
/*
    VS_OFFSET_S_SPECIAL_KEYS+ 0..VS_NSPECIAL_KEYS-1
    
    Add VS_SK_??? to VS_OFFSET_S_SPECIAL_KEYS to get Shift+special key.
*/
#define VS_OFFSET_S_SPECIAL_KEYS (VS_OFFSET_C_SPECIAL_KEYS+VS_NSPECIAL_KEYS)
/*
    VS_OFFSET_A_C_SPECIAL_KEYS+ 0..VS_SK_BACKSPACE
    
    Add VS_SK_??? to VS_OFFSET_A_C_SPECIAL_KEYS to get Alt+Ctrl+special key.
*/
#define VS_OFFSET_A_C_SPECIAL_KEYS (VS_OFFSET_S_SPECIAL_KEYS+VS_NSPECIAL_KEYS)


#define VS_NFKEYS 12      /*  Number of functions at each function key offset. */
/*
    VS_OFFSET_FKEYS+0..VS_NFKEYS-1 
    
    VS_OFFSET_FKEYS+0 is F1, VS_OFFSET_FKEYS+1 is F2, etc.
*/
#define VS_OFFSET_FKEYS    (VS_OFFSET_A_C_SPECIAL_KEYS+VS_SK_BACKSPACE+1)
/*
    VS_OFFSET_S_FKEYS+0..VS_NFKEYS-1 
    
    VS_OFFSET_S_FKEYS+0 is Shift+F1, VS_OFFSET_S_FKEYS+1 is Shift+F2, etc.
*/
#define VS_OFFSET_S_FKEYS  (VS_OFFSET_FKEYS+VS_NFKEYS)
/*
    VS_OFFSET_A_FKEYS+0..VS_NFKEYS-1 
    
    VS_OFFSET_A_FKEYS+0 is Alt+F1, VS_OFFSET_A_FKEYS+1 is Alt+F2, etc.
*/
#define VS_OFFSET_A_FKEYS  (VS_OFFSET_S_FKEYS+VS_NFKEYS)
/*
    VS_OFFSET_C_FKEYS+0..VS_NFKEYS-1 
    
    VS_OFFSET_C_FKEYS+0 is Ctrl+F1, VS_OFFSET_C_FKEYS+1 is Ctrl+F2, etc.
*/
#define VS_OFFSET_C_FKEYS  (VS_OFFSET_A_FKEYS+VS_NFKEYS)
/*
    VS_OFFSET_C_S_FKEYS+0..VS_NFKEYS-1 
    
    VS_OFFSET_C_S_FKEYS+0 is Ctrl+Shift+F1, VS_OFFSET_C_S_FKEYS+1 is Ctrl+Shift+F2, etc.
*/
#define VS_OFFSET_C_S_FKEYS  (VS_OFFSET_C_FKEYS+VS_NFKEYS)
/*
    VS_OFFSET_C_S_AZ+0..25
    
    VS_OFFSET_C_S_AZ+0 is Ctrl+Shift+'A', VS_OFFSET_C_S_AZ+1 is Ctrl+Shift+'Z', etc.
*/
#define VS_OFFSET_C_S_AZ       (VS_OFFSET_C_S_FKEYS+VS_NFKEYS)
/*
    VS_OFFSET_C_S_09+0..9
    
    VS_OFFSET_C_S_09+0 is Ctrl+Shift+'0', VS_OFFSET_C_S_09+1 is Ctrl+Shift+'9', etc.
*/
#define VS_OFFSET_C_S_09       (VS_OFFSET_C_S_AZ+26)
/*
    VS_OFFSET_C_09+0..9
    
    VS_OFFSET_C_09+0 is Ctrl+'0', VS_OFFSET_C_09+1 is Ctrl+'9', etc.
*/
#define VS_OFFSET_C_09         (VS_OFFSET_C_S_09+10)
#define VS_K_C_2       VS_OFFSET_C_09+2
/*
    VS_OFFSET_C_S_SPECIAL_KEYS+ 0..VS_NSPECIAL_KEYS-1
    
    Add VS_SK_??? to VS_OFFSET_C_S_SPECIAL_KEYS to get Ctrl+Shift+special key.
*/
#define VS_OFFSET_C_S_SPECIAL_KEYS  (VS_OFFSET_C_09+10)

#define VS_NMEVENTS2 13
#define VS_NMEVENTS 9
#define VS_MK_LBUTTON_DOWN          0
#define VS_MK_RBUTTON_DOWN          1
#define VS_MK_MBUTTON_DOWN          2
#define VS_MK_LBUTTON_DOUBLE_CLICK  3
#define VS_MK_RBUTTON_DOUBLE_CLICK  4
#define VS_MK_MBUTTON_DOUBLE_CLICK  5
#define VS_MK_LBUTTON_TRIPLE_CLICK  6
#define VS_MK_RBUTTON_TRIPLE_CLICK  7
#define VS_MK_MBUTTON_TRIPLE_CLICK  8
#define VS_MK_LBUTTON_UP            9
#define VS_MK_RBUTTON_UP            10
#define VS_MK_MBUTTON_UP            11
#define VS_MK_MOUSE_MOVE            12
/*
    VS_OFFSET_MEVENTS+ 0..VS_NMEVENTS2-1
    
    Add VS_MK_??? to VS_OFFSET_MEVENTS to get mouse event.
*/
#define VS_OFFSET_MEVENTS (VS_OFFSET_C_S_SPECIAL_KEYS+VS_NSPECIAL_KEYS)
/*
    VS_OFFSET_S_MEVENTS+ 0..VS_NMEVENTS-1
    
    Add VS_MK_??? to VS_OFFSET_MEVENTS to get Shift+mouse event.
*/
#define VS_OFFSET_S_MEVENTS (VS_OFFSET_MEVENTS+VS_NMEVENTS2)
/*
    VS_OFFSET_A_MEVENTS+ 0..VS_NMEVENTS-1
    
    Add VS_MK_??? to VS_OFFSET_A_MEVENTS to get Alt+mouse event.
*/
#define VS_OFFSET_A_MEVENTS (VS_OFFSET_S_MEVENTS+VS_NMEVENTS)
/*
    VS_OFFSET_C_MEVENTS+ 0..VS_NMEVENTS-1
    
    Add VS_MK_??? to VS_OFFSET_C_MEVENTS to get Ctrl+mouse event.
*/
#define VS_OFFSET_C_MEVENTS (VS_OFFSET_A_MEVENTS+VS_NMEVENTS)
/*
    VS_OFFSET_C_S_MEVENTS+ 0..VS_NMEVENTS-1
    
    Add VS_MK_??? to VS_OFFSET_C_S_MEVENTS to get Ctrl+Shift+mouse event.
*/
#define VS_OFFSET_C_S_MEVENTS (VS_OFFSET_C_MEVENTS+VS_NMEVENTS)
#define vsIsMouseEvent(event) (event>=VS_OFFSET_MEVENTS && event<VS_K_ON_FIRST)
#define vsIsKeyEvent(event) (map_pad_key(event,0)<VS_OFFSET_MEVENTS || event==VS_K_ON_NUM_LOCK || event==VS_K_ON)

#define VS_K_ON_FIRST       VS_K_ON_SELECT
#define VS_K_ON_SELECT        (VS_OFFSET_C_S_MEVENTS+VS_NMEVENTS)
#define VS_K_ON_NUM_LOCK       (VS_K_ON_SELECT+1)
#define VS_K_ON_CLOSE          (VS_K_ON_SELECT+2)
#define VS_K_ON_GOT_FOCUS      (VS_K_ON_SELECT+3)
#define VS_K_ON_LOST_FOCUS     (VS_K_ON_SELECT+4)
#define VS_K_ON_CHANGE         (VS_K_ON_SELECT+5)
#define VS_K_ON_RESIZE         (VS_K_ON_SELECT+6)
#define VS_K_ON_TIMER          (VS_K_ON_SELECT+7)
#define VS_K_ON_PAINT          (VS_K_ON_SELECT+8)
#define VS_K_ON_VSB_LINE_UP     (VS_K_ON_SELECT+9)
#define VS_K_ON_VSB_LINE_DOWN   (VS_K_ON_SELECT+10)
#define VS_K_ON_VSB_PAGE_UP     (VS_K_ON_SELECT+11)
#define VS_K_ON_VSB_PAGE_DOWN   (VS_K_ON_SELECT+12)
#define VS_K_ON_VSB_THUMB_TRACK (VS_K_ON_SELECT+13)
#define VS_K_ON_VSB_THUMB_POS   (VS_K_ON_SELECT+14)
#define VS_K_ON_VSB_TOP         (VS_K_ON_SELECT+15)
#define VS_K_ON_VSB_BOTTOM      (VS_K_ON_SELECT+16)

#define VS_K_ON_HSB_LINE_UP     (VS_K_ON_SELECT+17)
#define VS_K_ON_HSB_LINE_DOWN   (VS_K_ON_SELECT+18)
#define VS_K_ON_HSB_PAGE_UP     (VS_K_ON_SELECT+19)
#define VS_K_ON_HSB_PAGE_DOWN   (VS_K_ON_SELECT+20)
#define VS_K_ON_HSB_THUMB_TRACK (VS_K_ON_SELECT+21)
#define VS_K_ON_HSB_THUMB_POS   (VS_K_ON_SELECT+22)
#define VS_K_ON_HSB_TOP         (VS_K_ON_SELECT+23)
#define VS_K_ON_HSB_BOTTOM      (VS_K_ON_SELECT+24)


#define VS_K_ON_SB_END_SCROLL  (VS_K_ON_SELECT+25)

#define VS_K_ON_DROP_DOWN      (VS_K_ON_SELECT+26)
#define VS_K_ON_DRAG_DROP      (VS_K_ON_SELECT+27)
#define VS_K_ON_DRAG_OVER      (VS_K_ON_SELECT+28)
#define VS_K_ON_SCROLL_LOCK    (VS_K_ON_SELECT+29)
#define VS_K_ON_DROP_FILES     (VS_K_ON_SELECT+30)
#define VS_K_ON_CREATE         (VS_K_ON_SELECT+31)
#define VS_K_ON_DESTROY        (VS_K_ON_SELECT+32)
#define VS_K_ON_CREATE2        (VS_K_ON_SELECT+33)
#define VS_K_ON_DESTROY2       (VS_K_ON_SELECT+34)
#define VS_K_ON_SPIN_UP        (VS_K_ON_SELECT+35)
#define VS_K_ON_SPIN_DOWN      (VS_K_ON_SELECT+36)
#define VS_K_ON_SCROLL         (VS_K_ON_SELECT+37)
#define VS_K_ON_CHANGE2        (VS_K_ON_SELECT+38)
#define VS_K_ON_LOAD           (VS_K_ON_SELECT+39)
#define VS_K_ON_INIT_MENU      (VS_K_ON_SELECT+40)
#define VS_K_ON (VS_K_ON_SELECT+41)
#define VS_K_ON_RESERVED2      (VS_K_ON_SELECT+42)
#define VS_K_ON_RESERVED3      (VS_K_ON_SELECT+43)
#define VS_K_ON_RESERVED4      (VS_K_ON_SELECT+44)
#define VS_K_ON_RESERVED5      (VS_K_ON_SELECT+45)
#define VS_K_ON_RESERVED6      (VS_K_ON_SELECT+46)
#define VS_K_ON_LAST           VS_K_ON_RESERVED6


#define VS_K_LBUTTON_DOWN          (VS_MK_LBUTTON_DOWN+VS_OFFSET_MEVENTS)
#define VS_K_RBUTTON_DOWN          (VS_MK_RBUTTON_DOWN+VS_OFFSET_MEVENTS)
#define VS_K_MBUTTON_DOWN          (VS_MK_MBUTTON_DOWN+VS_OFFSET_MEVENTS)
#define VS_K_LBUTTON_DOUBLE_CLICK  (VS_MK_LBUTTON_DOUBLE_CLICK+VS_OFFSET_MEVENTS)
#define VS_K_RBUTTON_DOUBLE_CLICK  (VS_MK_RBUTTON_DOUBLE_CLICK+VS_OFFSET_MEVENTS)
#define VS_K_MBUTTON_DOUBLE_CLICK  (VS_MK_MBUTTON_DOUBLE_CLICK+VS_OFFSET_MEVENTS)
#define VS_K_LBUTTON_TRIPLE_CLICK  (VS_MK_LBUTTON_TRIPLE_CLICK+VS_OFFSET_MEVENTS)
#define VS_K_RBUTTON_TRIPLE_CLICK  (VS_MK_RBUTTON_TRIPLE_CLICK+VS_OFFSET_MEVENTS)
#define VS_K_MBUTTON_TRIPLE_CLICK  (VS_MK_MBUTTON_TRIPLE_CLICK+VS_OFFSET_MEVENTS)
#define VS_K_LBUTTON_UP            (VS_MK_LBUTTON_UP+VS_OFFSET_MEVENTS)
#define VS_K_RBUTTON_UP            (VS_MK_RBUTTON_UP+VS_OFFSET_MEVENTS)
#define VS_K_MBUTTON_UP            (VS_MK_MBUTTON_UP+VS_OFFSET_MEVENTS)
#define VS_K_MOUSE_MOVE            (VS_MK_MOUSE_MOVE+VS_OFFSET_MEVENTS)

#endif
