/*

   Example
      vsDllExport("_command void proc1(int i,VSPSZ i,VSHVAR x)",0,0);

   Syntax:

   [_command] [return-type] func-name([type [var-name] [,type [var-name]...])

   type
      VSPVOID        Pointer to something  Slick-C can't call this.
      VSPSZ          NULL terminated string
      VSPLSTR        See typedef below.
      int
      long
      VSHVAR           Handle to interpreter variable
      VSHREFVAR        Call by reference handle to interpreter variable.
                       This type can be used as input to functions which
                       accept VSHVAR parameters.

   return-type may be one of the following
      VSPSZ
      VSPLSTR
      int
      long
      void

   Performance considerations:

      For best performance, use the VSHVAR or VSREFVAR param-type when
      operating on long strings instead of VSPSZ or VSPLSTR.  Then
      use the "vsHvarGetLstr" function to return a pointer to the
      interpreter variable. WARNING:  Pointers to interpreter variables
      returned by the vsHvarGetLstr function are NOT VALID after any
      interpreter variable is set.  Be sure to reset any pointer after
      setting other interpreter variables or calling other macros.
      You may modify the contents of the VSPLSTR pointer returned by
      vsHvarGetLstr so long as you do not make the string any longer.

      We suspect that using the int and long parameter types are no
      slower than using the VSHVAR type and converting the parameter yourself.
*/
#ifndef VSAPI_H
#define VSAPI_H

#undef EXTERN_C
#undef EXTERN_C_BEGIN
#undef EXTERN_C_END
#undef VSDEFAULT
#undef VSREF

#if __cplusplus
   #define EXTERN_C extern "C"
   #define EXTERN_C_BEGIN extern "C" {
   #define EXTERN_C_END }
   #define VSDEFAULT(a) =a
   #define VSREF(a) &a
#else   
   #define EXTERN_C extern
   #define EXTERN_C_BEGIN
   #define EXTERN_C_END
   #define VSDEFAULT(a)
   #define VSREF(a) *a
#endif   

#if  defined(OS2386APP)
   #define INCL_DEV
   #define INCL_WIN
   #define INCL_GPI
   #define INCL_GPILCIDS
   #define INCL_WINPOINTERS
   #define INCL_GPILOGCOLORTABLE
   #define INCL_WINSYS
   #define INCL_DOSPROCESS
   #define INCL_ERRORS
   #define INCL_DOSMODULEMGR
   #include <os2.h>

   #define VSAPI _System
   #define VSUNIX  0
   #define VSOS2   1
   #define VSNT    0
#elif defined(WIN32)
   #ifndef _WINDOWS_
      #ifndef STRICT
         #define STRICT
      #endif
      #include <windows.h>
      #include <windowsx.h>
   #endif
   #define VSAPI  __stdcall
   #define VSUNIX  0
   #define VSOS2   0
   #define VSNT    1
#else
   #include <X11/Intrinsic.h>
   #define VSAPI
   #define VSUNIX  1
   #define VSOS2   0
   #define VSNT    0
   #if defined(S390APP)
      #undef EXTERN_C
      #undef EXTERN_C_BEGIN
      #undef EXTERN_C_END
      #define EXTERN_C
      #define EXTERN_C_BEGIN
      #define EXTERN_C_END
   #endif
#endif

#include <rc.h>

#define VSMAXLSTR  1024
  typedef struct {
     int len;
     unsigned char str[VSMAXLSTR];
  } VSLSTR, *VSPLSTR;

#define VSNOXLATDLLNAMES

#include <vs.h>
#include <vsheap.h>
#include <vstagsdb.h>
#include <tagstree.h>
#include <tagsrefs.h>

#endif
