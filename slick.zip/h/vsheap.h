#ifndef VSHEAP_H
#define VSHEAP_H

EXTERN_C_BEGIN

int VSAPI vsPosInit(int LineOffset);
void VSAPI vsPosGetLinePointers(unsigned char **pp,unsigned char **ppBeginLine,
                            unsigned char **ppEndLine,int *pRelLine);
int VSAPI vsPosIsEOL(int offset,int ReturnWhenBetweenNLChars VSDEFAULT(0));
void VSAPI vsPosSetPointer(unsigned char *p);
int VSAPI vsPosRelPGoTo(unsigned char *p);
int VSAPI vsPosNextBOL(int Noflines);
int VSAPI vsPosSave(void *pSavePos);
int VSAPI vsPosRestore(void *pSavePos);
int VSAPI vsPosIsEOR(int offset);
void VSAPI vsPosGetPointers(unsigned char **pp,unsigned char **ppEndLine,
                            unsigned char **ppEndBuf VSDEFAULT(0));
int VSAPI vsPosSetCurLine();
int VSAPI vsPosQCol();
int VSAPI vsPosQCol2(int addOffset);
/*******************BELOW NOT EXPOSED TO DLL INTERFACE YET***********************/
int VSAPI vsPosHasColor();
void VSAPI vsPosGetColorPointers(unsigned char **pp,unsigned char **ppEndLine,
                            unsigned char **ppEndBuf);
void VSAPI vsPosGetColorPointersRev(unsigned char **pp,unsigned char **ppBegin,
                           unsigned char **ppBeginBuf);
void VSAPI vsPosGetPointersRev(unsigned char **pp,unsigned char **ppBegin,
                           unsigned char **ppBeginBuf VSDEFAULT(0));

//int VSAPI vsPosRelPGoTo(unsigned char *p);
//int VSAPI vsPosRelPGoToRev(unsigned char *p);

int VSAPI vsPosRelGetChar(int offset);
int VSAPI vsPosRelGetColor(int offset);
int VSAPI vsPosGetChar();
int VSAPI vsPosRelGetCharRev(int offset);
int VSAPI vsPosRelGetColorRev(int offset);
int VSAPI vsPosGetCharRev();
int VSAPI vsPosQLineOffset();
int VSAPI vsPosOnLine0();
void VSAPI vsPosQPoint(long *pLinePoint,long *pDownCount,int *pLineOffset);
int VSAPI vsPosGoToOffset(long offset);
int VSAPI vsPosQLineLength(int IncludeNLChars);
long VSAPI vsPosQOffset();
int VSAPI vsPosQLine();
void VSAPI vsPosQRelLine(int *pNoflines,int *pStartRelLine);
int VSAPI vsPosRelGoTo(int offset);
int VSAPI vsPosRelPGoToRev(unsigned char *p);
int VSAPI vsPosRelGoToRev(int offset);
int VSAPI vsPosIsBOL(int offset);
int VSAPI vsPosIsAnyChar(int offset,int MultiLine);
int VSAPI vsPosFindBOL(int FindFirst);
int VSAPI vsPosFindEOL(int FindFirst);
int VSAPI vsPosPrevBOL(int Noflines);
int VSAPI vsPosFindBOLRev(int FindFirst);
int VSAPI vsPosFindEOLRev(int FindFirst);
EXTERN_C_END


#endif
